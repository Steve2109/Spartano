# Despliegue con Apache

**Autor:** T&M Technology Ec  
**Contacto:** soporte@tymtechnology.shop

Guía para desplegar Logo AI Creator usando Apache como reverse proxy.

## Arquitectura

```
Internet → HTTPS → Apache → HTTP → Node.js:32299
```

## Cuándo usar esta opción

- ✅ Ya tienes Apache configurado en el servidor
- ✅ No quieres usar Nginx Proxy Manager
- ✅ Necesitas integrar con otros sitios Apache existentes

## Despliegue Paso a Paso

### 1. Preparar el Servidor

```bash
# Actualizar sistema
sudo apt update && sudo apt upgrade -y

# Instalar Node.js 18+ si no está instalado
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt install -y nodejs

# Verificar instalación
node --version  # Debe ser v18+
npm --version

# Instalar PM2 globalmente
sudo npm install -g pm2
```

### 2. Configurar la Aplicación

```bash
# Crear directorio
sudo mkdir -p /var/www/logoai
sudo chown -R $USER:$USER /var/www/logoai

# Copiar archivos del proyecto (o clonar si usas git)
cd /var/www/logoai

# Copiar todos los archivos del proyecto aquí
# backend/, frontend/, package.json, etc.

# Crear archivo .env
sudo tee .env << 'EOF'
NODE_ENV=production
PORT=32299
HOST=0.0.0.0
CORS_ORIGIN=https://logoai.tymtechnology.shop
RATE_LIMIT_WINDOW_MS=900000
RATE_LIMIT_MAX_REQUESTS=100
LOG_LEVEL=info
TRUST_PROXY=1
EOF

# Instalar dependencias y construir
npm run install:all
npm run build
```

### 3. Configurar Apache

```bash
# Habilitar módulos necesarios
sudo a2enmod proxy
sudo a2enmod proxy_http
sudo a2enmod rewrite
sudo a2enmod headers

# Crear archivo de configuración del sitio
sudo tee /etc/apache2/sites-available/logoai.conf << 'EOF'
<VirtualHost *:80>
    ServerName logoai.tymtechnology.shop
    ServerAlias www.logoai.tymtechnology.shop
    
    # Logging
    ErrorLog ${APACHE_LOG_DIR}/logoai-error.log
    CustomLog ${APACHE_LOG_DIR}/logoai-access.log combined
    
    # Proxy configuration
    ProxyPreserveHost On
    ProxyPass / http://localhost:32299/
    ProxyPassReverse / http://localhost:32299/
    
    # WebSocket support (para features futuras)
    RewriteEngine on
    RewriteCond %{HTTP:Upgrade} websocket [NC]
    RewriteCond %{HTTP:Connection} upgrade [NC]
    RewriteRule .* "ws://localhost:32299/$1" [P,L]
    
    # Headers de seguridad
    RequestHeader set X-Real-IP %{REMOTE_ADDR}s
    RequestHeader set X-Forwarded-For %{PROXY_ADD_X_FORWARDED_FOR}s
    RequestHeader set X-Forwarded-Proto %{REQUEST_SCHEME}s
    
    # Timeouts
    ProxyTimeout 300
    ProxyBadHeader Ignore
</VirtualHost>
EOF

# Deshabilitar sitio default si es necesario
sudo a2dissite 000-default

# Habilitar sitio logoai
sudo a2ensite logoai

# Verificar configuración de Apache
sudo apache2ctl configtest

# Recargar Apache
sudo systemctl reload apache2
```

### 4. Configurar SSL con Certbot (Let's Encrypt)

```bash
# Instalar Certbot
sudo apt install certbot python3-certbot-apache -y

# Obtener certificado
sudo certbot --apache -d logoai.tymtechnology.shop

# Configurar auto-renewal
sudo certbot renew --dry-run
```

El proceso de Certbot modificará automáticamente tu archivo de configuración para incluir SSL.

### 5. Iniciar la Aplicación con PM2

```bash
# Ir al proyecto
cd /var/www/logoai

# Limpiar procesos anteriores de PM2
pm2 delete all 2>/dev/null || true

# Iniciar backend
pm2 start backend/dist/server.js --name "logoai-backend"

# Guardar configuración PM2
pm2 save

# Configurar PM2 para iniciar con el sistema
pm2 startup systemd
sudo env PATH=$PATH:/usr/bin pm2 startup systemd -u $USER --hp $HOME
```

### 6. Verificación

```bash
# Verificar que Apache está escuchando
sudo netstat -tlnp | grep :80
sudo netstat -tlnp | grep :443

# Verificar que Node.js está escuchando
sudo netstat -tlnp | grep :32299

# Probar localmente
curl http://localhost:32299/health

# Probar vía Apache
curl -H "Host: logoai.tymtechnology.shop" http://localhost/

# Probar HTTPS externamente
curl -v https://logoai.tymtechnology.shop/health
```

## Configuración Apache Completa (con SSL)

Después de Certbot, tu archivo debe lucir así:

```apache
<IfModule mod_ssl.c>
<VirtualHost *:443>
    ServerName logoai.tymtechnology.shop
    
    # SSL Configuration
    SSLEngine on
    SSLCertificateFile /etc/letsencrypt/live/logoai.tymtechnology.shop/fullchain.pem
    SSLCertificateKeyFile /etc/letsencrypt/live/logoai.tymtechnology.shop/privkey.pem
    Include /etc/letsencrypt/options-ssl-apache.conf
    
    # Proxy to Node.js
    ProxyPreserveHost On
    ProxyPass / http://localhost:32299/
    ProxyPassReverse / http://localhost:32299/
    
    # Headers
    RequestHeader set X-Forwarded-Proto "https"
    
    # Logging
    ErrorLog ${APACHE_LOG_DIR}/logoai-error.log
    CustomLog ${APACHE_LOG_DIR}/logoai-access.log combined
</VirtualHost>
</IfModule>

<VirtualHost *:80>
    ServerName logoai.tymtechnology.shop
    Redirect permanent / https://logoai.tymtechnology.shop/
</VirtualHost>
```

## Solución de Problemas

### Apache no inicia

```bash
# Verificar sintaxis
sudo apache2ctl configtest

# Ver logs
sudo tail -f /var/log/apache2/error.log

# Verificar puertos en uso
sudo lsof -i :80
sudo lsof -i :443
```

### Error 502/503

```bash
# Verificar que Node.js está corriendo
pm2 status
pm2 logs logoai-backend

# Verificar puerto
curl http://localhost:32299/health

# Reiniciar si es necesario
pm2 restart logoai-backend
sudo systemctl reload apache2
```

### Errores de Permisos

```bash
# Verificar propietario de archivos
sudo chown -R www-data:www-data /var/www/logoai/uploads
sudo chmod -R 755 /var/www/logoai/uploads

# Para logs de PM2
mkdir -p ~/.pm2/logs
```

### Certbot falla

```bash
# Verificar que el dominio apunta al servidor
dig logoai.tymtechnology.shop

# Verificar puerto 80 abierto
sudo ufw status
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp

# Forzar renovación
sudo certbot --apache -d logoai.tymtechnology.shop --force-renewal
```

## Optimización de Apache

### MPM Event (recomendado para proxy)

```bash
# Deshabilitar prefork
sudo a2dismod mpm_prefork

# Habilitar event
sudo a2enmod mpm_event

# Recargar
sudo systemctl restart apache2
```

### Configuración de Performance

```bash
# Editar /etc/apache2/apache2.conf
sudo tee -a /etc/apache2/conf-available/logoai-performance.conf << 'EOF'
# KeepAlive
KeepAlive On
MaxKeepAliveRequests 100
KeepAliveTimeout 5

# Timeouts
Timeout 300
ProxyTimeout 300

# Compression (opcional)
LoadModule deflate_module modules/mod_deflate.so
<IfModule mod_deflate.c>
    AddOutputFilterByType DEFLATE text/html text/plain text/xml text/css application/javascript application/json
</IfModule>
EOF

sudo a2enconf logoai-performance
sudo systemctl reload apache2
```

## Mantenimiento

```bash
# Ver logs de la aplicación
pm2 logs logoai-backend

# Logs de Apache
sudo tail -f /var/log/apache2/logoai-error.log
sudo tail -f /var/log/apache2/logoai-access.log

# Actualizar aplicación
cd /var/www/logoai
git pull  # o copiar nuevos archivos
npm run install:all
npm run build
pm2 restart logoai-backend

# Renovar certificado SSL
sudo certbot renew

# Verificar configuración
sudo apache2ctl configtest
```

## Firewall UFW

```bash
# Configurar UFW
sudo ufw default deny incoming
sudo ufw default allow outgoing

# Permitir SSH (importante!)
sudo ufw allow ssh

# Permitir HTTP/HTTPS
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp

# No exponer 32299 externamente
# sudo ufw allow 32299/tcp  # NO hacer esto

# Habilitar firewall
sudo ufw enable
sudo ufw status verbose
```

---

**Autor:** T&M Technology Ec  
**Soporte:** soporte@tymtechnology.shop
