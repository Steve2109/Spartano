# Despliegue con Docker

**Autor:** T&M Technology Ec  
**Contacto:** soporte@tymtechnology.shop

Guía para desplegar Logo AI Creator usando Docker y Docker Compose.

## Opciones de Despliegue Docker

1. **Docker Full Stack**: Todo en contenedores (recomendado)
2. **Docker + Nginx Proxy Manager**: Backend en Docker, NPM externo
3. **Docker para desarrollo**: Hot reload y volumes

## Opción 1: Docker Full Stack (Recomendado)

### Requisitos

- Docker Engine 20.10+
- Docker Compose 2.0+
- 2GB RAM mínimo
- 10GB espacio en disco

### Despliegue Rápido

```bash
# 1. Clonar o copiar el proyecto
cd /var/www/logoai

# 2. Crear archivo .env
sudo tee .env << 'EOF'
NODE_ENV=production
PORT=32299
HOST=0.0.0.0
CORS_ORIGIN=https://logoai.tymtechnology.shop
RATE_LIMIT_WINDOW_MS=900000
RATE_LIMIT_MAX_REQUESTS=100
LOG_LEVEL=info
MAX_FILE_SIZE=5242880
UPLOAD_PATH=./uploads
TRUST_PROXY=1
EOF

# 3. Construir y ejecutar
docker-compose up -d --build

# 4. Verificar estado
docker-compose ps
docker-compose logs -f

# 5. Verificar health check
curl http://localhost:32299/health
```

### Configuración Docker Compose

El archivo `docker-compose.yml` incluye:

- **Build multi-stage**: Frontend → Backend → Production
- **PM2**: Process manager dentro del contenedor
- **Health checks**: Verificación automática de salud
- **Logs**: Persistencia de logs
- **Uploads**: Volumen para archivos subidos
- **Resource limits**: Límites de CPU y memoria

### Comandos Docker Útiles

```bash
# Ver logs
docker-compose logs -f logoai

# Escalar (si tienes múltiples instancias)
docker-compose up -d --scale logoai=2

# Reiniciar
docker-compose restart

# Actualizar (después de cambios en código)
docker-compose down
docker-compose up -d --build

# Backup de uploads
docker cp logoai-creator:/app/uploads ./backup-$(date +%Y%m%d)

# Acceder al contenedor
docker-compose exec logoai sh

# Ver estadísticas
docker stats logoai-creator
```

## Opción 2: Docker + Nginx Proxy Manager

Si ya tienes NPM configurado en otra máquina:

### docker-compose.yml (modificado)

```yaml
version: '3.8'

services:
  logoai:
    build:
      context: .
      dockerfile: Dockerfile
    container_name: logoai-creator
    restart: unless-stopped
    
    # Solo expone internamente
    expose:
      - "32299"
    
    # NO expone puerto externo
    # ports:
    #   - "32299:32299"
    
    networks:
      - logoai-network
    
    environment:
      - NODE_ENV=production
      - PORT=32299
      - HOST=0.0.0.0
      - CORS_ORIGIN=https://logoai.tymtechnology.shop
    
    volumes:
      - ./uploads:/app/uploads
      - ./logs:/app/logs
    
    # IP estática para NPM
    networks:
      logoai-network:
        ipv4_address: 172.20.0.10

networks:
  logoai-network:
    driver: bridge
    ipam:
      config:
        - subnet: 172.20.0.0/16
```

### Configurar NPM

En tu Nginx Proxy Manager:

| Campo | Valor |
|-------|-------|
| Domain Names | logoai.tymtechnology.shop |
| Scheme | http |
| Forward Hostname/IP | **172.20.0.10** |
| Forward Port | 32299 |

> ⚠️ **Nota**: Usar la IP interna del contenedor, no localhost.

## Opción 3: Docker para Desarrollo

```yaml
# docker-compose.dev.yml
version: '3.8'

services:
  backend:
    build:
      context: ./backend
      dockerfile: Dockerfile.dev
    ports:
      - "32299:32299"
    volumes:
      - ./backend/src:/app/src
      - ./backend/uploads:/app/uploads
    environment:
      - NODE_ENV=development
      - PORT=32299
    command: npm run dev

  frontend:
    build:
      context: ./frontend
      dockerfile: Dockerfile.dev
    ports:
      - "3000:3000"
    volumes:
      - ./frontend/src:/app/src
      - ./frontend/public:/app/public
    environment:
      - VITE_API_URL=http://localhost:32299
    command: npm run dev
```

Ejecutar:

```bash
docker-compose -f docker-compose.dev.yml up -d
```

## Docker Swarm (Producción Escalable)

Para alta disponibilidad:

```bash
# Inicializar swarm
sudo docker swarm init --advertise-addr <IP>

# Crear stack
docker stack deploy -c docker-compose.stack.yml logoai

# Ver servicios
docker stack ps logoai
docker service logs logoai_backend
```

### docker-compose.stack.yml

```yaml
version: '3.8'

services:
  logoai:
    image: logoai:latest
    deploy:
      replicas: 2
      update_config:
        parallelism: 1
        delay: 10s
      restart_policy:
        condition: on-failure
      resources:
        limits:
          cpus: '0.5'
          memory: 512M
    networks:
      - web
    environment:
      - NODE_ENV=production
      - PORT=32299
      - HOST=0.0.0.0
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:32299/health"]
      interval: 30s

networks:
  web:
    external: true
```

## Optimización de Imágenes

### Multi-stage build

El Dockerfile ya incluye multi-stage:

1. **Stage 1**: Build frontend (Node + build)
2. **Stage 2**: Build backend (Node + native deps)
3. **Stage 3**: Production (Node Alpine, solo lo necesario)

### Reducir tamaño

```bash
# Ver tamaño de imágenes
docker images logoai

# Limpiar builds intermedios
docker system prune -f

# Usar .dockerignore
echo "node_modules
*.log
.git
uploads
logs" > .dockerignore
```

## Seguridad en Docker

### Mejores prácticas implementadas

1. **Non-root user** (en PM2 ecosystem)
2. **Resource limits**: CPU y memoria limitados
3. **Read-only root filesystem**: Donde sea posible
4. **No new privileges**: Protección contra escalada
5. **Health checks**: Verificación de salud automática

### Seguridad adicional (opcional)

```yaml
# docker-compose.security.yml
services:
  logoai:
    read_only: true
    user: "1000:1000"
    security_opt:
      - no-new-privileges:true
    cap_drop:
      - ALL
    cap_add:
      - CHOWN
      - SETGID
      - SETUID
    tmpfs:
      - /tmp:noexec,nosuid,size=100m
```

## Backup y Restore

### Backup automatizado

```bash
#!/bin/bash
# backup.sh

BACKUP_DIR="/backup/logoai-$(date +%Y%m%d_%H%M%S)"
mkdir -p $BACKUP_DIR

# Backup uploads
docker cp logoai-creator:/app/uploads "$BACKUP_DIR/uploads"

# Backup logs
docker cp logoai-creator:/app/logs "$BACKUP_DIR/logs"

# Backup base de datos (si aplica)
# docker exec logoai-creator tar czf - /app/data > "$BACKUP_DIR/data.tar.gz"

# Comprimir
tar czf "$BACKUP_DIR.tar.gz" "$BACKUP_DIR"
rm -rf "$BACKUP_DIR"

echo "Backup completado: $BACKUP_DIR.tar.gz"
```

### Restore

```bash
#!/bin/bash
# restore.sh

BACKUP_FILE="$1"

# Detener contenedores
docker-compose down

# Extraer backup
tar xzf "$BACKUP_FILE"

# Copiar uploads
docker-compose up -d --no-start
docker cp "$(basename $BACKUP_FILE .tar.gz)/uploads" logoai-creator:/app/

# Iniciar
docker-compose start
```

## Monitoreo

### Con Prometheus (opcional)

```yaml
# docker-compose.monitoring.yml
services:
  prometheus:
    image: prom/prometheus
    volumes:
      - ./prometheus.yml:/etc/prometheus/prometheus.yml
    ports:
      - "9090:9090"

  grafana:
    image: grafana/grafana
    ports:
      - "3001:3000"
    volumes:
      - grafana-data:/var/lib/grafana
```

### Logs centralizados

```yaml
logging:
  driver: "fluentd"
  options:
    fluentd-address: localhost:24224
    tag: docker.logoai
```

## Solución de Problemas

### Contenedor no inicia

```bash
# Ver logs
docker-compose logs --tail=100 logoai

# Ver eventos
docker system events --since 1h

# Verificar recursos
docker system df
```

### Permisos de archivos

```bash
# Fix permisos
sudo chown -R 1000:1000 ./uploads ./logs

# O en docker-compose
user: "${UID}:${GID}"
```

### Puerto ocupado

```bash
# Ver qué usa el puerto
sudo lsof -i :32299
sudo netstat -tlnp | grep 32299

# Matar proceso o cambiar puerto
# En docker-compose.yml:
# ports:
#   - "32298:32299"
```

### Error de memoria

```bash
# Ver uso de memoria
docker stats --no-stream

# Aumentar límite en docker-compose.yml
deploy:
  resources:
    limits:
      memory: 2G
```

## Comandos de Emergencia

```bash
# Reinicio completo
docker-compose down -v
docker system prune -f
docker-compose up -d --build

# Debug shell
docker-compose run --rm logoai sh

# Exportar imagen
docker save logoai:latest | gzip > logoai-image.tar.gz

# Importar imagen
gunzip -c logoai-image.tar.gz | docker load
```

---

## Resumen de Comandos

| Comando | Descripción |
|---------|-------------|
| `docker-compose up -d` | Iniciar en background |
| `docker-compose down` | Detener y eliminar |
| `docker-compose logs -f` | Ver logs en tiempo real |
| `docker-compose ps` | Listar contenedores |
| `docker-compose exec logoai sh` | Shell en contenedor |
| `docker-compose build` | Reconstruir imágenes |
| `docker system prune` | Limpiar recursos |

---

**Autor:** T&M Technology Ec  
**Soporte:** soporte@tymtechnology.shop  
**Versión:** 1.0.0
