# Despliegue con Nginx Proxy Manager

**Autor:** T&M Technology Ec  
**Contacto:** soporte@tymtechnology.shop

Esta es la configuración **recomendada** para tu infraestructura.

## Arquitectura

```
Internet → HTTPS → Nginx Proxy Manager → HTTP → Node.js:32299
                     (NPM máquina)       →    (LogoAI máquina)
```

## Ventajas de esta arquitectura

- ✅ **Simple**: Sin intermediarios innecesarios
- ✅ **Segura**: SSL terminado en NPM
- ✅ **Escalable**: Fácil de escalar horizontalmente
- ✅ **Mantenible**: Menos componentes = menos problemas

## Configuración Paso a Paso

### 1. En el servidor LogoAI (10.0.1.40)

```bash
# 1. Ir al proyecto
cd /var/www/logoai

# 2. Crear archivo .env
sudo tee .env << 'EOF'
NODE_ENV=production
PORT=32299
HOST=0.0.0.0
CORS_ORIGIN=https://logoai.tymtechnology.shop
RATE_LIMIT_WINDOW_MS=900000
RATE_LIMIT_MAX_REQUESTS=100
LOG_LEVEL=info
TRUST_PROXY=1
EOF

# 3. Instalar dependencias
npm run install:all
npm run build

# 4. Detener Apache si está corriendo
sudo systemctl stop apache2
sudo systemctl disable apache2

# 5. Configurar PM2
pm2 delete all 2>/dev/null || true
pm2 start backend/dist/server.js --name "logoai-backend"
pm2 save
pm2 startup systemd

# 6. Verificar que está escuchando
sudo netstat -tlnp | grep :32299
# o
sudo ss -tlnp | grep :32299
```

**Debe mostrar**: `0.0.0.0:32299` o `:::32299`

### 2. En Nginx Proxy Manager

Crear un **Proxy Host** con estos valores:

#### Tab General

| Campo | Valor |
|-------|-------|
| Domain Names | `logoai.tymtechnology.shop` |
| Scheme | `http` |
| Forward Hostname/IP | `10.0.1.40` |
| Forward Port | `32299` |
| Cache Assets | ❌ (opcional) |
| Block Common Exploits | ✅ (recomendado) |
| Websockets Support | ✅ (recomendado) |

#### Tab SSL

| Campo | Valor |
|-------|-------|
| SSL Certificate | `logoai.tymtechnology.shop` |
| Force SSL | ✅ |
| HTTP/2 Support | ✅ |
| HSTS Enabled | ✅ (opcional) |
| HSTS Subdomains | ✅ (opcional) |

#### Tab Advanced (Opcional)

Agregar headers personalizados:

```nginx
# Asegurar que las IPs reales se pasen al backend
proxy_set_header X-Real-IP $remote_addr;
proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
proxy_set_header X-Forwarded-Proto $scheme;

# Timeouts
proxy_connect_timeout 60s;
proxy_send_timeout 60s;
proxy_read_timeout 60s;
```

### 3. Verificación

Desde tu máquina local:

```bash
# Verificar DNS
dig logoai.tymtechnology.shop

# Verificar HTTPS
curl -v https://logoai.tymtechnology.shop/health

# Debería retornar:
# {"status":"OK","service":"Logo AI Creator API",...}
```

## Solución de Problemas

### Error 502 Bad Gateway

```bash
# En servidor LogoAI:
sudo netstat -tlnp | grep 32299

# Si no muestra nada:
pm2 status
pm2 logs logoai-backend

# Si el puerto está en 127.0.0.1 en vez de 0.0.0.0:
# Verificar HOST=0.0.0.0 en .env y reiniciar
pm2 restart all --update-env
```

### Error CORS

```bash
# Verificar CORS_ORIGIN en .env
cat /var/www/logoai/.env | grep CORS

# Debe ser exactamente el dominio HTTPS:
# CORS_ORIGIN=https://logoai.tymtechnology.shop
```

### Error 504 Gateway Timeout

```bash
# Verificar que el backend responde:
curl http://10.0.1.40:32299/health

# Si no responde:
pm2 restart logoai-backend
pm2 logs logoai-backend
```

## Comandos Útiles

```bash
# Ver logs del backend
pm2 logs logoai-backend

# Ver logs en tiempo real
pm2 logs logoai-backend --lines 100

# Reiniciar backend
pm2 restart logoai-backend

# Ver estado PM2
pm2 status
pm2 monit

# Actualizar código y reiniciar
cd /var/www/logoai
git pull  # o copiar nuevos archivos
npm run build
pm2 restart all --update-env
```

## Firewall (si aplica)

Si tienes firewall UFW en LogoAI:

```bash
# Solo necesitas el puerto 32299 interno
# No expongas 32299 externamente, solo para NPM
sudo ufw allow from 10.0.0.0/8 to any port 32299
sudo ufw reload
```

## Notas Importantes

1. **HOST=0.0.0.0 es CRÍTICO**: Si no está configurado, el servidor solo escucha en localhost y NPM no puede conectar

2. **No uses HTTPS interno**: La conexión entre NPM y LogoAI debe ser HTTP. SSL se maneja en NPM.

3. **Websockets**: Activar si planeas usar features realtime (collaboration, etc.)

4. **Backups**: Configura backup regular de:
   - `/var/www/logoai/uploads/`
   - Diseños guardados en localStorage (frontend)

---

**Autor:** T&M Technology Ec  
**Soporte:** soporte@tymtechnology.shop
