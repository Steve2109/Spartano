/**
 * Input Sanitization Middleware
 * Author: T&M Technology Ec
 * Prevents XSS and injection attacks
 */

import { Request, Response, NextFunction } from 'express';
import sanitizeHtml from 'sanitize-html';

// HTML sanitization options
const sanitizeOptions: sanitizeHtml.IOptions = {
  allowedTags: ['b', 'i', 'em', 'strong', 'u', 'span', 'p', 'br'],
  allowedAttributes: {
    'span': ['style', 'class'],
    'p': ['style', 'class'],
    '*': ['class']
  },
  allowedStyles: {
    'span': {
      'color': [/^#[0-9a-fA-F]{3,6}$/, /^rgb\(/, /^rgba\(/],
      'font-size': [/^[0-9]+px$/, /^[0-9]+em$/, /^[0-9]+rem$/],
      'font-family': [/^[-a-zA-Z0-9\s,'"]+$/]
    },
    'p': {
      'text-align': [/^left$/, /^right$/, /^center$/, /^justify$/]
    }
  }
};

// Recursively sanitize object values
const sanitizeObject = (obj: any): any => {
  if (typeof obj === 'string') {
    return sanitizeHtml(obj, sanitizeOptions);
  }
  
  if (Array.isArray(obj)) {
    return obj.map(item => sanitizeObject(item));
  }
  
  if (obj && typeof obj === 'object') {
    const sanitized: any = {};
    for (const key in obj) {
      if (obj.hasOwnProperty(key)) {
        // Sanitize keys too to prevent prototype pollution
        const sanitizedKey = key.replace(/[<>]/g, '');
        sanitized[sanitizedKey] = sanitizeObject(obj[key]);
      }
    }
    return sanitized;
  }
  
  return obj;
};

// Middleware to sanitize request body
export const sanitizeInput = (req: Request, res: Response, next: NextFunction): void => {
  if (req.body) {
    req.body = sanitizeObject(req.body);
  }
  next();
};

// Middleware to sanitize specific fields
export const sanitizeFields = (...fields: string[]) => {
  return (req: Request, res: Response, next: NextFunction): void => {
    fields.forEach(field => {
      if (req.body[field]) {
        req.body[field] = sanitizeHtml(req.body[field], sanitizeOptions);
      }
    });
    next();
  };
};

// Validate and sanitize SVG content
export const sanitizeSvg = (svgContent: string): string => {
  // Remove potentially dangerous SVG elements and attributes
  const dangerousPatterns = [
    /<script[^>]*>.*?<\/script>/gi,
    /javascript:/gi,
    /on\w+\s*=/gi,
    /<iframe[^>]*>.*?<\/iframe>/gi,
    /<object[^>]*>.*?<\/object>/gi,
    /<embed[^>]*>.*?<\/embed>/gi
  ];

  let sanitized = svgContent;
  dangerousPatterns.forEach(pattern => {
    sanitized = sanitized.replace(pattern, '');
  });

  return sanitized;
};

// Validate base64 image data
export const validateBase64Image = (data: string): boolean => {
  const validImagePattern = /^data:image\/(png|jpeg|jpg|gif|svg\+xml|webp);base64,[A-Za-z0-9+/=]+$/;
  return validImagePattern.test(data);
};

// Sanitize filename
export const sanitizeFilename = (filename: string): string => {
  return filename
    .replace(/[<>:"/\\|?*]/g, '_')
    .replace(/\.{2,}/g, '.')
    .substring(0, 255);
};
