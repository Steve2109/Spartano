/**
 * Logo AI Creator - Backend Server
 * Author: T&M Technology Ec
 * Contact: soporte@tymtechnology.shop
 */

import express, { Request, Response, NextFunction } from 'express';
import rateLimit from 'express-rate-limit';
import helmet from 'helmet';
import cors from 'cors';
import compression from 'compression';
import hpp from 'hpp';
import morgan from 'morgan';
import dotenv from 'dotenv';
import path from 'path';

// Import routes
import designRoutes from './routes/design';
import exportRoutes from './routes/export';
import templateRoutes from './routes/templates';
import uploadRoutes from './routes/upload';
import { errorHandler } from './middleware/errorHandler';
import { sanitizeInput } from './middleware/sanitizer';

dotenv.config();

const app = express();
const PORT = parseInt(process.env.PORT || '32299', 10);
const HOST = process.env.HOST || '0.0.0.0';
const CORS_ORIGIN = process.env.CORS_ORIGIN || 'https://logoai.tymtechnology.shop';
const RATE_LIMIT_WINDOW = parseInt(process.env.RATE_LIMIT_WINDOW_MS || '900000', 10);
const RATE_LIMIT_MAX = parseInt(process.env.RATE_LIMIT_MAX_REQUESTS || '100', 10);

// Trust proxy for correct IP detection behind Nginx Proxy Manager
app.set('trust proxy', parseInt(process.env.TRUST_PROXY || '1', 10));

// Security Middleware
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'", "'unsafe-inline'", "'unsafe-eval'"],
      styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
      fontSrc: ["'self'", "https://fonts.gstatic.com"],
      imgSrc: ["'self'", "data:", "blob:", "https:"],
      connectSrc: ["'self'", CORS_ORIGIN],
      mediaSrc: ["'self'", "blob:"],
      objectSrc: ["'none'"],
      upgradeInsecureRequests: [],
    },
  },
  crossOriginEmbedderPolicy: false,
  crossOriginResourcePolicy: { policy: "cross-origin" },
}));

// CORS configuration
app.use(cors({
  origin: CORS_ORIGIN,
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With'],
}));

// Rate limiting
const limiter = rateLimit({
  windowMs: RATE_LIMIT_WINDOW,
  max: RATE_LIMIT_MAX,
  message: {
    error: 'Too many requests from this IP, please try again later.',
    retryAfter: Math.ceil(RATE_LIMIT_WINDOW / 1000)
  },
  standardHeaders: true,
  legacyHeaders: false,
  handler: (req: Request, res: Response) => {
    res.status(429).json({
      error: 'Rate limit exceeded',
      message: 'Too many requests, please try again later.',
      retryAfter: Math.ceil(RATE_LIMIT_WINDOW / 1000)
    });
  }
});

// Stricter rate limit for export operations
const exportLimiter = rateLimit({
  windowMs: 60000, // 1 minute
  max: 10, // 10 exports per minute
  message: { error: 'Export limit exceeded, please try again later.' }
});

// Apply rate limiting
app.use('/api/', limiter);
app.use('/api/export', exportLimiter);

// Body parsing with size limits
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// HTTP Parameter Pollution prevention
app.use(hpp());

// Compression
app.use(compression());

// Request logging
app.use(morgan(process.env.NODE_ENV === 'production' ? 'combined' : 'dev'));

// Input sanitization
app.use(sanitizeInput);

// Static files
app.use('/uploads', express.static(path.join(__dirname, '../uploads'), {
  maxAge: '1d',
  setHeaders: (res) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
  }
}));

// Health check endpoint (no rate limit)
app.get('/health', (req: Request, res: Response) => {
  res.status(200).json({
    status: 'OK',
    timestamp: new Date().toISOString(),
    service: 'Logo AI Creator API',
    author: 'T&M Technology Ec',
    contact: 'soporte@tymtechnology.shop',
    uptime: process.uptime(),
    memory: process.memoryUsage()
  });
});

// API Routes
app.use('/api/design', designRoutes);
app.use('/api/export', exportRoutes);
app.use('/api/templates', templateRoutes);
app.use('/api/upload', uploadRoutes);

// API Info endpoint
app.get('/api', (req: Request, res: Response) => {
  res.json({
    name: 'Logo AI Creator API',
    version: '1.0.0',
    author: 'T&M Technology Ec',
    contact: 'soporte@tymtechnology.shop',
    endpoints: {
      health: '/health',
      design: '/api/design',
      export: '/api/export',
      templates: '/api/templates',
      upload: '/api/upload'
    }
  });
});

// 404 handler
app.use((req: Request, res: Response) => {
  res.status(404).json({
    error: 'Not Found',
    message: `Route ${req.method} ${req.path} not found`
  });
});

// Global error handler
app.use(errorHandler);

// Start server
app.listen(PORT, HOST, () => {
  console.log(`
╔════════════════════════════════════════════════════════════╗
║                    Logo AI Creator                         ║
║                       Backend API                          ║
╠════════════════════════════════════════════════════════════╣
║  Author: T&M Technology Ec                               ║
║  Contact: soporte@tymtechnology.shop                     ║
╠════════════════════════════════════════════════════════════╣
║  Server running on http://${HOST}:${PORT}                     ║
║  Environment: ${process.env.NODE_ENV || 'development'}                                  ║
╚════════════════════════════════════════════════════════════╝
  `);
});

export default app;
