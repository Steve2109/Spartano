/**
 * Upload Routes - File Upload Handling
 * Author: T&M Technology Ec
 */

import { Router, Request, Response } from 'express';
import multer from 'multer';
import path from 'path';
import { v4 as uuidv4 } from 'uuid';
import { asyncHandler, createError } from '../middleware/errorHandler';
import { sanitizeFilename } from '../middleware/sanitizer';
import fs from 'fs';

const router = Router();

// Ensure uploads directory exists
const uploadDir = process.env.UPLOAD_PATH || './uploads';
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

// Configure multer storage
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    const uniqueName = `${uuidv4()}-${sanitizeFilename(file.originalname)}`;
    cb(null, uniqueName);
  }
});

// File filter
const fileFilter = (req: any, file: any, cb: any) => {
  const allowedMimes = [
    'image/jpeg',
    'image/png',
    'image/gif',
    'image/svg+xml',
    'image/webp'
  ];
  
  const allowedExts = ['.jpg', '.jpeg', '.png', '.gif', '.svg', '.webp'];
  
  const ext = path.extname(file.originalname).toLowerCase();
  
  if (allowedMimes.includes(file.mimetype) && allowedExts.includes(ext)) {
    cb(null, true);
  } else {
    cb(new Error('Only image files (JPEG, PNG, GIF, SVG, WebP) are allowed'), false);
  }
};

// Configure upload
const upload = multer({
  storage,
  fileFilter,
  limits: {
    fileSize: parseInt(process.env.MAX_FILE_SIZE || '5242880'), // 5MB default
    files: 1
  }
});

// Upload single image
router.post('/image', upload.single('image'), asyncHandler(async (req: Request, res: Response) => {
  if (!req.file) {
    throw createError('No image file provided', 400);
  }

  const fileUrl = `/uploads/${req.file.filename}`;

  res.status(201).json({
    success: true,
    data: {
      filename: req.file.filename,
      originalName: req.file.originalname,
      url: fileUrl,
      size: req.file.size,
      mimetype: req.file.mimetype
    },
    message: 'Image uploaded successfully'
  });
}));

// Upload base64 image
router.post('/base64', asyncHandler(async (req: Request, res: Response) => {
  const { image, filename } = req.body;

  if (!image) {
    throw createError('No base64 image data provided', 400);
  }

  // Validate base64 format
  const base64Pattern = /^data:image\/(png|jpeg|jpg|gif|webp);base64,/;
  if (!base64Pattern.test(image)) {
    throw createError('Invalid base64 image format', 400);
  }

  // Extract mime type and data
  const matches = image.match(/^data:image\/(png|jpeg|jpg|gif|webp);base64,(.+)$/);
  if (!matches) {
    throw createError('Invalid base64 image data', 400);
  }

  const mimeType = matches[1];
  const base64Data = matches[2];

  // Validate file size (approximate)
  const sizeInBytes = (base64Data.length * 3) / 4;
  const maxSize = parseInt(process.env.MAX_FILE_SIZE || '5242880');
  
  if (sizeInBytes > maxSize) {
    throw createError(`File size exceeds maximum allowed size (${maxSize / 1024 / 1024}MB)`, 413);
  }

  // Generate filename
  const safeFilename = sanitizeFilename(filename || `upload-${Date.now()}`);
  const uniqueName = `${uuidv4()}-${safeFilename}.${mimeType === 'jpeg' ? 'jpg' : mimeType}`;
  const filePath = path.join(uploadDir, uniqueName);

  // Save file
  const buffer = Buffer.from(base64Data, 'base64');
  fs.writeFileSync(filePath, buffer);

  res.status(201).json({
    success: true,
    data: {
      filename: uniqueName,
      url: `/uploads/${uniqueName}`,
      size: buffer.length,
      mimetype: `image/${mimeType}`
    },
    message: 'Image uploaded successfully'
  });
}));

// Get upload info
router.get('/:filename', asyncHandler(async (req: Request, res: Response) => {
  const { filename } = req.params;
  const sanitizedFilename = sanitizeFilename(filename);
  const filePath = path.join(uploadDir, sanitizedFilename);

  if (!fs.existsSync(filePath)) {
    throw createError('File not found', 404);
  }

  const stats = fs.statSync(filePath);

  res.json({
    success: true,
    data: {
      filename: sanitizedFilename,
      url: `/uploads/${sanitizedFilename}`,
      size: stats.size,
      createdAt: stats.birthtime,
      modifiedAt: stats.mtime
    }
  });
}));

// Delete upload
router.delete('/:filename', asyncHandler(async (req: Request, res: Response) => {
  const { filename } = req.params;
  const sanitizedFilename = sanitizeFilename(filename);
  const filePath = path.join(uploadDir, sanitizedFilename);

  if (!fs.existsSync(filePath)) {
    throw createError('File not found', 404);
  }

  fs.unlinkSync(filePath);

  res.json({
    success: true,
    message: 'File deleted successfully'
  });
}));

// Error handler for multer
router.use((error: any, req: Request, res: Response, next: any) => {
  if (error instanceof multer.MulterError) {
    if (error.code === 'LIMIT_FILE_SIZE') {
      return res.status(413).json({
        error: 'File too large',
        message: `Maximum file size is ${parseInt(process.env.MAX_FILE_SIZE || '5242880') / 1024 / 1024}MB`
      });
    }
    return res.status(400).json({
      error: 'Upload error',
      message: error.message
    });
  }
  
  if (error) {
    return res.status(400).json({
      error: 'Upload failed',
      message: error.message
    });
  }
  
  next();
});

export default router;
