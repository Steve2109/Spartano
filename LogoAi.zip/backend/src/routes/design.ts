/**
 * Design Routes - Logo Creation & Manipulation
 * Author: T&M Technology Ec
 */

import { Router, Request, Response } from 'express';
import { body, validationResult } from 'express-validator';
import { v4 as uuidv4 } from 'uuid';
import { asyncHandler, createError } from '../middleware/errorHandler';
import { sanitizeSvg } from '../middleware/sanitizer';

const router = Router();

// In-memory storage for designs (replace with database in production)
const designs = new Map();

// Validation rules
const designValidation = [
  body('name').trim().isLength({ min: 1, max: 100 }).escape(),
  body('width').isInt({ min: 50, max: 4096 }),
  body('height').isInt({ min: 50, max: 4096 }),
  body('elements').isArray({ max: 500 }), // Limit elements
];

// Create new design
router.post('/', designValidation, asyncHandler(async (req: Request, res: Response) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  const { name, width, height, elements = [], background } = req.body;
  
  const designId = uuidv4();
  const design = {
    id: designId,
    name: name || 'Untitled Design',
    width,
    height,
    background: background || '#ffffff',
    elements: elements.map((el: any) => ({
      ...el,
      id: el.id || uuidv4(),
    })),
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };

  designs.set(designId, design);

  res.status(201).json({
    success: true,
    data: design,
    message: 'Design created successfully'
  });
}));

// Get design by ID
router.get('/:id', asyncHandler(async (req: Request, res: Response) => {
  const { id } = req.params;
  const design = designs.get(id);
  
  if (!design) {
    throw createError('Design not found', 404);
  }

  res.json({
    success: true,
    data: design
  });
}));

// Update design
router.put('/:id', designValidation, asyncHandler(async (req: Request, res: Response) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  const { id } = req.params;
  const existingDesign = designs.get(id);
  
  if (!existingDesign) {
    throw createError('Design not found', 404);
  }

  const { name, width, height, elements, background } = req.body;

  // Sanitize SVG content in elements
  const sanitizedElements = elements?.map((el: any) => {
    if (el.type === 'svg' || el.content?.includes('<svg')) {
      return {
        ...el,
        content: el.content ? sanitizeSvg(el.content) : el.content
      };
    }
    return el;
  });

  const updatedDesign = {
    ...existingDesign,
    name: name || existingDesign.name,
    width: width || existingDesign.width,
    height: height || existingDesign.height,
    background: background || existingDesign.background,
    elements: sanitizedElements || existingDesign.elements,
    updatedAt: new Date().toISOString(),
  };

  designs.set(id, updatedDesign);

  res.json({
    success: true,
    data: updatedDesign,
    message: 'Design updated successfully'
  });
}));

// Delete design
router.delete('/:id', asyncHandler(async (req: Request, res: Response) => {
  const { id } = req.params;
  
  if (!designs.has(id)) {
    throw createError('Design not found', 404);
  }

  designs.delete(id);

  res.json({
    success: true,
    message: 'Design deleted successfully'
  });
}));

// List all designs (with pagination)
router.get('/', asyncHandler(async (req: Request, res: Response) => {
  const page = parseInt(req.query.page as string) || 1;
  const limit = Math.min(parseInt(req.query.limit as string) || 20, 100); // Max 100
  
  const allDesigns = Array.from(designs.values());
  const startIndex = (page - 1) * limit;
  const endIndex = startIndex + limit;
  
  const paginatedDesigns = allDesigns.slice(startIndex, endIndex);

  res.json({
    success: true,
    data: paginatedDesigns,
    pagination: {
      page,
      limit,
      total: allDesigns.length,
      totalPages: Math.ceil(allDesigns.length / limit)
    }
  });
}));

// Duplicate design
router.post('/:id/duplicate', asyncHandler(async (req: Request, res: Response) => {
  const { id } = req.params;
  const existingDesign = designs.get(id);
  
  if (!existingDesign) {
    throw createError('Design not found', 404);
  }

  const newDesignId = uuidv4();
  const duplicatedDesign = {
    ...existingDesign,
    id: newDesignId,
    name: `${existingDesign.name} (Copy)`,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };

  designs.set(newDesignId, duplicatedDesign);

  res.status(201).json({
    success: true,
    data: duplicatedDesign,
    message: 'Design duplicated successfully'
  });
}));

// Auto-save design
router.patch('/:id/autosave', asyncHandler(async (req: Request, res: Response) => {
  const { id } = req.params;
  const existingDesign = designs.get(id);
  
  if (!existingDesign) {
    throw createError('Design not found', 404);
  }

  const { elements, background } = req.body;

  const updatedDesign = {
    ...existingDesign,
    elements: elements || existingDesign.elements,
    background: background || existingDesign.background,
    updatedAt: new Date().toISOString(),
  };

  designs.set(id, updatedDesign);

  res.json({
    success: true,
    data: { id, updatedAt: updatedDesign.updatedAt },
    message: 'Design auto-saved'
  });
}));

export default router;
