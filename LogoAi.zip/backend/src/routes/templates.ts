/**
 * Templates Routes - Pre-made Logo Templates
 * Author: T&M Technology Ec
 */

import { Router, Request, Response } from 'express';
import { query, validationResult } from 'express-validator';
import { asyncHandler, createError } from '../middleware/errorHandler';
import { v4 as uuidv4 } from 'uuid';

const router = Router();

// Built-in logo templates
const templates = [
  {
    id: 'minimal-1',
    name: 'Minimal Circle',
    category: 'minimalist',
    thumbnail: '/templates/minimal-circle.svg',
    width: 512,
    height: 512,
    background: '#ffffff',
    elements: [
      {
        id: uuidv4(),
        type: 'circle',
        x: 256,
        y: 256,
        radius: 150,
        fill: '#6366f1',
        stroke: '#4f46e5',
        strokeWidth: 4,
        opacity: 1,
        scaleX: 1,
        scaleY: 1,
        rotation: 0,
        visible: true
      },
      {
        id: uuidv4(),
        type: 'text',
        x: 256,
        y: 256,
        text: 'Logo',
        fontFamily: 'Inter',
        fontSize: 48,
        fontWeight: 'bold',
        fill: '#ffffff',
        align: 'center',
        opacity: 1,
        scaleX: 1,
        scaleY: 1,
        rotation: 0,
        visible: true
      }
    ]
  },
  {
    id: 'tech-1',
    name: 'Tech Shield',
    category: 'technology',
    thumbnail: '/templates/tech-shield.svg',
    width: 512,
    height: 512,
    background: '#0f172a',
    elements: [
      {
        id: uuidv4(),
        type: 'path',
        x: 256,
        y: 200,
        path: 'M128 64 L384 64 L384 256 Q384 384 256 448 Q128 384 128 256 Z',
        fill: '#3b82f6',
        opacity: 1,
        scaleX: 0.5,
        scaleY: 0.5,
        rotation: 0,
        visible: true
      },
      {
        id: uuidv4(),
        type: 'text',
        x: 256,
        y: 350,
        text: 'SECURE',
        fontFamily: 'Roboto Mono',
        fontSize: 36,
        fontWeight: 'bold',
        fill: '#60a5fa',
        align: 'center',
        letterSpacing: 4,
        opacity: 1,
        scaleX: 1,
        scaleY: 1,
        rotation: 0,
        visible: true
      }
    ]
  },
  {
    id: 'elegant-1',
    name: 'Elegant Crown',
    category: 'elegant',
    thumbnail: '/templates/elegant-crown.svg',
    width: 512,
    height: 512,
    background: '#fafafa',
    elements: [
      {
        id: uuidv4(),
        type: 'path',
        x: 256,
        y: 180,
        path: 'M100 150 L150 100 L200 150 L250 80 L300 150 L350 100 L400 150 L380 250 L120 250 Z',
        fill: '#fbbf24',
        stroke: '#f59e0b',
        strokeWidth: 3,
        opacity: 1,
        scaleX: 0.6,
        scaleY: 0.6,
        rotation: 0,
        visible: true
      },
      {
        id: uuidv4(),
        type: 'text',
        x: 256,
        y: 360,
        text: 'ROYAL',
        fontFamily: 'Playfair Display',
        fontSize: 42,
        fontWeight: 'bold',
        fill: '#1f2937',
        align: 'center',
        opacity: 1,
        scaleX: 1,
        scaleY: 1,
        rotation: 0,
        visible: true
      }
    ]
  },
  {
    id: 'modern-1',
    name: 'Modern Hexagon',
    category: 'modern',
    thumbnail: '/templates/modern-hexagon.svg',
    width: 512,
    height: 512,
    background: '#f8fafc',
    elements: [
      {
        id: uuidv4(),
        type: 'path',
        x: 256,
        y: 256,
        path: 'M256 80 L432 180 L432 380 L256 480 L80 380 L80 180 Z',
        fill: '#10b981',
        opacity: 0.9,
        scaleX: 0.4,
        scaleY: 0.4,
        rotation: 0,
        visible: true
      },
      {
        id: uuidv4(),
        type: 'text',
        x: 256,
        y: 256,
        text: 'M',
        fontFamily: 'Montserrat',
        fontSize: 72,
        fontWeight: 'bold',
        fill: '#ffffff',
        align: 'center',
        opacity: 1,
        scaleX: 1,
        scaleY: 1,
        rotation: 0,
        visible: true
      }
    ]
  },
  {
    id: 'food-1',
    name: 'Food & Drink',
    category: 'food',
    thumbnail: '/templates/food-drink.svg',
    width: 512,
    height: 512,
    background: '#fef3c7',
    elements: [
      {
        id: uuidv4(),
        type: 'circle',
        x: 256,
        y: 200,
        radius: 80,
        fill: '#f97316',
        opacity: 1,
        scaleX: 1,
        scaleY: 1,
        rotation: 0,
        visible: true
      },
      {
        id: uuidv4(),
        type: 'rect',
        x: 236,
        y: 120,
        width: 40,
        height: 40,
        radius: 5,
        fill: '#7c2d12',
        opacity: 1,
        scaleX: 1,
        scaleY: 1,
        rotation: 0,
        visible: true
      },
      {
        id: uuidv4(),
        type: 'text',
        x: 256,
        y: 360,
        text: 'TASTY',
        fontFamily: 'Pacifico',
        fontSize: 48,
        fill: '#7c2d12',
        align: 'center',
        opacity: 1,
        scaleX: 1,
        scaleY: 1,
        rotation: 0,
        visible: true
      }
    ]
  },
  {
    id: 'nature-1',
    name: 'Green Leaf',
    category: 'nature',
    thumbnail: '/templates/green-leaf.svg',
    width: 512,
    height: 512,
    background: '#f0fdf4',
    elements: [
      {
        id: uuidv4(),
        type: 'path',
        x: 256,
        y: 200,
        path: 'M256 80 Q350 150 350 250 Q350 350 256 420 Q162 350 162 250 Q162 150 256 80',
        fill: '#22c55e',
        stroke: '#16a34a',
        strokeWidth: 2,
        opacity: 1,
        scaleX: 0.8,
        scaleY: 0.8,
        rotation: 0,
        visible: true
      },
      {
        id: uuidv4(),
        type: 'path',
        x: 256,
        y: 200,
        path: 'M256 100 L256 400',
        stroke: '#15803d',
        strokeWidth: 3,
        opacity: 0.6,
        scaleX: 0.8,
        scaleY: 0.8,
        rotation: 0,
        visible: true
      },
      {
        id: uuidv4(),
        type: 'text',
        x: 256,
        y: 460,
        text: 'ECO',
        fontFamily: 'Nunito',
        fontSize: 40,
        fontWeight: 'bold',
        fill: '#166534',
        align: 'center',
        opacity: 1,
        scaleX: 1,
        scaleY: 1,
        rotation: 0,
        visible: true
      }
    ]
  },
  {
    id: 'sport-1',
    name: 'Sport Dynamic',
    category: 'sports',
    thumbnail: '/templates/sport-dynamic.svg',
    width: 512,
    height: 512,
    background: '#1e1b4b',
    elements: [
      {
        id: uuidv4(),
        type: 'path',
        x: 180,
        y: 256,
        path: 'M50 0 L100 50 L50 100 L0 50 Z',
        fill: '#ec4899',
        opacity: 1,
        scaleX: 1.5,
        scaleY: 1.5,
        rotation: 45,
        visible: true
      },
      {
        id: uuidv4(),
        type: 'path',
        x: 332,
        y: 256,
        path: 'M50 0 L100 50 L50 100 L0 50 Z',
        fill: '#8b5cf6',
        opacity: 1,
        scaleX: 1.5,
        scaleY: 1.5,
        rotation: -45,
        visible: true
      },
      {
        id: uuidv4(),
        type: 'text',
        x: 256,
        y: 400,
        text: 'ENERGY',
        fontFamily: 'Bebas Neue',
        fontSize: 56,
        fill: '#ffffff',
        align: 'center',
        letterSpacing: 6,
        opacity: 1,
        scaleX: 1,
        scaleY: 1,
        rotation: 0,
        visible: true
      }
    ]
  },
  {
    id: 'creative-1',
    name: 'Creative Burst',
    category: 'creative',
    thumbnail: '/templates/creative-burst.svg',
    width: 512,
    height: 512,
    background: '#fefce8',
    elements: [
      {
        id: uuidv4(),
        type: 'circle',
        x: 256,
        y: 230,
        radius: 100,
        fill: '#facc15',
        stroke: '#eab308',
        strokeWidth: 4,
        opacity: 1,
        scaleX: 1,
        scaleY: 1,
        rotation: 0,
        visible: true
      },
      {
        id: uuidv4(),
        type: 'text',
        x: 256,
        y: 230,
        text: '!',
        fontFamily: 'Arial Black',
        fontSize: 100,
        fill: '#854d0e',
        align: 'center',
        opacity: 1,
        scaleX: 1,
        scaleY: 1,
        rotation: 0,
        visible: true
      },
      {
        id: uuidv4(),
        type: 'text',
        x: 256,
        y: 380,
        text: 'IDEA',
        fontFamily: 'Fredoka One',
        fontSize: 42,
        fill: '#a16207',
        align: 'center',
        opacity: 1,
        scaleX: 1,
        scaleY: 1,
        rotation: 0,
        visible: true
      }
    ]
  }
];

// Categories
const categories = [
  { id: 'all', name: 'All Templates', count: templates.length },
  { id: 'minimalist', name: 'Minimalist', count: templates.filter(t => t.category === 'minimalist').length },
  { id: 'technology', name: 'Technology', count: templates.filter(t => t.category === 'technology').length },
  { id: 'elegant', name: 'Elegant', count: templates.filter(t => t.category === 'elegant').length },
  { id: 'modern', name: 'Modern', count: templates.filter(t => t.category === 'modern').length },
  { id: 'food', name: 'Food & Drink', count: templates.filter(t => t.category === 'food').length },
  { id: 'nature', name: 'Nature', count: templates.filter(t => t.category === 'nature').length },
  { id: 'sports', name: 'Sports', count: templates.filter(t => t.category === 'sports').length },
  { id: 'creative', name: 'Creative', count: templates.filter(t => t.category === 'creative').length },
];

// Get all templates with filtering
router.get('/', [
  query('category').optional().trim().escape(),
  query('search').optional().trim().escape(),
  query('page').optional().isInt({ min: 1 }),
  query('limit').optional().isInt({ min: 1, max: 50 }),
], asyncHandler(async (req: Request, res: Response) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  const { category, search } = req.query;
  const page = parseInt(req.query.page as string) || 1;
  const limit = Math.min(parseInt(req.query.limit as string) || 20, 50);

  let filteredTemplates = [...templates];

  // Filter by category
  if (category && category !== 'all') {
    filteredTemplates = filteredTemplates.filter(t => t.category === category);
  }

  // Search by name
  if (search) {
    const searchLower = (search as string).toLowerCase();
    filteredTemplates = filteredTemplates.filter(t =>
      t.name.toLowerCase().includes(searchLower)
    );
  }

  // Pagination
  const startIndex = (page - 1) * limit;
  const endIndex = startIndex + limit;
  const paginatedTemplates = filteredTemplates.slice(startIndex, endIndex);

  res.json({
    success: true,
    data: paginatedTemplates,
    pagination: {
      page,
      limit,
      total: filteredTemplates.length,
      totalPages: Math.ceil(filteredTemplates.length / limit)
    }
  });
}));

// Get template categories
router.get('/categories', asyncHandler(async (req: Request, res: Response) => {
  res.json({
    success: true,
    data: categories
  });
}));

// Get single template by ID
router.get('/:id', asyncHandler(async (req: Request, res: Response) => {
  const { id } = req.params;
  const template = templates.find(t => t.id === id);

  if (!template) {
    throw createError('Template not found', 404);
  }

  res.json({
    success: true,
    data: template
  });
}));

// Use template (create new design from template)
router.post('/:id/use', asyncHandler(async (req: Request, res: Response) => {
  const { id } = req.params;
  const template = templates.find(t => t.id === id);

  if (!template) {
    throw createError('Template not found', 404);
  }

  // Return template data for creating a new design
  res.json({
    success: true,
    data: {
      ...template,
      id: uuidv4(), // New ID for the design
      name: `${template.name} Design`,
      isTemplate: true,
      originalTemplateId: template.id
    },
    message: 'Template ready to use'
  });
}));

export default router;
