/**
 * Export Routes - Image and SVG Export
 * Author: T&M Technology Ec
 */

import { Router, Request, Response } from 'express';
import { body, validationResult } from 'express-validator';
import sharp from 'sharp';
import { asyncHandler, createError } from '../middleware/errorHandler';
import { sanitizeSvg, validateBase64Image } from '../middleware/sanitizer';
import { createCanvas, loadImage } from 'canvas';

const router = Router();

// Validation rules
const exportValidation = [
  body('format').isIn(['png', 'jpg', 'jpeg', 'svg', 'pdf', 'webp']),
  body('width').optional().isInt({ min: 50, max: 4096 }),
  body('height').optional().isInt({ min: 50, max: 4096 }),
  body('quality').optional().isInt({ min: 1, max: 100 }),
  body('elements').isArray({ max: 500 }),
];

// Export design to image
router.post('/image', exportValidation, asyncHandler(async (req: Request, res: Response) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  const {
    format = 'png',
    width = 800,
    height = 600,
    quality = 90,
    background = '#ffffff',
    elements = []
  } = req.body;

  try {
    // Create canvas
    const canvas = createCanvas(width, height);
    const ctx = canvas.getContext('2d');

    // Fill background
    ctx.fillStyle = background;
    ctx.fillRect(0, 0, width, height);

    // Render elements
    for (const element of elements) {
      await renderElement(ctx, element);
    }

    // Export based on format
    let buffer: Buffer;
    let contentType: string;

    switch (format.toLowerCase()) {
      case 'jpg':
      case 'jpeg':
        buffer = canvas.toBuffer('image/jpeg', { quality: quality / 100 });
        contentType = 'image/jpeg';
        break;
      case 'webp':
        buffer = await sharp(canvas.toBuffer('image/png'))
          .webp({ quality })
          .toBuffer();
        contentType = 'image/webp';
        break;
      case 'png':
      default:
        buffer = canvas.toBuffer('image/png');
        contentType = 'image/png';
        break;
    }

    // Set response headers
    res.setHeader('Content-Type', contentType);
    res.setHeader('Content-Disposition', `attachment; filename="logo.${format}"`);
    res.setHeader('Content-Length', buffer.length);
    res.setHeader('X-Export-Format', format);
    res.setHeader('X-Content-Type-Options', 'nosniff');

    res.send(buffer);

  } catch (error) {
    console.error('Export error:', error);
    throw createError('Failed to export image', 500);
  }
}));

// Export to SVG
router.post('/svg', exportValidation, asyncHandler(async (req: Request, res: Response) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  const {
    width = 800,
    height = 600,
    background = '#ffffff',
    elements = []
  } = req.body;

  try {
    // Build SVG
    let svgContent = `<svg width="${width}" height="${height}" viewBox="0 0 ${width} ${height}" xmlns="http://www.w3.org/2000/svg">`;
    
    // Background
    svgContent += `<rect width="${width}" height="${height}" fill="${background}"/>`;

    // Elements
    for (const element of elements) {
      svgContent += renderSvgElement(element);
    }

    svgContent += '</svg>';

    // Sanitize final SVG
    const sanitizedSvg = sanitizeSvg(svgContent);

    res.setHeader('Content-Type', 'image/svg+xml');
    res.setHeader('Content-Disposition', 'attachment; filename="logo.svg"');
    res.setHeader('X-Content-Type-Options', 'nosniff');

    res.send(sanitizedSvg);

  } catch (error) {
    console.error('SVG export error:', error);
    throw createError('Failed to export SVG', 500);
  }
}));

// Export with transparent background
router.post('/transparent', exportValidation, asyncHandler(async (req: Request, res: Response) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  const {
    format = 'png',
    width = 800,
    height = 600,
    quality = 90,
    elements = []
  } = req.body;

  try {
    // Create canvas with transparent background
    const canvas = createCanvas(width, height);
    const ctx = canvas.getContext('2d');

    // Clear canvas (transparent)
    ctx.clearRect(0, 0, width, height);

    // Render elements
    for (const element of elements) {
      await renderElement(ctx, element);
    }

    // Export
    let buffer: Buffer;
    let contentType: string;

    switch (format.toLowerCase()) {
      case 'webp':
        buffer = await sharp(canvas.toBuffer('image/png'))
          .webp({ quality, lossless: true })
          .toBuffer();
        contentType = 'image/webp';
        break;
      case 'png':
      default:
        buffer = canvas.toBuffer('image/png');
        contentType = 'image/png';
        break;
    }

    res.setHeader('Content-Type', contentType);
    res.setHeader('Content-Disposition', `attachment; filename="logo-transparent.${format}"`);
    res.setHeader('Content-Length', buffer.length);
    res.setHeader('X-Content-Type-Options', 'nosniff');

    res.send(buffer);

  } catch (error) {
    console.error('Transparent export error:', error);
    throw createError('Failed to export transparent image', 500);
  }
}));

// Helper function to render element on canvas
async function renderElement(ctx: any, element: any): Promise<void> {
  if (!element.visible) return;

  ctx.save();

  // Apply transformations
  ctx.translate(element.x || 0, element.y || 0);
  ctx.rotate((element.rotation || 0) * Math.PI / 180);
  ctx.scale(element.scaleX || 1, element.scaleY || 1);
  ctx.globalAlpha = element.opacity !== undefined ? element.opacity : 1;

  switch (element.type) {
    case 'text':
      renderText(ctx, element);
      break;
    case 'rect':
      renderRect(ctx, element);
      break;
    case 'circle':
      renderCircle(ctx, element);
      break;
    case 'image':
      await renderImage(ctx, element);
      break;
    case 'path':
      renderPath(ctx, element);
      break;
  }

  ctx.restore();
}

function renderText(ctx: any, element: any): void {
  ctx.font = `${element.fontStyle || 'normal'} ${element.fontWeight || 'normal'} ${element.fontSize || 24}px ${element.fontFamily || 'Arial'}`;
  ctx.fillStyle = element.fill || '#000000';
  ctx.textAlign = element.align || 'left';
  ctx.textBaseline = element.baseline || 'alphabetic';
  
  if (element.stroke) {
    ctx.strokeStyle = element.stroke;
    ctx.lineWidth = element.strokeWidth || 1;
    ctx.strokeText(element.text || '', 0, 0);
  }
  
  ctx.fillText(element.text || '', 0, 0);
}

function renderRect(ctx: any, element: any): void {
  ctx.fillStyle = element.fill || '#000000';
  
  if (element.radius) {
    // Rounded rectangle
    const r = element.radius;
    const w = element.width || 100;
    const h = element.height || 100;
    
    ctx.beginPath();
    ctx.moveTo(r, 0);
    ctx.lineTo(w - r, 0);
    ctx.quadraticCurveTo(w, 0, w, r);
    ctx.lineTo(w, h - r);
    ctx.quadraticCurveTo(w, h, w - r, h);
    ctx.lineTo(r, h);
    ctx.quadraticCurveTo(0, h, 0, h - r);
    ctx.lineTo(0, r);
    ctx.quadraticCurveTo(0, 0, r, 0);
    ctx.closePath();
    ctx.fill();
  } else {
    ctx.fillRect(0, 0, element.width || 100, element.height || 100);
  }
  
  if (element.stroke) {
    ctx.strokeStyle = element.stroke;
    ctx.lineWidth = element.strokeWidth || 1;
    ctx.strokeRect(0, 0, element.width || 100, element.height || 100);
  }
}

function renderCircle(ctx: any, element: any): void {
  ctx.beginPath();
  ctx.arc(
    element.radius || 50,
    element.radius || 50,
    element.radius || 50,
    0,
    Math.PI * 2
  );
  ctx.fillStyle = element.fill || '#000000';
  ctx.fill();
  
  if (element.stroke) {
    ctx.strokeStyle = element.stroke;
    ctx.lineWidth = element.strokeWidth || 1;
    ctx.stroke();
  }
}

async function renderImage(ctx: any, element: any): Promise<void> {
  try {
    if (element.src && validateBase64Image(element.src)) {
      const image = await loadImage(element.src);
      ctx.drawImage(image, 0, 0, element.width || image.width, element.height || image.height);
    }
  } catch (error) {
    console.error('Error loading image:', error);
  }
}

function renderPath(ctx: any, element: any): void {
  if (element.path) {
    ctx.beginPath();
    ctx.fillStyle = element.fill || '#000000';
    // Parse and render SVG path (simplified)
    ctx.fill(new Path2D(element.path));
    
    if (element.stroke) {
      ctx.strokeStyle = element.stroke;
      ctx.lineWidth = element.strokeWidth || 1;
      ctx.stroke(new Path2D(element.path));
    }
  }
}

// Helper function to render SVG element
function renderSvgElement(element: any): string {
  const transform = `translate(${element.x || 0}, ${element.y || 0}) rotate(${element.rotation || 0}) scale(${element.scaleX || 1}, ${element.scaleY || 1})`;
  const opacity = element.opacity !== undefined ? `opacity="${element.opacity}"` : '';
  
  switch (element.type) {
    case 'text':
      return `<text transform="${transform}" ${opacity} font-family="${element.fontFamily || 'Arial'}" font-size="${element.fontSize || 24}" fill="${element.fill || '#000000'}" text-anchor="${element.align === 'center' ? 'middle' : element.align === 'right' ? 'end' : 'start'}">${escapeXml(element.text || '')}</text>`;
    
    case 'rect':
      const rx = element.radius ? `rx="${element.radius}" ry="${element.radius}"` : '';
      return `<rect transform="${transform}" ${opacity} width="${element.width || 100}" height="${element.height || 100}" fill="${element.fill || '#000000'}" ${rx}/>`;
    
    case 'circle':
      return `<circle transform="${transform}" ${opacity} r="${element.radius || 50}" fill="${element.fill || '#000000'}"/>`;
    
    case 'path':
      return `<path transform="${transform}" ${opacity} d="${element.path || ''}" fill="${element.fill || '#000000'}"/>`;
    
    default:
      return '';
  }
}

function escapeXml(unsafe: string): string {
  return unsafe.replace(/[<>&'"]/g, (c) => {
    switch (c) {
      case '<': return '&lt;';
      case '>': return '&gt;';
      case '&': return '&amp;';
      case '"': return '&quot;';
      case "'": return '&apos;';
      default: return c;
    }
  });
}

export default router;
