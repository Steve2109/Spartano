# Logo AI Creator

**Creador de Logotipos Profesionales al estilo Canva**

**Autor:** T&M Technology Ec  
**Contacto:** soporte@tymtechnology.shop  
**Versión:** 1.0.0

---

## 🎨 Características

- **Editor Visual Estilo Canva**: Interfaz intuitiva con canvas interactivo
- **Plantillas Pre-diseñadas**: 8+ plantillas profesionales categorizadas
- **Elementos de Diseño**: Textos, formas geométricas, imágenes
- **Exportación Múltiple**: PNG, JPG, SVG, PDF
- **Capas y Organización**: Sistema de capas completo
- **Propiedades Avanzadas**: Colores, opacidad, rotación, escala
- **Deshacer/Rehacer**: Historial de cambios
- **Atajos de Teclado**: Productividad maximizada
- **Responsive**: Adaptable a diferentes pantallas

---

## 🛡️ Seguridad Implementada

1. **Rate Limiting**: 100 requests por 15 minutos por IP
2. **Sanitización de Entradas**: Previene XSS y HTML injection
3. **Helmet.js**: Headers de seguridad HTTP
4. **CORS Configurado**: Solo permite origen específico
5. **Validación de Archivos**: Solo imágenes permitidas (max 5MB)
6. **Protección de Headers**: X-Content-Type-Options, CSP

---

## 📁 Estructura del Proyecto

```
Creador de Logos/
├── backend/              # API Node.js + Express + TypeScript
│   ├── src/
│   │   ├── middleware/   # Seguridad, sanitización, errores
│   │   ├── routes/       # API endpoints
│   │   └── server.ts     # Servidor principal
│   ├── .env.example      # Variables de entorno
│   └── package.json
│
├── frontend/             # React + TypeScript + Tailwind CSS
│   ├── src/
│   │   ├── components/   # Componentes React
│   │   ├── store/        # Zustand state management
│   │   ├── App.tsx       # App principal
│   │   └── index.css     # Estilos
│   └── package.json
│
├── deployments-docs/     # Guías de despliegue
│   ├── nginx/            # Configuración Nginx
│   ├── apache/           # Configuración Apache
│   └── docker/           # Configuración Docker
│
├── Dockerfile            # Docker multi-stage
├── docker-compose.yml    # Docker Compose
└── package.json          # Scripts raíz
```

---

## 🚀 Opciones de Despliegue

### Opción 1: Arquitectura Limpia con Nginx Proxy Manager (Recomendada)

```
Internet → HTTPS → Nginx Proxy Manager → HTTP → Node.js:32299
                     (NPM máquina)       →    (LogoAI máquina)
```

**¿Por qué sin Apache?** NPM se conecta directo al backend Node.js, eliminamos intermediarios.

#### Paso 1: Backend en LogoAI (10.0.1.40)

```bash
# 1. Ir al proyecto
cd /var/www/logoai

# 2. Crear .env correcto (HOST=0.0.0.0 es CRÍTICO)
sudo tee .env << 'EOF'
NODE_ENV=production
PORT=32299
HOST=0.0.0.0
CORS_ORIGIN=https://logoai.tymtechnology.shop
RATE_LIMIT_WINDOW_MS=900000
RATE_LIMIT_MAX_REQUESTS=100
LOG_LEVEL=info
EOF

# 3. Instalar dependencias y construir
npm run install:all
npm run build

# 4. Detener Apache (no lo necesitamos)
sudo systemctl stop apache2
sudo systemctl disable apache2

# 5. Limpiar PM2 y reiniciar
pm2 delete all
pm2 start backend/dist/server.js --name "logoai-backend"
pm2 save
pm2 startup

# 6. Verificar que escucha en 0.0.0.0:32299
sudo netstat -tlnp | grep :32299
# Debe mostrar: 0.0.0.0:32299
```

#### Paso 2: Configurar Nginx Proxy Manager

En tu máquina NPM, crear un Proxy Host:

| Campo | Valor |
|-------|-------|
| Domain Names | logoai.tymtechnology.shop |
| Scheme | http |
| Forward Hostname/IP | 10.0.1.40 |
| Forward Port | 32299 |
| Block Common Exploits | ✅ (opcional) |
| Websockets Support | ✅ |

**SSL Tab:**
- SSL Certificate: logoai.tymtechnology.shop (crearlo o reutilizar)
- Force SSL: ✅
- HTTP/2 Support: ✅

#### Paso 3: Verificación

Desde tu máquina Windows:

```bash
curl -v https://logoai.tymtechnology.shop/
```

---

### Opción 2: Despliegue con Apache (si es necesario)

```bash
# 1. Instalar dependencias
cd /var/www/logoai
npm run install:all
npm run build

# 2. Configurar Apache como reverse proxy
sudo tee /etc/apache2/sites-available/logoai.conf << 'EOF'
<VirtualHost *:80>
    ServerName logoai.tymtechnology.shop
    
    ProxyPreserveHost On
    ProxyPass / http://localhost:32299/
    ProxyPassReverse / http://localhost:32299/
    
    # WebSocket support
    RewriteEngine on
    RewriteCond %{HTTP:Upgrade} websocket [NC]
    RewriteCond %{HTTP:Connection} upgrade [NC]
    RewriteRule .* "ws://localhost:32299/$1" [P,L]
</VirtualHost>
EOF

# 3. Habilitar módulos y sitio
sudo a2enmod proxy proxy_http rewrite headers
sudo a2ensite logoai
sudo a2dissite 000-default
sudo systemctl reload apache2

# 4. Iniciar aplicación con PM2
pm2 start backend/dist/server.js --name "logoai-backend"
pm2 save
pm2 startup
```

---

### Opción 3: Docker Full Stack

```bash
# 1. Clonar o copiar el proyecto
cd /var/www/logoai

# 2. Crear archivo .env
sudo tee .env << 'EOF'
NODE_ENV=production
PORT=32299
HOST=0.0.0.0
CORS_ORIGIN=https://logoai.tymtechnology.shop
EOF

# 3. Construir y ejecutar
docker-compose up -d --build

# 4. Verificar logs
docker-compose logs -f

# 5. Detener
docker-compose down
```

---

## ⚙️ Variables de Entorno

### Backend (.env)

```env
# Server Configuration
NODE_ENV=production
PORT=32299
HOST=0.0.0.0

# CORS Configuration
CORS_ORIGIN=https://logoai.tymtechnology.shop

# Rate Limiting (15 minutos = 900000ms)
RATE_LIMIT_WINDOW_MS=900000
RATE_LIMIT_MAX_REQUESTS=100

# Logging
LOG_LEVEL=info

# File Upload
MAX_FILE_SIZE=5242880
UPLOAD_PATH=./uploads

# Security
TRUST_PROXY=1
```

---

## 📋 Checklist de Errores a Evitar

| Error | Causa | Solución |
|-------|-------|----------|
| 502 Bad Gateway | NPM no puede conectar | Verificar HOST=0.0.0.0 en .env |
| Connection refused | Puerto cerrado o firewall | Verificar `netstat -tlnp \| grep 32299` |
| 504 Gateway Timeout | Backend caído | `pm2 status` y revisar logs |
| CORS error | CORS_ORIGIN incorrecto | Debe ser https://logoai.tymtechnology.shop |
| Rate limit error | Headers de proxy | Ya corregido con trust proxy |

---

## 🔧 Comandos de Emergencia

```bash
# Ver logs del backend
pm2 logs logoai-backend

# Reiniciar todo
pm2 restart all --update-env

# Verificar conectividad desde NPM (si tienes acceso SSH)
curl http://10.0.1.40:32299/

# Verificar desde internet
curl -v https://logoai.tymtechnology.shop/

# Verificar proceso Node.js
ps aux | grep node

# Verificar puertos
sudo netstat -tlnp | grep 32299
sudo ss -tlnp | grep 32299
```

---

## 📝 Atajos de Teclado

| Atajo | Acción |
|-------|--------|
| Ctrl+N | Nuevo diseño |
| Ctrl+S | Guardar |
| Ctrl+E | Exportar |
| Ctrl+Z | Deshacer |
| Ctrl+Y | Rehacer |
| Ctrl+Shift+Z | Rehacer |
| Ctrl+D | Duplicar elemento |
| Delete | Eliminar elemento |

---

## 🔒 Notas de Seguridad

1. **Nunca expongas el archivo .env** en repositorios públicos
2. **Usa HTTPS en producción** siempre
3. **Mantén Node.js actualizado** (v18+ recomendado)
4. **Configura backups** regulares de diseños
5. **Monitorea logs** para detectar abuso

---

## 📞 Soporte

Para soporte técnico o consultas:

- **Email:** soporte@tymtechnology.shop
- **Dominio:** https://logoai.tymtechnology.shop
- **Autor:** T&M Technology Ec

---

## 📄 Licencia

© 2024 T&M Technology Ec - Todos los derechos reservados
