/**
 * Images Panel Component
 * Author: T&M Technology Ec
 */

import React, { useState, useRef } from 'react';
import { ImageIcon, Upload, Link, Search } from 'lucide-react';
import { useLogoStore } from '../store/logoStore';
import toast from 'react-hot-toast';

export const ImagesPanel: React.FC = () => {
  const [imageUrl, setImageUrl] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { addElement } = useLogoStore();

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      toast.error('Por favor selecciona una imagen válida');
      return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      const dataUrl = e.target?.result as string;
      addElement({
        type: 'image',
        x: 150,
        y: 150,
        src: dataUrl,
        width: 200,
        height: 200,
        opacity: 1,
        scaleX: 1,
        scaleY: 1,
        rotation: 0,
        visible: true,
      });
      toast.success('Imagen subida');
    };
    reader.readAsDataURL(file);
  };

  const handleUrlAdd = () => {
    if (!imageUrl.trim()) {
      toast.error('Ingresa una URL válida');
      return;
    }

    addElement({
      type: 'image',
      x: 150,
      y: 150,
      src: imageUrl,
      width: 200,
      height: 200,
      opacity: 1,
      scaleX: 1,
      scaleY: 1,
      rotation: 0,
      visible: true,
    });
    setImageUrl('');
    toast.success('Imagen agregada');
  };

  return (
    <div className="p-4 space-y-4">
      {/* Upload Section */}
      <div className="space-y-2">
        <label className="text-sm font-medium text-gray-700">Subir Imagen</label>
        <input
          type="file"
          ref={fileInputRef}
          onChange={handleFileUpload}
          accept="image/*"
          className="hidden"
        />
        <button
          onClick={() => fileInputRef.current?.click()}
          className="w-full p-6 border-2 border-dashed border-gray-300 rounded-xl hover:border-brand-500 hover:bg-brand-50 transition-all flex flex-col items-center gap-2"
        >
          <Upload className="w-8 h-8 text-gray-400" />
          <span className="text-sm text-gray-600">Click para seleccionar imagen</span>
          <span className="text-xs text-gray-400">PNG, JPG, GIF, WebP</span>
        </button>
      </div>

      {/* URL Section */}
      <div className="space-y-2">
        <label className="text-sm font-medium text-gray-700">URL de Imagen</label>
        <div className="flex gap-2">
          <input
            type="url"
            value={imageUrl}
            onChange={(e) => setImageUrl(e.target.value)}
            placeholder="https://ejemplo.com/imagen.png"
            className="flex-1 px-3 py-2 bg-gray-100 rounded-lg text-sm"
          />
          <button
            onClick={handleUrlAdd}
            className="px-4 py-2 bg-brand-600 text-white rounded-lg hover:bg-brand-700 transition-colors"
          >
            <Link className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Info */}
      <div className="p-3 bg-amber-50 rounded-lg text-sm text-amber-700">
        <p className="font-medium mb-1">⚠️ Nota:</p>
        <p>Las imágenes grandes pueden afectar el rendimiento. Recomendamos imágenes menores a 2MB.</p>
      </div>
    </div>
  );
};
