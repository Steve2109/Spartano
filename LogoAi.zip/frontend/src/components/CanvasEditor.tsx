/**
 * Canvas Editor Component
 * Author: T&M Technology Ec
 */

import React, { useEffect, useRef, useCallback } from 'react';
import { fabric } from 'fabric';
import { useLogoStore, CanvasElement } from '../store/logoStore';

export const CanvasEditor: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const fabricCanvasRef = useRef<fabric.Canvas | null>(null);
  const isUpdatingRef = useRef(false);
  
  const { 
    design, 
    selectElement, 
    updateElement, 
    moveElement,
    saveHistory 
  } = useLogoStore();

  // Initialize canvas
  useEffect(() => {
    if (!canvasRef.current) return;

    const canvas = new fabric.Canvas(canvasRef.current, {
      width: design.width,
      height: design.height,
      backgroundColor: design.background,
      selection: true,
      preserveObjectStacking: true,
    });

    fabricCanvasRef.current = canvas;

    // Event handlers
    canvas.on('selection:created', (e) => {
      const obj = e.selected?.[0];
      if (obj && obj.data?.id) {
        selectElement(obj.data.id);
      }
    });

    canvas.on('selection:updated', (e) => {
      const obj = e.selected?.[0];
      if (obj && obj.data?.id) {
        selectElement(obj.data.id);
      }
    });

    canvas.on('selection:cleared', () => {
      selectElement(null);
    });

    canvas.on('object:modified', (e) => {
      const obj = e.target;
      if (obj && obj.data?.id) {
        isUpdatingRef.current = true;
        updateElement(obj.data.id, {
          x: obj.left || 0,
          y: obj.top || 0,
          scaleX: obj.scaleX || 1,
          scaleY: obj.scaleY || 1,
          rotation: obj.angle || 0,
        });
        isUpdatingRef.current = false;
        saveHistory();
      }
    });

    canvas.on('object:moving', (e) => {
      const obj = e.target;
      if (obj && obj.data?.id) {
        moveElement(obj.data.id, obj.left || 0, obj.top || 0);
      }
    });

    return () => {
      canvas.dispose();
      fabricCanvasRef.current = null;
    };
  }, []);

  // Update canvas size
  useEffect(() => {
    const canvas = fabricCanvasRef.current;
    if (!canvas) return;
    
    canvas.setWidth(design.width);
    canvas.setHeight(design.height);
    canvas.setBackgroundColor(design.background, () => {
      canvas.renderAll();
    });
  }, [design.width, design.height, design.background]);

  // Sync elements with fabric
  useEffect(() => {
    if (isUpdatingRef.current) return;
    
    const canvas = fabricCanvasRef.current;
    if (!canvas) return;

    const objects = canvas.getObjects();
    const currentIds = objects.map(obj => (obj as any).data?.id).filter(Boolean);
    const storeIds = design.elements.map(el => el.id);

    // Remove deleted elements
    objects.forEach((obj, index) => {
      const id = (obj as any).data?.id;
      if (id && !storeIds.includes(id)) {
        canvas.remove(obj);
      }
    });

    // Add or update elements
    design.elements.forEach((element) => {
      const existingObj = canvas.getObjects().find(obj => (obj as any).data?.id === element.id);
      
      if (existingObj) {
        // Update existing object
        existingObj.set({
          left: element.x,
          top: element.y,
          scaleX: element.scaleX,
          scaleY: element.scaleY,
          angle: element.rotation,
          opacity: element.opacity,
          visible: element.visible,
        });
        
        if (element.type === 'text' && existingObj instanceof fabric.Text) {
          existingObj.set({
            text: element.text || '',
            fontFamily: element.fontFamily,
            fontSize: element.fontSize,
            fontWeight: element.fontWeight,
            fill: element.fill,
          });
        }
      } else {
        // Create new object
        createFabricObject(element, canvas);
      }
    });

    // Handle selection
    const selectedObj = canvas.getObjects().find(obj => (obj as any).data?.id === design.selectedElementId);
    if (selectedObj) {
      canvas.setActiveObject(selectedObj);
    } else {
      canvas.discardActiveObject();
    }

    canvas.renderAll();
  }, [design.elements, design.selectedElementId]);

  const createFabricObject = (element: CanvasElement, canvas: fabric.Canvas) => {
    let obj: fabric.Object | null = null;

    const commonProps = {
      left: element.x,
      top: element.y,
      scaleX: element.scaleX,
      scaleY: element.scaleY,
      angle: element.rotation,
      opacity: element.opacity,
      visible: element.visible,
      selectable: true,
      data: { id: element.id, type: element.type },
    };

    switch (element.type) {
      case 'text':
        obj = new fabric.Text(element.text || 'Texto', {
          ...commonProps,
          fontFamily: element.fontFamily || 'Inter',
          fontSize: element.fontSize || 24,
          fontWeight: element.fontWeight || 'normal',
          fill: element.fill || '#000000',
          textAlign: (element.align as any) || 'left',
        });
        break;

      case 'rect':
        obj = new fabric.Rect({
          ...commonProps,
          width: element.width || 100,
          height: element.height || 100,
          fill: element.fill || '#3b82f6',
          rx: element.radius || 0,
          ry: element.radius || 0,
          stroke: element.stroke,
          strokeWidth: element.strokeWidth,
        });
        break;

      case 'circle':
        obj = new fabric.Circle({
          ...commonProps,
          radius: element.radius || 50,
          fill: element.fill || '#3b82f6',
          stroke: element.stroke,
          strokeWidth: element.strokeWidth,
        });
        break;

      case 'image':
        if (element.src) {
          fabric.Image.fromURL(element.src, (img) => {
            img.set({
              ...commonProps,
              width: element.width || img.width || 100,
              height: element.height || img.height || 100,
            });
            canvas.add(img);
            canvas.renderAll();
          });
          return;
        }
        break;

      case 'path':
        if (element.path) {
          obj = new fabric.Path(element.path, {
            ...commonProps,
            fill: element.fill || '#3b82f6',
            stroke: element.stroke,
            strokeWidth: element.strokeWidth,
          });
        }
        break;
    }

    if (obj) {
      canvas.add(obj);
    }
  };

  // Zoom handling
  useEffect(() => {
    const canvas = fabricCanvasRef.current;
    if (!canvas) return;
    
    const wrapper = canvas.wrapperEl;
    if (wrapper) {
      wrapper.style.transform = `scale(${design.zoom})`;
      wrapper.style.transformOrigin = 'center center';
    }
  }, [design.zoom]);

  return (
    <div className="flex items-center justify-center min-h-full p-4">
      <div className="relative canvas-container">
        <canvas
          ref={canvasRef}
          className="shadow-lg"
        />
        
        {/* Grid overlay for alignment */}
        <div 
          className="absolute inset-0 pointer-events-none grid-background opacity-30"
          style={{ 
            width: design.width, 
            height: design.height,
            display: design.zoom >= 1 ? 'block' : 'none'
          }}
        />
      </div>
    </div>
  );
};
