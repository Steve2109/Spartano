/**
 * Text Panel Component
 * Author: T&M Technology Ec
 */

import React, { useState } from 'react';
import { Type, Plus } from 'lucide-react';
import { useLogoStore } from '../store/logoStore';
import toast from 'react-hot-toast';

const fonts = [
  { name: 'Inter', family: 'Inter, sans-serif' },
  { name: 'Playfair Display', family: 'Playfair Display, serif' },
  { name: 'Montserrat', family: 'Montserrat, sans-serif' },
  { name: 'Roboto Mono', family: 'Roboto Mono, monospace' },
  { name: 'Nunito', family: 'Nunito, sans-serif' },
  { name: 'Arial', family: 'Arial, sans-serif' },
  { name: 'Georgia', family: 'Georgia, serif' },
  { name: 'Impact', family: 'Impact, sans-serif' },
];

export const TextPanel: React.FC = () => {
  const [text, setText] = useState('Tu texto aquí');
  const [selectedFont, setSelectedFont] = useState(fonts[0]);
  const { addElement } = useLogoStore();

  const handleAddText = () => {
    if (!text.trim()) {
      toast.error('Ingresa algún texto');
      return;
    }

    addElement({
      type: 'text',
      x: 200,
      y: 200,
      text: text,
      fontFamily: selectedFont.name,
      fontSize: 36,
      fontWeight: 'normal',
      fill: '#000000',
      align: 'center',
      opacity: 1,
      scaleX: 1,
      scaleY: 1,
      rotation: 0,
      visible: true,
    });

    toast.success('Texto agregado');
    setText('');
  };

  const quickTexts = [
    { text: 'Logo', style: { fontSize: 48, fontWeight: 'bold' } },
    { text: 'Company', style: { fontSize: 36, fontWeight: 'normal' } },
    { text: 'BRAND', style: { fontSize: 42, fontWeight: 'bold', letterSpacing: 4 } },
    { text: 'design', style: { fontSize: 32, fontWeight: 'normal', fontStyle: 'italic' } },
  ];

  const handleQuickText = (item: typeof quickTexts[0]) => {
    addElement({
      type: 'text',
      x: 200,
      y: 200,
      text: item.text,
      fontFamily: selectedFont.name,
      fontSize: item.style.fontSize,
      fontWeight: item.style.fontWeight as any,
      fill: '#000000',
      align: 'center',
      opacity: 1,
      scaleX: 1,
      scaleY: 1,
      rotation: 0,
      visible: true,
    });
    toast.success('Texto agregado');
  };

  return (
    <div className="p-4 space-y-4">
      {/* Text Input */}
      <div className="space-y-2">
        <label className="text-sm font-medium text-gray-700">Texto</label>
        <textarea
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="Escribe tu texto aquí..."
          className="w-full px-3 py-2 bg-gray-100 border-0 rounded-lg text-sm focus:ring-2 focus:ring-brand-500 focus:bg-white transition-all resize-none"
          rows={3}
        />
      </div>

      {/* Font Selection */}
      <div className="space-y-2">
        <label className="text-sm font-medium text-gray-700">Fuente</label>
        <div className="grid grid-cols-2 gap-2">
          {fonts.map((font) => (
            <button
              key={font.name}
              onClick={() => setSelectedFont(font)}
              className={`p-2 text-sm rounded-lg border transition-all ${
                selectedFont.name === font.name
                  ? 'border-brand-500 bg-brand-50 text-brand-700'
                  : 'border-gray-200 hover:border-gray-300'
              }`}
              style={{ fontFamily: font.family }}
            >
              {font.name}
            </button>
          ))}
        </div>
      </div>

      {/* Add Button */}
      <button
        onClick={handleAddText}
        className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-brand-600 text-white font-medium rounded-lg hover:bg-brand-700 transition-colors"
      >
        <Plus className="w-5 h-5" />
        Agregar Texto
      </button>

      {/* Quick Texts */}
      <div className="pt-4 border-t border-gray-200">
        <label className="text-sm font-medium text-gray-700 mb-3 block">Textos Rápidos</label>
        <div className="grid grid-cols-2 gap-2">
          {quickTexts.map((item, index) => (
            <button
              key={index}
              onClick={() => handleQuickText(item)}
              className="p-3 bg-gray-100 rounded-lg hover:bg-gray-200 transition-colors text-center"
              style={{ fontFamily: selectedFont.family }}
            >
              <span style={item.style}>{item.text}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Tips */}
      <div className="p-3 bg-blue-50 rounded-lg text-sm text-blue-700">
        <p className="font-medium mb-1">💡 Consejo:</p>
        <p>Agrega texto y luego selecciónalo en el canvas para editar sus propiedades.</p>
      </div>
    </div>
  );
};
