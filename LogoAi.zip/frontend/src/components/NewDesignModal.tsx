/**
 * New Design Modal Component
 * Author: T&M Technology Ec
 */

import React, { useState } from 'react';
import { X, FilePlus, Check, LayoutTemplate } from 'lucide-react';
import { useLogoStore } from '../store/logoStore';
import toast from 'react-hot-toast';

interface NewDesignModalProps {
  onClose: () => void;
}

const presets = [
  { name: 'Cuadrado Pequeño', width: 256, height: 256, icon: '📐' },
  { name: 'Cuadrado Mediano', width: 512, height: 512, icon: '📐' },
  { name: 'Cuadrado Grande', width: 1024, height: 1024, icon: '📐' },
  { name: 'Horizontal', width: 800, height: 400, icon: '📄' },
  { name: 'Vertical', width: 400, height: 800, icon: '📃' },
  { name: 'Social Media', width: 1080, height: 1080, icon: '📱' },
];

export const NewDesignModal: React.FC<NewDesignModalProps> = ({ onClose }) => {
  const { resetDesign, loadDesign, setDesignName } = useLogoStore();
  const [name, setName] = useState('Nuevo Diseño');
  const [width, setWidth] = useState(512);
  const [height, setHeight] = useState(512);
  const [selectedPreset, setSelectedPreset] = useState<number | null>(1);

  const handlePresetSelect = (index: number, preset: typeof presets[0]) => {
    setSelectedPreset(index);
    setWidth(preset.width);
    setHeight(preset.height);
  };

  const handleCreate = () => {
    resetDesign();
    loadDesign({
      name,
      width,
      height,
      background: '#ffffff',
      elements: [],
    });
    setDesignName(name);
    toast.success(`Nuevo diseño "${name}" creado`);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full overflow-hidden">
        <div className="p-6 border-b border-gray-100 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-brand-100 rounded-lg">
              <FilePlus className="w-5 h-5 text-brand-600" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-gray-900">Nuevo Diseño</h2>
              <p className="text-sm text-gray-500">Crea un logo desde cero</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-6">
          {/* Name Input */}
          <div className="space-y-2">
            <label className="text-sm font-medium text-gray-700">Nombre del diseño</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full px-4 py-3 bg-gray-100 border-0 rounded-xl text-lg focus:ring-2 focus:ring-brand-500 focus:bg-white transition-all"
              placeholder="Mi Logo"
            />
          </div>

          {/* Presets */}
          <div className="space-y-3">
            <label className="text-sm font-medium text-gray-700">Tamaño predefinido</label>
            <div className="grid grid-cols-2 gap-3">
              {presets.map((preset, index) => (
                <button
                  key={index}
                  onClick={() => handlePresetSelect(index, preset)}
                  className={`p-3 rounded-xl border-2 transition-all text-left ${
                    selectedPreset === index
                      ? 'border-brand-500 bg-brand-50'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <span className="text-2xl mr-2">{preset.icon}</span>
                  <div className="inline-block">
                    <p className={`font-semibold text-sm ${selectedPreset === index ? 'text-brand-700' : 'text-gray-700'}`}>
                      {preset.name}
                    </p>
                    <p className="text-xs text-gray-500">{preset.width}×{preset.height}</p>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Custom Size */}
          <div className="space-y-2">
            <label className="text-sm font-medium text-gray-700">Tamaño personalizado</label>
            <div className="flex items-center gap-3">
              <div className="flex-1">
                <label className="text-xs text-gray-500">Ancho (px)</label>
                <input
                  type="number"
                  value={width}
                  onChange={(e) => {
                    setWidth(Number(e.target.value));
                    setSelectedPreset(null);
                  }}
                  className="w-full px-3 py-2 bg-gray-100 rounded-lg text-sm"
                  min="50"
                  max="4096"
                />
              </div>
              <span className="text-gray-400 pt-5">×</span>
              <div className="flex-1">
                <label className="text-xs text-gray-500">Alto (px)</label>
                <input
                  type="number"
                  value={height}
                  onChange={(e) => {
                    setHeight(Number(e.target.value));
                    setSelectedPreset(null);
                  }}
                  className="w-full px-3 py-2 bg-gray-100 rounded-lg text-sm"
                  min="50"
                  max="4096"
                />
              </div>
            </div>
          </div>
        </div>

        <div className="p-6 border-t border-gray-100 bg-gray-50 flex gap-3">
          <button
            onClick={onClose}
            className="flex-1 py-3 px-4 bg-white border border-gray-300 text-gray-700 font-medium rounded-xl hover:bg-gray-50 transition-colors"
          >
            Cancelar
          </button>
          <button
            onClick={handleCreate}
            className="flex-1 py-3 px-4 bg-brand-600 text-white font-medium rounded-xl hover:bg-brand-700 transition-colors flex items-center justify-center gap-2"
          >
            <Check className="w-5 h-5" />
            Crear Diseño
          </button>
        </div>
      </div>
    </div>
  );
};
