/**
 * Templates Panel Component
 * Author: T&M Technology Ec
 */

import React, { useState } from 'react';
import { Search, LayoutTemplate, Sparkles } from 'lucide-react';
import { useLogoStore } from '../store/logoStore';
import toast from 'react-hot-toast';

const categories = [
  { id: 'all', name: 'Todas', count: 8 },
  { id: 'minimalist', name: 'Minimalista', count: 1 },
  { id: 'technology', name: 'Tecnología', count: 1 },
  { id: 'elegant', name: 'Elegante', count: 1 },
  { id: 'modern', name: 'Moderno', count: 1 },
  { id: 'food', name: 'Comida', count: 1 },
  { id: 'nature', name: 'Naturaleza', count: 1 },
  { id: 'sports', name: 'Deportes', count: 1 },
  { id: 'creative', name: 'Creativo', count: 1 },
];

const templates = [
  {
    id: 'minimal-1',
    name: 'Círculo Minimal',
    category: 'minimalist',
    thumbnail: 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAwIiBoZWlnaHQ9IjIwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48Y2lyY2xlIGN4PSIxMDAiIGN5PSIxMDAiIHI9IjgwIiBmaWxsPSIjNjM2NmYxIi8+PHRleHQgeD0iMTAwIiB5PSIxMTAiIGZvbnQtZmFtaWx5PSJBcmlhbCIgZm9udC1zaXplPSI0MCIgZmlsbD0id2hpdGUiIHRleHQtYW5jaG9yPSJtaWRkbGUiPkxvZ288L3RleHQ+PC9zdmc+',
    width: 512,
    height: 512,
    background: '#ffffff',
    elements: [
      { id: '1', type: 'circle' as const, x: 256, y: 256, radius: 150, fill: '#6366f1', stroke: '#4f46e5', strokeWidth: 4, opacity: 1, scaleX: 1, scaleY: 1, rotation: 0, visible: true, zIndex: 0 },
      { id: '2', type: 'text' as const, x: 256, y: 256, text: 'Logo', fontFamily: 'Inter', fontSize: 48, fontWeight: 'bold', fill: '#ffffff', align: 'center', opacity: 1, scaleX: 1, scaleY: 1, rotation: 0, visible: true, zIndex: 1 },
    ],
  },
  {
    id: 'tech-1',
    name: 'Escudo Tech',
    category: 'technology',
    thumbnail: 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAwIiBoZWlnaHQ9IjIwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cGF0aCBkPSJNMTAwIDMwIEwxNzAgODAgTDE3MCAxNDAgTDEwMCAxODAgTDMwIDE0MCBMMzAgODAgWiIgZmlsbD0iIzNiODJmNiIgc3Ryb2tlPSIjMWQ0ZWQ4IiBzdHJva2Utd2lkdGg9IjQiLz48dGV4dCB4PSIxMDAiIHk9IjEyMCIgZm9udC1mYW1pbHk9IkFyaWFsIiBmb250LXNpemU9IjI0IiBmaWxsPSJ3aGl0ZSIgdGV4dC1hbmNob3I9Im1pZGRsZSI+U0VDVVJFPjwvdGV4dD48L3N2Zz4=',
    width: 512,
    height: 512,
    background: '#0f172a',
    elements: [
      { id: '1', type: 'path' as const, x: 256, y: 200, path: 'M128 64 L384 64 L384 256 Q384 384 256 448 Q128 384 128 256 Z', fill: '#3b82f6', opacity: 1, scaleX: 0.5, scaleY: 0.5, rotation: 0, visible: true, zIndex: 0 },
      { id: '2', type: 'text' as const, x: 256, y: 350, text: 'SECURE', fontFamily: 'Roboto Mono', fontSize: 36, fontWeight: 'bold', fill: '#60a5fa', align: 'center', opacity: 1, scaleX: 1, scaleY: 1, rotation: 0, visible: true, zIndex: 1 },
    ],
  },
  {
    id: 'elegant-1',
    name: 'Corona Real',
    category: 'elegant',
    thumbnail: 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAwIiBoZWlnaHQ9IjIwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cGF0aCBkPSJNNDAgMTUwIEw2MCAxMDAgTDkwIDE0MCBMTDEwMCA4MCBMMTMwIDEzMCBMMTYwIDkwIEwxNjAgMTUwIFoiIGZpbGw9IiNmYmJmMjQiIHN0cm9rZT0iI2Y1OWUwYiIgc3Ryb2tlLXdpZHRoPSIzIi8+PHRleHQgeD0iMTAwIiB5PSIxODAiIGZvbnQtZmFtaWx5PSJBcmlhbCIgZm9udC1zaXplPSIyMCIgZmlsbD0iIzFmMjkzNyIgdGV4dC1hbmNob3I9Im1pZGRsZSI+Uk9ZQUw8L3RleHQ+PC9zdmc+',
    width: 512,
    height: 512,
    background: '#fafafa',
    elements: [
      { id: '1', type: 'path' as const, x: 256, y: 180, path: 'M100 150 L150 100 L200 150 L250 80 L300 150 L350 100 L400 150 L380 250 L120 250 Z', fill: '#fbbf24', stroke: '#f59e0b', strokeWidth: 3, opacity: 1, scaleX: 0.6, scaleY: 0.6, rotation: 0, visible: true, zIndex: 0 },
      { id: '2', type: 'text' as const, x: 256, y: 360, text: 'ROYAL', fontFamily: 'Playfair Display', fontSize: 42, fontWeight: 'bold', fill: '#1f2937', align: 'center', opacity: 1, scaleX: 1, scaleY: 1, rotation: 0, visible: true, zIndex: 1 },
    ],
  },
  {
    id: 'modern-1',
    name: 'Hexágono Moderno',
    category: 'modern',
    thumbnail: 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAwIiBoZWlnaHQ9IjIwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cGF0aCBkPSJNMTAwIDQwIEwxNzAgODAgTDE3MCAxNjAgTDEwMCAyMDAgTDMwIDE2MCBMMzAgODAgWiIgZmlsbD0iIzEwYjk4MSIvPjx0ZXh0IHg9IjEwMCIgeT0iMTI1IiBmb250LWZhbWlseT0iQXJpYWwiIGZvbnQtc2l6ZT0iNjAiIGZvbnQtd2VpZ2h0PSJib2xkIiBmaWxsPSJ3aGl0ZSIgdGV4dC1hbmNob3I9Im1pZGRsZSI+TTwvdGV4dD48L3N2Zz4=',
    width: 512,
    height: 512,
    background: '#f8fafc',
    elements: [
      { id: '1', type: 'path' as const, x: 256, y: 256, path: 'M256 80 L432 180 L432 380 L256 480 L80 380 L80 180 Z', fill: '#10b981', opacity: 0.9, scaleX: 0.4, scaleY: 0.4, rotation: 0, visible: true, zIndex: 0 },
      { id: '2', type: 'text' as const, x: 256, y: 256, text: 'M', fontFamily: 'Montserrat', fontSize: 72, fontWeight: 'bold', fill: '#ffffff', align: 'center', opacity: 1, scaleX: 1, scaleY: 1, rotation: 0, visible: true, zIndex: 1 },
    ],
  },
  {
    id: 'food-1',
    name: 'Food & Drink',
    category: 'food',
    thumbnail: 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAwIiBoZWlnaHQ9IjIwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48Y2lyY2xlIGN4PSIxMDAiIGN5PSI5MCIgcj0iNTAiIGZpbGw9IiNmOTczMTYiLz48cmVjdCB4PSI4NSIgeT0iNDAiIHdpZHRoPSIzMCIgaGVpZ2h0PSIzMCIgZmlsbD0iIzdjMmQxMiIgcng9IjUiLz48dGV4dCB4PSIxMDAiIHk9IjE3MCIgZm9udC1mYW1pbHk9IkFyaWFsIiBmb250LXNpemU9IjI0IiBmaWxsPSIjN2MyZDEyIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIj5UQVNUWTwvdGV4dD48L3N2Zz4=',
    width: 512,
    height: 512,
    background: '#fef3c7',
    elements: [
      { id: '1', type: 'circle' as const, x: 256, y: 200, radius: 80, fill: '#f97316', opacity: 1, scaleX: 1, scaleY: 1, rotation: 0, visible: true, zIndex: 0 },
      { id: '2', type: 'rect' as const, x: 236, y: 120, width: 40, height: 40, radius: 5, fill: '#7c2d12', opacity: 1, scaleX: 1, scaleY: 1, rotation: 0, visible: true, zIndex: 1 },
      { id: '3', type: 'text' as const, x: 256, y: 360, text: 'TASTY', fontFamily: 'Pacifico', fontSize: 48, fill: '#7c2d12', align: 'center', opacity: 1, scaleX: 1, scaleY: 1, rotation: 0, visible: true, zIndex: 2 },
    ],
  },
  {
    id: 'nature-1',
    name: 'Hoja Verde',
    category: 'nature',
    thumbnail: 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAwIiBoZWlnaHQ9IjIwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cGF0aCBkPSJNMTAwIDQwIFExNDAgODAgMTQwIDEzMCBRMTQwIDE4MCAxMDAgMjAwIFE2MCAxODAgNjAgMTMwIFE2MCA4MCAxMDAgNDAiIGZpbGw9IiMyMmM1NWUiIHN0cm9rZT0iIzE2YTM0YSIgc3Ryb2tlLXdpZHRoPSIyIi8+PGxpbmUgeDE9IjEwMCIgeTE9IjYwIiB4Mj0iMTAwIiB5Mj0iMTgwIiBzdHJva2U9IiMxNTgwM2QiIHN0cm9rZS13aWR0aD0iMyIgb3BhY2l0eT0iMC42Ii8+PHRleHQgeD0iMTAwIiB5PSIyMzAiIGZvbnQtZmFtaWx5PSJBcmlhbCIgZm9udC1zaXplPSIyMCIgZmlsbD0iIzE2NjUzNCIgdGV4dC1hbmNob3I9Im1pZGRsZSI+RUNPPC90ZXh0Pjwvc3ZnPg==',
    width: 512,
    height: 512,
    background: '#f0fdf4',
    elements: [
      { id: '1', type: 'path' as const, x: 256, y: 200, path: 'M256 80 Q350 150 350 250 Q350 350 256 420 Q162 350 162 250 Q162 150 256 80', fill: '#22c55e', stroke: '#16a34a', strokeWidth: 2, opacity: 1, scaleX: 0.8, scaleY: 0.8, rotation: 0, visible: true, zIndex: 0 },
      { id: '2', type: 'path' as const, x: 256, y: 200, path: 'M256 100 L256 400', stroke: '#15803d', strokeWidth: 3, opacity: 0.6, scaleX: 0.8, scaleY: 0.8, rotation: 0, visible: true, zIndex: 1 },
      { id: '3', type: 'text' as const, x: 256, y: 460, text: 'ECO', fontFamily: 'Nunito', fontSize: 40, fontWeight: 'bold', fill: '#166534', align: 'center', opacity: 1, scaleX: 1, scaleY: 1, rotation: 0, visible: true, zIndex: 2 },
    ],
  },
  {
    id: 'sport-1',
    name: 'Sport Dinámico',
    category: 'sports',
    thumbnail: 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAwIiBoZWlnaHQ9IjIwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cGF0aCBkPSJNNTAgNTAgTDEwMCAxMDAgTDUwIDE1MCBMMCA5OSBaIiBmaWxsPSIjZWM0ODk5IiB0cmFuc2Zvcm09InJvdGF0ZSg0NSwgNzUsIDEwMCkiLz48cGF0aCBkPSJNMTUwIDUwIEwyMDAgMTAwIEwxNTAgMTUwIEwxMDAgMTAwIFoiIGZpbGw9IiM4YjVjZjYiIHRyYW5zZm9ybT0icm90YXRlKC00NSwgMTUwLCAxMDApIi8+PHRleHQgeD0iMTAwIiB5PSIxODAiIGZvbnQtZmFtaWx5PSJBcmlhbCIgZm9udC1zaXplPSIxOCIgZm9udC13ZWlnaHQ9ImJvbGQiIGZpbGw9IndoaXRlIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBsZXR0ZXItc3BhY2luZz0iNCI+RU5FUkdZPC90ZXh0Pjwvc3ZnPg==',
    width: 512,
    height: 512,
    background: '#1e1b4b',
    elements: [
      { id: '1', type: 'path' as const, x: 180, y: 256, path: 'M50 0 L100 50 L50 100 L0 50 Z', fill: '#ec4899', opacity: 1, scaleX: 1.5, scaleY: 1.5, rotation: 45, visible: true, zIndex: 0 },
      { id: '2', type: 'path' as const, x: 332, y: 256, path: 'M50 0 L100 50 L50 100 L0 50 Z', fill: '#8b5cf6', opacity: 1, scaleX: 1.5, scaleY: 1.5, rotation: -45, visible: true, zIndex: 1 },
      { id: '3', type: 'text' as const, x: 256, y: 400, text: 'ENERGY', fontFamily: 'Bebas Neue', fontSize: 56, fill: '#ffffff', align: 'center', letterSpacing: 6, opacity: 1, scaleX: 1, scaleY: 1, rotation: 0, visible: true, zIndex: 2 },
    ],
  },
  {
    id: 'creative-1',
    name: 'Burst Creativo',
    category: 'creative',
    thumbnail: 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAwIiBoZWlnaHQ9IjIwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48Y2lyY2xlIGN4PSIxMDAiIGN5PSIxMDAiIHI9IjgwIiBmaWxsPSIjZmFjYzE1IiBzdHJva2U9IiNlYWIzMDgiIHN0cm9rZS13aWR0aD0iNCIvPjx0ZXh0IHg9IjEwMCIgeT0iMTIwIiBmb250LWZhbWlseT0iQXJpYWwgQmxhY2siIGZvbnQtc2l6ZT0iODAiIGZvbnQtd2VpZ2h0PSJib2xkIiBmaWxsPSIjODU0ZDBlIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIj4hPC90ZXh0Pjx0ZXh0IHg9IjEwMCIgeT0iMTgwIiBmb250LWZhbWlseT0iQXJpYWwiIGZvbnQtc2l6ZT0iMjAiIGZpbGw9IiNhMTYyMDciIHRleHQtYW5jaG9yPSJtaWRkbGUiPklERUE8L3RleHQ+PC9zdmc+',
    width: 512,
    height: 512,
    background: '#fefce8',
    elements: [
      { id: '1', type: 'circle' as const, x: 256, y: 230, radius: 100, fill: '#facc15', stroke: '#eab308', strokeWidth: 4, opacity: 1, scaleX: 1, scaleY: 1, rotation: 0, visible: true, zIndex: 0 },
      { id: '2', type: 'text' as const, x: 256, y: 230, text: '!', fontFamily: 'Arial Black', fontSize: 100, fill: '#854d0e', align: 'center', opacity: 1, scaleX: 1, scaleY: 1, rotation: 0, visible: true, zIndex: 1 },
      { id: '3', type: 'text' as const, x: 256, y: 380, text: 'IDEA', fontFamily: 'Fredoka One', fontSize: 42, fill: '#a16207', align: 'center', opacity: 1, scaleX: 1, scaleY: 1, rotation: 0, visible: true, zIndex: 2 },
    ],
  },
];

export const TemplatesPanel: React.FC = () => {
  const [activeCategory, setActiveCategory] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const { loadTemplate } = useLogoStore();

  const filteredTemplates = templates.filter(template => {
    const matchesCategory = activeCategory === 'all' || template.category === activeCategory;
    const matchesSearch = template.name.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const handleUseTemplate = (template: typeof templates[0]) => {
    loadTemplate({
      name: template.name,
      width: template.width,
      height: template.height,
      background: template.background,
      elements: template.elements,
    });
    toast.success(`Plantilla "${template.name}" cargada`);
  };

  return (
    <div className="p-4 space-y-4">
      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
        <input
          type="text"
          placeholder="Buscar plantillas..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full pl-9 pr-4 py-2 bg-gray-100 border-0 rounded-lg text-sm focus:ring-2 focus:ring-brand-500 focus:bg-white transition-all"
        />
      </div>

      {/* Categories */}
      <div className="flex flex-wrap gap-2">
        {categories.map((cat) => (
          <button
            key={cat.id}
            onClick={() => setActiveCategory(cat.id)}
            className={`px-3 py-1.5 text-xs font-medium rounded-full transition-colors ${
              activeCategory === cat.id
                ? 'bg-brand-500 text-white'
                : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
            }`}
          >
            {cat.name} ({cat.count})
          </button>
        ))}
      </div>

      {/* Templates Grid */}
      <div className="grid grid-cols-2 gap-3">
        {filteredTemplates.map((template) => (
          <button
            key={template.id}
            onClick={() => handleUseTemplate(template)}
            className="group relative aspect-square bg-gray-100 rounded-xl overflow-hidden hover:shadow-lg transition-all"
          >
            <img
              src={template.thumbnail}
              alt={template.name}
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
            <div className="absolute bottom-0 left-0 right-0 p-3 translate-y-full group-hover:translate-y-0 transition-transform">
              <p className="text-white font-medium text-sm truncate">{template.name}</p>
              <p className="text-white/80 text-xs">{template.width}×{template.height}</p>
            </div>
            <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity">
              <div className="p-2 bg-white rounded-lg shadow-md">
                <Sparkles className="w-4 h-4 text-brand-500" />
              </div>
            </div>
          </button>
        ))}
      </div>

      {filteredTemplates.length === 0 && (
        <div className="text-center py-8 text-gray-500">
          <LayoutTemplate className="w-12 h-12 mx-auto mb-3 opacity-50" />
          <p className="text-sm">No se encontraron plantillas</p>
        </div>
      )}
    </div>
  );
};
