/**
 * Properties Panel Component
 * Author: T&M Technology Ec
 */

import React from 'react';
import { useLogoStore } from '../store/logoStore';
import { HexColorPicker } from 'react-colorful';

export const PropertiesPanel: React.FC = () => {
  const { design, updateElement, deleteElement, setBackground, setCanvasSize } = useLogoStore();
  
  const selectedElement = design.elements.find(el => el.id === design.selectedElementId);

  const handleUpdate = (updates: Partial<typeof selectedElement>) => {
    if (selectedElement?.id) {
      updateElement(selectedElement.id, updates);
    }
  };

  if (!selectedElement) {
    return (
      <div className="p-4 space-y-6">
        <div>
          <h3 className="font-semibold text-gray-900 mb-3">Canvas</h3>
          
          {/* Background Color */}
          <div className="space-y-2 mb-4">
            <label className="text-sm text-gray-600">Color de Fondo</label>
            <div className="flex items-center gap-2">
              <input
                type="color"
                value={design.background}
                onChange={(e) => setBackground(e.target.value)}
                className="w-10 h-10 rounded-lg cursor-pointer"
              />
              <input
                type="text"
                value={design.background}
                onChange={(e) => setBackground(e.target.value)}
                className="flex-1 px-3 py-2 bg-gray-100 rounded-lg text-sm"
              />
            </div>
          </div>

          {/* Canvas Size */}
          <div className="space-y-2">
            <label className="text-sm text-gray-600">Tamaño del Canvas</label>
            <div className="flex gap-2">
              <input
                type="number"
                value={design.width}
                onChange={(e) => setCanvasSize(Number(e.target.value), design.height)}
                className="w-20 px-3 py-2 bg-gray-100 rounded-lg text-sm"
                min="50"
                max="4096"
              />
              <span className="flex items-center text-gray-400">×</span>
              <input
                type="number"
                value={design.height}
                onChange={(e) => setCanvasSize(design.width, Number(e.target.value))}
                className="w-20 px-3 py-2 bg-gray-100 rounded-lg text-sm"
                min="50"
                max="4096"
              />
            </div>
          </div>
        </div>

        <div className="p-4 bg-gray-100 rounded-lg text-center text-gray-500">
          <p className="text-sm">Selecciona un elemento para editar sus propiedades</p>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 space-y-4">
      <h3 className="font-semibold text-gray-900">Propiedades</h3>

      {/* Position */}
      <div className="space-y-2">
        <label className="text-sm text-gray-600">Posición</label>
        <div className="flex gap-2">
          <div className="flex-1">
            <label className="text-xs text-gray-400">X</label>
            <input
              type="number"
              value={Math.round(selectedElement.x)}
              onChange={(e) => handleUpdate({ x: Number(e.target.value) })}
              className="w-full px-3 py-2 bg-gray-100 rounded-lg text-sm"
            />
          </div>
          <div className="flex-1">
            <label className="text-xs text-gray-400">Y</label>
            <input
              type="number"
              value={Math.round(selectedElement.y)}
              onChange={(e) => handleUpdate({ y: Number(e.target.value) })}
              className="w-full px-3 py-2 bg-gray-100 rounded-lg text-sm"
            />
          </div>
        </div>
      </div>

      {/* Size / Scale */}
      <div className="space-y-2">
        <label className="text-sm text-gray-600">Escala</label>
        <input
          type="range"
          min="0.1"
          max="3"
          step="0.1"
          value={selectedElement.scaleX}
          onChange={(e) => handleUpdate({ scaleX: Number(e.target.value), scaleY: Number(e.target.value) })}
          className="w-full"
        />
        <div className="flex justify-between text-xs text-gray-400">
          <span>10%</span>
          <span>{Math.round(selectedElement.scaleX * 100)}%</span>
          <span>300%</span>
        </div>
      </div>

      {/* Rotation */}
      <div className="space-y-2">
        <label className="text-sm text-gray-600">Rotación</label>
        <input
          type="range"
          min="0"
          max="360"
          step="1"
          value={selectedElement.rotation}
          onChange={(e) => handleUpdate({ rotation: Number(e.target.value) })}
          className="w-full"
        />
        <div className="text-center text-xs text-gray-400">
          {Math.round(selectedElement.rotation)}°
        </div>
      </div>

      {/* Opacity */}
      <div className="space-y-2">
        <label className="text-sm text-gray-600">Opacidad</label>
        <input
          type="range"
          min="0"
          max="1"
          step="0.1"
          value={selectedElement.opacity}
          onChange={(e) => handleUpdate({ opacity: Number(e.target.value) })}
          className="w-full"
        />
      </div>

      {/* Color */}
      <div className="space-y-2">
        <label className="text-sm text-gray-600">Color</label>
        <div className="flex items-center gap-2">
          <input
            type="color"
            value={selectedElement.fill || '#000000'}
            onChange={(e) => handleUpdate({ fill: e.target.value })}
            className="w-10 h-10 rounded-lg cursor-pointer"
          />
          <input
            type="text"
            value={selectedElement.fill || '#000000'}
            onChange={(e) => handleUpdate({ fill: e.target.value })}
            className="flex-1 px-3 py-2 bg-gray-100 rounded-lg text-sm"
          />
        </div>
      </div>

      {/* Text Specific Properties */}
      {selectedElement.type === 'text' && (
        <div className="space-y-4 pt-4 border-t border-gray-200">
          <h4 className="font-medium text-sm text-gray-700">Propiedades de Texto</h4>
          
          <div className="space-y-2">
            <label className="text-sm text-gray-600">Texto</label>
            <input
              type="text"
              value={selectedElement.text || ''}
              onChange={(e) => handleUpdate({ text: e.target.value })}
              className="w-full px-3 py-2 bg-gray-100 rounded-lg text-sm"
            />
          </div>

          <div className="space-y-2">
            <label className="text-sm text-gray-600">Tamaño de Fuente</label>
            <input
              type="number"
              value={selectedElement.fontSize || 24}
              onChange={(e) => handleUpdate({ fontSize: Number(e.target.value) })}
              className="w-full px-3 py-2 bg-gray-100 rounded-lg text-sm"
              min="8"
              max="200"
            />
          </div>

          <div className="space-y-2">
            <label className="text-sm text-gray-600">Fuente</label>
            <select
              value={selectedElement.fontFamily || 'Inter'}
              onChange={(e) => handleUpdate({ fontFamily: e.target.value })}
              className="w-full px-3 py-2 bg-gray-100 rounded-lg text-sm"
            >
              <option value="Inter">Inter</option>
              <option value="Playfair Display">Playfair Display</option>
              <option value="Montserrat">Montserrat</option>
              <option value="Roboto Mono">Roboto Mono</option>
              <option value="Nunito">Nunito</option>
              <option value="Arial">Arial</option>
            </select>
          </div>
        </div>
      )}

      {/* Delete Button */}
      <button
        onClick={() => selectedElement.id && deleteElement(selectedElement.id)}
        className="w-full py-2 bg-red-50 text-red-600 rounded-lg hover:bg-red-100 transition-colors text-sm font-medium"
      >
        Eliminar Elemento
      </button>
    </div>
  );
};
