/**
 * Layers Panel Component
 * Author: T&M Technology Ec
 */

import React from 'react';
import { Layers, Eye, EyeOff, Trash2, ArrowUp, ArrowDown, Copy } from 'lucide-react';
import { useLogoStore } from '../store/logoStore';
import toast from 'react-hot-toast';

export const LayersPanel: React.FC = () => {
  const { 
    design, 
    selectElement, 
    deleteElement, 
    duplicateElement,
    moveLayerUp,
    moveLayerDown,
    updateElement
  } = useLogoStore();

  // Sort elements by zIndex (top to bottom)
  const sortedElements = [...design.elements].sort((a, b) => b.zIndex - a.zIndex);

  const toggleVisibility = (id: string, currentVisible: boolean) => {
    updateElement(id, { visible: !currentVisible });
  };

  return (
    <div className="p-4">
      {sortedElements.length === 0 ? (
        <div className="text-center py-8 text-gray-500">
          <Layers className="w-12 h-12 mx-auto mb-3 opacity-50" />
          <p className="text-sm">No hay elementos</p>
          <p className="text-xs mt-1">Agrega texto, formas o imágenes</p>
        </div>
      ) : (
        <div className="space-y-1">
          {sortedElements.map((element, index) => (
            <div
              key={element.id}
              onClick={() => selectElement(element.id)}
              className={`flex items-center gap-2 p-3 rounded-lg cursor-pointer transition-colors ${
                design.selectedElementId === element.id
                  ? 'bg-brand-100 border border-brand-200'
                  : 'hover:bg-gray-100'
              }`}
            >
              {/* Visibility Toggle */}
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  toggleVisibility(element.id, element.visible);
                }}
                className="p-1 text-gray-400 hover:text-gray-600"
              >
                {element.visible ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
              </button>

              {/* Element Info */}
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium truncate capitalize">
                  {element.type === 'text' ? (element.text || 'Texto') : element.type}
                </p>
                <p className="text-xs text-gray-500">
                  {Math.round(element.x)}, {Math.round(element.y)}
                </p>
              </div>

              {/* Actions */}
              <div className="flex items-center gap-1">
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    moveLayerUp(element.id);
                  }}
                  disabled={index === 0}
                  className="p-1 text-gray-400 hover:text-gray-600 disabled:opacity-30"
                >
                  <ArrowUp className="w-4 h-4" />
                </button>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    moveLayerDown(element.id);
                  }}
                  disabled={index === sortedElements.length - 1}
                  className="p-1 text-gray-400 hover:text-gray-600 disabled:opacity-30"
                >
                  <ArrowDown className="w-4 h-4" />
                </button>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    duplicateElement(element.id);
                    toast.success('Duplicado');
                  }}
                  className="p-1 text-gray-400 hover:text-brand-600"
                >
                  <Copy className="w-4 h-4" />
                </button>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    deleteElement(element.id);
                    toast.success('Eliminado');
                  }}
                  className="p-1 text-gray-400 hover:text-red-600"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
