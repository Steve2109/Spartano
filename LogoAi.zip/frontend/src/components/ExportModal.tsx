/**
 * Export Modal Component
 * Author: T&M Technology Ec
 */

import React, { useState } from 'react';
import { X, Download, FileImage, FileText, Check } from 'lucide-react';
import { useLogoStore } from '../store/logoStore';
import html2canvas from 'html2canvas';
import toast from 'react-hot-toast';

interface ExportModalProps {
  onClose: () => void;
}

export const ExportModal: React.FC<ExportModalProps> = ({ onClose }) => {
  const { design } = useLogoStore();
  const [format, setFormat] = useState<'png' | 'jpg' | 'svg' | 'pdf'>('png');
  const [quality, setQuality] = useState(90);
  const [transparent, setTransparent] = useState(false);
  const [isExporting, setIsExporting] = useState(false);

  const handleExport = async () => {
    setIsExporting(true);
    
    try {
      const canvas = document.querySelector('.canvas-container canvas') as HTMLCanvasElement;
      
      if (!canvas) {
        toast.error('No se encontró el canvas');
        return;
      }

      if (format === 'svg') {
        // Export as SVG
        const svgContent = generateSVG(design);
        downloadFile(svgContent, `${design.name}.svg`, 'image/svg+xml');
      } else if (format === 'pdf') {
        // Export as PDF (simplified - would need jspdf in production)
        const dataUrl = canvas.toDataURL('image/png');
        downloadFile(dataUrl, `${design.name}.png`, 'image/png');
        toast.info('PDF exportado como PNG (requiere configuración adicional)');
      } else {
        // Export as image
        const mimeType = format === 'jpg' ? 'image/jpeg' : 'image/png';
        const dataUrl = canvas.toDataURL(mimeType, quality / 100);
        downloadFile(dataUrl, `${design.name}.${format}`, mimeType);
      }

      toast.success('¡Logo exportado exitosamente!');
      onClose();
    } catch (error) {
      console.error('Export error:', error);
      toast.error('Error al exportar');
    } finally {
      setIsExporting(false);
    }
  };

  const generateSVG = (design: any) => {
    let svg = `<svg width="${design.width}" height="${design.height}" xmlns="http://www.w3.org/2000/svg">`;
    
    if (!transparent) {
      svg += `<rect width="${design.width}" height="${design.height}" fill="${design.background}"/>`;
    }

    // Sort elements by zIndex
    const sortedElements = [...design.elements].sort((a, b) => a.zIndex - b.zIndex);

    sortedElements.forEach((el) => {
      if (!el.visible) return;
      
      const transform = `translate(${el.x}, ${el.y}) rotate(${el.rotation}) scale(${el.scaleX}, ${el.scaleY})`;
      const opacity = el.opacity !== 1 ? `opacity="${el.opacity}"` : '';

      switch (el.type) {
        case 'text':
          svg += `<text transform="${transform}" ${opacity} font-family="${el.fontFamily || 'Arial'}" font-size="${el.fontSize || 24}" fill="${el.fill || '#000'}" text-anchor="${el.align === 'center' ? 'middle' : 'start'}">${escapeXml(el.text || '')}</text>`;
          break;
        case 'rect':
          svg += `<rect transform="${transform}" ${opacity} width="${el.width || 100}" height="${el.height || 100}" fill="${el.fill || '#000'}" rx="${el.radius || 0}"/>`;
          break;
        case 'circle':
          svg += `<circle transform="${transform}" ${opacity} r="${el.radius || 50}" fill="${el.fill || '#000'}"/>`;
          break;
        case 'path':
          svg += `<path transform="${transform}" ${opacity} d="${el.path || ''}" fill="${el.fill || '#000'}"/>`;
          break;
      }
    });

    svg += '</svg>';
    return svg;
  };

  const escapeXml = (unsafe: string): string => {
    return unsafe.replace(/[<>&'"]/g, (c) => {
      switch (c) {
        case '<': return '&lt;';
        case '>': return '&gt;';
        case '&': return '&amp;';
        case '"': return '&quot;';
        case "'": return '&apos;';
        default: return c;
      }
    });
  };

  const downloadFile = (data: string, filename: string, mimeType: string) => {
    const blob = new Blob([data], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const formats = [
    { id: 'png', name: 'PNG', icon: FileImage, description: 'Imagen con transparencia' },
    { id: 'jpg', name: 'JPG', icon: FileImage, description: 'Imagen comprimida' },
    { id: 'svg', name: 'SVG', icon: FileText, description: 'Vector escalable' },
    { id: 'pdf', name: 'PDF', icon: FileText, description: 'Documento PDF' },
  ];

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full overflow-hidden">
        <div className="p-6 border-b border-gray-100 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-brand-100 rounded-lg">
              <Download className="w-5 h-5 text-brand-600" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-gray-900">Exportar Logo</h2>
              <p className="text-sm text-gray-500">{design.name}</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-6">
          {/* Format Selection */}
          <div className="space-y-3">
            <label className="text-sm font-medium text-gray-700">Formato de exportación</label>
            <div className="grid grid-cols-2 gap-3">
              {formats.map((f) => {
                const Icon = f.icon;
                return (
                  <button
                    key={f.id}
                    onClick={() => setFormat(f.id as any)}
                    className={`p-4 rounded-xl border-2 transition-all text-left ${
                      format === f.id
                        ? 'border-brand-500 bg-brand-50'
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                  >
                    <Icon className={`w-6 h-6 mb-2 ${format === f.id ? 'text-brand-600' : 'text-gray-400'}`} />
                    <p className={`font-semibold ${format === f.id ? 'text-brand-700' : 'text-gray-700'}`}>
                      {f.name}
                    </p>
                    <p className="text-xs text-gray-500">{f.description}</p>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Options */}
          <div className="space-y-4">
            {(format === 'png' || format === 'jpg') && (
              <div className="space-y-2">
                <div className="flex justify-between">
                  <label className="text-sm font-medium text-gray-700">Calidad</label>
                  <span className="text-sm text-gray-500">{quality}%</span>
                </div>
                <input
                  type="range"
                  min="50"
                  max="100"
                  value={quality}
                  onChange={(e) => setQuality(Number(e.target.value))}
                  className="w-full"
                />
              </div>
            )}

            {format === 'png' && (
              <label className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg cursor-pointer">
                <input
                  type="checkbox"
                  checked={transparent}
                  onChange={(e) => setTransparent(e.target.checked)}
                  className="w-4 h-4 text-brand-600 rounded"
                />
                <span className="text-sm text-gray-700">Fondo transparente</span>
              </label>
            )}
          </div>

          {/* Info */}
          <div className="p-4 bg-blue-50 rounded-lg text-sm text-blue-700">
            <p className="font-medium mb-1">📐 Tamaño del canvas</p>
            <p>{design.width} × {design.height} px</p>
          </div>
        </div>

        <div className="p-6 border-t border-gray-100 bg-gray-50 flex gap-3">
          <button
            onClick={onClose}
            className="flex-1 py-3 px-4 bg-white border border-gray-300 text-gray-700 font-medium rounded-xl hover:bg-gray-50 transition-colors"
          >
            Cancelar
          </button>
          <button
            onClick={handleExport}
            disabled={isExporting}
            className="flex-1 py-3 px-4 bg-brand-600 text-white font-medium rounded-xl hover:bg-brand-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
          >
            {isExporting ? (
              <>
                <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                Exportando...
              </>
            ) : (
              <>
                <Check className="w-5 h-5" />
                Exportar
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
