/**
 * Shapes Panel Component
 * Author: T&M Technology Ec
 */

import React from 'react';
import { Square, Circle, Triangle, Hexagon, Star, Heart } from 'lucide-react';
import { useLogoStore } from '../store/logoStore';
import toast from 'react-hot-toast';

const shapes = [
  { id: 'rect', name: 'Rectángulo', icon: Square, color: '#3b82f6' },
  { id: 'circle', name: 'Círculo', icon: Circle, color: '#ef4444' },
  { id: 'triangle', name: 'Triángulo', icon: Triangle, color: '#10b981' },
  { id: 'hexagon', name: 'Hexágono', icon: Hexagon, color: '#f59e0b' },
  { id: 'star', name: 'Estrella', icon: Star, color: '#fbbf24' },
  { id: 'heart', name: 'Corazón', icon: Heart, color: '#ec4899' },
];

export const ShapesPanel: React.FC = () => {
  const { addElement } = useLogoStore();

  const handleAddShape = (shape: typeof shapes[0]) => {
    const commonProps = {
      x: 200,
      y: 200,
      fill: shape.color,
      opacity: 1,
      scaleX: 1,
      scaleY: 1,
      rotation: 0,
      visible: true,
    };

    switch (shape.id) {
      case 'rect':
        addElement({
          type: 'rect',
          ...commonProps,
          width: 150,
          height: 100,
          radius: 8,
        });
        break;
      case 'circle':
        addElement({
          type: 'circle',
          ...commonProps,
          radius: 75,
        });
        break;
      case 'triangle':
        addElement({
          type: 'path',
          ...commonProps,
          path: 'M75 0 L150 150 L0 150 Z',
        });
        break;
      case 'hexagon':
        addElement({
          type: 'path',
          ...commonProps,
          path: 'M75 0 L140 37 L140 112 L75 150 L10 112 L10 37 Z',
        });
        break;
      case 'star':
        addElement({
          type: 'path',
          ...commonProps,
          path: 'M75 0 L93 50 L150 50 L105 85 L120 150 L75 115 L30 150 L45 85 L0 50 L57 50 Z',
        });
        break;
      case 'heart':
        addElement({
          type: 'path',
          ...commonProps,
          path: 'M75 40 Q50 0 25 25 Q0 50 25 75 L75 140 L125 75 Q150 50 125 25 Q100 0 75 40',
        });
        break;
    }

    toast.success(`${shape.name} agregado`);
  };

  return (
    <div className="p-4 space-y-4">
      <p className="text-sm text-gray-600">
        Selecciona una forma para agregarla a tu diseño.
      </p>

      <div className="grid grid-cols-2 gap-3">
        {shapes.map((shape) => {
          const Icon = shape.icon;
          return (
            <button
              key={shape.id}
              onClick={() => handleAddShape(shape)}
              className="flex flex-col items-center gap-2 p-4 bg-gray-100 rounded-xl hover:bg-gray-200 transition-all group"
            >
              <div 
                className="p-3 rounded-lg transition-colors"
                style={{ backgroundColor: `${shape.color}20` }}
              >
                <Icon 
                  className="w-8 h-8 transition-colors"
                  style={{ color: shape.color }}
                />
              </div>
              <span className="text-sm font-medium text-gray-700 group-hover:text-gray-900">
                {shape.name}
              </span>
            </button>
          );
        })}
      </div>

      {/* Color Tips */}
      <div className="p-3 bg-green-50 rounded-lg text-sm text-green-700">
        <p className="font-medium mb-1">🎨 Personaliza:</p>
        <p>Agrega la forma y luego cambia su color, tamaño y posición desde el panel de propiedades.</p>
      </div>
    </div>
  );
};
