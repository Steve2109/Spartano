/**
 * Logo Store - Zustand state management
 * Author: T&M Technology Ec
 */

import { create } from 'zustand';
import { devtools, persist } from 'zustand/middleware';

export interface CanvasElement {
  id: string;
  type: 'text' | 'rect' | 'circle' | 'image' | 'path' | 'svg';
  x: number;
  y: number;
  width?: number;
  height?: number;
  radius?: number;
  scaleX: number;
  scaleY: number;
  rotation: number;
  opacity: number;
  visible: boolean;
  // Text properties
  text?: string;
  fontFamily?: string;
  fontSize?: number;
  fontWeight?: string;
  fontStyle?: string;
  fill?: string;
  stroke?: string;
  strokeWidth?: number;
  align?: string;
  letterSpacing?: number;
  // Image properties
  src?: string;
  // Path properties
  path?: string;
  // Layer
  zIndex: number;
}

export interface DesignState {
  id: string | null;
  name: string;
  width: number;
  height: number;
  background: string;
  elements: CanvasElement[];
  selectedElementId: string | null;
  zoom: number;
  history: DesignState[];
  historyIndex: number;
}

interface LogoStore {
  // Design state
  design: DesignState;
  
  // Actions
  setDesignName: (name: string) => void;
  setCanvasSize: (width: number, height: number) => void;
  setBackground: (color: string) => void;
  setZoom: (zoom: number) => void;
  
  // Element actions
  addElement: (element: Omit<CanvasElement, 'id' | 'zIndex'>) => void;
  updateElement: (id: string, updates: Partial<CanvasElement>) => void;
  deleteElement: (id: string) => void;
  selectElement: (id: string | null) => void;
  moveElement: (id: string, x: number, y: number) => void;
  resizeElement: (id: string, width: number, height: number) => void;
  rotateElement: (id: string, rotation: number) => void;
  bringToFront: (id: string) => void;
  sendToBack: (id: string) => void;
  
  // Layer management
  moveLayerUp: (id: string) => void;
  moveLayerDown: (id: string) => void;
  
  // History
  undo: () => void;
  redo: () => void;
  saveHistory: () => void;
  
  // Import/Export
  loadDesign: (design: Partial<DesignState>) => void;
  resetDesign: () => void;
  duplicateElement: (id: string) => void;
  
  // Template
  loadTemplate: (template: Partial<DesignState>) => void;
}

const initialState: DesignState = {
  id: null,
  name: 'Untitled Logo',
  width: 512,
  height: 512,
  background: '#ffffff',
  elements: [],
  selectedElementId: null,
  zoom: 1,
  history: [],
  historyIndex: -1,
};

export const useLogoStore = create<LogoStore>()(
  devtools(
    persist(
      (set, get) => ({
        design: initialState,

        setDesignName: (name) => {
          set((state) => ({
            design: { ...state.design, name }
          }));
        },

        setCanvasSize: (width, height) => {
          set((state) => ({
            design: { ...state.design, width, height }
          }));
          get().saveHistory();
        },

        setBackground: (background) => {
          set((state) => ({
            design: { ...state.design, background }
          }));
          get().saveHistory();
        },

        setZoom: (zoom) => {
          set((state) => ({
            design: { ...state.design, zoom: Math.max(0.1, Math.min(3, zoom)) }
          }));
        },

        addElement: (element) => {
          const newElement: CanvasElement = {
            ...element,
            id: crypto.randomUUID(),
            zIndex: get().design.elements.length,
          };
          set((state) => ({
            design: {
              ...state.design,
              elements: [...state.design.elements, newElement],
              selectedElementId: newElement.id,
            }
          }));
          get().saveHistory();
        },

        updateElement: (id, updates) => {
          set((state) => ({
            design: {
              ...state.design,
              elements: state.design.elements.map((el) =>
                el.id === id ? { ...el, ...updates } : el
              ),
            }
          }));
        },

        deleteElement: (id) => {
          set((state) => ({
            design: {
              ...state.design,
              elements: state.design.elements.filter((el) => el.id !== id),
              selectedElementId: state.design.selectedElementId === id ? null : state.design.selectedElementId,
            }
          }));
          get().saveHistory();
        },

        selectElement: (id) => {
          set((state) => ({
            design: { ...state.design, selectedElementId: id }
          }));
        },

        moveElement: (id, x, y) => {
          set((state) => ({
            design: {
              ...state.design,
              elements: state.design.elements.map((el) =>
                el.id === id ? { ...el, x, y } : el
              ),
            }
          }));
        },

        resizeElement: (id, width, height) => {
          set((state) => ({
            design: {
              ...state.design,
              elements: state.design.elements.map((el) =>
                el.id === id ? { ...el, width, height } : el
              ),
            }
          }));
        },

        rotateElement: (id, rotation) => {
          set((state) => ({
            design: {
              ...state.design,
              elements: state.design.elements.map((el) =>
                el.id === id ? { ...el, rotation } : el
              ),
            }
          }));
        },

        bringToFront: (id) => {
          const elements = get().design.elements;
          const maxZ = Math.max(...elements.map((e) => e.zIndex));
          set((state) => ({
            design: {
              ...state.design,
              elements: state.design.elements.map((el) =>
                el.id === id ? { ...el, zIndex: maxZ + 1 } : el
              ),
            }
          }));
          get().saveHistory();
        },

        sendToBack: (id) => {
          const elements = get().design.elements;
          const minZ = Math.min(...elements.map((e) => e.zIndex));
          set((state) => ({
            design: {
              ...state.design,
              elements: state.design.elements.map((el) =>
                el.id === id ? { ...el, zIndex: minZ - 1 } : el
              ),
            }
          }));
          get().saveHistory();
        },

        moveLayerUp: (id) => {
          const element = get().design.elements.find((e) => e.id === id);
          if (!element) return;
          
          const aboveElement = get().design.elements.find((e) => e.zIndex === element.zIndex + 1);
          if (aboveElement) {
            set((state) => ({
              design: {
                ...state.design,
                elements: state.design.elements.map((el) => {
                  if (el.id === id) return { ...el, zIndex: el.zIndex + 1 };
                  if (el.id === aboveElement.id) return { ...el, zIndex: el.zIndex - 1 };
                  return el;
                }),
              }
            }));
            get().saveHistory();
          }
        },

        moveLayerDown: (id) => {
          const element = get().design.elements.find((e) => e.id === id);
          if (!element) return;
          
          const belowElement = get().design.elements.find((e) => e.zIndex === element.zIndex - 1);
          if (belowElement) {
            set((state) => ({
              design: {
                ...state.design,
                elements: state.design.elements.map((el) => {
                  if (el.id === id) return { ...el, zIndex: el.zIndex - 1 };
                  if (el.id === belowElement.id) return { ...el, zIndex: el.zIndex + 1 };
                  return el;
                }),
              }
            }));
            get().saveHistory();
          }
        },

        saveHistory: () => {
          set((state) => {
            const newHistory = state.design.history.slice(0, state.design.historyIndex + 1);
            newHistory.push({ ...state.design, history: [], historyIndex: -1 });
            
            // Keep only last 50 states
            if (newHistory.length > 50) {
              newHistory.shift();
            }
            
            return {
              design: {
                ...state.design,
                history: newHistory,
                historyIndex: newHistory.length - 1,
              }
            };
          });
        },

        undo: () => {
          set((state) => {
            if (state.design.historyIndex > 0) {
              const newIndex = state.design.historyIndex - 1;
              return {
                design: {
                  ...state.design.history[newIndex],
                  history: state.design.history,
                  historyIndex: newIndex,
                }
              };
            }
            return state;
          });
        },

        redo: () => {
          set((state) => {
            if (state.design.historyIndex < state.design.history.length - 1) {
              const newIndex = state.design.historyIndex + 1;
              return {
                design: {
                  ...state.design.history[newIndex],
                  history: state.design.history,
                  historyIndex: newIndex,
                }
              };
            }
            return state;
          });
        },

        loadDesign: (design) => {
          set((state) => ({
            design: {
              ...initialState,
              ...design,
              history: [],
              historyIndex: -1,
            }
          }));
          get().saveHistory();
        },

        resetDesign: () => {
          set({ design: initialState });
          get().saveHistory();
        },

        duplicateElement: (id) => {
          const element = get().design.elements.find((e) => e.id === id);
          if (element) {
            const newElement: CanvasElement = {
              ...element,
              id: crypto.randomUUID(),
              x: element.x + 20,
              y: element.y + 20,
              zIndex: get().design.elements.length,
            };
            set((state) => ({
              design: {
                ...state.design,
                elements: [...state.design.elements, newElement],
                selectedElementId: newElement.id,
              }
            }));
            get().saveHistory();
          }
        },

        loadTemplate: (template) => {
          set((state) => ({
            design: {
              ...initialState,
              ...template,
              id: null,
              name: `${template.name || 'Template'} Design`,
              history: [],
              historyIndex: -1,
            }
          }));
          get().saveHistory();
        },
      }),
      {
        name: 'logo-ai-creator',
        partialize: (state) => ({ design: { ...state.design, history: [], historyIndex: -1 } }),
      }
    )
  )
);
