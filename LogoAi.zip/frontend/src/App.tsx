/**
 * Logo AI Creator - Main Application
 * Author: T&M Technology Ec
 */

import React, { useState, useCallback, useEffect } from 'react';
import { QueryClient, QueryClientProvider } from 'react-query';
import { Toaster, toast } from 'react-hot-toast';
import { 
  LayoutTemplate, 
  Type, 
  Shapes, 
  Image as ImageIcon, 
  Download, 
  Undo, 
  Redo,
  Settings,
  HelpCircle,
  Layers,
  Menu,
  X,
  ChevronLeft,
  ChevronRight,
  ZoomIn,
  ZoomOut,
  Grid3X3,
  Save,
  FilePlus,
  Trash2,
  Copy,
  AlignLeft,
  AlignCenter,
  AlignRight,
  AlignVerticalJustifyCenter,
  AlignHorizontalJustifyCenter,
  ArrowUp,
  ArrowDown,
  Palette,
  RotateCcw,
  Maximize,
  Wand2,
  Sparkles,
  Search,
  MousePointer2,
  Type as TypeIcon,
  Square,
  Circle,
  Triangle,
  Hexagon,
  Star,
  Heart,
  Crown,
  Zap,
  Shield,
  Globe,
  Music,
  Camera,
  Coffee,
  ShoppingBag,
  Briefcase,
  GraduationCap,
  Truck,
  Utensils,
  Home,
  Smartphone,
  Mail,
  Phone,
  Clock,
  Calendar,
  MapPin,
  Link,
  Share2,
  MoreHorizontal,
  Check,
  AlertCircle,
  Info,
  LogOut
} from 'lucide-react';

import { useLogoStore } from './store/logoStore';
import { CanvasEditor } from './components/CanvasEditor';
import { TextPanel } from './components/TextPanel';
import { ShapesPanel } from './components/ShapesPanel';
import { ImagesPanel } from './components/ImagesPanel';
import { TemplatesPanel } from './components/TemplatesPanel';
import { LayersPanel } from './components/LayersPanel';
import { PropertiesPanel } from './components/PropertiesPanel';
import { ExportModal } from './components/ExportModal';
import { NewDesignModal } from './components/NewDesignModal';

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 5 * 60 * 1000,
      retry: 1,
    },
  },
});

type PanelType = 'templates' | 'text' | 'shapes' | 'images' | 'layers' | null;

function App() {
  const [activePanel, setActivePanel] = useState<PanelType>('templates');
  const [showExportModal, setShowExportModal] = useState(false);
  const [showNewDesignModal, setShowNewDesignModal] = useState(false);
  const [showHelpModal, setShowHelpModal] = useState(false);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  
  const {
    design,
    undo,
    redo,
    saveHistory,
    setZoom,
    resetDesign,
    deleteElement,
    duplicateElement,
    bringToFront,
    sendToBack,
  } = useLogoStore();

  useEffect(() => {
    // Auto-save every 30 seconds
    const autoSave = setInterval(() => {
      saveHistory();
      toast.success('Diseño guardado automáticamente', {
        duration: 2000,
        position: 'bottom-right',
      });
    }, 30000);

    return () => clearInterval(autoSave);
  }, [saveHistory]);

  const handleKeyDown = useCallback((e: KeyboardEvent) => {
    // Keyboard shortcuts
    if ((e.ctrlKey || e.metaKey) && !e.shiftKey) {
      switch (e.key.toLowerCase()) {
        case 'z':
          e.preventDefault();
          undo();
          toast.success('Deshacer', { duration: 1000 });
          break;
        case 'y':
          e.preventDefault();
          redo();
          toast.success('Rehacer', { duration: 1000 });
          break;
        case 's':
          e.preventDefault();
          saveHistory();
          toast.success('Guardado', { duration: 1000 });
          break;
        case 'n':
          e.preventDefault();
          setShowNewDesignModal(true);
          break;
        case 'e':
          e.preventDefault();
          setShowExportModal(true);
          break;
        case 'd':
          e.preventDefault();
          if (design.selectedElementId) {
            duplicateElement(design.selectedElementId);
            toast.success('Elemento duplicado', { duration: 1000 });
          }
          break;
      }
    }
    
    if ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key.toLowerCase() === 'z') {
      e.preventDefault();
      redo();
      toast.success('Rehacer', { duration: 1000 });
    }

    if (e.key === 'Delete' || e.key === 'Backspace') {
      if (design.selectedElementId && document.activeElement?.tagName !== 'INPUT') {
        deleteElement(design.selectedElementId);
        toast.success('Elemento eliminado', { duration: 1000 });
      }
    }
  }, [undo, redo, saveHistory, design.selectedElementId, deleteElement, duplicateElement]);

  useEffect(() => {
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleKeyDown]);

  const renderPanel = () => {
    switch (activePanel) {
      case 'templates':
        return <TemplatesPanel />;
      case 'text':
        return <TextPanel />;
      case 'shapes':
        return <ShapesPanel />;
      case 'images':
        return <ImagesPanel />;
      case 'layers':
        return <LayersPanel />;
      default:
        return null;
    }
  };

  const panelItems = [
    { id: 'templates' as PanelType, icon: LayoutTemplate, label: 'Plantillas', color: 'text-purple-600', bgColor: 'bg-purple-50 hover:bg-purple-100' },
    { id: 'text' as PanelType, icon: Type, label: 'Texto', color: 'text-blue-600', bgColor: 'bg-blue-50 hover:bg-blue-100' },
    { id: 'shapes' as PanelType, icon: Shapes, label: 'Formas', color: 'text-green-600', bgColor: 'bg-green-50 hover:bg-green-100' },
    { id: 'images' as PanelType, icon: ImageIcon, label: 'Imágenes', color: 'text-orange-600', bgColor: 'bg-orange-50 hover:bg-orange-100' },
    { id: 'layers' as PanelType, icon: Layers, label: 'Capas', color: 'text-red-600', bgColor: 'bg-red-50 hover:bg-red-100' },
  ];

  return (
    <QueryClientProvider client={queryClient}>
      <div className="h-screen flex flex-col bg-gray-50">
        {/* Header */}
        <header className="h-16 bg-white border-b border-gray-200 flex items-center justify-between px-4 shadow-sm z-50">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 bg-gradient-to-br from-brand-500 to-brand-700 rounded-xl flex items-center justify-center shadow-lg">
                <Sparkles className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="font-bold text-lg text-gray-900">Logo AI Creator</h1>
                <p className="text-xs text-gray-500">by T&M Technology Ec</p>
              </div>
            </div>
            
            <div className="h-8 w-px bg-gray-200 mx-2" />
            
            <div className="flex items-center gap-2">
              <button
                onClick={() => setShowNewDesignModal(true)}
                className="flex items-center gap-2 px-3 py-2 text-sm font-medium text-gray-700 hover:bg-gray-100 rounded-lg transition-colors"
                data-tooltip="Nuevo diseño (Ctrl+N)"
              >
                <FilePlus className="w-4 h-4" />
                <span className="hidden sm:inline">Nuevo</span>
              </button>
              <button
                onClick={() => {
                  saveHistory();
                  toast.success('Guardado');
                }}
                className="flex items-center gap-2 px-3 py-2 text-sm font-medium text-gray-700 hover:bg-gray-100 rounded-lg transition-colors"
                data-tooltip="Guardar (Ctrl+S)"
              >
                <Save className="w-4 h-4" />
                <span className="hidden sm:inline">Guardar</span>
              </button>
            </div>

            <div className="h-8 w-px bg-gray-200 mx-2" />

            <div className="flex items-center gap-1">
              <button
                onClick={undo}
                disabled={design.historyIndex <= 0}
                className="p-2 text-gray-600 hover:bg-gray-100 rounded-lg transition-colors disabled:opacity-30 disabled:cursor-not-allowed"
                data-tooltip="Deshacer (Ctrl+Z)"
              >
                <Undo className="w-5 h-5" />
              </button>
              <button
                onClick={redo}
                disabled={design.historyIndex >= design.history.length - 1}
                className="p-2 text-gray-600 hover:bg-gray-100 rounded-lg transition-colors disabled:opacity-30 disabled:cursor-not-allowed"
                data-tooltip="Rehacer (Ctrl+Y)"
              >
                <Redo className="w-5 h-5" />
              </button>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1 bg-gray-100 rounded-lg p-1">
              <button
                onClick={() => setZoom(design.zoom - 0.1)}
                className="p-1.5 text-gray-600 hover:bg-white rounded-md transition-colors"
                data-tooltip="Alejar"
              >
                <ZoomOut className="w-4 h-4" />
              </button>
              <span className="text-sm font-medium text-gray-700 w-16 text-center">
                {Math.round(design.zoom * 100)}%
              </span>
              <button
                onClick={() => setZoom(design.zoom + 0.1)}
                className="p-1.5 text-gray-600 hover:bg-white rounded-md transition-colors"
                data-tooltip="Acercar"
              >
                <ZoomIn className="w-4 h-4" />
              </button>
            </div>

            <div className="h-8 w-px bg-gray-200 mx-2" />

            <button
              onClick={() => setShowExportModal(true)}
              className="flex items-center gap-2 px-4 py-2 bg-brand-600 text-white font-medium rounded-lg hover:bg-brand-700 transition-colors shadow-sm"
              data-tooltip="Exportar (Ctrl+E)"
            >
              <Download className="w-4 h-4" />
              <span className="hidden sm:inline">Exportar</span>
            </button>

            <button
              onClick={() => setShowHelpModal(true)}
              className="p-2 text-gray-600 hover:bg-gray-100 rounded-lg transition-colors ml-2"
              data-tooltip="Ayuda"
            >
              <HelpCircle className="w-5 h-5" />
            </button>
          </div>
        </header>

        {/* Main Content */}
        <div className="flex-1 flex overflow-hidden">
          {/* Sidebar */}
          <div className={`flex ${sidebarCollapsed ? 'w-16' : 'w-80'} bg-white border-r border-gray-200 transition-all duration-300`}>
            {/* Icons */}
            <div className="w-16 flex flex-col items-center py-4 gap-1 border-r border-gray-100">
              {panelItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => {
                    setActivePanel(activePanel === item.id ? null : item.id);
                    if (sidebarCollapsed) setSidebarCollapsed(false);
                  }}
                  className={`w-12 h-12 flex flex-col items-center justify-center gap-1 rounded-xl transition-all ${
                    activePanel === item.id
                      ? `${item.bgColor} ${item.color} shadow-sm`
                      : 'text-gray-500 hover:bg-gray-100'
                  }`}
                  data-tooltip={item.label}
                >
                  <item.icon className="w-5 h-5" />
                  <span className="text-[10px] font-medium">{item.label.slice(0, 4)}</span>
                </button>
              ))}
              
              <div className="flex-1" />
              
              <button
                onClick={() => setSidebarCollapsed(!sidebarCollapsed)}
                className="w-12 h-12 flex items-center justify-center text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-xl transition-all"
                data-tooltip={sidebarCollapsed ? 'Expandir' : 'Colapsar'}
              >
                {sidebarCollapsed ? <ChevronRight className="w-5 h-5" /> : <ChevronLeft className="w-5 h-5" />}
              </button>
            </div>

            {/* Panel Content */}
            {!sidebarCollapsed && activePanel && (
              <div className="flex-1 overflow-hidden flex flex-col">
                <div className="p-4 border-b border-gray-100">
                  <h2 className="font-semibold text-gray-900">
                    {panelItems.find(p => p.id === activePanel)?.label}
                  </h2>
                </div>
                <div className="flex-1 overflow-y-auto">
                  {renderPanel()}
                </div>
              </div>
            )}
          </div>

          {/* Canvas Area */}
          <div className="flex-1 flex flex-col bg-gray-100">
            {/* Toolbar */}
            <div className="h-12 bg-white border-b border-gray-200 flex items-center px-4 gap-2">
              <div className="flex items-center gap-1">
                <button
                  onClick={() => {
                    if (design.selectedElementId) {
                      bringToFront(design.selectedElementId);
                      toast.success('Traído al frente');
                    }
                  }}
                  disabled={!design.selectedElementId}
                  className="p-2 text-gray-600 hover:bg-gray-100 rounded-lg transition-colors disabled:opacity-30"
                  data-tooltip="Traer al frente"
                >
                  <ArrowUp className="w-4 h-4" />
                </button>
                <button
                  onClick={() => {
                    if (design.selectedElementId) {
                      sendToBack(design.selectedElementId);
                      toast.success('Enviado atrás');
                    }
                  }}
                  disabled={!design.selectedElementId}
                  className="p-2 text-gray-600 hover:bg-gray-100 rounded-lg transition-colors disabled:opacity-30"
                  data-tooltip="Enviar atrás"
                >
                  <ArrowDown className="w-4 h-4" />
                </button>
              </div>

              <div className="h-6 w-px bg-gray-200" />

              <div className="flex items-center gap-1">
                <button
                  onClick={() => {
                    if (design.selectedElementId) {
                      duplicateElement(design.selectedElementId);
                      toast.success('Duplicado');
                    }
                  }}
                  disabled={!design.selectedElementId}
                  className="p-2 text-gray-600 hover:bg-gray-100 rounded-lg transition-colors disabled:opacity-30"
                  data-tooltip="Duplicar (Ctrl+D)"
                >
                  <Copy className="w-4 h-4" />
                </button>
                <button
                  onClick={() => {
                    if (design.selectedElementId) {
                      deleteElement(design.selectedElementId);
                      toast.success('Eliminado');
                    }
                  }}
                  disabled={!design.selectedElementId}
                  className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors disabled:opacity-30"
                  data-tooltip="Eliminar (Delete)"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>

              <div className="h-6 w-px bg-gray-200" />

              <div className="flex items-center gap-2 text-sm text-gray-600">
                <span>{design.elements.length} elementos</span>
                <span className="text-gray-300">|</span>
                <span>{design.width} × {design.height} px</span>
              </div>
            </div>

            {/* Canvas */}
            <div className="flex-1 overflow-auto p-8">
              <CanvasEditor />
            </div>
          </div>

          {/* Properties Panel */}
          <div className="w-72 bg-white border-l border-gray-200 overflow-y-auto">
            <PropertiesPanel />
          </div>
        </div>

        {/* Footer */}
        <footer className="h-8 bg-gray-900 text-gray-400 text-xs flex items-center justify-between px-4">
          <div className="flex items-center gap-4">
            <span>Logo AI Creator v1.0.0</span>
            <span className="text-gray-600">|</span>
            <span>T&M Technology Ec</span>
            <span className="text-gray-600">|</span>
            <a href="mailto:soporte@tymtechnology.shop" className="hover:text-white transition-colors">
              soporte@tymtechnology.shop
            </a>
          </div>
          <div className="flex items-center gap-4">
            <span>© 2024 Todos los derechos reservados</span>
            <span className="text-gray-600">|</span>
            <button onClick={() => setShowHelpModal(true)} className="hover:text-white transition-colors">
              Ayuda
            </button>
          </div>
        </footer>

        {/* Modals */}
        {showExportModal && (
          <ExportModal onClose={() => setShowExportModal(false)} />
        )}
        {showNewDesignModal && (
          <NewDesignModal onClose={() => setShowNewDesignModal(false)} />
        )}
        {showHelpModal && (
          <HelpModal onClose={() => setShowHelpModal(false)} />
        )}

        {/* Toast */}
        <Toaster 
          position="bottom-right"
          toastOptions={{
            style: {
              background: '#1e293b',
              color: '#fff',
            },
          }}
        />
      </div>
    </QueryClientProvider>
  );
}

// Help Modal Component
function HelpModal({ onClose }: { onClose: () => void }) {
  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full max-h-[80vh] overflow-hidden">
        <div className="p-6 border-b border-gray-100 flex items-center justify-between">
          <h2 className="text-xl font-bold text-gray-900">Ayuda y Atajos de Teclado</h2>
          <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>
        <div className="p-6 overflow-y-auto max-h-[60vh]">
          <div className="space-y-6">
            <section>
              <h3 className="font-semibold text-gray-900 mb-3">Atajos Generales</h3>
              <div className="grid grid-cols-2 gap-2 text-sm">
                <div className="flex items-center justify-between p-2 bg-gray-50 rounded">
                  <span>Nuevo diseño</span>
                  <kbd className="px-2 py-1 bg-white border rounded text-xs">Ctrl+N</kbd>
                </div>
                <div className="flex items-center justify-between p-2 bg-gray-50 rounded">
                  <span>Guardar</span>
                  <kbd className="px-2 py-1 bg-white border rounded text-xs">Ctrl+S</kbd>
                </div>
                <div className="flex items-center justify-between p-2 bg-gray-50 rounded">
                  <span>Exportar</span>
                  <kbd className="px-2 py-1 bg-white border rounded text-xs">Ctrl+E</kbd>
                </div>
                <div className="flex items-center justify-between p-2 bg-gray-50 rounded">
                  <span>Deshacer</span>
                  <kbd className="px-2 py-1 bg-white border rounded text-xs">Ctrl+Z</kbd>
                </div>
                <div className="flex items-center justify-between p-2 bg-gray-50 rounded">
                  <span>Rehacer</span>
                  <kbd className="px-2 py-1 bg-white border rounded text-xs">Ctrl+Y</kbd>
                </div>
              </div>
            </section>

            <section>
              <h3 className="font-semibold text-gray-900 mb-3">Edición de Elementos</h3>
              <div className="grid grid-cols-2 gap-2 text-sm">
                <div className="flex items-center justify-between p-2 bg-gray-50 rounded">
                  <span>Duplicar elemento</span>
                  <kbd className="px-2 py-1 bg-white border rounded text-xs">Ctrl+D</kbd>
                </div>
                <div className="flex items-center justify-between p-2 bg-gray-50 rounded">
                  <span>Eliminar elemento</span>
                  <kbd className="px-2 py-1 bg-white border rounded text-xs">Delete</kbd>
                </div>
              </div>
            </section>

            <section>
              <h3 className="font-semibold text-gray-900 mb-3">Contacto</h3>
              <p className="text-gray-600 text-sm">
                Para soporte técnico o consultas, contacta a:
              </p>
              <a 
                href="mailto:soporte@tymtechnology.shop" 
                className="text-brand-600 hover:text-brand-700 font-medium"
              >
                soporte@tymtechnology.shop
              </a>
            </section>
          </div>
        </div>
        <div className="p-6 border-t border-gray-100 bg-gray-50">
          <button 
            onClick={onClose}
            className="w-full py-2 bg-brand-600 text-white rounded-lg hover:bg-brand-700 transition-colors font-medium"
          >
            Entendido
          </button>
        </div>
      </div>
    </div>
  );
}

export default App;
