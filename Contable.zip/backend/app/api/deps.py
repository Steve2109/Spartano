"""
Dependencies para FastAPI.
Autenticación, autorización, rate limiting.
"""
from fastapi import Depends, HTTPException, status, Request
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from sqlalchemy.orm import Session
from typing import Optional, Generator
from jose import JWTError

from app.db.base import get_db, SessionLocal
from app.core.security import decode_token, limiter
from app.core.config import settings
from app.models.usuario import Usuario

# Esquema de seguridad HTTP Bearer
security = HTTPBearer()


def get_current_user(
    db: Session = Depends(get_db),
    credentials: HTTPAuthorizationCredentials = Depends(security)
) -> Usuario:
    """
    Dependency que obtiene el usuario actual desde el token JWT.
    """
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Credenciales inválidas",
        headers={"WWW-Authenticate": "Bearer"},
    )
    
    token = credentials.credentials
    payload = decode_token(token)
    
    if payload is None:
        raise credentials_exception
    
    user_id: Optional[int] = payload.get("sub")
    token_type: Optional[str] = payload.get("type")
    
    if user_id is None or token_type != "access":
        raise credentials_exception
    
    user = db.query(Usuario).filter(Usuario.id == user_id).first()
    
    if user is None:
        raise credentials_exception
    
    if not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Usuario inactivo"
        )
    
    return user


def get_current_active_user(
    current_user: Usuario = Depends(get_current_user)
) -> Usuario:
    """Verifica que el usuario esté activo."""
    if not current_user.is_active:
        raise HTTPException(status_code=400, detail="Usuario inactivo")
    return current_user


def get_current_superuser(
    current_user: Usuario = Depends(get_current_user)
) -> Usuario:
    """Verifica que el usuario sea superadmin."""
    if not current_user.is_superuser:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Se requieren permisos de superadmin"
        )
    return current_user


class PermisoChecker:
    """Dependency factory para verificar permisos específicos."""
    
    def __init__(self, permiso: str):
        self.permiso = permiso
    
    def __call__(
        self,
        empresa_id: int,
        current_user: Usuario = Depends(get_current_user),
        db: Session = Depends(get_db)
    ) -> bool:
        """Verifica si el usuario tiene el permiso en la empresa."""
        if current_user.is_superuser:
            return True
        
        # Verificar si pertenece a la empresa
        empresa_ids = [e.id for e in current_user.empresas]
        if empresa_id not in empresa_ids:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="No tiene acceso a esta empresa"
            )
        
        # Verificar permiso específico
        if not current_user.tiene_permiso(empresa_id, self.permiso):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Requiere permiso: {self.permiso}"
            )
        
        return True


# Dependency para tenant/empresa
async def get_tenant_empresa(
    empresa_id: Optional[int] = None,
    current_user: Usuario = Depends(get_current_user)
) -> Optional[int]:
    """
    Obtiene el ID de empresa (tenant) actual.
    Verifica que el usuario tenga acceso.
    """
    if empresa_id is None:
        # Si no se especifica, usar la primera empresa del usuario
        if current_user.empresas:
            return current_user.empresas[0].id
        return None
    
    # Verificar acceso
    empresa_ids = [e.id for e in current_user.empresas]
    if empresa_id not in empresa_ids and not current_user.is_superuser:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="No tiene acceso a esta empresa"
        )
    
    return empresa_id


# Rate limiting dependency
async def rate_limit_dependency(request: Request):
    """Dependency para aplicar rate limiting."""
    # La limitación real se maneja por el decorador @limiter.limit()
    # Esta función es para compatibilidad con Depends
    pass


# Database session para contextos no-FastAPI
def get_db_context() -> Generator[Session, None, None]:
    """Context manager para obtener sesión de DB."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
