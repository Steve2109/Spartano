"""
Router principal de la API v1.
"""
from fastapi import APIRouter

from app.api.v1.endpoints import auth, sri, empresas, uploads

api_router = APIRouter()

# Endpoints de autenticación
api_router.include_router(auth.router, prefix="/auth", tags=["Autenticación"])

# Endpoints de consulta SRI
api_router.include_router(sri.router, prefix="/sri", tags=["SRI - Consultas"])

# Endpoints de empresas
api_router.include_router(empresas.router, prefix="/empresas", tags=["Empresas"])

# Endpoints de archivos y seguridad
api_router.include_router(uploads.router, prefix="/uploads", tags=["Archivos y Seguridad"])

# Aquí se agregarían más routers:
# api_router.include_router(facturas.router, prefix="/facturas", tags=["Facturación"])
# api_router.include_router(productos.router, prefix="/productos", tags=["Productos"])
# api_router.include_router(inventario.router, prefix="/inventario", tags=["Inventario"])
# api_router.include_router(contabilidad.router, prefix="/contabilidad", tags=["Contabilidad"])
# api_router.include_router(reportes.router, prefix="/reportes", tags=["Reportes"])
# api_router.include_router(dashboard.router, prefix="/dashboard", tags=["Dashboard"])
