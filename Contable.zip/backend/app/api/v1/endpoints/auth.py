"""
Endpoints de autenticación.
"""
from datetime import timedelta
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, status, Request, Response
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from sqlalchemy.orm import Session
from slowapi import Limiter
from slowapi.util import get_remote_address

from app.api.deps import get_db, get_current_user
from app.core.security import (
    create_access_token, create_refresh_token, verify_password, 
    get_password_hash, decode_token, limiter
)
from app.core.config import settings
from app.models.usuario import Usuario, SesionUsuario
from app.schemas.usuario import (
    UsuarioCreate, Usuario, Token, LoginRequest, 
    RefreshRequest, PasswordChangeRequest, PasswordResetRequest
)
from app.core.security import sanitize_input, validate_email

router = APIRouter()
security = HTTPBearer()


@router.post("/register", response_model=Usuario, status_code=status.HTTP_201_CREATED)
@limiter.limit("5/hour")  # Rate limiting para registro
async def register(
    request: Request,
    user_data: UsuarioCreate,
    db: Session = Depends(get_db)
) -> Any:
    """
    Registrar un nuevo usuario.
    Rate limit: 5 registros por hora por IP.
    """
    # Sanitizar inputs
    user_data.nombres = sanitize_input(user_data.nombres)
    user_data.apellidos = sanitize_input(user_data.apellidos)
    
    # Verificar email único
    if db.query(Usuario).filter(Usuario.email == user_data.email).first():
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Email ya registrado"
        )
    
    # Verificar cédula única si se proporciona
    if user_data.cedula:
        if db.query(Usuario).filter(Usuario.cedula == user_data.cedula).first():
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Cédula ya registrada"
            )
    
    # Crear usuario
    db_user = Usuario(
        email=user_data.email,
        hashed_password=get_password_hash(user_data.password),
        nombres=user_data.nombres,
        apellidos=user_data.apellidos,
        cedula=user_data.cedula,
        telefono=user_data.telefono,
        direccion=user_data.direccion,
        idioma=user_data.idioma,
        tema=user_data.tema,
    )
    
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    
    return db_user


@router.post("/login", response_model=Token)
@limiter.limit("10/minute")  # Rate limiting para login
async def login(
    request: Request,
    credentials: LoginRequest,
    db: Session = Depends(get_db)
) -> Any:
    """
    Iniciar sesión y obtener tokens.
    Rate limit: 10 intentos por minuto.
    """
    # Buscar usuario
    user = db.query(Usuario).filter(Usuario.email == credentials.email).first()
    
    if not user or not verify_password(credentials.password, user.hashed_password):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Email o contraseña incorrectos",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    if not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Usuario desactivado"
        )
    
    # Crear tokens
    access_token_expires = timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = create_access_token(
        data={"sub": user.id}, expires_delta=access_token_expires
    )
    refresh_token = create_refresh_token(data={"sub": user.id})
    
    # Registrar sesión
    client_ip = request.client.host if request.client else None
    user_agent = request.headers.get("user-agent")
    
    sesion = SesionUsuario(
        usuario_id=user.id,
        ip_address=client_ip,
        user_agent=user_agent,
    )
    db.add(sesion)
    db.commit()
    
    return {
        "access_token": access_token,
        "refresh_token": refresh_token,
        "token_type": "bearer",
        "expires_in": settings.ACCESS_TOKEN_EXPIRE_MINUTES * 60
    }


@router.post("/refresh", response_model=Token)
async def refresh_token(
    refresh_data: RefreshRequest,
    db: Session = Depends(get_db)
) -> Any:
    """
    Refrescar token de acceso usando refresh token.
    """
    payload = decode_token(refresh_data.refresh_token)
    
    if payload is None or payload.get("type") != "refresh":
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Refresh token inválido",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    user_id = payload.get("sub")
    user = db.query(Usuario).filter(Usuario.id == user_id).first()
    
    if not user or not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Usuario no encontrado o inactivo"
        )
    
    # Crear nuevos tokens
    access_token_expires = timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = create_access_token(
        data={"sub": user.id}, expires_delta=access_token_expires
    )
    new_refresh_token = create_refresh_token(data={"sub": user.id})
    
    return {
        "access_token": access_token,
        "refresh_token": new_refresh_token,
        "token_type": "bearer",
        "expires_in": settings.ACCESS_TOKEN_EXPIRE_MINUTES * 60
    }


@router.post("/logout")
async def logout(
    credentials: HTTPAuthorizationCredentials = Depends(security),
    current_user: Usuario = Depends(get_current_user),
    db: Session = Depends(get_db)
) -> Any:
    """
    Cerrar sesión (invalidar token actual).
    """
    # En implementación stateless, el cliente debe eliminar el token
    # Aquí podríamos agregar a lista negra si usamos Redis
    
    # Invalidar sesiones activas del usuario
    db.query(SesionUsuario).filter(
        SesionUsuario.usuario_id == current_user.id,
        SesionUsuario.activa == True
    ).update({"activa": False})
    db.commit()
    
    return {"message": "Sesión cerrada exitosamente"}


@router.get("/me", response_model=Usuario)
async def get_me(
    current_user: Usuario = Depends(get_current_user)
) -> Any:
    """
    Obtener información del usuario autenticado.
    """
    return current_user


@router.put("/me", response_model=Usuario)
async def update_me(
    user_update: Any,  # UsuarioUpdate
    current_user: Usuario = Depends(get_current_user),
    db: Session = Depends(get_db)
) -> Any:
    """
    Actualizar perfil del usuario.
    """
    update_data = user_update.dict(exclude_unset=True)
    
    # Sanitizar
    for field in ['nombres', 'apellidos', 'direccion']:
        if field in update_data and update_data[field]:
            update_data[field] = sanitize_input(update_data[field])
    
    for field, value in update_data.items():
        setattr(current_user, field, value)
    
    db.commit()
    db.refresh(current_user)
    
    return current_user


@router.post("/change-password")
async def change_password(
    password_data: PasswordChangeRequest,
    current_user: Usuario = Depends(get_current_user),
    db: Session = Depends(get_db)
) -> Any:
    """
    Cambiar contraseña del usuario.
    """
    # Verificar contraseña actual
    if not verify_password(password_data.current_password, current_user.hashed_password):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Contraseña actual incorrecta"
        )
    
    # Actualizar
    current_user.hashed_password = get_password_hash(password_data.new_password)
    db.commit()
    
    return {"message": "Contraseña actualizada exitosamente"}


@router.post("/password-reset-request")
@limiter.limit("3/hour")
async def request_password_reset(
    request: Request,
    reset_request: PasswordResetRequest,
    db: Session = Depends(get_db)
) -> Any:
    """
    Solicitar reset de contraseña.
    Rate limit: 3 solicitudes por hora.
    """
    user = db.query(Usuario).filter(Usuario.email == reset_request.email).first()
    
    if user:
        # Aquí se enviaría email con token
        # Por seguridad, no revelar si el email existe
        pass
    
    # Siempre retornar éxito (no revelar si el email existe)
    return {"message": "Si el email existe, recibirás instrucciones"}
