"""
Endpoints de gestión de empresas.
"""
from typing import Any, List, Optional
from fastapi import APIRouter, Depends, HTTPException, status, UploadFile, File, Form
from sqlalchemy.orm import Session
from datetime import datetime
import shutil
import os
from pathlib import Path

from app.api.deps import get_db, get_current_user, get_current_superuser
from app.core.config import settings
from app.core.security import validate_ruc, sanitize_input
from app.models.empresa import Empresa, Sucursal
from app.models.usuario import Usuario, usuario_empresa
from app.schemas.empresa import (
    EmpresaCreate, Empresa, EmpresaUpdate, 
    SucursalCreate, Sucursal, EmpresaConSucursales
)
from app.services.sri_service import sri_service
from app.services.file_scanner import file_scanner

router = APIRouter()


@router.post("/", response_model=Empresa, status_code=status.HTTP_201_CREATED)
async def create_empresa(
    empresa_data: EmpresaCreate,
    db: Session = Depends(get_db),
    current_user: Usuario = Depends(get_current_user)
) -> Any:
    """
    Crear una nueva empresa.
    """
    # Verificar RUC único
    if db.query(Empresa).filter(Empresa.ruc == empresa_data.ruc).first():
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="RUC ya registrado"
        )
    
    # Crear empresa
    db_empresa = Empresa(
        ruc=empresa_data.ruc,
        razon_social=sanitize_input(empresa_data.razon_social),
        nombre_comercial=sanitize_input(empresa_data.nombre_comercial),
        direccion_matriz=sanitize_input(empresa_data.direccion_matriz),
        direccion_establecimiento=sanitize_input(empresa_data.direccion_establecimiento),
        email=empresa_data.email,
        telefono=empresa_data.telefono,
        celular=empresa_data.celular,
        obligado_contabilidad=empresa_data.obligado_contabilidad,
        contribuyente_especial=empresa_data.contribuyente_especial,
        tipo_regimen=empresa_data.tipo_regimen,
        agente_retencion=empresa_data.agente_retencion,
        numero_resolucion_agente=empresa_data.numero_resolucion_agente,
        creado_por_id=current_user.id,
        configuracion=empresa_data.configuracion or {}
    )
    
    db.add(db_empresa)
    db.commit()
    db.refresh(db_empresa)
    
    # Asociar usuario creador como admin
    from sqlalchemy import insert
    db.execute(
        insert(usuario_empresa).values(
            usuario_id=current_user.id,
            empresa_id=db_empresa.id,
            rol="admin",
            permisos='["*"]',
            activo=True
        )
    )
    db.commit()
    
    # Crear sucursal matriz por defecto
    sucursal_matriz = Sucursal(
        empresa_id=db_empresa.id,
        codigo="001",
        nombre="MATRIZ",
        direccion=empresa_data.direccion_matriz,
        telefono=empresa_data.telefono,
        email=empresa_data.email
    )
    db.add(sucursal_matriz)
    db.commit()
    
    return db_empresa


@router.get("/", response_model=List[Empresa])
async def list_empresas(
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db),
    current_user: Usuario = Depends(get_current_user)
) -> Any:
    """
    Listar empresas del usuario actual.
    """
    if current_user.is_superuser:
        empresas = db.query(Empresa).offset(skip).limit(limit).all()
    else:
        empresas = current_user.empresas
    
    return empresas


@router.get("/{empresa_id}", response_model=EmpresaConSucursales)
async def get_empresa(
    empresa_id: int,
    db: Session = Depends(get_db),
    current_user: Usuario = Depends(get_current_user)
) -> Any:
    """
    Obtener detalle de una empresa.
    """
    empresa = db.query(Empresa).filter(Empresa.id == empresa_id).first()
    
    if not empresa:
        raise HTTPException(status_code=404, detail="Empresa no encontrada")
    
    # Verificar acceso
    if not current_user.is_superuser:
        empresa_ids = [e.id for e in current_user.empresas]
        if empresa_id not in empresa_ids:
            raise HTTPException(status_code=403, detail="Sin acceso a esta empresa")
    
    return empresa


@router.put("/{empresa_id}", response_model=Empresa)
async def update_empresa(
    empresa_id: int,
    empresa_update: EmpresaUpdate,
    db: Session = Depends(get_db),
    current_user: Usuario = Depends(get_current_user)
) -> Any:
    """
    Actualizar datos de empresa.
    """
    empresa = db.query(Empresa).filter(Empresa.id == empresa_id).first()
    
    if not empresa:
        raise HTTPException(status_code=404, detail="Empresa no encontrada")
    
    # Verificar permisos
    if not current_user.is_superuser:
        if not current_user.tiene_permiso(empresa_id, "empresa.editar"):
            raise HTTPException(status_code=403, detail="Sin permisos para editar")
    
    update_data = empresa_update.dict(exclude_unset=True)
    
    # Sanitizar
    for field in ['razon_social', 'nombre_comercial', 'direccion_matriz', 'direccion_establecimiento']:
        if field in update_data and update_data[field]:
            update_data[field] = sanitize_input(update_data[field])
    
    for field, value in update_data.items():
        setattr(empresa, field, value)
    
    db.commit()
    db.refresh(empresa)
    
    return empresa


@router.post("/{empresa_id}/firma")
async def upload_firma_electronica(
    empresa_id: int,
    firma_file: UploadFile = File(...),
    fecha_validez: str = Form(...),
    emitido_por: str = Form(None),
    db: Session = Depends(get_db),
    current_user: Usuario = Depends(get_current_user)
) -> Any:
    """
    Subir firma electrónica (.p12).
    
    **IMPORTANTE**: La contraseña de la firma debe guardarse en el archivo .env,
    nunca en la base de datos. Esta ruta solo guarda el archivo.
    
    El archivo se guarda en: uploads/firmas/{empresa_id}/
    """
    empresa = db.query(Empresa).filter(Empresa.id == empresa_id).first()
    
    if not empresa:
        raise HTTPException(status_code=404, detail="Empresa no encontrada")
    
    # Verificar permisos
    if not current_user.is_superuser:
        if not current_user.tiene_permiso(empresa_id, "empresa.admin"):
            raise HTTPException(status_code=403, detail="Sin permisos")
    
    # Validar extensión
    if not firma_file.filename.endswith('.p12'):
        raise HTTPException(status_code=400, detail="Solo se permiten archivos .p12")
    
    # Verificar tamaño
    contents = await firma_file.read()
    if len(contents) > settings.MAX_UPLOAD_SIZE:
        raise HTTPException(status_code=400, detail="Archivo demasiado grande")
    
    # Crear directorio
    upload_dir = Path(settings.UPLOAD_DIR) / "firmas" / str(empresa_id)
    upload_dir.mkdir(parents=True, exist_ok=True)
    
    # Guardar archivo
    file_path = upload_dir / f"firma_{empresa.ruc}.p12"
    with open(file_path, "wb") as f:
        f.write(contents)
    
    # Actualizar empresa
    empresa.firma_electronica_path = str(file_path)
    empresa.firma_electronica_validez = datetime.fromisoformat(fecha_validez) if fecha_validez else None
    empresa.firma_electronica_emitido_por = emitido_por
    
    db.commit()
    
    return {
        "message": "Firma electrónica guardada exitosamente",
        "path": str(file_path),
        "validez": fecha_validez,
        "instruccion": f"Para completar la configuración, agregue al .env: EMPRESA_{empresa_id}_FIRMA_PASSWORD=tu_clave"
    }


@router.post("/{empresa_id}/logo")
async def upload_logo(
    empresa_id: int,
    logo_file: UploadFile = File(...),
    db: Session = Depends(get_db),
    current_user: Usuario = Depends(get_current_user)
) -> Any:
    """
    Subir logo de la empresa.
    """
    empresa = db.query(Empresa).filter(Empresa.id == empresa_id).first()
    
    if not empresa:
        raise HTTPException(status_code=404, detail="Empresa no encontrada")
    
    # Validar tipo
    allowed_types = ['image/jpeg', 'image/png', 'image/gif']
    if logo_file.content_type not in allowed_types:
        raise HTTPException(status_code=400, detail="Solo imágenes JPEG, PNG o GIF")
    
    # Guardar
    upload_dir = Path(settings.UPLOAD_DIR) / "logos"
    upload_dir.mkdir(parents=True, exist_ok=True)
    
    ext = logo_file.filename.split('.')[-1]
    file_path = upload_dir / f"logo_{empresa_id}.{ext}"
    
    contents = await logo_file.read()
    with open(file_path, "wb") as f:
        f.write(contents)
    
    empresa.logo_path = str(file_path)
    db.commit()
    
    return {"message": "Logo guardado", "path": str(file_path)}


@router.get("/{empresa_id}/sri-sync")
async def sync_with_sri(
    empresa_id: int,
    db: Session = Depends(get_db),
    current_user: Usuario = Depends(get_current_user)
) -> Any:
    """
    Sincronizar datos de empresa con información del SRI.
    """
    empresa = db.query(Empresa).filter(Empresa.id == empresa_id).first()
    
    if not empresa:
        raise HTTPException(status_code=404, detail="Empresa no encontrada")
    
    # Consultar SRI
    sri_data = await sri_service.consultar_ruc(empresa.ruc)
    
    if not sri_data:
        raise HTTPException(status_code=404, detail="No se pudo obtener datos del SRI")
    
    # Actualizar campos automáticamente
    if sri_data.get("razon_social"):
        empresa.razon_social = sri_data["razon_social"]
    if sri_data.get("nombre_comercial"):
        empresa.nombre_comercial = sri_data["nombre_comercial"]
    if sri_data.get("direccion"):
        empresa.direccion_matriz = sri_data["direccion"]
    
    empresa.obligado_contabilidad = sri_data.get("obligado_contabilidad", empresa.obligado_contabilidad)
    empresa.contribuyente_especial = sri_data.get("contribuyente_especial")
    empresa.certificada_sri = True
    
    db.commit()
    
    return {
        "message": "Datos sincronizados con SRI",
        "empresa": empresa,
        "sri_data": sri_data
    }


# ============ SUCURSALES ============

@router.post("/{empresa_id}/sucursales", response_model=Sucursal)
async def create_sucursal(
    empresa_id: int,
    sucursal_data: SucursalCreate,
    db: Session = Depends(get_db),
    current_user: Usuario = Depends(get_current_user)
) -> Any:
    """
    Crear una nueva sucursal.
    """
    empresa = db.query(Empresa).filter(Empresa.id == empresa_id).first()
    
    if not empresa:
        raise HTTPException(status_code=404, detail="Empresa no encontrada")
    
    # Verificar código único
    if db.query(Sucursal).filter(
        Sucursal.empresa_id == empresa_id,
        Sucursal.codigo == sucursal_data.codigo
    ).first():
        raise HTTPException(status_code=400, detail="Código de sucursal ya existe")
    
    sucursal = Sucursal(
        empresa_id=empresa_id,
        codigo=sucursal_data.codigo,
        nombre=sucursal_data.nombre,
        direccion=sucursal_data.direccion,
        telefono=sucursal_data.telefono,
        email=sucursal_data.email,
        serie_factura=sucursal_data.serie_factura,
        serie_nota_credito=sucursal_data.serie_nota_credito,
        serie_nota_debito=sucursal_data.serie_nota_debito,
        serie_retencion=sucursal_data.serie_retencion,
        serie_guia=sucursal_data.serie_guia
    )
    
    db.add(sucursal)
    db.commit()
    db.refresh(sucursal)
    
    return sucursal


@router.get("/{empresa_id}/sucursales", response_model=List[Sucursal])
async def list_sucursales(
    empresa_id: int,
    db: Session = Depends(get_db),
    current_user: Usuario = Depends(get_current_user)
) -> Any:
    """
    Listar sucursales de una empresa.
    """
    empresa = db.query(Empresa).filter(Empresa.id == empresa_id).first()
    
    if not empresa:
        raise HTTPException(status_code=404, detail="Empresa no encontrada")
    
    return empresa.sucursales
