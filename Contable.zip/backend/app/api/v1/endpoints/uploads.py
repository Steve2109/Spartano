"""
Endpoints para subida de archivos con escaneo de seguridad.
"""
from typing import Any, Optional
from fastapi import APIRouter, Depends, HTTPException, status, UploadFile, File, Form, Query
from sqlalchemy.orm import Session
from pathlib import Path
import shutil
import os
from datetime import datetime

from app.api.deps import get_db, get_current_user
from app.services.file_scanner import file_scanner
from app.models.backup_config import FileScanResult
from app.models.usuario import Usuario
from app.core.config import settings

router = APIRouter()


@router.post("/scan")
async def scan_upload(
    file: UploadFile = File(...),
    use_virustotal: bool = Query(default=False, description="Usar VirusTotal como segunda capa"),
    empresa_id: Optional[int] = Form(None),
    db: Session = Depends(get_db),
    current_user: Usuario = Depends(get_current_user)
) -> Any:
    """
    Subir y escanear archivo por malware.
    
    - **ClamAV**: Escaneo obligatorio si está habilitado
    - **VirusTotal**: Opcional, usar solo cuando sea necesario
    
    Si el archivo contiene malware, se rechaza inmediatamente.
    """
    # Validar extensión
    if not file_scanner.is_safe_extension(file.filename):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Extensión de archivo no permitida. Extensiones peligrosas detectadas."
        )
    
    # Verificar tamaño
    contents = await file.read()
    if len(contents) > settings.MAX_UPLOAD_SIZE:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Archivo excede el tamaño máximo de {settings.MAX_UPLOAD_SIZE} bytes"
        )
    
    # Guardar temporalmente
    temp_dir = Path(settings.UPLOAD_DIR) / "temp"
    temp_dir.mkdir(parents=True, exist_ok=True)
    
    temp_path = temp_dir / f"scan_{current_user.id}_{datetime.now().timestamp()}_{file.filename}"
    
    with open(temp_path, "wb") as f:
        f.write(contents)
    
    try:
        # Escanear
        scan_result = await file_scanner.scan_file(
            str(temp_path),
            use_virustotal=use_virustotal
        )
        
        # Guardar resultado en BD
        db_result = FileScanResult(
            empresa_id=empresa_id,
            nombre_original=file.filename,
            nombre_almacenado=temp_path.name,
            ruta_archivo=str(temp_path),
            tamano_bytes=len(contents),
            mime_type=file.content_type,
            checksum_sha256=scan_result["checksum_sha256"],
            clamav_escaneado=scan_result["clamav"]["escaneado"],
            clamav_limpio=scan_result["clamav"]["limpio"],
            clamav_malware_detectado=scan_result["clamav"]["malware_detectado"],
            clamav_nombre_virus=scan_result["clamav"]["nombre_virus"],
            clamav_version=scan_result["clamav"]["version"],
            vt_escaneado=scan_result["virustotal"]["escaneado"],
            vt_api_used=scan_result["virustotal"]["api_usada"],
            vt_positives=scan_result["virustotal"]["positives"],
            vt_total=scan_result["virustotal"]["total"],
            archivo_aceptado=scan_result["aprobado"],
            motivo_rechazo=scan_result["motivo_rechazo"],
            subido_por_id=current_user.id
        )
        db.add(db_result)
        db.commit()
        
        # Si fue rechazado, eliminar archivo
        if not scan_result["aprobado"]:
            os.remove(temp_path)
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=scan_result["motivo_rechazo"]
            )
        
        # Mover a directorio definitivo
        final_dir = Path(settings.UPLOAD_DIR) / "scanned" / str(empresa_id or "general")
        final_dir.mkdir(parents=True, exist_ok=True)
        
        final_path = final_dir / temp_path.name
        shutil.move(str(temp_path), str(final_path))
        
        # Actualizar ruta en BD
        db_result.ruta_archivo = str(final_path)
        db.commit()
        
        return {
            "status": "success",
            "message": "Archivo escaneado y aceptado",
            "file_id": db_result.id,
            "filename": file.filename,
            "size_bytes": len(contents),
            "scan_results": {
                "clamav": {
                    "escaneado": scan_result["clamav"]["escaneado"],
                    "limpio": scan_result["clamav"]["limpio"]
                },
                "virustotal": {
                    "escaneado": scan_result["virustotal"]["escaneado"],
                    "positives": scan_result["virustotal"]["positives"]
                }
            },
            "stored_path": str(final_path)
        }
        
    except HTTPException:
        raise
    except Exception as e:
        # Limpieza
        if temp_path.exists():
            os.remove(temp_path)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error durante el escaneo: {str(e)}"
        )


@router.post("/import-excel")
async def import_excel(
    file: UploadFile = File(...),
    tipo: str = Form(..., description="productos, clientes, proveedores, inventario"),
    empresa_id: int = Form(...),
    db: Session = Depends(get_db),
    current_user: Usuario = Depends(get_current_user)
) -> Any:
    """
    Importar datos desde Excel.
    
    El archivo se escanea automáticamente antes de procesar.
    """
    # Validar tipo
    tipos_validos = ["productos", "clientes", "proveedores", "inventario", "plan_cuentas"]
    if tipo not in tipos_validos:
        raise HTTPException(
            status_code=400,
            detail=f"Tipo inválido. Opciones: {', '.join(tipos_validos)}"
        )
    
    # Validar extensión
    if not file.filename.endswith(('.xlsx', '.xls', '.csv')):
        raise HTTPException(status_code=400, detail="Solo archivos Excel o CSV")
    
    # 1. Escanear primero
    contents = await file.read()
    
    temp_dir = Path(settings.UPLOAD_DIR) / "temp"
    temp_dir.mkdir(parents=True, exist_ok=True)
    temp_path = temp_dir / f"import_{current_user.id}_{file.filename}"
    
    with open(temp_path, "wb") as f:
        f.write(contents)
    
    scan_result = await file_scanner.scan_file(str(temp_path))
    
    if not scan_result["aprobado"]:
        os.remove(temp_path)
        raise HTTPException(status_code=400, detail=f"Archivo rechazado: {scan_result['motivo_rechazo']}")
    
    # 2. Procesar según tipo
    try:
        # Aquí iría la lógica de importación específica
        # Por ahora, simulamos el resultado
        
        result = {
            "status": "success",
            "tipo": tipo,
            "empresa_id": empresa_id,
            "registros_procesados": 0,
            "registros_exitosos": 0,
            "errores": []
        }
        
        # Limpiar temp
        os.remove(temp_path)
        
        return result
        
    except Exception as e:
        if temp_path.exists():
            os.remove(temp_path)
        raise HTTPException(status_code=500, detail=f"Error en importación: {str(e)}")


@router.get("/scan-history")
async def get_scan_history(
    empresa_id: Optional[int] = None,
    skip: int = 0,
    limit: int = 50,
    db: Session = Depends(get_db),
    current_user: Usuario = Depends(get_current_user)
) -> Any:
    """
    Obtener historial de escaneo de archivos.
    """
    query = db.query(FileScanResult)
    
    if empresa_id:
        query = query.filter(FileScanResult.empresa_id == empresa_id)
    
    # Filtrar por permisos
    if not current_user.is_superuser:
        empresa_ids = [e.id for e in current_user.empresas]
        if empresa_id and empresa_id not in empresa_ids:
            raise HTTPException(status_code=403, detail="Sin acceso")
        query = query.filter(FileScanResult.empresa_id.in_(empresa_ids))
    
    results = query.order_by(FileScanResult.creado_en.desc()).offset(skip).limit(limit).all()
    
    return {
        "total": query.count(),
        "results": results,
        "skip": skip,
        "limit": limit
    }
