"""
Endpoints para consultas al SRI Ecuador.
"""
from typing import Any, Optional
from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.orm import Session

from app.api.deps import get_db, get_current_user
from app.services.sri_service import sri_service
from app.models.usuario import Usuario
from app.schemas.usuario import SRIContribuyenteResponse
from app.schemas.empresa import SRIEmpresaData

router = APIRouter()


@router.get("/consultar-ruc", response_model=SRIEmpresaData)
async def consultar_ruc(
    ruc: str = Query(..., min_length=13, max_length=13, description="RUC ecuatoriano"),
    current_user: Usuario = Depends(get_current_user)
) -> Any:
    """
    Consulta datos de un contribuyente por RUC en el SRI.
    
    - **ruc**: Número de RUC de 13 dígitos
    
    Retorna datos como razón social, nombre comercial, estado, establecimientos.
    """
    data = await sri_service.consultar_ruc(ruc)
    
    if data is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="RUC no encontrado en el SRI"
        )
    
    return data


@router.get("/consultar-cedula", response_model=SRIContribuyenteResponse)
async def consultar_cedula(
    cedula: str = Query(..., min_length=10, max_length=10, description="Cédula ecuatoriana"),
    current_user: Usuario = Depends(get_current_user)
) -> Any:
    """
    Consulta datos de una persona por cédula en el SRI.
    
    - **cedula**: Número de cédula de 10 dígitos
    
    Retorna nombres, apellidos y estado del contribuyente.
    """
    data = await sri_service.consultar_cedula(cedula)
    
    if data is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Cédula no encontrada"
        )
    
    return data


@router.get("/generar-clave-acceso")
async def generar_clave_acceso(
    tipo_comprobante: str = Query(..., description="01=Factura, 04=Nota Crédito, 05=Nota Débito, 06=Guía, 07=Retención"),
    ruc: str = Query(..., min_length=13, max_length=13),
    ambiente: str = Query(..., description="1=Pruebas, 2=Producción"),
    serie: str = Query(..., min_length=6, max_length=6, description="001001"),
    numero: str = Query(..., min_length=9, max_length=9, description="000000001"),
    fecha: str = Query(..., description="DD/MM/YYYY o DD-MM-YYYY"),
    current_user: Usuario = Depends(get_current_user)
) -> dict:
    """
    Genera una clave de acceso según especificaciones SRI (49 dígitos).
    
    La clave se usa para comprobantes electrónicos.
    """
    clave = sri_service.generar_clave_acceso(
        tipo_comprobante=tipo_comprobante,
        ruc=ruc,
        ambiente=ambiente,
        serie=serie,
        numero=numero,
        fecha=fecha
    )
    
    return {
        "clave_acceso": clave,
        "longitud": len(clave),
        "componentes": {
            "fecha": clave[:8],
            "tipo_comprobante": clave[8:10],
            "ruc": clave[10:23],
            "ambiente": clave[23:24],
            "serie": clave[24:30],
            "numero": clave[30:39],
            "codigo_numerico": clave[39:47],
            "tipo_emision": clave[47:48],
            "digito_verificador": clave[48:49]
        }
    }


@router.get("/establecimientos/{ruc}")
async def get_establecimientos(
    ruc: str,
    current_user: Usuario = Depends(get_current_user)
) -> Any:
    """
    Obtiene los establecimientos registrados para un RUC.
    """
    data = await sri_service.consultar_ruc(ruc)
    
    if not data:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="RUC no encontrado"
        )
    
    return {
        "ruc": ruc,
        "establecimientos": data.get("establecimientos", [])
    }
