"""
Tareas Celery para backups automáticos.
"""
from celery import Celery
from celery.schedules import crontab
import os

from app.core.config import settings
from app.services.backup_service import backup_service

# Configurar Celery con Redis
celery_app = Celery(
    "sistema_contable",
    broker=settings.REDIS_URL,
    backend=settings.REDIS_URL,
    include=["app.celery_tasks.backup_tasks"]
)

celery_app.conf.update(
    task_serializer="json",
    accept_content=["json"],
    result_serializer="json",
    timezone="America/Guayaquil",
    enable_utc=True,
    beat_schedule={
        "backup-midnight": {
            "task": "app.celery_tasks.backup_tasks.backup_all_empresas",
            "schedule": crontab(hour=0, minute=0),  # Medianoche
        },
        "cleanup-old-backups": {
            "task": "app.celery_tasks.backup_tasks.cleanup_old_backups",
            "schedule": crontab(hour=1, minute=0),  # 1 AM
        },
    }
)


@celery_app.task(bind=True, max_retries=3)
def backup_all_empresas(self):
    """
    Tarea programada: Backup de todas las empresas a medianoche.
    """
    from sqlalchemy.orm import Session
    from app.db.base import SessionLocal
    from app.models.empresa import Empresa
    
    db = SessionLocal()
    
    try:
        results = []
        empresas = db.query(Empresa).filter(Empresa.activa == True).all()
        
        # 1. Backup completo
        full_result = backup_service.create_backup()
        results.append({"tipo": "full", "result": full_result})
        
        # 2. Backups individuales por empresa
        for empresa in empresas:
            try:
                result = backup_service.create_backup(empresa_id=empresa.id)
                results.append({
                    "tipo": "empresa",
                    "empresa_id": empresa.id,
                    "ruc": empresa.ruc,
                    "result": result
                })
            except Exception as e:
                results.append({
                    "tipo": "empresa",
                    "empresa_id": empresa.id,
                    "error": str(e)
                })
        
        return {
            "status": "completed",
            "empresas_procesadas": len(empresas),
            "results": results,
            "timestamp": datetime.now().isoformat()
        }
        
    except Exception as exc:
        # Reintentar en 5 minutos
        raise self.retry(exc=exc, countdown=300)
    finally:
        db.close()


@celery_app.task
def backup_single_empresa(empresa_id: int):
    """
    Backup de una empresa específica.
    """
    result = backup_service.create_backup(empresa_id=empresa_id)
    return {
        "empresa_id": empresa_id,
        "result": result,
        "timestamp": datetime.now().isoformat()
    }


@celery_app.task
def cleanup_old_backups():
    """
    Elimina backups antiguos según política de retención.
    """
    result = backup_service.cleanup_old_backups()
    return {
        "status": "completed",
        "result": result,
        "timestamp": datetime.now().isoformat()
    }


@celery_app.task
def test_backup_encryption(backup_path: str):
    """
    Verifica que un backup pueda ser desencriptado.
    """
    result = backup_service.restore_backup(backup_path, validate_checksum=True)
    return {
        "backup_path": backup_path,
        "valid": result.get("success", False),
        "details": result
    }


# Import para fecha
from datetime import datetime
