"""
Schemas Pydantic para Usuario.
"""
from pydantic import BaseModel, EmailStr, Field, field_validator
from typing import Optional, List
from datetime import datetime
from app.core.security import validate_cedula, sanitize_input


class UsuarioBase(BaseModel):
    email: EmailStr
    nombres: str = Field(..., min_length=1, max_length=200)
    apellidos: str = Field(..., min_length=1, max_length=200)
    cedula: Optional[str] = Field(None, max_length=13)
    telefono: Optional[str] = Field(None, max_length=20)
    direccion: Optional[str] = None
    idioma: str = Field(default="es_EC", pattern="^(es_EC|es_LATAM|es|en)$")
    tema: str = Field(default="light", pattern="^(light|dark)$")
    
    @field_validator('cedula')
    @classmethod
    def validar_cedula(cls, v):
        if v and not validate_cedula(v):
            raise ValueError('Cédula ecuatoriana inválida')
        return v
    
    @field_validator('nombres', 'apellidos', 'direccion')
    @classmethod
    def sanitizar_texto(cls, v):
        if v:
            return sanitize_input(v)
        return v


class UsuarioCreate(UsuarioBase):
    password: str = Field(..., min_length=8, max_length=100)
    
    @field_validator('password')
    @classmethod
    def validar_password(cls, v):
        if not any(c.isupper() for c in v):
            raise ValueError('La contraseña debe contener al menos una mayúscula')
        if not any(c.islower() for c in v):
            raise ValueError('La contraseña debe contener al menos una minúscula')
        if not any(c.isdigit() for c in v):
            raise ValueError('La contraseña debe contener al menos un número')
        return v


class UsuarioUpdate(BaseModel):
    nombres: Optional[str] = Field(None, min_length=1, max_length=200)
    apellidos: Optional[str] = Field(None, min_length=1, max_length=200)
    telefono: Optional[str] = Field(None, max_length=20)
    direccion: Optional[str] = None
    idioma: Optional[str] = Field(None, pattern="^(es_EC|es_LATAM|es|en)$")
    tema: Optional[str] = Field(None, pattern="^(light|dark)$")
    is_active: Optional[bool] = None


class UsuarioEnEmpresa(BaseModel):
    empresa_id: int
    rol: str
    permisos: List[str]
    activo: bool


class Usuario(UsuarioBase):
    id: int
    username: Optional[str]
    is_active: bool
    is_superuser: bool
    email_verified: bool
    ultimo_acceso: Optional[datetime]
    creado_en: datetime
    
    class Config:
        from_attributes = True


class UsuarioResponse(BaseModel):
    id: int
    email: str
    nombre_completo: str
    nombres: str
    apellidos: str
    is_active: bool
    is_superuser: bool
    idioma: str
    tema: str


class Token(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    expires_in: int


class TokenPayload(BaseModel):
    sub: Optional[int] = None
    type: Optional[str] = None
    exp: Optional[datetime] = None


class LoginRequest(BaseModel):
    email: EmailStr
    password: str


class RefreshRequest(BaseModel):
    refresh_token: str


class PasswordChangeRequest(BaseModel):
    current_password: str
    new_password: str = Field(..., min_length=8, max_length=100)
    
    @field_validator('new_password')
    @classmethod
    def validar_nueva_password(cls, v):
        if not any(c.isupper() for c in v):
            raise ValueError('La contraseña debe contener al menos una mayúscula')
        if not any(c.islower() for c in v):
            raise ValueError('La contraseña debe contener al menos una minúscula')
        if not any(c.isdigit() for c in v):
            raise ValueError('La contraseña debe contener al menos un número')
        return v


class PasswordResetRequest(BaseModel):
    email: EmailStr


# Consulta SRI para datos de usuario/empresa
class SRIContribuyenteResponse(BaseModel):
    ruc: str
    razon_social: str
    nombre_comercial: Optional[str]
    estado_contribuyente: str
    clase_contribuyente: str
    obligado_contabilidad: bool
    tipo_contribuyente: str
    fecha_inicio_actividades: Optional[str]
    fecha_cese: Optional[str]
    fecha_reinicio_actividades: Optional[str]
    fecha_actualizacion: Optional[str]
    establecimientos: List[dict] = []
    actividades_economicas: List[dict] = []
