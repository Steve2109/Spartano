"""
Schemas Pydantic para Empresa.
"""
from pydantic import BaseModel, Field, field_validator
from typing import Optional, List, Dict, Any
from datetime import datetime
from app.core.security import validate_ruc, sanitize_input


class EmpresaBase(BaseModel):
    ruc: str = Field(..., max_length=13)
    razon_social: str = Field(..., min_length=1, max_length=500)
    nombre_comercial: Optional[str] = Field(None, max_length=500)
    direccion_matriz: str
    direccion_establecimiento: Optional[str] = None
    
    email: Optional[str] = Field(None, max_length=255)
    telefono: Optional[str] = Field(None, max_length=20)
    celular: Optional[str] = Field(None, max_length=20)
    
    obligado_contabilidad: bool = True
    contribuyente_especial: Optional[str] = None
    tipo_regimen: str = Field(default="RIMPE", pattern="^(RIMPE|GENERAL|MICROEMPRESA|OTRO)$")
    agente_retencion: bool = False
    numero_resolucion_agente: Optional[str] = None
    
    @field_validator('ruc')
    @classmethod
    def validar_ruc(cls, v):
        if not validate_ruc(v):
            raise ValueError('RUC ecuatoriano inválido')
        return v
    
    @field_validator('razon_social', 'nombre_comercial', 'direccion_matriz', 'direccion_establecimiento')
    @classmethod
    def sanitizar_texto(cls, v):
        if v:
            return sanitize_input(v)
        return v


class EmpresaCreate(EmpresaBase):
    # Firma electrónica (ruta del archivo, NUNCA el contenido)
    firma_electronica_path: Optional[str] = None
    firma_electronica_validez: Optional[datetime] = None
    
    # Logo
    logo_path: Optional[str] = None
    
    configuracion: Optional[Dict[str, Any]] = {}


class EmpresaUpdate(BaseModel):
    razon_social: Optional[str] = Field(None, min_length=1, max_length=500)
    nombre_comercial: Optional[str] = Field(None, max_length=500)
    direccion_matriz: Optional[str] = None
    direccion_establecimiento: Optional[str] = None
    email: Optional[str] = Field(None, max_length=255)
    telefono: Optional[str] = Field(None, max_length=20)
    celular: Optional[str] = Field(None, max_length=20)
    obligado_contabilidad: Optional[bool] = None
    contribuyente_especial: Optional[str] = None
    tipo_regimen: Optional[str] = None
    agente_retencion: Optional[bool] = None
    configuracion: Optional[Dict[str, Any]] = None


class EmpresaFirmaUpdate(BaseModel):
    """Actualización de firma electrónica - la contraseña va al .env"""
    firma_electronica_path: str
    firma_electronica_validez: datetime
    firma_electronica_emitido_por: Optional[str] = None


class Empresa(EmpresaBase):
    id: int
    firma_electronica_path: Optional[str]
    firma_electronica_validez: Optional[datetime]
    firma_electronica_emitido_por: Optional[str]
    logo_path: Optional[str]
    configuracion: Dict[str, Any]
    activa: bool
    certificada_sri: bool
    creado_en: datetime
    actualizado_en: Optional[datetime]
    
    class Config:
        from_attributes = True


class SucursalBase(BaseModel):
    codigo: str = Field(..., max_length=3, pattern="^\\d{3}$")
    nombre: str = Field(..., min_length=1, max_length=200)
    direccion: str
    telefono: Optional[str] = Field(None, max_length=20)
    email: Optional[str] = Field(None, max_length=255)
    
    serie_factura: str = Field(default="001-001", max_length=6)
    serie_nota_credito: str = Field(default="001-002", max_length=6)
    serie_nota_debito: str = Field(default="001-003", max_length=6)
    serie_retencion: str = Field(default="001-004", max_length=6)
    serie_guia: str = Field(default="001-005", max_length=6)


class SucursalCreate(SucursalBase):
    pass


class Sucursal(SucursalBase):
    id: int
    empresa_id: int
    secuencia_factura: int
    secuencia_nota_credito: int
    secuencia_nota_debito: int
    secuencia_retencion: int
    secuencia_guia: int
    activa: bool
    creado_en: datetime
    
    class Config:
        from_attributes = True


class EmpresaConSucursales(Empresa):
    sucursales: List[Sucursal] = []


# Respuesta de consulta SRI
class SRIEmpresaData(BaseModel):
    """Datos obtenidos del SRI para auto-completar."""
    ruc: str
    razon_social: str
    nombre_comercial: Optional[str]
    estado: str
    direccion: Optional[str]
    obligado_contabilidad: bool
    contribuyente_especial: Optional[str]
    establecimientos: List[Dict[str, Any]] = []
    actividades: List[Dict[str, Any]] = []
