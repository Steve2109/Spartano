"""
Punto de entrada principal de la aplicación FastAPI.
"""
from fastapi import FastAPI, Request, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.trustedhost import TrustedHostMiddleware
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles
from slowapi import _rate_limit_exceeded_handler
from slowapi.errors import RateLimitExceeded
import time
import logging

from app.api.v1.api import api_router
from app.core.config import settings
from app.core.security import limiter, add_security_headers
from app.db.base import init_db

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


def create_application() -> FastAPI:
    """Factory function para crear la aplicación."""
    
    app = FastAPI(
        title=settings.PROJECT_NAME,
        version=settings.VERSION,
        description="Sistema Contable TyM - Ecuador (SRI Compliant)",
        docs_url="/api/docs" if not settings.is_production else None,
        redoc_url="/api/redoc" if not settings.is_production else None,
        openapi_url="/api/openapi.json" if not settings.is_production else None,
    )
    
    # Rate limiting
    app.state.limiter = limiter
    app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)
    
    # CORS
    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.allowed_origins_list,
        allow_credentials=True,
        allow_methods=["GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS"],
        allow_headers=["*"],
        expose_headers=["X-Request-ID"],
    )
    
    # Trusted Hosts (producción)
    if settings.is_production:
        app.add_middleware(
            TrustedHostMiddleware,
            allowed_hosts=["*.tymcontable.com", "localhost"]
        )
    
    # Middleware de seguridad y logging
    @app.middleware("http")
    async def security_middleware(request: Request, call_next):
        start_time = time.time()
        
        response = await call_next(request)
        
        # Añadir headers de seguridad
        response = add_security_headers(response)
        
        # Logging
        process_time = time.time() - start_time
        response.headers["X-Process-Time"] = str(process_time)
        
        logger.info(
            f"{request.method} {request.url.path} - "
            f"Status: {response.status_code} - "
            f"Time: {process_time:.3f}s - "
            f"IP: {request.client.host if request.client else 'unknown'}"
        )
        
        return response
    
    # Mount archivos estáticos (uploads)
    app.mount("/uploads", StaticFiles(directory=settings.UPLOAD_DIR), name="uploads")
    
    # Routers
    app.include_router(api_router, prefix="/api/v1")
    
    # Eventos de ciclo de vida
    @app.on_event("startup")
    async def startup_event():
        logger.info("Iniciando aplicación...")
        init_db()
        logger.info("Base de datos inicializada")
    
    @app.on_event("shutdown")
    async def shutdown_event():
        logger.info("Apagando aplicación...")
    
    # Health check
    @app.get("/health")
    async def health_check():
        return {
            "status": "healthy",
            "version": settings.VERSION,
            "environment": settings.ENVIRONMENT
        }
    
    # Root
    @app.get("/")
    async def root():
        return {
            "message": "Sistema Contable TyM API",
            "version": settings.VERSION,
            "docs": "/api/docs"
        }
    
    # Manejadores de excepciones
    @app.exception_handler(Exception)
    async def general_exception_handler(request: Request, exc: Exception):
        logger.error(f"Error no manejado: {exc}", exc_info=True)
        return JSONResponse(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            content={"detail": "Error interno del servidor"}
        )
    
    return app


# Crear instancia de aplicación
app = create_application()
