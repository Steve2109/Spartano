"""
Configuración centralizada del sistema contable.
Todas las API keys y credenciales se cargan desde variables de entorno.
"""
from pydantic_settings import BaseSettings, SettingsConfigDict
from typing import Optional, List
import os


class Settings(BaseSettings):
    """Configuración del aplicativo."""
    
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=True
    )
    
    # General
    PROJECT_NAME: str = "Sistema Contable TyM"
    VERSION: str = "1.0.0"
    DEBUG: bool = False
    ENVIRONMENT: str = "development"
    
    # Base de datos
    DATABASE_URL: str = "sqlite:///./data/app.db"
    
    # Seguridad JWT
    SECRET_KEY: str = "cambiar-en-produccion"
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 30
    REFRESH_TOKEN_EXPIRE_DAYS: int = 7
    
    # Rate Limiting
    RATE_LIMIT_REQUESTS: int = 100
    RATE_LIMIT_PERIOD: int = 60
    
    # ClamAV
    CLAMAV_HOST: str = "localhost"
    CLAMAV_PORT: int = 3310
    CLAMAV_SOCKET: Optional[str] = None
    CLAMAV_ENABLED: bool = True
    
    # VirusTotal
    VIRUSTOTAL_API_KEY: Optional[str] = None
    VIRUSTOTAL_ENABLED: bool = False
    
    # Backups
    BACKUP_ENCRYPTION_KEY: str = "cambiar-por-clave-segura-32-chars"
    BACKUP_SCHEDULE: str = "0 0 * * *"
    BACKUP_RETENTION_DAYS: int = 30
    BACKUP_PATH: str = "./backups"
    
    # Email SMTP
    SMTP_HOST: Optional[str] = None
    SMTP_PORT: int = 587
    SMTP_USER: Optional[str] = None
    SMTP_PASSWORD: Optional[str] = None
    SMTP_TLS: bool = True
    
    # Email IMAP
    IMAP_HOST: Optional[str] = None
    IMAP_PORT: int = 993
    IMAP_USER: Optional[str] = None
    IMAP_PASSWORD: Optional[str] = None
    IMAP_SSL: bool = True
    
    # Email POP
    POP_HOST: Optional[str] = None
    POP_PORT: int = 995
    POP_USER: Optional[str] = None
    POP_PASSWORD: Optional[str] = None
    POP_SSL: bool = True
    
    # SRI
    SRI_AMBIENTE: str = "pruebas"
    
    # Redis
    REDIS_URL: str = "redis://localhost:6379/0"
    
    # Uploads
    UPLOAD_DIR: str = "./uploads"
    MAX_UPLOAD_SIZE: int = 10 * 1024 * 1024  # 10MB
    
    # CORS
    ALLOWED_ORIGINS: str = "http://localhost:3000"
    
    @property
    def allowed_origins_list(self) -> List[str]:
        return [origin.strip() for origin in self.ALLOWED_ORIGINS.split(",")]
    
    @property
    def is_production(self) -> bool:
        return self.ENVIRONMENT == "production"
    
    @property
    def sri_recepcion_url(self) -> str:
        if self.SRI_AMBIENTE == "produccion":
            return "https://cel.sri.gob.ec/comprobantes-electronicos-ws/RecepcionComprobantesOffline?wsdl"
        return "https://celcer.sri.gob.ec/comprobantes-electronicos-ws/RecepcionComprobantesOffline?wsdl"
    
    @property
    def sri_autorizacion_url(self) -> str:
        if self.SRI_AMBIENTE == "produccion":
            return "https://cel.sri.gob.ec/comprobantes-electronicos-ws/AutorizacionComprobantesOffline?wsdl"
        return "https://celcer.sri.gob.ec/comprobantes-electronicos-ws/AutorizacionComprobantesOffline?wsdl"


# Instancia global de configuración
settings = Settings()
