"""
Módulo de seguridad: hashing, JWT, rate limiting, sanitización.
"""
from datetime import datetime, timedelta
from typing import Optional, Union, Any
from jose import JWTError, jwt
from passlib.context import CryptContext
from fastapi import HTTPException, status, Request
from slowapi import Limiter
from slowapi.util import get_remote_address
import bleach
import re
from app.core.config import settings

# Contexto para hashing de contraseñas
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

# Rate limiter
limiter = Limiter(key_func=get_remote_address)


def verify_password(plain_password: str, hashed_password: str) -> bool:
    """Verifica una contraseña contra su hash."""
    return pwd_context.verify(plain_password, hashed_password)


def get_password_hash(password: str) -> str:
    """Genera hash de una contraseña."""
    return pwd_context.hash(password)


def create_access_token(data: dict, expires_delta: Optional[timedelta] = None) -> str:
    """Crea un token JWT de acceso."""
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)
    
    to_encode.update({"exp": expire, "type": "access"})
    encoded_jwt = jwt.encode(to_encode, settings.SECRET_KEY, algorithm=settings.ALGORITHM)
    return encoded_jwt


def create_refresh_token(data: dict) -> str:
    """Crea un token JWT de refresh."""
    to_encode = data.copy()
    expire = datetime.utcnow() + timedelta(days=settings.REFRESH_TOKEN_EXPIRE_DAYS)
    to_encode.update({"exp": expire, "type": "refresh"})
    encoded_jwt = jwt.encode(to_encode, settings.SECRET_KEY, algorithm=settings.ALGORITHM)
    return encoded_jwt


def decode_token(token: str) -> Optional[dict]:
    """Decodifica y valida un token JWT."""
    try:
        payload = jwt.decode(token, settings.SECRET_KEY, algorithms=[settings.ALGORITHM])
        return payload
    except JWTError:
        return None


# ============== SANITIZACIÓN DE INPUTS ==============

ALLOWED_TAGS = ['p', 'br', 'strong', 'em', 'u', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'ul', 'ol', 'li']
ALLOWED_ATTRIBUTES = {'*': ['class'], 'a': ['href', 'title']}


def sanitize_html(text: Optional[str]) -> Optional[str]:
    """Sanitiza HTML permitiendo solo tags seguros."""
    if not text:
        return text
    return bleach.clean(text, tags=ALLOWED_TAGS, attributes=ALLOWED_ATTRIBUTES, strip=True)


def sanitize_input(text: Optional[str]) -> Optional[str]:
    """Sanitiza input de texto removiendo caracteres peligrosos."""
    if not text:
        return text
    # Remover caracteres de control excepto newlines y tabs
    text = ''.join(char for char in text if ord(char) >= 32 or char in '\n\t\r')
    # Remover null bytes
    text = text.replace('\x00', '')
    # Limitar longitud
    return text[:10000]


def validate_ruc(ruc: str) -> bool:
    """Valida un RUC ecuatoriano."""
    if not ruc or len(ruc) != 13:
        return False
    if not ruc.isdigit():
        return False
    
    # Validar tipo de contribuyente
    tipo = int(ruc[2])
    if tipo not in [0, 1, 2, 3, 4, 5, 6, 9]:  # 0-5 personas naturales, 6-9 sociedades
        return False
    
    # Validar código de provincia
    provincia = int(ruc[0:2])
    if provincia < 1 or provincia > 24:
        return False
    
    # Validar dígito verificador
    coeficientes = [2, 1, 2, 1, 2, 1, 2, 1, 2]
    suma = 0
    
    for i in range(9):
        valor = int(ruc[i]) * coeficientes[i]
        if valor >= 10:
            valor -= 9
        suma += valor
    
    digito_verificador = (10 - (suma % 10)) % 10
    
    return digito_verificador == int(ruc[9])


def validate_cedula(cedula: str) -> bool:
    """Valida una cédula ecuatoriana."""
    if not cedula or len(cedula) != 10:
        return False
    if not cedula.isdigit():
        return False
    
    provincia = int(cedula[0:2])
    if provincia < 1 or provincia > 24:
        return False
    
    tercer_digito = int(cedula[2])
    if tercer_digito > 6:
        return False
    
    # Algoritmo de validación
    coeficientes = [2, 1, 2, 1, 2, 1, 2, 1, 2]
    suma = 0
    
    for i in range(9):
        valor = int(cedula[i]) * coeficientes[i]
        if valor >= 10:
            valor -= 9
        suma += valor
    
    digito_verificador = (10 - (suma % 10)) % 10
    
    return digito_verificador == int(cedula[9])


def validate_email(email: str) -> bool:
    """Valida formato de email."""
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return re.match(pattern, email) is not None


# ============== HEADERS DE SEGURIDAD ==============

SECURITY_HEADERS = {
    "X-Content-Type-Options": "nosniff",
    "X-Frame-Options": "DENY",
    "X-XSS-Protection": "1; mode=block",
    "Strict-Transport-Security": "max-age=31536000; includeSubDomains",
    "Content-Security-Policy": "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline';",
    "Referrer-Policy": "strict-origin-when-cross-origin",
    "Permissions-Policy": "geolocation=(), microphone=(), camera=()",
}


def add_security_headers(response: Any) -> Any:
    """Añade headers de seguridad a las respuestas."""
    for header, value in SECURITY_HEADERS.items():
        response.headers[header] = value
    return response
