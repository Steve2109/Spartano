"""
Configuración de base de datos con soporte multi-tenant.
"""
from sqlalchemy import create_engine, event, MetaData
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, Session
from sqlalchemy.pool import StaticPool
from contextlib import contextmanager
from typing import Generator, Optional
import os

from app.core.config import settings

# Metadata con naming convention
convention = {
    "ix": "ix_%(column_0_label)s",
    "uq": "uq_%(table_name)s_%(column_0_name)s",
    "ck": "ck_%(table_name)s_%(constraint_name)s",
    "fk": "fk_%(table_name)s_%(column_0_name)s_%(referred_table_name)s",
    "pk": "pk_%(table_name)s",
}

metadata = MetaData(naming_convention=convention)
Base = declarative_base(metadata=metadata)

# Engine global
if settings.DATABASE_URL.startswith("sqlite"):
    engine = create_engine(
        settings.DATABASE_URL,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
else:
    engine = create_engine(
        settings.DATABASE_URL,
        pool_pre_ping=True,
        pool_size=5,
        max_overflow=10,
    )

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


class TenantSession:
    """Manejador de sesiones con soporte multi-tenant."""
    
    def __init__(self, db: Session, tenant_id: Optional[int] = None):
        self.db = db
        self.tenant_id = tenant_id
    
    def query(self, model):
        """Query con filtro de tenant automático."""
        q = self.db.query(model)
        if self.tenant_id is not None and hasattr(model, "empresa_id"):
            q = q.filter(model.empresa_id == self.tenant_id)
        return q
    
    def add(self, obj):
        """Añade objeto asignando tenant si aplica."""
        if self.tenant_id is not None and hasattr(obj, "empresa_id"):
            obj.empresa_id = self.tenant_id
        self.db.add(obj)
    
    def commit(self):
        self.db.commit()
    
    def rollback(self):
        self.db.rollback()
    
    def refresh(self, obj):
        self.db.refresh(obj)
    
    def close(self):
        self.db.close()
    
    def __enter__(self):
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        if exc_type is not None:
            self.rollback()
        self.close()


def get_db() -> Generator[Session, None, None]:
    """Dependency para obtener sesión de DB en FastAPI."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def get_tenant_db(tenant_id: Optional[int] = None) -> Generator[TenantSession, None, None]:
    """Dependency para obtener sesión con filtro de tenant."""
    db = SessionLocal()
    try:
        yield TenantSession(db, tenant_id)
    finally:
        db.close()


@contextmanager
def get_db_context() -> Generator[Session, None, None]:
    """Context manager para uso fuera de FastAPI dependencies."""
    db = SessionLocal()
    try:
        yield db
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()


def init_db() -> None:
    """Inicializa la base de datos creando todas las tablas."""
    # Crear directorio para SQLite si no existe
    if settings.DATABASE_URL.startswith("sqlite"):
        db_path = settings.DATABASE_URL.replace("sqlite:///", "")
        os.makedirs(os.path.dirname(db_path) or ".", exist_ok=True)
    
    # Importar modelos para que se registren
    from app.models import (
        usuario, empresa, sucursal, plan_cuentas, 
        producto, inventario, cliente, proveedor,
        factura, asiento_contable, backup_config
    )
    
    Base.metadata.create_all(bind=engine)


def check_connection() -> bool:
    """Verifica la conexión a la base de datos."""
    try:
        with engine.connect() as conn:
            conn.execute("SELECT 1")
        return True
    except Exception:
        return False
