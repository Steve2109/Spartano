"""
Servicio de backups automáticos y encriptados.
"""
import os
import json
import gzip
import shutil
import hashlib
from datetime import datetime, timedelta
from typing import Optional, List, Dict, Any
from pathlib import Path
from cryptography.fernet import Fernet
import base64

from sqlalchemy import text
from app.core.config import settings
from app.db.base import engine, SessionLocal


class BackupService:
    """
    Servicio de backups de base de datos.
    Genera backups encriptados automáticamente.
    """
    
    def __init__(self):
        self.backup_path = Path(settings.BACKUP_PATH)
        self.backup_path.mkdir(parents=True, exist_ok=True)
        self.encryption_key = self._get_or_create_key()
    
    def _get_or_create_key(self) -> bytes:
        """Obtiene o deriva la clave de encriptación."""
        # Derivar clave de 32 bytes desde la configuración
        key_material = settings.BACKUP_ENCRYPTION_KEY.encode()
        # Usar SHA-256 para obtener exactamente 32 bytes
        key = hashlib.sha256(key_material).digest()
        # Convertir a formato Fernet (URL-safe base64)
        return base64.urlsafe_b64encode(key)
    
    def create_backup(self, empresa_id: Optional[int] = None) -> Dict[str, Any]:
        """
        Crea un backup encriptado de la base de datos.
        
        Args:
            empresa_id: Si se especifica, solo backup de esa empresa
            
        Returns:
            Dict con información del backup creado
        """
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        
        if empresa_id:
            filename = f"backup_empresa_{empresa_id}_{timestamp}.json.gz.enc"
        else:
            filename = f"backup_full_{timestamp}.json.gz.enc"
        
        backup_file = self.backup_path / filename
        
        try:
            # 1. Extraer datos
            data = self._extract_data(empresa_id)
            
            # 2. Convertir a JSON
            json_data = json.dumps(data, default=str, indent=2)
            
            # 3. Comprimir
            compressed = gzip.compress(json_data.encode('utf-8'))
            
            # 4. Encriptar
            fernet = Fernet(self.encryption_key)
            encrypted = fernet.encrypt(compressed)
            
            # 5. Guardar
            with open(backup_file, 'wb') as f:
                f.write(encrypted)
            
            # 6. Calcular checksum
            checksum = hashlib.sha256(encrypted).hexdigest()
            
            return {
                "success": True,
                "filename": filename,
                "filepath": str(backup_file),
                "size_bytes": len(encrypted),
                "checksum": checksum,
                "empresa_id": empresa_id,
                "timestamp": datetime.now().isoformat(),
                "tables_backed_up": len(data.get("tables", {})),
                "records_backed_up": sum(len(records) for records in data.get("tables", {}).values())
            }
            
        except Exception as e:
            # Limpiar archivo parcial si existe
            if backup_file.exists():
                backup_file.unlink()
            
            return {
                "success": False,
                "error": str(e),
                "timestamp": datetime.now().isoformat()
            }
    
    def _extract_data(self, empresa_id: Optional[int] = None) -> Dict[str, Any]:
        """Extrae datos de la base de datos."""
        db = SessionLocal()
        try:
            data = {
                "metadata": {
                    "version": settings.VERSION,
                    "created_at": datetime.now().isoformat(),
                    "empresa_id": empresa_id,
                    "database_url": settings.DATABASE_URL.split('@')[-1]  # Sin credenciales
                },
                "tables": {}
            }
            
            # Lista de tablas a respaldar (excluir sesiones, logs temporales)
            tables = [
                "usuarios", "empresas", "sucursales", "usuario_empresa",
                "cuentas_contables", "asientos_contables", "movimientos_contables",
                "productos", "clientes", "proveedores",
                "bodegas", "stocks_bodega", "movimientos_inventario",
                "facturas", "factura_items", "retenciones", "retencion_items",
                "email_configs", "backup_history"
            ]
            
            for table in tables:
                try:
                    query = text(f"SELECT * FROM {table}")
                    
                    # Filtrar por empresa si se especifica
                    if empresa_id and self._table_has_empresa_id(table):
                        query = text(f"SELECT * FROM {table} WHERE empresa_id = :empresa_id")
                        result = db.execute(query, {"empresa_id": empresa_id})
                    else:
                        result = db.execute(query)
                    
                    records = []
                    for row in result.mappings():
                        record = dict(row)
                        # Convertir datetime a string
                        for key, value in record.items():
                            if isinstance(value, datetime):
                                record[key] = value.isoformat()
                        records.append(record)
                    
                    data["tables"][table] = records
                    
                except Exception as e:
                    # Tabla puede no existir, continuar
                    data["tables"][table] = {"error": str(e)}
            
            return data
            
        finally:
            db.close()
    
    def _table_has_empresa_id(self, table: str) -> bool:
        """Verifica si una tabla tiene columna empresa_id."""
        tables_with_empresa = {
            "empresas", "sucursales", "cuentas_contables", "asientos_contables",
            "movimientos_contables", "productos", "clientes", "proveedores",
            "bodegas", "stocks_bodega", "movimientos_inventario",
            "facturas", "factura_items", "retenciones", "retencion_items",
            "alertas_stock", "ajustes_inventario", "ajuste_inventario_items",
            "file_scan_results", "backup_history", "email_configs"
        }
        return table in tables_with_empresa
    
    def restore_backup(self, backup_file: str, 
                      validate_checksum: bool = True) -> Dict[str, Any]:
        """
        Restaura un backup desde archivo encriptado.
        
        Args:
            backup_file: Ruta al archivo de backup
            validate_checksum: Si se debe validar checksum
            
        Returns:
            Dict con resultado de la restauración
        """
        try:
            filepath = Path(backup_file)
            if not filepath.exists():
                return {"success": False, "error": "Archivo de backup no encontrado"}
            
            # 1. Leer archivo
            with open(filepath, 'rb') as f:
                encrypted = f.read()
            
            # 2. Desencriptar
            fernet = Fernet(self.encryption_key)
            try:
                compressed = fernet.decrypt(encrypted)
            except Exception:
                return {"success": False, "error": "No se pudo desencriptar. Clave incorrecta?"}
            
            # 3. Descomprimir
            json_data = gzip.decompress(compressed).decode('utf-8')
            data = json.loads(json_data)
            
            # 4. Validar estructura
            if "tables" not in data:
                return {"success": False, "error": "Formato de backup inválido"}
            
            # 5. Restaurar datos (opcional - podría ser destructive)
            # Por seguridad, solo reportamos qué se restauraría
            restore_info = {
                "tables_to_restore": list(data["tables"].keys()),
                "total_records": sum(len(records) for records in data["tables"].values() 
                                   if isinstance(records, list)),
                "backup_date": data.get("metadata", {}).get("created_at"),
                "backup_version": data.get("metadata", {}).get("version")
            }
            
            return {
                "success": True,
                "validated": True,
                "restore_info": restore_info,
                "message": "Backup validado. Use restore_data() para restaurar realmente."
            }
            
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def list_backups(self, empresa_id: Optional[int] = None) -> List[Dict[str, Any]]:
        """Lista los backups disponibles."""
        backups = []
        
        pattern = f"backup_empresa_{empresa_id}_" if empresa_id else "backup_"
        
        for file in self.backup_path.glob("*.json.gz.enc"):
            if empresa_id is None or pattern in file.name:
                stat = file.stat()
                backups.append({
                    "filename": file.name,
                    "filepath": str(file),
                    "size_bytes": stat.st_size,
                    "created": datetime.fromtimestamp(stat.st_mtime).isoformat(),
                    "empresa_id": empresa_id
                })
        
        return sorted(backups, key=lambda x: x["created"], reverse=True)
    
    def cleanup_old_backups(self, retention_days: Optional[int] = None) -> Dict[str, Any]:
        """Elimina backups antiguos según política de retención."""
        if retention_days is None:
            retention_days = settings.BACKUP_RETENTION_DAYS
        
        cutoff = datetime.now() - timedelta(days=retention_days)
        deleted = []
        errors = []
        
        for file in self.backup_path.glob("*.json.gz.enc"):
            try:
                mtime = datetime.fromtimestamp(file.stat().st_mtime)
                if mtime < cutoff:
                    file.unlink()
                    deleted.append({
                        "filename": file.name,
                        "deleted_at": datetime.now().isoformat(),
                        "age_days": (datetime.now() - mtime).days
                    })
            except Exception as e:
                errors.append({"filename": file.name, "error": str(e)})
        
        return {
            "deleted": deleted,
            "errors": errors,
            "total_deleted": len(deleted),
            "retention_days": retention_days
        }


# Instancia global
backup_service = BackupService()
