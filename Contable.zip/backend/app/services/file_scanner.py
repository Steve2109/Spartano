"""
Servicio de escaneo de archivos con ClamAV y VirusTotal.
Implementa seguridad para archivos subidos al sistema.
"""
import os
import hashlib
import asyncio
from typing import Optional, Dict, Any, Tuple
from pathlib import Path
import clamd
import aiohttp
from datetime import datetime

from app.core.config import settings


class FileScannerService:
    """
    Servicio de escaneo de archivos contra malware.
    Usa ClamAV como escaneo primario y VirusTotal como secundario opcional.
    """
    
    def __init__(self):
        self.clamav = None
        self.vt_api_key = settings.VIRUSTOTAL_API_KEY
        self.vt_enabled = settings.VIRUSTOTAL_ENABLED and bool(self.vt_api_key)
        self.clamav_enabled = settings.CLAMAV_ENABLED
        
        if self.clamav_enabled:
            try:
                self._init_clamav()
            except Exception as e:
                print(f"[WARNING] No se pudo inicializar ClamAV: {e}")
                self.clamav_enabled = False
    
    def _init_clamav(self):
        """Inicializa conexión con ClamAV daemon."""
        if settings.CLAMAV_SOCKET:
            self.clamav = clamd.ClamdUnixSocket(settings.CLAMAV_SOCKET)
        else:
            self.clamav = clamd.ClamdNetworkSocket(
                settings.CLAMAV_HOST,
                settings.CLAMAV_PORT
            )
        
        # Verificar conexión
        version = self.clamav.version()
        print(f"[INFO] ClamAV conectado: {version}")
    
    async def scan_file(self, 
                       file_path: str,
                       use_virustotal: bool = False) -> Dict[str, Any]:
        """
        Escanea un archivo contra malware.
        
        Args:
            file_path: Ruta al archivo temporal
            use_virustotal: Si se debe escanear también con VirusTotal
            
        Returns:
            Dict con resultados del escaneo
        """
        result = {
            "archivo": file_path,
            "tamano_bytes": os.path.getsize(file_path),
            "checksum_sha256": self._calcular_hash(file_path),
            "escaneado_en": datetime.utcnow().isoformat(),
            "clamav": {
                "escaneado": False,
                "limpio": None,
                "malware_detectado": False,
                "nombre_virus": None,
                "error": None
            },
            "virustotal": {
                "escaneado": False,
                "api_usada": False,
                "positives": None,
                "total": None,
                "error": None
            },
            "aprobado": False,
            "motivo_rechazo": None
        }
        
        # 1. Escanear con ClamAV (obligatorio si está habilitado)
        if self.clamav_enabled:
            try:
                clam_result = await self._scan_with_clamav(file_path)
                result["clamav"].update(clam_result)
                result["clamav"]["escaneado"] = True
                
                # Si ClamAV detecta malware, rechazar inmediatamente
                if clam_result.get("malware_detectado"):
                    result["aprobado"] = False
                    result["motivo_rechazo"] = f"Malware detectado por ClamAV: {clam_result.get('nombre_virus')}"
                    return result
                    
            except Exception as e:
                result["clamav"]["error"] = str(e)
                # Si ClamAV falla y es obligatorio, rechazar
                if not use_virustotal:
                    result["aprobado"] = False
                    result["motivo_rechazo"] = "Error en escaneo ClamAV y no hay alternativa"
                    return result
        
        # 2. Escanear con VirusTotal (opcional)
        if use_virustotal and self.vt_enabled:
            try:
                vt_result = await self._scan_with_virustotal(file_path)
                result["virustotal"].update(vt_result)
                result["virustotal"]["escaneado"] = True
                result["virustotal"]["api_usada"] = True
                
                # Si VirusTotal detecta positivos, rechazar
                if vt_result.get("positives", 0) > 0:
                    result["aprobado"] = False
                    result["motivo_rechazo"] = f"Detectado por {vt_result.get('positives')} motores en VirusTotal"
                    return result
                    
            except Exception as e:
                result["virustotal"]["error"] = str(e)
        
        # 3. Verificación final
        if not self.clamav_enabled and not (use_virustotal and self.vt_enabled):
            # Ningún escaneo realizado - decisión de seguridad
            result["aprobado"] = False
            result["motivo_rechazo"] = "No se pudo realizar ningún escaneo de seguridad"
            return result
        
        # Si llegamos aquí, el archivo pasó los escaneos
        result["aprobado"] = True
        return result
    
    async def _scan_with_clamav(self, file_path: str) -> Dict[str, Any]:
        """Escanear archivo con ClamAV."""
        # clamd no es async, usar thread
        loop = asyncio.get_event_loop()
        result = await loop.run_in_executor(None, self._clamav_scan_sync, file_path)
        return result
    
    def _clamav_scan_sync(self, file_path: str) -> Dict[str, Any]:
        """Sincrono: escanear con ClamAV."""
        scan_result = self.clamav.scan(file_path)
        
        # Analizar resultado
        # Formato: {'/path/to/file': ('FOUND', 'Virus.Name')}
        for path, data in scan_result.items():
            status, info = data
            
            if status == 'FOUND':
                return {
                    "limpio": False,
                    "malware_detectado": True,
                    "nombre_virus": info,
                    "version": self.clamav.version()
                }
            elif status == 'OK':
                return {
                    "limpio": True,
                    "malware_detectado": False,
                    "nombre_virus": None,
                    "version": self.clamav.version()
                }
            else:
                # ERROR u otro estado
                return {
                    "limpio": None,
                    "malware_detectado": False,
                    "nombre_virus": None,
                    "error": f"Estado desconocido: {status}",
                    "version": self.clamav.version()
                }
        
        return {"error": "No se pudo analizar el resultado"}
    
    async def _scan_with_virustotal(self, file_path: str) -> Dict[str, Any]:
        """Escanear archivo con VirusTotal API."""
        file_hash = self._calcular_hash(file_path)
        
        async with aiohttp.ClientSession() as session:
            # Primero intentar buscar por hash (no consume cuota)
            url = f"https://www.virustotal.com/api/v3/files/{file_hash}"
            headers = {"x-apikey": self.vt_api_key}
            
            async with session.get(url, headers=headers) as response:
                if response.status == 200:
                    data = await response.json()
                    attributes = data.get("data", {}).get("attributes", {})
                    last_analysis = attributes.get("last_analysis_stats", {})
                    
                    return {
                        "positives": last_analysis.get("malicious", 0) + last_analysis.get("suspicious", 0),
                        "total": sum(last_analysis.values()),
                        "scan_id": data.get("data", {}).get("id"),
                        "permalink": f"https://www.virustotal.com/gui/file/{file_hash}"
                    }
                
                elif response.status == 404:
                    # Archivo no escaneado antes, subir para análisis
                    return await self._upload_to_virustotal(session, file_path, file_hash)
                
                else:
                    return {"error": f"VirusTotal API error: {response.status}"}
    
    async def _upload_to_virustotal(self, 
                                   session: aiohttp.ClientSession,
                                   file_path: str,
                                   file_hash: str) -> Dict[str, Any]:
        """Sube archivo a VirusTotal para análisis."""
        url = "https://www.virustotal.com/api/v3/files"
        headers = {"x-apikey": self.vt_api_key}
        
        with open(file_path, 'rb') as f:
            data = aiohttp.FormData()
            data.add_field('file', f, filename=os.path.basename(file_path))
            
            async with session.post(url, headers=headers, data=data) as response:
                if response.status in (200, 201):
                    result = await response.json()
                    analysis_id = result.get("data", {}).get("id")
                    
                    # Esperar y obtener resultado
                    await asyncio.sleep(3)  # Dar tiempo para análisis inicial
                    return await self._get_vt_analysis(session, analysis_id)
                else:
                    return {"error": f"Upload failed: {response.status}"}
    
    async def _get_vt_analysis(self, 
                                session: aiohttp.ClientSession,
                                analysis_id: str) -> Dict[str, Any]:
        """Obtiene resultado de análisis de VirusTotal."""
        url = f"https://www.virustotal.com/api/v3/analyses/{analysis_id}"
        headers = {"x-apikey": self.vt_api_key}
        
        async with session.get(url, headers=headers) as response:
            if response.status == 200:
                data = await response.json()
                attributes = data.get("data", {}).get("attributes", {})
                stats = attributes.get("stats", {})
                
                return {
                    "positives": stats.get("malicious", 0) + stats.get("suspicious", 0),
                    "total": sum(stats.values()),
                    "scan_id": analysis_id
                }
            return {"error": f"Could not get analysis: {response.status}"}
    
    def _calcular_hash(self, file_path: str) -> str:
        """Calcula SHA-256 del archivo."""
        sha256_hash = hashlib.sha256()
        with open(file_path, "rb") as f:
            for byte_block in iter(lambda: f.read(4096), b""):
                sha256_hash.update(byte_block)
        return sha256_hash.hexdigest()
    
    def is_safe_extension(self, filename: str) -> bool:
        """Verifica si la extensión del archivo es segura."""
        safe_extensions = {
            '.xlsx', '.xls', '.csv', '.pdf', '.zip',
            '.txt', '.xml', '.json', '.jpg', '.jpeg',
            '.png', '.gif', '.doc', '.docx'
        }
        ext = Path(filename).suffix.lower()
        return ext in safe_extensions
    
    def get_dangerous_extensions(self) -> set:
        """Retorna conjunto de extensiones potencialmente peligrosas."""
        return {
            '.exe', '.dll', '.bat', '.cmd', '.sh', '.bin',
            '.jar', '.py', '.js', '.vbs', '.ps1', '.scr',
            '.msi', '.com', '.gadget', '.wsf', '.wsh'
        }


# Instancia global
file_scanner = FileScannerService()
