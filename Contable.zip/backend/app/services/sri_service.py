"""
Servicio de integración con SRI Ecuador.
Consulta de RUC y datos de contribuyentes.
"""
import requests
import json
from typing import Optional, Dict, Any, List
from datetime import datetime
import xml.etree.ElementTree as ET
from app.core.config import settings
from app.core.security import validate_ruc


class SRIService:
    """Servicio para consultas y operaciones con el SRI."""
    
    # URLs de consulta de RUC (endpoints no oficiales pero funcionales)
    # Nota: El SRI no tiene API oficial pública de consulta de RUC
    # Estos son endpoints alternativos que pueden cambiar
    
    SRI_CONSULTA_URL = "https://srienlinea.sri.gob.ec/sri-catastro-sujeto-estructurado/sujeto/sujeto-estructurado/{ruc}"
    SRI_CEDULA_URL = "https://srienlinea.sri.gob.ec/sri-catastro-sujeto-estructurado/sujeto/sujeto-estructurado-cedula/{cedula}"
    
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Accept': 'application/json',
        })
    
    async def consultar_ruc(self, ruc: str) -> Optional[Dict[str, Any]]:
        """
        Consulta datos de contribuyente por RUC al SRI.
        
        Args:
            ruc: Número de RUC ecuatoriano (13 dígitos)
            
        Returns:
            Dict con datos del contribuyente o None si no existe
        """
        if not validate_ruc(ruc):
            raise ValueError("RUC inválido")
        
        try:
            url = self.SRI_CONSULTA_URL.format(ruc=ruc)
            response = self.session.get(url, timeout=30)
            
            if response.status_code == 200:
                data = response.json()
                return self._parse_contribuyente_data(data)
            elif response.status_code == 404:
                return None
            else:
                # Fallback a servicio alternativo si el primero falla
                return await self._consultar_ruc_alternativo(ruc)
                
        except requests.RequestException as e:
            # Intentar servicio alternativo
            return await self._consultar_ruc_alternativo(ruc)
    
    async def _consultar_ruc_alternativo(self, ruc: str) -> Optional[Dict[str, Any]]:
        """
        Método alternativo de consulta usando servicios de terceros.
        Nota: Este es un placeholder - en producción usarías un servicio confiable.
        """
        # Implementar aquí tu servicio de consulta alternativo
        # Por ejemplo: APIS.net, Facturacionelectronica.com, etc.
        
        # Por ahora retornamos datos de ejemplo estructurados
        # En producción, reemplazar con integración real
        
        # Verificación básica del RUC
        tipo = int(ruc[2])
        provincia = int(ruc[:2])
        
        # Generar datos de ejemplo basados en el RUC
        return {
            "ruc": ruc,
            "razon_social": f"EMPRESA DE PRUEBA S.A. (RUC: {ruc})",
            "nombre_comercial": "EMPRESA PRUEBA",
            "estado": "ACTIVO",
            "direccion": f"DIRECCION EN PROVINCIA {provincia}",
            "obligado_contabilidad": tipo >= 6,  # Sociedades obligadas
            "contribuyente_especial": None,
            "tipo_regimen": "RIMPE" if tipo == 6 else "GENERAL",
            "agente_retencion": False,
            "establecimientos": [
                {
                    "codigo": "001",
                    "nombre": "MATRIZ",
                    "direccion": f"DIRECCION MATRIZ PROVINCIA {provincia}",
                    "estado": "ACTIVO"
                }
            ],
            "actividades_economicas": [
                {"codigo": "46301", "descripcion": "VENTA AL POR MAYOR DE PRODUCTOS ALIMENTICIOS"}
            ],
            "fecha_inicio_actividades": "2020-01-01",
            "_fuente": "simulado"
        }
    
    def _parse_contribuyente_data(self, data: Dict) -> Dict[str, Any]:
        """Parsea la respuesta del SRI a formato uniforme."""
        # Adaptar según la estructura real de la respuesta del SRI
        return {
            "ruc": data.get("ruc", ""),
            "razon_social": data.get("nombreComercial", "") or data.get("razonSocial", ""),
            "nombre_comercial": data.get("nombreFantasiaComercial", ""),
            "estado": data.get("estadoContribuyente", "DESCONOCIDO"),
            "direccion": data.get("direccionMatriz", ""),
            "obligado_contabilidad": data.get("obligadoContabilidad", "NO") == "SI",
            "contribuyente_especial": data.get("numeroResolucionContribuyenteEspecial"),
            "tipo_regimen": self._determinar_regimen(data),
            "agente_retencion": data.get("agenteRetencion", "NO") == "SI",
            "establecimientos": self._parse_establecimientos(data.get("establecimientos", [])),
            "actividades": self._parse_actividades(data.get("actividadesEconomicas", [])),
            "fecha_inicio_actividades": data.get("fechaInicioActividades"),
            "_fuente": "sri"
        }
    
    def _determinar_regimen(self, data: Dict) -> str:
        """Determina el tipo de régimen tributario."""
        regimen = data.get("clasificacionRIMPE", "")
        if "RIMPE" in regimen.upper():
            return "RIMPE"
        elif "MICROEMPRESA" in regimen.upper():
            return "MICROEMPRESA"
        return "GENERAL"
    
    def _parse_establecimientos(self, establecimientos: List) -> List[Dict]:
        """Parsea la lista de establecimientos."""
        result = []
        for est in establecimientos:
            result.append({
                "codigo": est.get("codigo", "").zfill(3),
                "nombre": est.get("nombre", ""),
                "direccion": est.get("direccion", ""),
                "estado": est.get("estado", "ACTIVO")
            })
        return result
    
    def _parse_actividades(self, actividades: List) -> List[Dict]:
        """Parsea la lista de actividades económicas."""
        result = []
        for act in actividades:
            result.append({
                "codigo": act.get("codigo", ""),
                "descripcion": act.get("descripcion", "")
            })
        return result
    
    async def consultar_cedula(self, cedula: str) -> Optional[Dict[str, Any]]:
        """Consulta datos de persona por cédula."""
        if len(cedula) != 10 or not cedula.isdigit():
            raise ValueError("Cédula inválida")
        
        try:
            url = self.SRI_CEDULA_URL.format(cedula=cedula)
            response = self.session.get(url, timeout=30)
            
            if response.status_code == 200:
                data = response.json()
                return {
                    "cedula": cedula,
                    "nombres": data.get("nombres", ""),
                    "apellidos": f"{data.get('apellidoPaterno', '')} {data.get('apellidoMaterno', '')}".strip(),
                    "nombre_completo": data.get("nombreCompleto", ""),
                    "estado": data.get("estado", "DESCONOCIDO"),
                    "_fuente": "sri"
                }
            return None
            
        except requests.RequestException:
            # Fallback: retornar estructura básica
            return {
                "cedula": cedula,
                "nombres": "",
                "apellidos": "",
                "nombre_completo": "",
                "estado": "DESCONOCIDO",
                "_fuente": "no_disponible"
            }
    
    def generar_clave_acceso(self, 
                            tipo_comprobante: str,
                            ruc: str,
                            ambiente: str,
                            serie: str,
                            numero: str,
                            fecha: str,
                            codigo_numerico: str = "12345678") -> str:
        """
        Genera clave de acceso según especificaciones SRI.
        
        Estructura (49 dígitos):
        - 2: Día emisión
        - 2: Mes emisión  
        - 4: Año emisión
        - 2: Tipo comprobante (01=factura, 04=nota crédito, etc.)
        - 13: RUC
        - 1: Ambiente (1=pruebas, 2=producción)
        - 3: Serie (establecimiento + punto emisión)
        - 9: Número secuencial
        - 8: Código numérico aleatorio
        - 1: Tipo emisión (1=normal)
        - 1: Dígito verificador (módulo 11)
        """
        # Fecha en formato DDMMAAAA
        fecha_parts = fecha.split("-") if "-" in fecha else fecha.split("/")
        if len(fecha_parts) == 3:
            dia, mes, anio = fecha_parts[0], fecha_parts[1], fecha_parts[2]
            if len(anio) == 2:
                anio = "20" + anio
        else:
            from datetime import datetime
            now = datetime.now()
            dia, mes, anio = now.strftime("%d"), now.strftime("%m"), now.strftime("%Y")
        
        # Construir clave base (48 dígitos)
        clave_base = f"{dia}{mes}{anio}{tipo_comprobante}{ruc}{ambiente}{serie}{numero}{codigo_numerico}1"
        
        # Calcular dígito verificador (módulo 11)
        digito_verificador = self._calcular_digito_verificador(clave_base)
        
        return clave_base + str(digito_verificador)
    
    def _calcular_digito_verificador(self, clave: str) -> int:
        """Calcula dígito verificador usando módulo 11."""
        pesos = [7, 6, 5, 4, 3, 2] * 8  # Repetir secuencia de pesos
        
        suma = 0
        for i, digito in enumerate(clave[:48]):
            suma += int(digito) * pesos[i]
        
        modulo = suma % 11
        
        if modulo == 0:
            return 0
        elif modulo == 1:
            return 1
        else:
            return 11 - modulo


# Instancia global
sri_service = SRIService()
