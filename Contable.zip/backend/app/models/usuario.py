"""
Modelo de Usuario con soporte multiempresa.
"""
from sqlalchemy import Column, Integer, String, Boolean, DateTime, Table, ForeignKey, Text
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from app.db.base import Base

# Tabla intermedia para relación muchos a muchos: Usuario - Empresa
usuario_empresa = Table(
    "usuario_empresa",
    Base.metadata,
    Column("usuario_id", Integer, ForeignKey("usuarios.id", ondelete="CASCADE"), primary_key=True),
    Column("empresa_id", Integer, ForeignKey("empresas.id", ondelete="CASCADE"), primary_key=True),
    Column("rol", String(50), default="usuario"),  # admin, contador, usuario
    Column("permisos", String(500), default="[]"),  # JSON de permisos
    Column("activo", Boolean, default=True),
    Column("creado_en", DateTime(timezone=True), server_default=func.now()),
)


class Usuario(Base):
    """Modelo de usuario del sistema."""
    
    __tablename__ = "usuarios"
    
    id = Column(Integer, primary_key=True, index=True)
    email = Column(String(255), unique=True, index=True, nullable=False)
    username = Column(String(100), unique=True, index=True, nullable=True)
    hashed_password = Column(String(255), nullable=False)
    
    # Datos personales
    nombres = Column(String(200), nullable=False)
    apellidos = Column(String(200), nullable=False)
    cedula = Column(String(13), unique=True, index=True, nullable=True)
    telefono = Column(String(20), nullable=True)
    direccion = Column(Text, nullable=True)
    
    # Estado
    is_active = Column(Boolean, default=True)
    is_superuser = Column(Boolean, default=False)
    email_verified = Column(Boolean, default=False)
    
    # Preferencias
    idioma = Column(String(10), default="es_EC")  # es_EC, es_LATAM
    tema = Column(String(20), default="light")  # light, dark
    
    # Auditoría
    ultimo_acceso = Column(DateTime(timezone=True), nullable=True)
    creado_en = Column(DateTime(timezone=True), server_default=func.now())
    actualizado_en = Column(DateTime(timezone=True), onupdate=func.now())
    
    # Relaciones
    empresas = relationship("Empresa", secondary=usuario_empresa, back_populates="usuarios")
    sesiones = relationship("SesionUsuario", back_populates="usuario", cascade="all, delete-orphan")
    
    @property
    def nombre_completo(self) -> str:
        return f"{self.nombres} {self.apellidos}"
    
    def tiene_permiso(self, empresa_id: int, permiso: str) -> bool:
        """Verifica si el usuario tiene un permiso específico en una empresa."""
        if self.is_superuser:
            return True
        
        for ue in self.empresas:
            if ue.id == empresa_id:
                # Obtener permisos de la relación
                assoc = self._get_empresa_association(empresa_id)
                if assoc:
                    permisos = assoc.permisos or "[]"
                    return permiso in permisos or assoc.rol == "admin"
        return False
    
    def _get_empresa_association(self, empresa_id: int):
        """Obtiene la relación usuario-empresa."""
        from sqlalchemy.orm import object_session
        session = object_session(self)
        if session:
            result = session.execute(
                usuario_empresa.select().where(
                    (usuario_empresa.c.usuario_id == self.id) &
                    (usuario_empresa.c.empresa_id == empresa_id)
                )
            ).first()
            return result
        return None


class SesionUsuario(Base):
    """Registro de sesiones de usuario para auditoría."""
    
    __tablename__ = "sesiones_usuario"
    
    id = Column(Integer, primary_key=True, index=True)
    usuario_id = Column(Integer, ForeignKey("usuarios.id", ondelete="CASCADE"), nullable=False)
    token_jti = Column(String(255), nullable=True)  # JWT ID para invalidación
    ip_address = Column(String(45), nullable=True)
    user_agent = Column(Text, nullable=True)
    dispositivo = Column(String(255), nullable=True)
    
    # Estado
    activa = Column(Boolean, default=True)
    creado_en = Column(DateTime(timezone=True), server_default=func.now())
    expira_en = Column(DateTime(timezone=True), nullable=True)
    cerrada_en = Column(DateTime(timezone=True), nullable=True)
    
    usuario = relationship("Usuario", back_populates="sesiones")
