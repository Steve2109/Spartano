"""
Modelos de Producto, Inventario, Cliente, Proveedor y Facturación.
"""
from sqlalchemy import Column, Integer, String, Boolean, DateTime, Text, Numeric, ForeignKey, JSON, Enum
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
import enum
from app.db.base import Base


class TipoProducto(str, enum.Enum):
    BIEN = "bien"
    SERVICIO = "servicio"


class TipoIva(str, enum.Enum):
    IVA_0 = "0"
    IVA_12 = "12"
    IVA_14 = "14"
    EXENTO = "exento"
    NO_OBJETO = "no_objeto"


class Producto(Base):
    """Productos o servicios de la empresa."""
    
    __tablename__ = "productos"
    
    id = Column(Integer, primary_key=True, index=True)
    empresa_id = Column(Integer, ForeignKey("empresas.id", ondelete="CASCADE"), nullable=False)
    
    # Código y nombre
    codigo = Column(String(50), nullable=False)
    codigo_barras = Column(String(100), nullable=True)
    nombre = Column(String(500), nullable=False)
    descripcion = Column(Text, nullable=True)
    
    # Tipo
    tipo = Column(Enum(TipoProducto), default=TipoProducto.BIEN)
    categoria = Column(String(100), nullable=True)
    
    # Impuestos
    tipo_iva = Column(Enum(TipoIva), default=TipoIva.IVA_12)
    iva_porcentaje = Column(Numeric(5, 2), default=12)
    
    # ICE (Impuesto a Consumos Especiales)
    sujeto_ice = Column(Boolean, default=False)
    codigo_ice = Column(String(10), nullable=True)
    tarifa_ice = Column(Numeric(10, 4), default=0)
    
    # IRBPNR (Impuesto Reducible a Bebidas no Retornables)
    sujeto_irbpnr = Column(Boolean, default=False)
    
    # Precios
    precio_compra = Column(Numeric(18, 4), default=0)
    precio_venta = Column(Numeric(18, 4), default=0)
    precio_venta_2 = Column(Numeric(18, 4), nullable=True)
    precio_venta_3 = Column(Numeric(18, 4), nullable=True)
    
    # Unidad
    unidad_medida = Column(String(50), default="UNIDAD")
    
    # Control de inventario
    maneja_stock = Column(Boolean, default=True)
    stock_minimo = Column(Numeric(18, 2), default=0)
    stock_maximo = Column(Numeric(18, 2), nullable=True)
    stock_actual = Column(Numeric(18, 2), default=0)
    
    # Cuentas contables asociadas
    cuenta_venta_id = Column(Integer, ForeignKey("cuentas_contables.id"), nullable=True)
    cuenta_compra_id = Column(Integer, ForeignKey("cuentas_contables.id"), nullable=True)
    cuenta_inventario_id = Column(Integer, ForeignKey("cuentas_contables.id"), nullable=True)
    
    # Estado
    activo = Column(Boolean, default=True)
    
    # Auditoría
    creado_en = Column(DateTime(timezone=True), server_default=func.now())
    actualizado_en = Column(DateTime(timezone=True), onupdate=func.now())
    
    # Relaciones
    empresa = relationship("Empresa", back_populates="productos")
    movimientos_inventario = relationship("MovimientoInventario", back_populates="producto")
    
    def calcular_precio_final(self) -> float:
        """Calcula precio con IVA incluido."""
        if self.tipo_iva == TipoIva.IVA_0 or self.tipo_iva == TipoIva.EXENTO:
            return float(self.precio_venta)
        return float(self.precio_venta) * (1 + float(self.iva_porcentaje) / 100)


class Cliente(Base):
    """Clientes de la empresa."""
    
    __tablename__ = "clientes"
    
    id = Column(Integer, primary_key=True, index=True)
    empresa_id = Column(Integer, ForeignKey("empresas.id", ondelete="CASCADE"), nullable=False)
    
    # Identificación
    tipo_identificacion = Column(String(2), nullable=False)  # 04=RUC, 05=Cédula, 06=PAS, 07=CF, 08=ID Ext
    identificacion = Column(String(20), nullable=False, index=True)
    
    # Datos
    razon_social = Column(String(500), nullable=False)
    nombre_comercial = Column(String(500), nullable=True)
    direccion = Column(Text, nullable=True)
    telefono = Column(String(20), nullable=True)
    email = Column(String(255), nullable=True)
    
    # Retenciones
    obligado_contabilidad = Column(Boolean, default=False)
    tipo_cliente = Column(String(50), default="normal")  # normal, especiales, exterior
    
    # Plazos
    plazo_credito_dias = Column(Integer, default=0)
    cupo_credito = Column(Numeric(18, 2), default=0)
    
    # Estado
    activo = Column(Boolean, default=True)
    
    # Auditoría
    creado_en = Column(DateTime(timezone=True), server_default=func.now())
    actualizado_en = Column(DateTime(timezone=True), onupdate=func.now())
    
    empresa = relationship("Empresa", back_populates="clientes")
    facturas = relationship("Factura", back_populates="cliente")


class Proveedor(Base):
    """Proveedores de la empresa."""
    
    __tablename__ = "proveedores"
    
    id = Column(Integer, primary_key=True, index=True)
    empresa_id = Column(Integer, ForeignKey("empresas.id", ondelete="CASCADE"), nullable=False)
    
    # Identificación
    tipo_identificacion = Column(String(2), nullable=False)
    identificacion = Column(String(20), nullable=False, index=True)
    
    # Datos
    razon_social = Column(String(500), nullable=False)
    nombre_comercial = Column(String(500), nullable=True)
    direccion = Column(Text, nullable=True)
    telefono = Column(String(20), nullable=True)
    email = Column(String(255), nullable=True)
    
    # Retenciones por defecto
    retencion_iva_default = Column(Numeric(5, 2), default=30)  # 30, 70, 100
    retencion_renta_default = Column(Numeric(5, 2), default=0)  # Según tabla
    
    # Plazos
    plazo_credito_dias = Column(Integer, default=0)
    
    # Estado
    activo = Column(Boolean, default=True)
    
    # Auditoría
    creado_en = Column(DateTime(timezone=True), server_default=func.now())
    actualizado_en = Column(DateTime(timezone=True), onupdate=func.now())
    
    empresa = relationship("Empresa", back_populates="proveedores")


class Factura(Base):
    """Facturas electrónicas emitidas."""
    
    __tablename__ = "facturas"
    
    id = Column(Integer, primary_key=True, index=True)
    empresa_id = Column(Integer, ForeignKey("empresas.id", ondelete="CASCADE"), nullable=False)
    cliente_id = Column(Integer, ForeignKey("clientes.id"), nullable=False)
    
    # Serie y número
    establecimiento = Column(String(3), nullable=False)
    punto_emision = Column(String(3), nullable=False)
    secuencial = Column(String(9), nullable=False)
    
    # Clave de acceso SRI (49 dígitos)
    clave_acceso = Column(String(49), unique=True, index=True, nullable=True)
    
    # Fechas
    fecha_emision = Column(DateTime(timezone=True), nullable=False)
    fecha_vencimiento = Column(DateTime(timezone=True), nullable=True)
    
    # Totales
    subtotal_sin_impuestos = Column(Numeric(18, 2), default=0)
    subtotal_12 = Column(Numeric(18, 2), default=0)
    subtotal_0 = Column(Numeric(18, 2), default=0)
    subtotal_no_objeto = Column(Numeric(18, 2), default=0)
    subtotal_exento = Column(Numeric(18, 2), default=0)
    
    descuento_total = Column(Numeric(18, 2), default=0)
    
    iva_12 = Column(Numeric(18, 2), default=0)
    ice = Column(Numeric(18, 2), default=0)
    irbpnr = Column(Numeric(18, 2), default=0)
    
    propina = Column(Numeric(18, 2), default=0)
    
    importe_total = Column(Numeric(18, 2), default=0)
    
    # Forma de pago
    forma_pago = Column(String(2), default="01")  # 01=efectivo, 16=tarjeta, 20=transferencia, etc.
    
    # Estado SRI
    estado_sri = Column(String(20), default="PENDIENTE")  # PENDIENTE, RECIBIDA, AUTORIZADA, RECHAZADA, ANULADA
    numero_autorizacion = Column(String(50), nullable=True)
    fecha_autorizacion = Column(DateTime(timezone=True), nullable=True)
    mensaje_sri = Column(Text, nullable=True)
    
    # Archivos
    xml_path = Column(String(500), nullable=True)
    pdf_path = Column(String(500), nullable=True)
    
    # Estado
    anulada = Column(Boolean, default=False)
    
    # Auditoría
    creado_en = Column(DateTime(timezone=True), server_default=func.now())
    creado_por_id = Column(Integer, ForeignKey("usuarios.id"), nullable=True)
    
    empresa = relationship("Empresa", back_populates="facturas")
    cliente = relationship("Cliente", back_populates="facturas")
    items = relationship("FacturaItem", back_populates="factura", cascade="all, delete-orphan")


class FacturaItem(Base):
    """Items de una factura."""
    
    __tablename__ = "factura_items"
    
    id = Column(Integer, primary_key=True, index=True)
    factura_id = Column(Integer, ForeignKey("facturas.id", ondelete="CASCADE"), nullable=False)
    producto_id = Column(Integer, ForeignKey("productos.id"), nullable=True)
    
    # Datos del item
    codigo_principal = Column(String(50), nullable=True)
    codigo_auxiliar = Column(String(50), nullable=True)
    descripcion = Column(Text, nullable=False)
    
    # Cantidad y unidad
    cantidad = Column(Numeric(18, 6), nullable=False)
    unidad_medida = Column(String(50), default="UNIDAD")
    
    # Precios
    precio_unitario = Column(Numeric(18, 6), nullable=False)
    descuento = Column(Numeric(18, 6), default=0)
    
    # Impuestos
    tipo_iva = Column(Enum(TipoIva), default=TipoIva.IVA_12)
    iva_porcentaje = Column(Numeric(5, 2), default=12)
    valor_iva = Column(Numeric(18, 2), default=0)
    
    # Totales
    precio_total_sin_impuesto = Column(Numeric(18, 2), nullable=False)
    
    factura = relationship("Factura", back_populates="items")
    producto = relationship("Producto")


class Retencion(Base):
    """Comprobantes de retención emitidos."""
    
    __tablename__ = "retenciones"
    
    id = Column(Integer, primary_key=True, index=True)
    empresa_id = Column(Integer, ForeignKey("empresas.id", ondelete="CASCADE"), nullable=False)
    proveedor_id = Column(Integer, ForeignKey("proveedores.id"), nullable=False)
    
    # Serie y número
    establecimiento = Column(String(3), nullable=False)
    punto_emision = Column(String(3), nullable=False)
    secuencial = Column(String(9), nullable=False)
    
    clave_acceso = Column(String(49), unique=True, index=True, nullable=True)
    
    # Referencia a documento retenido
    doc_sustento_tipo = Column(String(2), nullable=False)  # 01=factura
    doc_sustento_numero = Column(String(20), nullable=False)
    doc_sustento_autorizacion = Column(String(50), nullable=False)
    doc_sustento_fecha = Column(DateTime(timezone=True), nullable=False)
    
    # Fecha
    fecha_emision = Column(DateTime(timezone=True), nullable=False)
    
    # Estado SRI
    estado_sri = Column(String(20), default="PENDIENTE")
    numero_autorizacion = Column(String(50), nullable=True)
    fecha_autorizacion = Column(DateTime(timezone=True), nullable=True)
    
    # Archivos
    xml_path = Column(String(500), nullable=True)
    pdf_path = Column(String(500), nullable=True)
    
    # Auditoría
    creado_en = Column(DateTime(timezone=True), server_default=func.now())
    
    items = relationship("RetencionItem", back_populates="retencion", cascade="all, delete-orphan")


class RetencionItem(Base):
    """Items de retención (impuestos retenidos)."""
    
    __tablename__ = "retencion_items"
    
    id = Column(Integer, primary_key=True, index=True)
    retencion_id = Column(Integer, ForeignKey("retenciones.id", ondelete="CASCADE"), nullable=False)
    
    # Tipo de impuesto
    tipo_impuesto = Column(String(2), nullable=False)  # 1=renta, 2=iva, 6=ISD
    codigo_impuesto = Column(String(10), nullable=False)  # Código según SRI
    
    # Base y porcentaje
    base_imponible = Column(Numeric(18, 2), nullable=False)
    porcentaje_retencion = Column(Numeric(5, 2), nullable=False)
    valor_retenido = Column(Numeric(18, 2), nullable=False)
    
    retencion = relationship("Retencion", back_populates="items")
