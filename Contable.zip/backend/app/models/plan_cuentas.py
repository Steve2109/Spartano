"""
Plan de cuentas contables según catálogo SRI ecuatoriano.
"""
from sqlalchemy import Column, Integer, String, Boolean, DateTime, Text, Numeric, ForeignKey, Enum
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
import enum
from app.db.base import Base


class TipoCuenta(str, enum.Enum):
    ACTIVO = "activo"
    PASIVO = "pasivo"
    PATRIMONIO = "patrimonio"
    INGRESOS = "ingresos"
    GASTOS = "gastos"
    COSTOS = "costos"


class NivelCuenta(int, enum.Enum):
    GRUPO = 1
    SUBGRUPO = 2  
    CUENTA = 3
    SUBCUENTA = 4
    AUXILIAR = 5


class CuentaContable(Base):
    """Cuenta del plan de cuentas contables."""
    
    __tablename__ = "cuentas_contables"
    
    id = Column(Integer, primary_key=True, index=True)
    empresa_id = Column(Integer, ForeignKey("empresas.id", ondelete="CASCADE"), nullable=False)
    
    # Estructura jerárquica
    codigo = Column(String(20), nullable=False, index=True)
    codigo_padre = Column(String(20), ForeignKey("cuentas_contables.codigo"), nullable=True)
    
    # Datos
    nombre = Column(String(500), nullable=False)
    descripcion = Column(Text, nullable=True)
    tipo = Column(Enum(TipoCuenta), nullable=False)
    nivel = Column(Enum(NivelCuenta), nullable=False)
    
    # Comportamiento
    permite_movimientos = Column(Boolean, default=True)
    es_cuenta_efectivo = Column(Boolean, default=False)  # Para conciliación bancaria
    es_cuenta_banco = Column(Boolean, default=False)
    es_cuenta_iva = Column(Boolean, default=False)
    es_cuenta_retencion = Column(Boolean, default=False)
    
    # Códigos SRI específicos
    codigo_sri = Column(String(20), nullable=True)  # Código en catálogo SRI
    
    # Saldos
    saldo_actual = Column(Numeric(18, 2), default=0)
    saldo_anterior = Column(Numeric(18, 2), default=0)
    
    # Estado
    activa = Column(Boolean, default=True)
    
    # Auditoría
    creado_en = Column(DateTime(timezone=True), server_default=func.now())
    actualizado_en = Column(DateTime(timezone=True), onupdate=func.now())
    
    # Relaciones
    empresa = relationship("Empresa", back_populates="cuentas")
    padre = relationship("CuentaContable", remote_side=[codigo], back_populates="hijos")
    hijos = relationship("CuentaContable", back_populates="padre")
    movimientos = relationship("MovimientoContable", back_populates="cuenta")
    
    def __repr__(self):
        return f"<Cuenta {self.codigo} - {self.nombre}>"


class AsientoContable(Base):
    """Asiento contable (transacción)."""
    
    __tablename__ = "asientos_contables"
    
    id = Column(Integer, primary_key=True, index=True)
    empresa_id = Column(Integer, ForeignKey("empresas.id", ondelete="CASCADE"), nullable=False)
    
    # Identificación
    numero = Column(String(50), nullable=False)
    fecha = Column(DateTime(timezone=True), nullable=False)
    
    # Datos
    concepto = Column(Text, nullable=False)
    documento_referencia = Column(String(100), nullable=True)  # Factura, etc.
    tipo_asiento = Column(String(50), default="normal")  # apertura, cierre, ajuste, normal
    
    # Estado
    cuadrado = Column(Boolean, default=False)  # Debe == Haber
    anulado = Column(Boolean, default=False)
    
    # Auditoría
    creado_en = Column(DateTime(timezone=True), server_default=func.now())
    creado_por_id = Column(Integer, ForeignKey("usuarios.id"), nullable=True)
    
    # Relaciones
    empresa = relationship("Empresa", back_populates="asientos")
    movimientos = relationship("MovimientoContable", back_populates="asiento", cascade="all, delete-orphan")
    
    def verificar_cuadre(self) -> bool:
        """Verifica que los débitos igualen los créditos."""
        total_debe = sum(m.debe for m in self.movimientos)
        total_haber = sum(m.haber for m in self.movimientos)
        return total_debe == total_haber
    
    def __repr__(self):
        return f"<Asiento {self.numero}>"


class MovimientoContable(Base):
    """Movimiento individual dentro de un asiento contable."""
    
    __tablename__ = "movimientos_contables"
    
    id = Column(Integer, primary_key=True, index=True)
    asiento_id = Column(Integer, ForeignKey("asientos_contables.id", ondelete="CASCADE"), nullable=False)
    cuenta_id = Column(Integer, ForeignKey("cuentas_contables.id"), nullable=False)
    
    # Montos
    debe = Column(Numeric(18, 2), default=0)
    haber = Column(Numeric(18, 2), default=0)
    
    # Descripción
    descripcion = Column(Text, nullable=True)
    
    # Referencia externa
    documento_tipo = Column(String(50), nullable=True)  # factura, retencion, etc.
    documento_id = Column(Integer, nullable=True)
    
    asiento = relationship("AsientoContable", back_populates="movimientos")
    cuenta = relationship("CuentaContable", back_populates="movimientos")
    
    def __repr__(self):
        return f"<Movimiento {self.cuenta.codigo if self.cuenta else ''}: D={self.debe} H={self.haber}>"
