"""
Configuración de backups y archivos.
"""
from sqlalchemy import Column, Integer, String, Boolean, DateTime, Text, ForeignKey, JSON
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from app.db.base import Base


class BackupHistory(Base):
    """Historial de backups automáticos."""
    
    __tablename__ = "backup_history"
    
    id = Column(Integer, primary_key=True, index=True)
    empresa_id = Column(Integer, ForeignKey("empresas.id", ondelete="CASCADE"), nullable=False)
    
    # Información del backup
    nombre_archivo = Column(String(255), nullable=False)
    ruta_archivo = Column(String(500), nullable=False)
    tamano_bytes = Column(Integer, nullable=False)
    
    # Estado
    estado = Column(String(20), default="EN_PROGRESO")  # EN_PROGRESO, COMPLETADO, FALLIDO
    mensaje_error = Column(Text, nullable=True)
    
    # Verificación
    checksum = Column(String(64), nullable=True)  # SHA-256
    encriptado = Column(Boolean, default=True)
    
    # Fechas
    iniciado_en = Column(DateTime(timezone=True), server_default=func.now())
    completado_en = Column(DateTime(timezone=True), nullable=True)
    
    # Metadatos
    tablas_incluidas = Column(JSON, default=list)
    registros_respaldados = Column(Integer, nullable=True)


class EmailConfig(Base):
    """Configuración de email por empresa."""
    
    __tablename__ = "email_configs"
    
    id = Column(Integer, primary_key=True, index=True)
    empresa_id = Column(Integer, ForeignKey("empresas.id", ondelete="CASCADE"), nullable=False)
    
    # SMTP
    smtp_host = Column(String(255), nullable=True)
    smtp_port = Column(Integer, default=587)
    smtp_user = Column(String(255), nullable=True)
    # La contraseña SMTP se guarda en .env, aquí solo referencia o uso de keychain
    smtp_password_reference = Column(String(100), nullable=True)
    smtp_tls = Column(Boolean, default=True)
    
    # IMAP
    imap_host = Column(String(255), nullable=True)
    imap_port = Column(Integer, default=993)
    imap_user = Column(String(255), nullable=True)
    imap_password_reference = Column(String(100), nullable=True)
    imap_ssl = Column(Boolean, default=True)
    
    # POP
    pop_host = Column(String(255), nullable=True)
    pop_port = Column(Integer, default=995)
    pop_user = Column(String(255), nullable=True)
    pop_password_reference = Column(String(100), nullable=True)
    pop_ssl = Column(Boolean, default=True)
    
    # Configuración general
    email_default_from = Column(String(255), nullable=True)
    nombre_default_from = Column(String(255), nullable=True)
    
    # Estado
    activa = Column(Boolean, default=True)
    ultima_prueba = Column(DateTime(timezone=True), nullable=True)
    ultima_prueba_exitosa = Column(Boolean, default=False)
    
    creado_en = Column(DateTime(timezone=True), server_default=func.now())
    actualizado_en = Column(DateTime(timezone=True), onupdate=func.now())


class FileScanResult(Base):
    """Resultados de escaneo de archivos con ClamAV y VirusTotal."""
    
    __tablename__ = "file_scan_results"
    
    id = Column(Integer, primary_key=True, index=True)
    empresa_id = Column(Integer, ForeignKey("empresas.id", ondelete="CASCADE"), nullable=False)
    
    # Información del archivo
    nombre_original = Column(String(255), nullable=False)
    nombre_almacenado = Column(String(255), nullable=False)
    ruta_archivo = Column(String(500), nullable=False)
    tamano_bytes = Column(Integer, nullable=False)
    mime_type = Column(String(100), nullable=True)
    checksum_sha256 = Column(String(64), nullable=True)
    
    # Resultados ClamAV
    clamav_escaneado = Column(Boolean, default=False)
    clamav_limpio = Column(Boolean, nullable=True)
    clamav_malware_detectado = Column(Boolean, default=False)
    clamav_nombre_virus = Column(String(255), nullable=True)
    clamav_version = Column(String(50), nullable=True)
    
    # Resultados VirusTotal (opcional)
    vt_escaneado = Column(Boolean, default=False)
    vt_api_used = Column(Boolean, default=False)
    vt_positives = Column(Integer, nullable=True)
    vt_total = Column(Integer, nullable=True)
    vt_scan_id = Column(String(100), nullable=True)
    vt_permalink = Column(String(500), nullable=True)
    
    # Decisión final
    archivo_aceptado = Column(Boolean, default=False)
    motivo_rechazo = Column(Text, nullable=True)
    
    # Usuario que subió el archivo
    subido_por_id = Column(Integer, ForeignKey("usuarios.id"), nullable=True)
    ip_address = Column(String(45), nullable=True)
    
    # Fechas
    creado_en = Column(DateTime(timezone=True), server_default=func.now())
    procesado_en = Column(DateTime(timezone=True), nullable=True)
