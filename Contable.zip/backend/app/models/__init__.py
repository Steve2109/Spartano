"""
Modelos de base de datos del Sistema Contable TyM.
"""
from app.models.usuario import Usuario, SesionUsuario, usuario_empresa
from app.models.empresa import Empresa, Sucursal
from app.models.plan_cuentas import (
    CuentaContable, AsientoContable, MovimientoContable,
    TipoCuenta, NivelCuenta
)
from app.models.producto import (
    Producto, Cliente, Proveedor, Factura, FacturaItem,
    Retencion, RetencionItem, TipoProducto, TipoIva
)
from app.models.inventario import (
    Bodega, StockBodega, MovimientoInventario, AjusteInventario,
    AjusteInventarioItem, AlertaStock,
    TipoMovimiento, TipoDocumentoOrigen
)
from app.models.backup_config import BackupHistory, EmailConfig, FileScanResult

__all__ = [
    # Usuarios
    "Usuario",
    "SesionUsuario",
    "usuario_empresa",
    
    # Empresas
    "Empresa",
    "Sucursal",
    
    # Contabilidad
    "CuentaContable",
    "AsientoContable",
    "MovimientoContable",
    "TipoCuenta",
    "NivelCuenta",
    
    # Productos y Facturación
    "Producto",
    "Cliente",
    "Proveedor",
    "Factura",
    "FacturaItem",
    "Retencion",
    "RetencionItem",
    "TipoProducto",
    "TipoIva",
    
    # Inventario
    "Bodega",
    "StockBodega",
    "MovimientoInventario",
    "AjusteInventario",
    "AjusteInventarioItem",
    "AlertaStock",
    "TipoMovimiento",
    "TipoDocumentoOrigen",
    
    # Configuración
    "BackupHistory",
    "EmailConfig",
    "FileScanResult",
]
