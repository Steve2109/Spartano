"""
Modelos de Inventario: Bodegas, Movimientos, Kardex.
"""
from sqlalchemy import Column, Integer, String, Boolean, DateTime, Text, Numeric, ForeignKey, Enum, JSON
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
import enum
from app.db.base import Base


class TipoMovimiento(str, enum.Enum):
    ENTRADA = "entrada"
    SALIDA = "salida"
    TRASLADO = "traslado"
    AJUSTE = "ajuste"
    DEVOLUCION = "devolucion"


class TipoDocumentoOrigen(str, enum.Enum):
    FACTURA_COMPRA = "factura_compra"
    FACTURA_VENTA = "factura_venta"
    NOTA_CREDITO = "nota_credito"
    NOTA_DEBITO = "nota_debito"
    AJUSTE_INVENTARIO = "ajuste_inventario"
    TRASLADO = "traslado"
    ORDEN_COMPRA = "orden_compra"
    ORDEN_VENTA = "orden_venta"
    DEVOLUCION = "devolucion"
    PRODUCCION = "produccion"
    OTRO = "otro"


class Bodega(Base):
    """Bodegas o almacenes."""
    
    __tablename__ = "bodegas"
    
    id = Column(Integer, primary_key=True, index=True)
    sucursal_id = Column(Integer, ForeignKey("sucursales.id", ondelete="CASCADE"), nullable=False)
    
    codigo = Column(String(20), nullable=False)
    nombre = Column(String(200), nullable=False)
    descripcion = Column(Text, nullable=True)
    direccion = Column(Text, nullable=True)
    
    # Responsable
    responsable_id = Column(Integer, ForeignKey("usuarios.id"), nullable=True)
    
    # Tipo
    es_principal = Column(Boolean, default=False)
    permite_venta = Column(Boolean, default=True)
    permite_compra = Column(Boolean, default=True)
    
    # Estado
    activa = Column(Boolean, default=True)
    
    # Auditoría
    creado_en = Column(DateTime(timezone=True), server_default=func.now())
    
    sucursal = relationship("Sucursal", back_populates="bodegas")
    stocks = relationship("StockBodega", back_populates="bodega", cascade="all, delete-orphan")
    movimientos_origen = relationship("MovimientoInventario", foreign_keys="MovimientoInventario.bodega_origen_id", back_populates="bodega_origen")
    movimientos_destino = relationship("MovimientoInventario", foreign_keys="MovimientoInventario.bodega_destino_id", back_populates="bodega_destino")


class StockBodega(Base):
    """Stock de producto por bodega."""
    
    __tablename__ = "stocks_bodega"
    
    id = Column(Integer, primary_key=True, index=True)
    bodega_id = Column(Integer, ForeignKey("bodegas.id", ondelete="CASCADE"), nullable=False)
    producto_id = Column(Integer, ForeignKey("productos.id", ondelete="CASCADE"), nullable=False)
    
    cantidad = Column(Numeric(18, 4), default=0)
    cantidad_reservada = Column(Numeric(18, 4), default=0)  # Para pedidos
    cantidad_disponible = Column(Numeric(18, 4), default=0)
    
    # Costos
    costo_promedio = Column(Numeric(18, 6), default=0)
    ultimo_costo = Column(Numeric(18, 6), default=0)
    
    # Ubicación física
    ubicacion = Column(String(200), nullable=True)
    
    # Alertas
    stock_minimo = Column(Numeric(18, 4), default=0)
    stock_maximo = Column(Numeric(18, 4), nullable=True)
    alerta_generada = Column(Boolean, default=False)
    
    actualizado_en = Column(DateTime(timezone=True), onupdate=func.now())
    
    bodega = relationship("Bodega", back_populates="stocks")
    producto = relationship("Producto")
    
    def calcular_disponible(self):
        """Recalcula cantidad disponible."""
        self.cantidad_disponible = self.cantidad - self.cantidad_reservada


class MovimientoInventario(Base):
    """
    Kardex - Registro de todos los movimientos de inventario.
    Este es el libro de inventarios obligatorio.
    """
    
    __tablename__ = "movimientos_inventario"
    
    id = Column(Integer, primary_key=True, index=True)
    empresa_id = Column(Integer, ForeignKey("empresas.id", ondelete="CASCADE"), nullable=False)
    
    # Producto
    producto_id = Column(Integer, ForeignKey("productos.id"), nullable=False)
    
    # Bodegas
    bodega_origen_id = Column(Integer, ForeignKey("bodegas.id"), nullable=True)
    bodega_destino_id = Column(Integer, ForeignKey("bodegas.id"), nullable=True)
    
    # Tipo y naturaleza
    tipo_movimiento = Column(Enum(TipoMovimiento), nullable=False)
    tipo_documento_origen = Column(Enum(TipoDocumentoOrigen), nullable=True)
    
    # Documento origen
    documento_id = Column(Integer, nullable=True)  # ID del documento relacionado
    documento_numero = Column(String(50), nullable=True)
    documento_fecha = Column(DateTime(timezone=True), nullable=True)
    
    # Cantidades
    cantidad = Column(Numeric(18, 6), nullable=False)
    
    # Valores (para cálculo de costo promedio)
    costo_unitario = Column(Numeric(18, 6), nullable=False)
    costo_total = Column(Numeric(18, 2), nullable=False)
    
    # Saldos después del movimiento (para el Kardex)
    saldo_cantidad = Column(Numeric(18, 6), nullable=False)
    saldo_costo_promedio = Column(Numeric(18, 6), nullable=False)
    saldo_costo_total = Column(Numeric(18, 2), nullable=False)
    
    # Descripción/observación
    descripcion = Column(Text, nullable=True)
    
    # Usuario que realizó el movimiento
    usuario_id = Column(Integer, ForeignKey("usuarios.id"), nullable=True)
    
    # Fecha del movimiento
    fecha_movimiento = Column(DateTime(timezone=True), nullable=False)
    creado_en = Column(DateTime(timezone=True), server_default=func.now())
    
    # Relaciones
    producto = relationship("Producto", back_populates="movimientos_inventario")
    bodega_origen = relationship("Bodega", foreign_keys=[bodega_origen_id], back_populates="movimientos_origen")
    bodega_destino = relationship("Bodega", foreign_keys=[bodega_destino_id], back_populates="movimientos_destino")
    
    def es_entrada(self) -> bool:
        """Determina si el movimiento es entrada de inventario."""
        return self.tipo_movimiento in [TipoMovimiento.ENTRADA, TipoMovimiento.DEVOLUCION]
    
    def es_salida(self) -> bool:
        """Determina si el movimiento es salida de inventario."""
        return self.tipo_movimiento in [TipoMovimiento.SALIDA, TipoMovimiento.TRASLADO]


class AjusteInventario(Base):
    """Registro de ajustes de inventario físico."""
    
    __tablename__ = "ajustes_inventario"
    
    id = Column(Integer, primary_key=True, index=True)
    empresa_id = Column(Integer, ForeignKey("empresas.id", ondelete="CASCADE"), nullable=False)
    
    # Cabecera
    numero = Column(String(20), nullable=False, unique=True)
    fecha = Column(DateTime(timezone=True), nullable=False)
    bodega_id = Column(Integer, ForeignKey("bodegas.id"), nullable=False)
    
    # Estado
    estado = Column(String(20), default="BORRADOR")  # BORRADOR, APROBADO, ANULADO
    
    # Observación
    observacion = Column(Text, nullable=True)
    
    # Auditoría
    creado_en = Column(DateTime(timezone=True), server_default=func.now())
    aprobado_en = Column(DateTime(timezone=True), nullable=True)
    aprobado_por_id = Column(Integer, ForeignKey("usuarios.id"), nullable=True)
    
    # Relaciones
    items = relationship("AjusteInventarioItem", back_populates="ajuste", cascade="all, delete-orphan")


class AjusteInventarioItem(Base):
    """Items de ajuste de inventario."""
    
    __tablename__ = "ajuste_inventario_items"
    
    id = Column(Integer, primary_key=True, index=True)
    ajuste_id = Column(Integer, ForeignKey("ajustes_inventario.id", ondelete="CASCADE"), nullable=False)
    producto_id = Column(Integer, ForeignKey("productos.id"), nullable=False)
    
    # Cantidades
    stock_sistema = Column(Numeric(18, 4), nullable=False)
    stock_fisico = Column(Numeric(18, 4), nullable=False)
    diferencia = Column(Numeric(18, 4), nullable=False)
    
    # Costo unitario para valorizar el ajuste
    costo_unitario = Column(Numeric(18, 6), default=0)
    
    # Observación del item
    observacion = Column(String(500), nullable=True)
    
    ajuste = relationship("AjusteInventario", back_populates="items")
    producto = relationship("Producto")


class AlertaStock(Base):
    """Alertas de stock bajo o agotado."""
    
    __tablename__ = "alertas_stock"
    
    id = Column(Integer, primary_key=True, index=True)
    empresa_id = Column(Integer, ForeignKey("empresas.id", ondelete="CASCADE"), nullable=False)
    producto_id = Column(Integer, ForeignKey("productos.id"), nullable=False)
    bodega_id = Column(Integer, ForeignKey("bodegas.id"), nullable=True)
    
    # Tipo de alerta
    tipo = Column(String(20), nullable=False)  # STOCK_BAJO, SIN_STOCK, STOCK_EXCEDIDO
    
    # Datos de la alerta
    stock_actual = Column(Numeric(18, 4), nullable=False)
    stock_minimo = Column(Numeric(18, 4), nullable=True)
    stock_maximo = Column(Numeric(18, 4), nullable=True)
    
    # Estado
    leida = Column(Boolean, default=False)
    resuelta = Column(Boolean, default=False)
    
    # Fechas
    creado_en = Column(DateTime(timezone=True), server_default=func.now())
    leida_en = Column(DateTime(timezone=True), nullable=True)
    resuelta_en = Column(DateTime(timezone=True), nullable=True)
    
    # Usuarios
    notificar_a_id = Column(Integer, ForeignKey("usuarios.id"), nullable=True)
    resuelta_por_id = Column(Integer, ForeignKey("usuarios.id"), nullable=True)
