"""
Modelo de Empresa con configuración de firma electrónica.
"""
from sqlalchemy import Column, Integer, String, Boolean, DateTime, Text, Numeric, ForeignKey, JSON
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from app.db.base import Base


class Empresa(Base):
    """Modelo de empresa/organización (multi-tenant)."""
    
    __tablename__ = "empresas"
    
    id = Column(Integer, primary_key=True, index=True)
    
    # Datos básicos
    ruc = Column(String(13), unique=True, index=True, nullable=False)
    razon_social = Column(String(500), nullable=False)
    nombre_comercial = Column(String(500), nullable=True)
    direccion_matriz = Column(Text, nullable=False)
    direccion_establecimiento = Column(Text, nullable=True)
    
    # Contácto
    email = Column(String(255), nullable=True)
    telefono = Column(String(20), nullable=True)
    celular = Column(String(20), nullable=True)
    
    # Configuración SRI
    obligado_contabilidad = Column(Boolean, default=True)
    contribuyente_especial = Column(String(10), nullable=True)  # Número de resolución
    tipo_regimen = Column(String(50), default="RIMPE")  # RIMPE, GENERAL
    agente_retencion = Column(Boolean, default=False)
    numero_resolucion_agente = Column(String(50), nullable=True)
    
    # Firma electrónica (ruta en disco, NUNCA el archivo .p12)
    firma_electronica_path = Column(String(500), nullable=True)
    firma_electronica_validez = Column(DateTime(timezone=True), nullable=True)
    firma_electronica_emitido_por = Column(String(255), nullable=True)
    
    # Logo (ruta en disco)
    logo_path = Column(String(500), nullable=True)
    
    # Configuración adicional
    configuracion = Column(JSON, default=dict)  # Configuraciones varias en JSON
    
    # Estado
    activa = Column(Boolean, default=True)
    certificada_sri = Column(Boolean, default=False)
    
    # Auditoría
    creado_en = Column(DateTime(timezone=True), server_default=func.now())
    actualizado_en = Column(DateTime(timezone=True), onupdate=func.now())
    creado_por_id = Column(Integer, ForeignKey("usuarios.id"), nullable=True)
    
    # Relaciones
    usuarios = relationship("Usuario", secondary="usuario_empresa", back_populates="empresas")
    sucursales = relationship("Sucursal", back_populates="empresa", cascade="all, delete-orphan")
    productos = relationship("Producto", back_populates="empresa", cascade="all, delete-orphan")
    clientes = relationship("Cliente", back_populates="empresa", cascade="all, delete-orphan")
    proveedores = relationship("Proveedor", back_populates="empresa", cascade="all, delete-orphan")
    facturas = relationship("Factura", back_populates="empresa", cascade="all, delete-orphan")
    asientos = relationship("AsientoContable", back_populates="empresa", cascade="all, delete-orphan")
    cuentas = relationship("CuentaContable", back_populates="empresa", cascade="all, delete-orphan")
    
    def __repr__(self):
        return f"<Empresa {self.ruc} - {self.razon_social}>"


class Sucursal(Base):
    """Sucursal o establecimiento de la empresa."""
    
    __tablename__ = "sucursales"
    
    id = Column(Integer, primary_key=True, index=True)
    empresa_id = Column(Integer, ForeignKey("empresas.id", ondelete="CASCADE"), nullable=False)
    
    codigo = Column(String(3), nullable=False)  # 001, 002, etc.
    nombre = Column(String(200), nullable=False)
    direccion = Column(Text, nullable=False)
    telefono = Column(String(20), nullable=True)
    email = Column(String(255), nullable=True)
    
    # Configuración facturación
    serie_factura = Column(String(6), default="001-001")
    serie_nota_credito = Column(String(6), default="001-002")
    serie_nota_debito = Column(String(6), default="001-003")
    serie_retencion = Column(String(6), default="001-004")
    serie_guia = Column(String(6), default="001-005")
    
    # Secuencias actuales
    secuencia_factura = Column(Integer, default=1)
    secuencia_nota_credito = Column(Integer, default=1)
    secuencia_nota_debito = Column(Integer, default=1)
    secuencia_retencion = Column(Integer, default=1)
    secuencia_guia = Column(Integer, default=1)
    
    activa = Column(Boolean, default=True)
    creado_en = Column(DateTime(timezone=True), server_default=func.now())
    
    empresa = relationship("Empresa", back_populates="sucursales")
    bodegas = relationship("Bodega", back_populates="sucursal", cascade="all, delete-orphan")
    
    def get_siguiente_numero(self, tipo: str) -> int:
        """Obtiene y incrementa la secuencia para un tipo de documento."""
        campos = {
            "factura": "secuencia_factura",
            "nota_credito": "secuencia_nota_credito",
            "nota_debito": "secuencia_nota_debito",
            "retencion": "secuencia_retencion",
            "guia": "secuencia_guia",
        }
        campo = campos.get(tipo, "secuencia_factura")
        actual = getattr(self, campo)
        setattr(self, campo, actual + 1)
        return actual
