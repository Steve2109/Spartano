"""
Sistema Contable TyM - Backend FastAPI
"""
__version__ = "1.0.0"
