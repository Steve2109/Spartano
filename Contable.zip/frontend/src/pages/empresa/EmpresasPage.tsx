import { useEffect } from 'react'
import { useTranslation } from 'react-i18next'
import { Link } from 'react-router-dom'
import { Plus, Building2, Search, Edit2, Trash2, RefreshCw } from 'lucide-react'
import toast from 'react-hot-toast'
import { useEmpresaStore } from '../../store/empresaStore'
import { cn } from '../../utils/cn'

export function EmpresasPage() {
  const { t } = useTranslation()
  const { empresas, isLoading, fetchEmpresas, deleteEmpresa, setEmpresaActual, syncWithSRI } = useEmpresaStore()

  useEffect(() => {
    fetchEmpresas()
  }, [fetchEmpresas])

  const handleDelete = async (id: number, razonSocial: string) => {
    if (!confirm(`¿Está seguro de eliminar la empresa "${razonSocial}"? Esta acción no se puede deshacer.`)) {
      return
    }
    
    try {
      await deleteEmpresa(id)
      toast.success('Empresa eliminada exitosamente')
    } catch (error) {
      toast.error('Error al eliminar la empresa')
    }
  }

  const handleSelect = (empresa: any) => {
    setEmpresaActual(empresa)
    toast.success(`Empresa "${empresa.nombre_comercial || empresa.razon_social}" seleccionada`)
  }

  const handleSyncSRI = async (id: number) => {
    try {
      await syncWithSRI(id)
      toast.success('Datos sincronizados con el SRI')
    } catch (error) {
      toast.error('Error al sincronizar con el SRI')
    }
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white">
            {t('empresa.title')}
          </h1>
          <p className="text-slate-600 dark:text-slate-400 mt-1">
            Gestione sus empresas y sucursales
          </p>
        </div>
        <Link
          to="/empresas/nueva"
          className="inline-flex items-center px-4 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700 transition-colors"
        >
          <Plus className="h-5 w-5 mr-2" />
          {t('empresa.create')}
        </Link>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-400" />
        <input
          type="text"
          placeholder="Buscar empresas..."
          className="w-full pl-10 pr-4 py-3 bg-white dark:bg-dark-800 border border-soft-200 dark:border-dark-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500 dark:text-white"
        />
      </div>

      {/* Empresas Grid */}
      {isLoading ? (
        <div className="text-center py-12">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600 mx-auto"></div>
          <p className="mt-4 text-slate-600 dark:text-slate-400">Cargando empresas...</p>
        </div>
      ) : empresas.length === 0 ? (
        <div className="text-center py-12 bg-white dark:bg-dark-800 rounded-xl border border-soft-200 dark:border-dark-700">
          <Building2 className="h-12 w-12 text-slate-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-slate-900 dark:text-white mb-2">
            {t('empresa.noEmpresas')}
          </h3>
          <p className="text-slate-500 dark:text-slate-400 mb-4">
            Comience creando su primera empresa
          </p>
          <Link
            to="/empresas/nueva"
            className="inline-flex items-center px-4 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700"
          >
            <Plus className="h-5 w-5 mr-2" />
            {t('empresa.create')}
          </Link>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {empresas.map((empresa) => (
            <div
              key={empresa.id}
              className="bg-white dark:bg-dark-800 rounded-xl shadow-soft border border-soft-200 dark:border-dark-700 overflow-hidden hover:shadow-lg transition-shadow"
            >
              <div className="p-6">
                <div className="flex items-start justify-between">
                  <div className="flex items-center">
                    <div className="w-12 h-12 rounded-lg bg-primary-100 dark:bg-primary-900/30 flex items-center justify-center">
                      <Building2 className="h-6 w-6 text-primary-600 dark:text-primary-400" />
                    </div>
                    <div className="ml-4">
                      <h3 className="font-semibold text-slate-900 dark:text-white">
                        {empresa.nombre_comercial || empresa.razon_social}
                      </h3>
                      <p className="text-sm text-slate-500">RUC: {empresa.ruc}</p>
                    </div>
                  </div>
                  <span
                    className={cn(
                      'inline-flex px-2 py-1 rounded-full text-xs font-medium',
                      empresa.activa
                        ? 'bg-success-100 text-success-700'
                        : 'bg-danger-100 text-danger-700'
                    )}
                  >
                    {empresa.activa ? 'Activa' : 'Inactiva'}
                  </span>
                </div>

                <div className="mt-4 space-y-2">
                  <p className="text-sm text-slate-600 dark:text-slate-400">
                    <span className="font-medium">Dirección:</span> {empresa.direccion_matriz}
                  </p>
                  <p className="text-sm text-slate-600 dark:text-slate-400">
                    <span className="font-medium">Régimen:</span> {empresa.tipo_regimen}
                  </p>
                  {empresa.contribuyente_especial && (
                    <p className="text-sm text-slate-600 dark:text-slate-400">
                      <span className="font-medium">Contribuyente Especial:</span>{' '}
                      {empresa.contribuyente_especial}
                    </p>
                  )}
                </div>

                <div className="mt-4 flex items-center gap-2">
                  <span
                    className={cn(
                      'inline-flex px-2 py-1 rounded-full text-xs font-medium',
                      empresa.certificada_sri
                        ? 'bg-success-100 text-success-700'
                        : 'bg-warning-100 text-warning-700'
                    )}
                  >
                    SRI: {empresa.certificada_sri ? 'Certificada' : 'Pendiente'}
                  </span>
                  {empresa.firma_electronica_path && (
                    <span className="inline-flex px-2 py-1 rounded-full text-xs font-medium bg-primary-100 text-primary-700">
                      Firma OK
                    </span>
                  )}
                </div>
              </div>

              <div className="border-t border-soft-200 dark:border-dark-700 p-4 flex items-center justify-between">
                <button
                  onClick={() => handleSelect(empresa)}
                  className="text-sm font-medium text-primary-600 hover:text-primary-500"
                >
                  Seleccionar
                </button>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handleSyncSRI(empresa.id)}
                    className="p-2 text-slate-400 hover:text-primary-600 hover:bg-primary-50 rounded-lg transition-colors"
                    title="Sincronizar con SRI"
                  >
                    <RefreshCw className="h-4 w-4" />
                  </button>
                  <Link
                    to={`/empresas/${empresa.id}`}
                    className="p-2 text-slate-400 hover:text-primary-600 hover:bg-primary-50 rounded-lg transition-colors"
                    title="Editar"
                  >
                    <Edit2 className="h-4 w-4" />
                  </Link>
                  <button
                    onClick={() => handleDelete(empresa.id, empresa.razon_social)}
                    className="p-2 text-slate-400 hover:text-danger-600 hover:bg-danger-50 rounded-lg transition-colors"
                    title="Eliminar"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
