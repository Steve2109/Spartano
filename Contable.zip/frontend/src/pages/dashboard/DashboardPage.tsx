import { useEffect } from 'react'
import { useTranslation } from 'react-i18next'
import { 
  TrendingUp, 
  TrendingDown, 
  DollarSign, 
  Package, 
  Users, 
  FileText,
  ArrowUpRight,
  ArrowDownRight
} from 'lucide-react'
import { useEmpresaStore } from '../../store/empresaStore'
import toast from 'react-hot-toast'

// Componente de tarjeta de estadística
function StatCard({ 
  title, 
  value, 
  change, 
  changeType,
  icon: Icon,
  color 
}: { 
  title: string
  value: string
  change: string
  changeType: 'up' | 'down' | 'neutral'
  icon: any
  color: string
}) {
  return (
    <div className="bg-white dark:bg-dark-800 rounded-xl p-6 shadow-soft border border-soft-200 dark:border-dark-700">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm font-medium text-slate-600 dark:text-slate-400">{title}</p>
          <p className="text-2xl font-bold text-slate-900 dark:text-white mt-1">{value}</p>
        </div>
        <div className={`p-3 rounded-lg ${color}`}>
          <Icon className="h-6 w-6 text-white" />
        </div>
      </div>
      <div className="mt-4 flex items-center">
        {changeType === 'up' && <ArrowUpRight className="h-4 w-4 text-success-500 mr-1" />}
        {changeType === 'down' && <ArrowDownRight className="h-4 w-4 text-danger-500 mr-1" />}
        <span className={`text-sm font-medium ${
          changeType === 'up' ? 'text-success-600' : 
          changeType === 'down' ? 'text-danger-600' : 
          'text-slate-600'
        }`}>
          {change}
        </span>
        <span className="text-sm text-slate-500 ml-2">vs mes anterior</span>
      </div>
    </div>
  )
}

export function DashboardPage() {
  const { t } = useTranslation()
  const { empresaActual, fetchEmpresas } = useEmpresaStore()

  useEffect(() => {
    fetchEmpresas()
  }, [fetchEmpresas])

  useEffect(() => {
    if (!empresaActual) {
      toast.error('Por favor seleccione o cree una empresa para comenzar', { duration: 5000 })
    }
  }, [empresaActual])

  if (!empresaActual) {
    return (
      <div className="p-6">
        <div className="bg-warning-50 dark:bg-warning-900/20 border border-warning-200 dark:border-warning-800 rounded-lg p-6">
          <h2 className="text-lg font-semibold text-warning-800 dark:text-warning-400 mb-2">
            No hay empresa seleccionada
          </h2>
          <p className="text-warning-700 dark:text-warning-300 mb-4">
            Para utilizar el sistema, primero debe crear o seleccionar una empresa.
          </p>
          <a 
            href="/empresas/nueva" 
            className="inline-flex items-center px-4 py-2 bg-warning-600 text-white rounded-lg hover:bg-warning-700"
          >
            Crear nueva empresa
          </a>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white">
            {t('navigation.dashboard')}
          </h1>
          <p className="text-slate-600 dark:text-slate-400 mt-1">
            Resumen de {empresaActual.nombre_comercial || empresaActual.razon_social}
          </p>
        </div>
        <div className="text-right">
          <p className="text-sm text-slate-500 dark:text-slate-400">Período</p>
          <p className="font-medium text-slate-900 dark:text-white">{new Date().toLocaleDateString('es-EC', { month: 'long', year: 'numeric' })}</p>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard
          title="Ventas del Mes"
          value="$12,450.00"
          change="12.5%"
          changeType="up"
          icon={TrendingUp}
          color="bg-primary-500"
        />
        <StatCard
          title="Compras del Mes"
          value="$8,230.00"
          change="5.2%"
          changeType="down"
          icon={TrendingDown}
          color="bg-danger-500"
        />
        <StatCard
          title="Facturas Emitidas"
          value="24"
          change="8 nuevas"
          changeType="neutral"
          icon={FileText}
          color="bg-success-500"
        />
        <StatCard
          title="Stock Bajo"
          value="5 productos"
          change="Requiere atención"
          changeType="down"
          icon={Package}
          color="bg-warning-500"
        />
      </div>

      {/* Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Ventas Recientes */}
        <div className="lg:col-span-2 bg-white dark:bg-dark-800 rounded-xl shadow-soft border border-soft-200 dark:border-dark-700 p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-slate-900 dark:text-white">
              Ventas Recientes
            </h3>
            <a href="/facturacion" className="text-primary-600 hover:text-primary-500 text-sm">
              Ver todas
            </a>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-soft-200 dark:border-dark-700">
                  <th className="text-left py-3 text-sm font-medium text-slate-600 dark:text-slate-400">Nº Factura</th>
                  <th className="text-left py-3 text-sm font-medium text-slate-600 dark:text-slate-400">Cliente</th>
                  <th className="text-left py-3 text-sm font-medium text-slate-600 dark:text-slate-400">Fecha</th>
                  <th className="text-right py-3 text-sm font-medium text-slate-600 dark:text-slate-400">Total</th>
                  <th className="text-center py-3 text-sm font-medium text-slate-600 dark:text-slate-400">Estado</th>
                </tr>
              </thead>
              <tbody>
                <tr className="border-b border-soft-100 dark:border-dark-700">
                  <td className="py-3 text-sm text-slate-900 dark:text-white font-medium">001-001-000000001</td>
                  <td className="py-3 text-sm text-slate-600 dark:text-slate-400">Consumidor Final</td>
                  <td className="py-3 text-sm text-slate-600 dark:text-slate-400">24/04/2026</td>
                  <td className="py-3 text-sm text-slate-900 dark:text-white text-right">$156.00</td>
                  <td className="py-3 text-center">
                    <span className="px-2 py-1 bg-success-100 text-success-700 rounded-full text-xs font-medium">
                      Autorizada
                    </span>
                  </td>
                </tr>
                <tr className="border-b border-soft-100 dark:border-dark-700">
                  <td className="py-3 text-sm text-slate-900 dark:text-white font-medium">001-001-000000002</td>
                  <td className="py-3 text-sm text-slate-600 dark:text-slate-400">Juan Pérez</td>
                  <td className="py-3 text-sm text-slate-600 dark:text-slate-400">24/04/2026</td>
                  <td className="py-3 text-sm text-slate-900 dark:text-white text-right">$450.50</td>
                  <td className="py-3 text-center">
                    <span className="px-2 py-1 bg-warning-100 text-warning-700 rounded-full text-xs font-medium">
                      Pendiente
                    </span>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        {/* Accesos Rápidos */}
        <div className="bg-white dark:bg-dark-800 rounded-xl shadow-soft border border-soft-200 dark:border-dark-700 p-6">
          <h3 className="text-lg font-semibold text-slate-900 dark:text-white mb-4">
            Accesos Rápidos
          </h3>
          <div className="space-y-3">
            <a 
              href="/facturacion" 
              className="flex items-center p-3 rounded-lg bg-soft-50 dark:bg-dark-700 hover:bg-soft-100 dark:hover:bg-dark-600 transition-colors"
            >
              <div className="p-2 bg-primary-100 dark:bg-primary-900/30 rounded-lg mr-3">
                <FileText className="h-5 w-5 text-primary-600 dark:text-primary-400" />
              </div>
              <div>
                <p className="font-medium text-slate-900 dark:text-white">Nueva Factura</p>
                <p className="text-sm text-slate-500">Emitir comprobante electrónico</p>
              </div>
            </a>
            <a 
              href="/productos" 
              className="flex items-center p-3 rounded-lg bg-soft-50 dark:bg-dark-700 hover:bg-soft-100 dark:hover:bg-dark-600 transition-colors"
            >
              <div className="p-2 bg-success-100 dark:bg-success-900/30 rounded-lg mr-3">
                <Package className="h-5 w-5 text-success-600 dark:text-success-400" />
              </div>
              <div>
                <p className="font-medium text-slate-900 dark:text-white">Productos</p>
                <p className="text-sm text-slate-500">Gestionar inventario</p>
              </div>
            </a>
            <a 
              href="/clientes" 
              className="flex items-center p-3 rounded-lg bg-soft-50 dark:bg-dark-700 hover:bg-soft-100 dark:hover:bg-dark-600 transition-colors"
            >
              <div className="p-2 bg-warning-100 dark:bg-warning-900/30 rounded-lg mr-3">
                <Users className="h-5 w-5 text-warning-600 dark:text-warning-400" />
              </div>
              <div>
                <p className="font-medium text-slate-900 dark:text-white">Clientes</p>
                <p className="text-sm text-slate-500">Ver lista de clientes</p>
              </div>
            </a>
          </div>
        </div>
      </div>

      {/* Empresa Info */}
      <div className="bg-white dark:bg-dark-800 rounded-xl shadow-soft border border-soft-200 dark:border-dark-700 p-6">
        <h3 className="text-lg font-semibold text-slate-900 dark:text-white mb-4">
          Información de la Empresa
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <div>
            <p className="text-sm text-slate-500 dark:text-slate-400">Razón Social</p>
            <p className="font-medium text-slate-900 dark:text-white">{empresaActual.razon_social}</p>
          </div>
          <div>
            <p className="text-sm text-slate-500 dark:text-slate-400">RUC</p>
            <p className="font-medium text-slate-900 dark:text-white">{empresaActual.ruc}</p>
          </div>
          <div>
            <p className="text-sm text-slate-500 dark:text-slate-400">Dirección Matriz</p>
            <p className="font-medium text-slate-900 dark:text-white">{empresaActual.direccion_matriz}</p>
          </div>
          <div>
            <p className="text-sm text-slate-500 dark:text-slate-400">Estado SRI</p>
            <span className={`inline-flex px-2 py-1 rounded-full text-xs font-medium ${
              empresaActual.certificada_sri 
                ? 'bg-success-100 text-success-700' 
                : 'bg-warning-100 text-warning-700'
            }`}>
              {empresaActual.certificada_sri ? 'Certificada' : 'Pendiente'}
            </span>
          </div>
        </div>
      </div>
    </div>
  )
}
