import { useEffect } from 'react'
import { Routes, Route, Navigate } from 'react-router-dom'
import { useTranslation } from 'react-i18next'

import { useAuthStore } from './store/authStore'
import { useThemeStore } from './store/themeStore'
import { useEmpresaStore } from './store/empresaStore'

import { Layout } from './components/layout/Layout'
import { LoginPage } from './pages/auth/LoginPage'
import { RegisterPage } from './pages/auth/RegisterPage'
import { DashboardPage } from './pages/dashboard/DashboardPage'
import { EmpresasPage } from './pages/empresa/EmpresasPage'
import { EmpresaCreatePage } from './pages/empresa/EmpresaCreatePage'
import { EmpresaDetailPage } from './pages/empresa/EmpresaDetailPage'
import { ConfiguracionPage } from './pages/configuracion/ConfiguracionPage'
import { ProtectedRoute } from './components/auth/ProtectedRoute'

function App() {
  const { i18n } = useTranslation()
  const { initialize: initializeAuth } = useAuthStore()
  const { theme, initialize: initializeTheme } = useThemeStore()
  const { initialize: initializeEmpresa } = useEmpresaStore()

  // Inicializar al cargar
  useEffect(() => {
    initializeAuth()
    initializeTheme()
    initializeEmpresa()
  }, [initializeAuth, initializeTheme, initializeEmpresa])

  // Aplicar tema al documento
  useEffect(() => {
    const root = window.document.documentElement
    root.classList.remove('light', 'dark')
    
    if (theme === 'system') {
      const systemTheme = window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'
      root.classList.add(systemTheme)
    } else {
      root.classList.add(theme)
    }
  }, [theme])

  // Cambiar idioma según preferencia
  useEffect(() => {
    const userLang = localStorage.getItem('i18nextLng') || 'es-EC'
    if (i18n.language !== userLang) {
      i18n.changeLanguage(userLang)
    }
  }, [i18n])

  return (
    <div className="min-h-screen bg-soft-50 dark:bg-dark-900 transition-colors duration-300">
      <Routes>
        {/* Rutas públicas */}
        <Route path="/login" element={<LoginPage />} />
        <Route path="/register" element={<RegisterPage />} />
        
        {/* Rutas protegidas */}
        <Route element={<ProtectedRoute />}>
          <Route element={<Layout />}>
            <Route path="/" element={<Navigate to="/dashboard" replace />} />
            <Route path="/dashboard" element={<DashboardPage />} />
            
            {/* Empresas */}
            <Route path="/empresas" element={<EmpresasPage />} />
            <Route path="/empresas/nueva" element={<EmpresaCreatePage />} />
            <Route path="/empresas/:id" element={<EmpresaDetailPage />} />
            
            {/* Facturación */}
            <Route path="/facturacion" element={<div className="p-6"><h1 className="text-2xl font-bold">Facturación</h1></div>} />
            
            {/* Inventario */}
            <Route path="/inventario" element={<div className="p-6"><h1 className="text-2xl font-bold">Inventario</h1></div>} />
            
            {/* Clientes */}
            <Route path="/clientes" element={<div className="p-6"><h1 className="text-2xl font-bold">Clientes</h1></div>} />
            
            {/* Proveedores */}
            <Route path="/proveedores" element={<div className="p-6"><h1 className="text-2xl font-bold">Proveedores</h1></div>} />
            
            {/* Contabilidad */}
            <Route path="/contabilidad" element={<div className="p-6"><h1 className="text-2xl font-bold">Contabilidad</h1></div>} />
            
            {/* Reportes */}
            <Route path="/reportes" element={<div className="p-6"><h1 className="text-2xl font-bold">Reportes</h1></div>} />
            
            {/* Configuración */}
            <Route path="/configuracion" element={<ConfiguracionPage />} />
            
            {/* Perfil */}
            <Route path="/perfil" element={<div className="p-6"><h1 className="text-2xl font-bold">Perfil</h1></div>} />
          </Route>
        </Route>
        
        {/* Ruta 404 */}
        <Route path="*" element={<div className="flex items-center justify-center h-screen"><h1 className="text-2xl">404 - Página no encontrada</h1></div>} />
      </Routes>
    </div>
  )
}

export default App
