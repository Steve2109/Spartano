import { api } from './api'
import type { RegisterData } from '../store/authStore'

export interface LoginResponse {
  access_token: string
  refresh_token: string
  token_type: string
  expires_in: number
}

export interface UserData {
  id: number
  email: string
  nombres: string
  apellidos: string
  nombre_completo: string
  idioma: string
  tema: string
  is_active: boolean
  is_superuser: boolean
}

export const authService = {
  async login(email: string, password: string): Promise<LoginResponse> {
    const response = await api.post<LoginResponse>('/auth/login', {
      email,
      password
    })
    return response.data
  },

  async register(data: RegisterData): Promise<UserData> {
    const response = await api.post<UserData>('/auth/register', data)
    return response.data
  },

  async logout(token: string): Promise<void> {
    await api.post('/auth/logout', {}, {
      headers: { Authorization: `Bearer ${token}` }
    })
  },

  async refresh(refreshToken: string): Promise<LoginResponse> {
    const response = await api.post<LoginResponse>('/auth/refresh', {
      refresh_token: refreshToken
    })
    return response.data
  },

  async getMe(token: string): Promise<UserData> {
    const response = await api.get<UserData>('/auth/me', {
      headers: { Authorization: `Bearer ${token}` }
    })
    return response.data
  },

  async changePassword(currentPassword: string, newPassword: string): Promise<void> {
    await api.post('/auth/change-password', {
      current_password: currentPassword,
      new_password: newPassword
    })
  },

  async requestPasswordReset(email: string): Promise<void> {
    await api.post('/auth/password-reset-request', { email })
  }
}
