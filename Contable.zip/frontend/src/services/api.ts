import axios from 'axios'
import { useAuthStore } from '../store/authStore'

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:8000/api/v1'

// Instancia de axios configurada
export const api = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/json'
  }
})

// Interceptor para agregar token
api.interceptors.request.use(
  (config) => {
    const token = useAuthStore.getState().token
    if (token) {
      config.headers.Authorization = `Bearer ${token}`
    }
    return config
  },
  (error) => {
    return Promise.reject(error)
  }
)

// Interceptor para manejar errores y refresh token
api.interceptors.response.use(
  (response) => response,
  async (error) => {
    const originalRequest = error.config
    
    // Si es error 401 y no es una petición de refresh
    if (error.response?.status === 401 && !originalRequest._retry) {
      originalRequest._retry = true
      
      try {
        // Intentar refrescar token
        const refreshed = await useAuthStore.getState().refresh()
        
        if (refreshed) {
          // Reintentar petición original con nuevo token
          const newToken = useAuthStore.getState().token
          originalRequest.headers.Authorization = `Bearer ${newToken}`
          return api(originalRequest)
        }
      } catch (refreshError) {
        // Si refresh falla, logout
        useAuthStore.getState().logout()
        window.location.href = '/login'
      }
    }
    
    return Promise.reject(error)
  }
)

// Función auxiliar para manejar errores
export const handleApiError = (error: any): string => {
  if (error.response) {
    // Error del servidor
    const data = error.response.data
    if (typeof data === 'string') return data
    if (data.detail) return data.detail
    if (data.message) return data.message
    
    // Errores de validación
    if (data.errors) {
      const errors = Object.values(data.errors).flat()
      return errors.join(', ')
    }
    
    return `Error ${error.response.status}: ${error.response.statusText}`
  }
  
  if (error.request) {
    // No se recibió respuesta
    return 'No se pudo conectar con el servidor. Verifique su conexión.'
  }
  
  // Error de configuración
  return error.message || 'Error desconocido'
}
