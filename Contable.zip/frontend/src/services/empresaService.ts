import { api, handleApiError } from './api'
import type { Empresa, Sucursal, CreateEmpresaData, UpdateEmpresaData } from '../store/empresaStore'

export const empresaService = {
  async list(): Promise<Empresa[]> {
    try {
      const response = await api.get<Empresa[]>('/empresas/')
      return response.data
    } catch (error) {
      throw new Error(handleApiError(error))
    }
  },

  async get(id: number): Promise<Empresa> {
    try {
      const response = await api.get<Empresa>(`/empresas/${id}`)
      return response.data
    } catch (error) {
      throw new Error(handleApiError(error))
    }
  },

  async create(data: CreateEmpresaData): Promise<Empresa> {
    try {
      const response = await api.post<Empresa>('/empresas/', data)
      return response.data
    } catch (error) {
      throw new Error(handleApiError(error))
    }
  },

  async update(id: number, data: UpdateEmpresaData): Promise<Empresa> {
    try {
      const response = await api.put<Empresa>(`/empresas/${id}`, data)
      return response.data
    } catch (error) {
      throw new Error(handleApiError(error))
    }
  },

  async delete(id: number): Promise<void> {
    try {
      await api.delete(`/empresas/${id}`)
    } catch (error) {
      throw new Error(handleApiError(error))
    }
  },

  async uploadLogo(id: number, file: File): Promise<{ path: string }> {
    try {
      const formData = new FormData()
      formData.append('logo_file', file)
      
      const response = await api.post(`/empresas/${id}/logo`, formData, {
        headers: { 'Content-Type': 'multipart/form-data' }
      })
      return response.data
    } catch (error) {
      throw new Error(handleApiError(error))
    }
  },

  async uploadFirma(
    id: number, 
    file: File, 
    fechaValidez: string, 
    emitidoPor?: string
  ): Promise<{ message: string; path: string }> {
    try {
      const formData = new FormData()
      formData.append('firma_file', file)
      formData.append('fecha_validez', fechaValidez)
      if (emitidoPor) formData.append('emitido_por', emitidoPor)
      
      const response = await api.post(`/empresas/${id}/firma`, formData, {
        headers: { 'Content-Type': 'multipart/form-data' }
      })
      return response.data
    } catch (error) {
      throw new Error(handleApiError(error))
    }
  },

  async consultarSRI(ruc: string): Promise<any> {
    try {
      const response = await api.get('/sri/consultar-ruc', {
        params: { ruc }
      })
      return response.data
    } catch (error) {
      throw new Error(handleApiError(error))
    }
  },

  async syncWithSRI(id: number): Promise<Empresa> {
    try {
      const response = await api.get<Empresa>(`/empresas/${id}/sri-sync`)
      return response.data
    } catch (error) {
      throw new Error(handleApiError(error))
    }
  },

  // Sucursales
  async listSucursales(empresaId: number): Promise<Sucursal[]> {
    try {
      const response = await api.get<Sucursal[]>(`/empresas/${empresaId}/sucursales`)
      return response.data
    } catch (error) {
      throw new Error(handleApiError(error))
    }
  },

  async createSucursal(empresaId: number, data: Partial<Sucursal>): Promise<Sucursal> {
    try {
      const response = await api.post<Sucursal>(`/empresas/${empresaId}/sucursales`, data)
      return response.data
    } catch (error) {
      throw new Error(handleApiError(error))
    }
  }
}
