import { create } from 'zustand'
import { persist } from 'zustand/middleware'
import { authService } from '../services/authService'

export interface User {
  id: number
  email: string
  nombres: string
  apellidos: string
  nombre_completo: string
  idioma: string
  tema: string
  is_active: boolean
  is_superuser: boolean
}

export interface AuthState {
  user: User | null
  token: string | null
  refreshToken: string | null
  isAuthenticated: boolean
  isLoading: boolean
  error: string | null
  
  // Actions
  login: (email: string, password: string) => Promise<void>
  register: (data: RegisterData) => Promise<void>
  logout: () => void
  refresh: () => Promise<boolean>
  initialize: () => void
  clearError: () => void
}

export interface RegisterData {
  email: string
  password: string
  nombres: string
  apellidos: string
  cedula?: string
  telefono?: string
  direccion?: string
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set, get) => ({
      user: null,
      token: null,
      refreshToken: null,
      isAuthenticated: false,
      isLoading: false,
      error: null,

      initialize: () => {
        const { token, user } = get()
        if (token && user) {
          set({ isAuthenticated: true })
        }
      },

      login: async (email: string, password: string) => {
        set({ isLoading: true, error: null })
        try {
          const response = await authService.login(email, password)
          const { access_token, refresh_token } = response
          
          // Obtener datos del usuario
          const userData = await authService.getMe(access_token)
          
          set({
            user: userData,
            token: access_token,
            refreshToken: refresh_token,
            isAuthenticated: true,
            isLoading: false
          })
        } catch (error: any) {
          set({
            error: error.response?.data?.detail || 'Error al iniciar sesión',
            isLoading: false
          })
          throw error
        }
      },

      register: async (data: RegisterData) => {
        set({ isLoading: true, error: null })
        try {
          await authService.register(data)
          set({ isLoading: false })
        } catch (error: any) {
          set({
            error: error.response?.data?.detail || 'Error al registrar usuario',
            isLoading: false
          })
          throw error
        }
      },

      logout: () => {
        const { token } = get()
        if (token) {
          authService.logout(token).catch(() => {})
        }
        set({
          user: null,
          token: null,
          refreshToken: null,
          isAuthenticated: false
        })
      },

      refresh: async () => {
        const { refreshToken } = get()
        if (!refreshToken) return false
        
        try {
          const response = await authService.refresh(refreshToken)
          set({
            token: response.access_token,
            refreshToken: response.refresh_token
          })
          return true
        } catch (error) {
          get().logout()
          return false
        }
      },

      clearError: () => set({ error: null })
    }),
    {
      name: 'auth-storage',
      partialize: (state) => ({ 
        user: state.user, 
        token: state.token, 
        refreshToken: state.refreshToken,
        isAuthenticated: state.isAuthenticated 
      })
    }
  )
)
