import { create } from 'zustand'
import { persist } from 'zustand/middleware'

type Theme = 'light' | 'dark' | 'system'

interface ThemeState {
  theme: Theme
  setTheme: (theme: Theme) => void
  toggleTheme: () => void
  initialize: () => void
}

export const useThemeStore = create<ThemeState>()(
  persist(
    (set, get) => ({
      theme: 'light', // Por defecto modo claro (color suave)

      setTheme: (theme: Theme) => {
        set({ theme })
        localStorage.setItem('theme', theme)
      },

      toggleTheme: () => {
        const current = get().theme
        const next = current === 'light' ? 'dark' : 'light'
        set({ theme: next })
        localStorage.setItem('theme', next)
      },

      initialize: () => {
        // Intentar obtener tema guardado o preferencia del sistema
        const savedTheme = localStorage.getItem('theme') as Theme
        if (savedTheme && ['light', 'dark', 'system'].includes(savedTheme)) {
          set({ theme: savedTheme })
        }
      }
    }),
    {
      name: 'theme-storage'
    }
  )
)
