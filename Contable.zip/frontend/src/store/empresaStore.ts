import { create } from 'zustand'
import { persist } from 'zustand/middleware'
import { empresaService } from '../services/empresaService'

export interface Empresa {
  id: number
  ruc: string
  razon_social: string
  nombre_comercial?: string
  direccion_matriz: string
  direccion_establecimiento?: string
  email?: string
  telefono?: string
  celular?: string
  obligado_contabilidad: boolean
  contribuyente_especial?: string
  tipo_regimen: string
  agente_retencion: boolean
  numero_resolucion_agente?: string
  firma_electronica_path?: string
  firma_electronica_validez?: string
  firma_electronica_emitido_por?: string
  logo_path?: string
  activa: boolean
  certificada_sri: boolean
  creado_en: string
  actualizado_en?: string
}

export interface Sucursal {
  id: number
  empresa_id: number
  codigo: string
  nombre: string
  direccion: string
  telefono?: string
  email?: string
  serie_factura: string
  serie_nota_credito: string
  serie_nota_debito: string
  serie_retencion: string
  serie_guia: string
  activa: boolean
}

interface EmpresaState {
  empresas: Empresa[]
  empresaActual: Empresa | null
  sucursales: Sucursal[]
  isLoading: boolean
  error: string | null

  // Actions
  fetchEmpresas: () => Promise<void>
  fetchEmpresa: (id: number) => Promise<void>
  createEmpresa: (data: CreateEmpresaData) => Promise<Empresa>
  updateEmpresa: (id: number, data: UpdateEmpresaData) => Promise<void>
  deleteEmpresa: (id: number) => Promise<void>
  setEmpresaActual: (empresa: Empresa | null) => void
  consultarSRI: (ruc: string) => Promise<any>
  syncWithSRI: (id: number) => Promise<void>
  initialize: () => void
}

export interface CreateEmpresaData {
  ruc: string
  razon_social: string
  nombre_comercial?: string
  direccion_matriz: string
  direccion_establecimiento?: string
  email?: string
  telefono?: string
  celular?: string
  obligado_contabilidad?: boolean
  contribuyente_especial?: string
  tipo_regimen?: string
  agente_retencion?: boolean
  numero_resolucion_agente?: string
}

export interface UpdateEmpresaData extends Partial<CreateEmpresaData> {}

export const useEmpresaStore = create<EmpresaState>()(
  persist(
    (set, get) => ({
      empresas: [],
      empresaActual: null,
      sucursales: [],
      isLoading: false,
      error: null,

      initialize: () => {
        const savedEmpresa = localStorage.getItem('empresa-actual')
        if (savedEmpresa) {
          try {
            const empresa = JSON.parse(savedEmpresa)
            set({ empresaActual: empresa })
          } catch (e) {
            localStorage.removeItem('empresa-actual')
          }
        }
      },

      fetchEmpresas: async () => {
        set({ isLoading: true, error: null })
        try {
          const empresas = await empresaService.list()
          set({ empresas, isLoading: false })
          
          // Si hay empresas y no hay una seleccionada, seleccionar la primera
          if (empresas.length > 0 && !get().empresaActual) {
            get().setEmpresaActual(empresas[0])
          }
        } catch (error: any) {
          set({ error: error.message, isLoading: false })
        }
      },

      fetchEmpresa: async (id: number) => {
        set({ isLoading: true, error: null })
        try {
          const empresa = await empresaService.get(id)
          set({ empresaActual: empresa, isLoading: false })
          localStorage.setItem('empresa-actual', JSON.stringify(empresa))
        } catch (error: any) {
          set({ error: error.message, isLoading: false })
        }
      },

      createEmpresa: async (data: CreateEmpresaData) => {
        set({ isLoading: true, error: null })
        try {
          const empresa = await empresaService.create(data)
          set(state => ({ 
            empresas: [...state.empresas, empresa],
            isLoading: false 
          }))
          return empresa
        } catch (error: any) {
          set({ error: error.message, isLoading: false })
          throw error
        }
      },

      updateEmpresa: async (id: number, data: UpdateEmpresaData) => {
        set({ isLoading: true, error: null })
        try {
          const empresa = await empresaService.update(id, data)
          set(state => ({
            empresas: state.empresas.map(e => e.id === id ? empresa : e),
            empresaActual: state.empresaActual?.id === id ? empresa : state.empresaActual,
            isLoading: false
          }))
        } catch (error: any) {
          set({ error: error.message, isLoading: false })
          throw error
        }
      },

      deleteEmpresa: async (id: number) => {
        set({ isLoading: true, error: null })
        try {
          await empresaService.delete(id)
          set(state => ({
            empresas: state.empresas.filter(e => e.id !== id),
            empresaActual: state.empresaActual?.id === id ? null : state.empresaActual,
            isLoading: false
          }))
        } catch (error: any) {
          set({ error: error.message, isLoading: false })
          throw error
        }
      },

      setEmpresaActual: (empresa: Empresa | null) => {
        set({ empresaActual: empresa })
        if (empresa) {
          localStorage.setItem('empresa-actual', JSON.stringify(empresa))
        } else {
          localStorage.removeItem('empresa-actual')
        }
      },

      consultarSRI: async (ruc: string) => {
        try {
          return await empresaService.consultarSRI(ruc)
        } catch (error: any) {
          set({ error: error.message })
          throw error
        }
      },

      syncWithSRI: async (id: number) => {
        set({ isLoading: true, error: null })
        try {
          const empresa = await empresaService.syncWithSRI(id)
          set(state => ({
            empresas: state.empresas.map(e => e.id === id ? empresa : e),
            empresaActual: state.empresaActual?.id === id ? empresa : state.empresaActual,
            isLoading: false
          }))
        } catch (error: any) {
          set({ error: error.message, isLoading: false })
          throw error
        }
      }
    }),
    {
      name: 'empresa-storage',
      partialize: (state) => ({ empresaActual: state.empresaActual })
    }
  )
)
