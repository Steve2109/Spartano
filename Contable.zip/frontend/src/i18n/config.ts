import i18n from 'i18next'
import { initReactI18next } from 'react-i18next'
import LanguageDetector from 'i18next-browser-languagedetector'

import esEC from './locales/es-EC.json'
import es from './locales/es.json'

i18n
  .use(LanguageDetector)
  .use(initReactI18next)
  .init({
    resources: {
      'es-EC': {
        translation: esEC
      },
      'es': {
        translation: es
      }
    },
    fallbackLng: 'es-EC',
    lng: 'es-EC', // Idioma por defecto: Español Ecuador
    
    detection: {
      order: ['localStorage', 'navigator', 'htmlTag'],
      caches: ['localStorage'],
      lookupLocalStorage: 'i18nextLng'
    },
    
    interpolation: {
      escapeValue: false // React ya escapa por defecto
    },
    
    react: {
      useSuspense: false
    }
  })

export default i18n
