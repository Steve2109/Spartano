import { Navigate, Outlet } from 'react-router-dom'
import { useAuthStore } from '../../store/authStore'
import toast from 'react-hot-toast'
import { useEffect } from 'react'

export function ProtectedRoute() {
  const { isAuthenticated, user } = useAuthStore()

  useEffect(() => {
    if (!isAuthenticated) {
      toast.error('Por favor inicie sesión para continuar')
    }
  }, [isAuthenticated])

  if (!isAuthenticated) {
    return <Navigate to="/login" replace />
  }

  if (!user?.is_active) {
    toast.error('Su cuenta está desactivada')
    return <Navigate to="/login" replace />
  }

  return <Outlet />
}
