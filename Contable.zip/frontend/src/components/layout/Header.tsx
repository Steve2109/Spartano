import { useState } from 'react'
import { useTranslation } from 'react-i18next'
import { Link } from 'react-router-dom'
import { 
  Bell, 
  User, 
  Moon, 
  Sun, 
  LogOut, 
  Menu,
  Building2,
  ChevronDown
} from 'lucide-react'
import { useAuthStore } from '../../store/authStore'
import { useThemeStore } from '../../store/themeStore'
import { useEmpresaStore } from '../../store/empresaStore'
import { cn } from '../../utils/cn'
import toast from 'react-hot-toast'

export function Header() {
  const { t, i18n } = useTranslation()
  const { user, logout } = useAuthStore()
  const { theme, toggleTheme } = useThemeStore()
  const { empresas, empresaActual, setEmpresaActual } = useEmpresaStore()
  
  const [isProfileOpen, setIsProfileOpen] = useState(false)
  const [isEmpresaOpen, setIsEmpresaOpen] = useState(false)

  const handleLogout = () => {
    logout()
    toast.success('Sesión cerrada exitosamente')
  }

  const handleThemeToggle = () => {
    toggleTheme()
    toast.success(theme === 'light' ? 'Modo oscuro activado' : 'Modo claro activado')
  }

  return (
    <header className="h-16 bg-white dark:bg-dark-800 border-b border-soft-200 dark:border-dark-700 sticky top-0 z-30">
      <div className="h-full px-4 flex items-center justify-between">
        {/* Left side - Mobile menu button */}
        <button className="lg:hidden p-2 rounded-lg text-slate-500 hover:bg-slate-100 dark:hover:bg-dark-700">
          <Menu className="h-6 w-6" />
        </button>

        {/* Right side */}
        <div className="flex items-center gap-2 ml-auto">
          {/* Selector de empresa */}
          {empresas.length > 1 && (
            <div className="relative">
              <button
                onClick={() => setIsEmpresaOpen(!isEmpresaOpen)}
                className="flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-dark-700"
              >
                <Building2 className="h-4 w-4" />
                <span className="hidden sm:inline">{empresaActual?.nombre_comercial || empresaActual?.razon_social}</span>
                <ChevronDown className="h-4 w-4" />
              </button>

              {isEmpresaOpen && (
                <div className="absolute right-0 mt-2 w-64 bg-white dark:bg-dark-800 rounded-lg shadow-lg border border-soft-200 dark:border-dark-700 py-1">
                  <p className="px-4 py-2 text-xs font-medium text-slate-500 dark:text-slate-400 uppercase">
                    Cambiar empresa
                  </p>
                  {empresas.map((empresa) => (
                    <button
                      key={empresa.id}
                      onClick={() => {
                        setEmpresaActual(empresa)
                        setIsEmpresaOpen(false)
                        toast.success(`Empresa cambiada a: ${empresa.nombre_comercial || empresa.razon_social}`)
                      }}
                      className={cn(
                        'w-full text-left px-4 py-2 text-sm hover:bg-slate-50 dark:hover:bg-dark-700',
                        empresaActual?.id === empresa.id 
                          ? 'bg-primary-50 text-primary-700 dark:bg-primary-900/20 dark:text-primary-400' 
                          : 'text-slate-700 dark:text-slate-200'
                      )}
                    >
                      <p className="font-medium">{empresa.nombre_comercial || empresa.razon_social}</p>
                      <p className="text-xs text-slate-500">RUC: {empresa.ruc}</p>
                    </button>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Theme toggle */}
          <button
            onClick={handleThemeToggle}
            className="p-2 rounded-lg text-slate-500 hover:bg-slate-100 dark:hover:bg-dark-700 transition-colors"
            title={theme === 'light' ? 'Cambiar a modo oscuro' : 'Cambiar a modo claro'}
          >
            {theme === 'light' ? <Moon className="h-5 w-5" /> : <Sun className="h-5 w-5" />}
          </button>

          {/* Notifications */}
          <button className="p-2 rounded-lg text-slate-500 hover:bg-slate-100 dark:hover:bg-dark-700 relative">
            <Bell className="h-5 w-5" />
            <span className="absolute top-1 right-1 h-2 w-2 rounded-full bg-danger-500"></span>
          </button>

          {/* User menu */}
          <div className="relative">
            <button
              onClick={() => setIsProfileOpen(!isProfileOpen)}
              className="flex items-center gap-2 p-2 rounded-lg text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-dark-700"
            >
              <div className="h-8 w-8 rounded-full bg-primary-100 dark:bg-primary-900/30 flex items-center justify-center">
                <User className="h-5 w-5 text-primary-600 dark:text-primary-400" />
              </div>
              <span className="hidden md:block text-sm font-medium">{user?.nombre_completo}</span>
            </button>

            {isProfileOpen && (
              <div className="absolute right-0 mt-2 w-48 bg-white dark:bg-dark-800 rounded-lg shadow-lg border border-soft-200 dark:border-dark-700 py-1">
                <div className="px-4 py-2 border-b border-soft-200 dark:border-dark-700">
                  <p className="text-sm font-medium text-slate-900 dark:text-white">{user?.nombre_completo}</p>
                  <p className="text-xs text-slate-500 dark:text-slate-400">{user?.email}</p>
                </div>
                <Link
                  to="/perfil"
                  className="block px-4 py-2 text-sm text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-dark-700"
                  onClick={() => setIsProfileOpen(false)}
                >
                  Perfil
                </Link>
                <Link
                  to="/configuracion"
                  className="block px-4 py-2 text-sm text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-dark-700"
                  onClick={() => setIsProfileOpen(false)}
                >
                  Configuración
                </Link>
                <button
                  onClick={handleLogout}
                  className="w-full text-left px-4 py-2 text-sm text-danger-600 hover:bg-danger-50 dark:hover:bg-danger-900/20 flex items-center gap-2"
                >
                  <LogOut className="h-4 w-4" />
                  Cerrar sesión
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  )
}
