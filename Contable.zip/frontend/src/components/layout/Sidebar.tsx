import { NavLink } from 'react-router-dom'
import { useTranslation } from 'react-i18next'
import { 
  LayoutDashboard, 
  Building2, 
  FileText, 
  Package, 
  Users, 
  Truck, 
  Calculator, 
  BarChart3, 
  Settings,
  ChevronRight
} from 'lucide-react'
import { useEmpresaStore } from '../../store/empresaStore'
import { cn } from '../../utils/cn'

const navigation = [
  { name: 'navigation.dashboard', href: '/dashboard', icon: LayoutDashboard },
  { name: 'navigation.empresas', href: '/empresas', icon: Building2 },
  { name: 'navigation.facturacion', href: '/facturacion', icon: FileText },
  { name: 'navigation.productos', href: '/productos', icon: Package },
  { name: 'navigation.clientes', href: '/clientes', icon: Users },
  { name: 'navigation.proveedores', href: '/proveedores', icon: Truck },
  { name: 'navigation.contabilidad', href: '/contabilidad', icon: Calculator },
  { name: 'navigation.reportes', href: '/reportes', icon: BarChart3 },
  { name: 'navigation.configuracion', href: '/configuracion', icon: Settings },
]

export function Sidebar() {
  const { t } = useTranslation()
  const { empresaActual } = useEmpresaStore()

  return (
    <aside className="hidden lg:flex lg:flex-col lg:w-64 lg:fixed lg:inset-y-0 z-40">
      <div className="flex flex-col h-full bg-white dark:bg-dark-800 border-r border-soft-200 dark:border-dark-700">
        {/* Logo */}
        <div className="flex items-center h-16 px-6 border-b border-soft-200 dark:border-dark-700">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-primary-600 flex items-center justify-center">
              <span className="text-white font-bold text-lg">TyM</span>
            </div>
            <span className="font-semibold text-slate-700 dark:text-slate-200">
              {t('app.name')}
            </span>
          </div>
        </div>

        {/* Empresa actual */}
        {empresaActual && (
          <div className="px-4 py-3 border-b border-soft-200 dark:border-dark-700">
            <p className="text-xs text-slate-500 dark:text-slate-400 uppercase tracking-wider">
              Empresa seleccionada
            </p>
            <p className="text-sm font-medium text-slate-900 dark:text-slate-100 truncate">
              {empresaActual.nombre_comercial || empresaActual.razon_social}
            </p>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              RUC: {empresaActual.ruc}
            </p>
          </div>
        )}

        {/* Navigation */}
        <nav className="flex-1 overflow-y-auto py-4 px-3 space-y-1">
          {navigation.map((item) => (
            <NavLink
              key={item.name}
              to={item.href}
              className={({ isActive }) =>
                cn(
                  'group flex items-center px-3 py-2.5 text-sm font-medium rounded-lg transition-colors',
                  isActive
                    ? 'bg-primary-50 text-primary-700 dark:bg-primary-900/20 dark:text-primary-400'
                    : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900 dark:text-slate-300 dark:hover:bg-dark-700 dark:hover:text-white'
                )
              }
            >
              <item.icon className="mr-3 h-5 w-5 flex-shrink-0" />
              {t(item.name)}
              <ChevronRight className="ml-auto h-4 w-4 opacity-0 group-hover:opacity-100 transition-opacity" />
            </NavLink>
          ))}
        </nav>

        {/* Footer */}
        <div className="p-4 border-t border-soft-200 dark:border-dark-700">
          <p className="text-xs text-slate-400 dark:text-slate-500 text-center">
            {t('app.version', { version: '1.0.0' })}
          </p>
        </div>
      </div>
    </aside>
  )
}
