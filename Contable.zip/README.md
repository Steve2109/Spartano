# Sistema Contable TyM - Ecuador

Sistema contable completo para Ecuador, cumpliendo con los requisitos del SRI (Servicio de Rentas Internas). Desarrollado con Python FastAPI y React TypeScript.

## Características Principales

### Seguridad
- **JWT Authentication**: Tokens de acceso y refresh con expiración configurable
- **Rate Limiting**: Limitación de peticiones por IP (10/min login, 5/hora registro)
- **Sanitización de inputs**: Validación y limpieza de todos los datos de entrada
- **Headers de seguridad**: X-Content-Type-Options, X-Frame-Options, CSP, etc.
- **ClamAV**: Escaneo de malware en todos los archivos subidos
- **VirusTotal**: Segunda capa de escaneo opcional
- **Encriptación**: Backups encriptados con Fernet (AES-128)

### Facturación Electrónica SRI
- Generación de claves de acceso (49 dígitos)
- Consulta de RUC y cédula al SRI
- Firma electrónica digital (.p12)
- Generación de XML según XSD del SRI
- Comprobantes: Facturas, Notas de Crédito/Débito, Retenciones, Guías de Remisión

### Contabilidad
- Plan de cuentas según catálogo SRI
- Libro Diario y Libro Mayor
- Balance de Comprobación
- Asientos contables automáticos desde facturación
- Kardex de inventario

### Inventario
- Gestión de productos y servicios
- Control de stock por bodega
- Movimientos de inventario (Kardex)
- Alertas de stock bajo
- Ajustes de inventario físico

### Multiempresa (Multi-tenant)
- Separación completa de datos por empresa
- Un usuario puede acceder a múltiples empresas
- Permisos granulares por empresa

### Backups Automáticos
- Ejecución diaria a medianoche vía Celery
- Backups encriptados y comprimidos
- Retención configurable (por defecto 30 días)
- Clave de encriptación configurable en .env

### Email
- Configuración SMTP/IMAP/POP
- Soporte para Gmail, Zoho, Microsoft, etc.
- Envío de comprobantes por email

### Frontend
- **Tema claro**: Color suave #f8fafc para no cansar la vista
- **Tema oscuro**: Para uso nocturno
- **i18n**: Español latinoamericano y español de Ecuador
- **Dashboards interactivos** con estadísticas
- **UI moderna** con TailwindCSS

## Estructura del Proyecto

```
Sistema Contable/
├── backend/                 # API FastAPI
│   ├── app/
│   │   ├── api/v1/endpoints/    # Rutas API
│   │   ├── core/                # Configuración y seguridad
│   │   ├── db/                  # Base de datos
│   │   ├── models/              # Modelos SQLAlchemy
│   │   ├── schemas/             # Pydantic schemas
│   │   ├── services/            # Lógica de negocio
│   │   └── celery_tasks/         # Tareas programadas
│   ├── requirements.txt
│   └── .env.example
├── frontend/                # React + TypeScript
│   ├── src/
│   │   ├── components/       # Componentes React
│   │   ├── pages/            # Páginas
│   │   ├── store/            # Zustand stores
│   │   ├── services/         # API services
│   │   └── i18n/             # Traducciones
│   ├── package.json
│   └── tailwind.config.js
└── README.md
```

## Requisitos

- Python 3.11+
- Node.js 18+
- PostgreSQL 14+ (o SQLite para desarrollo)
- Redis (para Celery y caché)
- ClamAV (opcional, para escaneo de archivos)

## Instalación

### 1. Backend

```bash
cd backend

# Crear entorno virtual
python -m venv venv
source venv/bin/activate  # Linux/Mac
venv\Scripts\activate     # Windows

# Instalar dependencias
pip install -r requirements.txt

# Configurar variables de entorno
cp .env.example .env
# Editar .env con tus configuraciones

# Inicializar base de datos
python -c "from app.db.base import init_db; init_db()"

# Iniciar servidor
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

### 2. Frontend

```bash
cd frontend

# Instalar dependencias
npm install

# Configurar API URL
echo "VITE_API_URL=http://localhost:8000/api/v1" > .env.local

# Iniciar servidor de desarrollo
npm run dev
```

### 3. Celery (Backups automáticos)

```bash
# Terminal 1: Worker
cd backend
source venv/bin/activate
celery -A app.celery_tasks.backup_tasks worker --loglevel=info

# Terminal 2: Beat (scheduler)
cd backend
source venv/bin/activate
celery -A app.celery_tasks.backup_tasks beat --loglevel=info
```

## Configuración de Variables de Entorno (.env)

### Seguridad (Obligatorio)
```env
SECRET_KEY=tu-clave-secreta-muy-larga-y-segura
BACKUP_ENCRYPTION_KEY=clave-encriptacion-32-caracteres!
```

### Base de Datos
```env
# PostgreSQL (Recomendado para producción)
DATABASE_URL=postgresql://usuario:password@localhost:5432/sistema_contable

# SQLite (Desarrollo)
DATABASE_URL=sqlite:///./data/app.db
```

### ClamAV (Seguridad de archivos)
```env
CLAMAV_ENABLED=true
CLAMAV_HOST=localhost
CLAMAV_PORT=3310
```

### VirusTotal (Opcional)
```env
VIRUSTOTAL_ENABLED=false
VIRUSTOTAL_API_KEY=tu-api-key
```

### Email
```env
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=tu-email@gmail.com
SMTP_PASSWORD=tu-app-password
```

### SRI
```env
SRI_AMBIENTE=pruebas  # pruebas o produccion
```

## Configuración de Firma Electrónica

1. Subir archivo .p12 en la interfaz de empresa
2. La contraseña de la firma debe configurarse en el archivo .env:
```env
EMPRESA_{id}_FIRMA_PASSWORD=tu_clave_firma
```

## Flujo de Facturación Electrónica

1. Crear factura en el sistema
2. Generar XML según XSD del SRI
3. Firmar XML con certificado digital
4. Enviar al web service de recepción del SRI
5. Consultar autorización
6. Generar PDF con código de barras bidimensional (QR)
7. Enviar al cliente por email

## API Endpoints Principales

### Autenticación
- `POST /api/v1/auth/login` - Iniciar sesión
- `POST /api/v1/auth/register` - Registrar usuario
- `POST /api/v1/auth/refresh` - Refrescar token

### Empresas
- `GET /api/v1/empresas` - Listar empresas
- `POST /api/v1/empresas` - Crear empresa
- `GET /api/v1/empresas/{id}/sri-sync` - Sincronizar con SRI

### SRI
- `GET /api/v1/sri/consultar-ruc?ruc=XXX` - Consultar RUC
- `GET /api/v1/sri/generar-clave-acceso` - Generar clave de acceso

### Archivos
- `POST /api/v1/uploads/scan` - Subir archivo con escaneo de seguridad

## Seguridad de Archivos

Todos los archivos subidos pasan por:
1. **Validación de extensión**: Solo permitidos (.xlsx, .pdf, .jpg, etc.)
2. **Validación de tamaño**: Máximo 10MB por defecto
3. **ClamAV**: Escaneo de malware local
4. **VirusTotal**: Escaneo adicional opcional

## Despliegue en Producción

### Backend
```bash
# Usar Gunicorn con Uvicorn workers
gunicorn app.main:app -w 4 -k uvicorn.workers.UvicornWorker --bind 0.0.0.0:8000
```

### Frontend
```bash
# Build de producción
npm run build

# Los archivos estáticos se generan en /dist
```

### Docker (Próximamente)
Se incluirá configuración Docker y docker-compose para despliegue simplificado.

## Licencia

Este proyecto es propiedad privada de T&M Technology Ec.

## Soporte

Para soporte técnico o consultas:
- Email: soporte@tymtechnology.shop
- Teléfono: +593 960940921

## Changelog

### v1.0.0 (2026-04-24)
- Lanzamiento inicial
- Facturación electrónica SRI completa
- Módulo de inventario con Kardex
- Sistema multiempresa
- Backups automáticos encriptados
- Escaneo de malware con ClamAV
