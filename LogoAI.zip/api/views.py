"""
Vistas API del editor
Autor: T&M Technology Ec
"""

import json
import bleach
from rest_framework import generics, status, parsers
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from rest_framework.views import APIView
from rest_framework.throttling import UserRateThrottle, AnonRateThrottle
from django.shortcuts import get_object_or_404
from django.db import transaction
from django_ratelimit.decorators import ratelimit
from django.utils.decorators import method_decorator

from editor.models import Project, Layer, ShapeLibrary, Template, FontLibrary
from editor.image_processor import ImageProcessor
from .serializers import (
    ProjectSerializer, LayerSerializer, 
    ShapeLibrarySerializer, TemplateSerializer, FontLibrarySerializer
)


class APIRateThrottle(UserRateThrottle):
    rate = '60/minute'


class ProjectListAPI(generics.ListCreateAPIView):
    """API para listar y crear proyectos."""
    serializer_class = ProjectSerializer
    permission_classes = [IsAuthenticated]
    throttle_classes = [APIRateThrottle]
    
    def get_queryset(self):
        return Project.objects.filter(
            user=self.request.user
        ).exclude(is_template=True)
    
    def perform_create(self, serializer):
        serializer.save(user=self.request.user)


class ProjectDetailAPI(generics.RetrieveUpdateDestroyAPIView):
    """API para detalle de proyecto."""
    serializer_class = ProjectSerializer
    permission_classes = [IsAuthenticated]
    throttle_classes = [APIRateThrottle]
    lookup_field = 'pk'
    
    def get_queryset(self):
        return Project.objects.filter(user=self.request.user)


class LayerListAPI(generics.ListCreateAPIView):
    """API para capas de un proyecto."""
    serializer_class = LayerSerializer
    permission_classes = [IsAuthenticated]
    throttle_classes = [APIRateThrottle]
    
    def get_queryset(self):
        project_id = self.kwargs.get('pk')
        return Layer.objects.filter(
            project__id=project_id,
            project__user=self.request.user
        )
    
    def perform_create(self, serializer):
        project_id = self.kwargs.get('pk')
        project = get_object_or_404(Project, id=project_id, user=self.request.user)
        serializer.save(project=project)


class LayerDetailAPI(generics.RetrieveUpdateDestroyAPIView):
    """API para detalle de capa."""
    serializer_class = LayerSerializer
    permission_classes = [IsAuthenticated]
    throttle_classes = [APIRateThrottle]
    lookup_field = 'pk'
    
    def get_queryset(self):
        return Layer.objects.filter(project__user=self.request.user)


class ShapeLibraryAPI(generics.ListAPIView):
    """API para biblioteca de formas."""
    queryset = ShapeLibrary.objects.filter(category='general')
    serializer_class = ShapeLibrarySerializer
    permission_classes = [IsAuthenticated]
    throttle_classes = [AnonRateThrottle]


class TemplateListAPI(generics.ListAPIView):
    """API para plantillas."""
    queryset = Template.objects.filter(is_active=True)
    serializer_class = TemplateSerializer
    permission_classes = [IsAuthenticated]
    throttle_classes = [AnonRateThrottle]


class FontListAPI(generics.ListAPIView):
    """API para fuentes."""
    queryset = FontLibrary.objects.filter(is_active=True)
    serializer_class = FontLibrarySerializer
    permission_classes = [IsAuthenticated]
    throttle_classes = [AnonRateThrottle]


@method_decorator(ratelimit(key='user', rate='10/m'), name='post')
class ImageUploadAPI(APIView):
    """API para subir imágenes."""
    permission_classes = [IsAuthenticated]
    parser_classes = [parsers.MultiPartParser, parsers.FormParser]
    
    MAX_SIZE = 10 * 1024 * 1024  # 10MB
    ALLOWED_TYPES = ['image/jpeg', 'image/png', 'image/gif', 'image/webp']
    
    def post(self, request):
        if 'image' not in request.FILES:
            return Response(
                {'error': 'No se proporcionó imagen'},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        image = request.FILES['image']
        
        # Validar tamaño
        if image.size > self.MAX_SIZE:
            return Response(
                {'error': 'Imagen excede 10MB'},
                status=status.HTTP_413_REQUEST_ENTITY_TOO_LARGE
            )
        
        # Validar tipo
        if image.content_type not in self.ALLOWED_TYPES:
            return Response(
                {'error': f'Tipo {image.content_type} no permitido'},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        # Sanitizar nombre
        filename = bleach.clean(image.name, tags=[], strip=True)
        
        # Guardar
        from django.core.files.storage import default_storage
        path = default_storage.save(f'uploads/{filename}', image)
        
        return Response({
            'success': True,
            'url': f'/media/{path}',
            'filename': filename,
            'size': image.size
        })


@method_decorator(ratelimit(key='user', rate='20/m'), name='post')
class ImageProcessAPI(APIView):
    """API para procesar imágenes."""
    permission_classes = [IsAuthenticated]
    
    def post(self, request):
        try:
            data = json.loads(request.body)
            # Sanitizar entrada
            data = {k: self._sanitize_value(v) for k, v in data.items()}
            
            operation = data.get('operation')
            image_path = data.get('image_path', '').lstrip('/')
            
            if not image_path.startswith('media/'):
                return Response(
                    {'error': 'Ruta de imagen inválida'},
                    status=status.HTTP_400_BAD_REQUEST
                )
            
            processor = ImageProcessor()
            full_path = image_path.replace('media/', '', 1)
            
            if operation == 'crop':
                result = processor.crop_image(
                    full_path,
                    int(data.get('x', 0)),
                    int(data.get('y', 0)),
                    int(data.get('width', 100)),
                    int(data.get('height', 100))
                )
            elif operation == 'resize':
                result = processor.resize_image(
                    full_path,
                    int(data.get('width', 100)),
                    int(data.get('height', 100)),
                    data.get('maintain_aspect', True)
                )
            elif operation == 'filter':
                result = processor.apply_filter(
                    full_path,
                    data.get('filter_type', 'blur'),
                    **data.get('params', {})
                )
            elif operation == 'remove_bg':
                result = processor.remove_background(full_path)
            else:
                return Response(
                    {'error': 'Operación no soportada'},
                    status=status.HTTP_400_BAD_REQUEST
                )
            
            # Guardar resultado
            from django.core.files.storage import default_storage
            from django.core.files.base import ContentFile
            import uuid
            
            output_filename = f"processed_{uuid.uuid4().hex[:8]}.png"
            saved_path = default_storage.save(
                f'processed/{output_filename}',
                ContentFile(result.getvalue())
            )
            
            return Response({
                'success': True,
                'url': f'/media/{saved_path}',
                'filename': output_filename
            })
        
        except json.JSONDecodeError:
            return Response(
                {'error': 'JSON inválido'},
                status=status.HTTP_400_BAD_REQUEST
            )
        except Exception as e:
            return Response(
                {'error': str(e)},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )
    
    def _sanitize_value(self, value):
        """Sanitizar valor recursivamente."""
        if isinstance(value, str):
            return bleach.clean(value, tags=[], strip=True)
        elif isinstance(value, dict):
            return {k: self._sanitize_value(v) for k, v in value.items()}
        elif isinstance(value, list):
            return [self._sanitize_value(v) for v in value]
        return value


@method_decorator(ratelimit(key='user', rate='5/m'), name='post')
class ExportAPI(APIView):
    """API para exportar proyectos."""
    permission_classes = [IsAuthenticated]
    
    def post(self, request):
        try:
            data = json.loads(request.body)
            data = {k: self._sanitize_value(v) for k, v in data.items()}
            
            project_id = data.get('project_id')
            format_type = data.get('format', 'png').lower()
            quality = min(int(data.get('quality', 100)), 100)
            
            project = get_object_or_404(
                Project,
                id=project_id,
                user=request.user
            )
            
            processor = ImageProcessor()
            result = processor.export_project(project, format_type, quality)
            
            return Response({
                'success': True,
                'download_url': result['url'],
                'filename': result['filename']
            })
        
        except Exception as e:
            return Response(
                {'error': str(e)},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )
    
    def _sanitize_value(self, value):
        if isinstance(value, str):
            return bleach.clean(value, tags=[], strip=True)
        elif isinstance(value, dict):
            return {k: self._sanitize_value(v) for k, v in value.items()}
        elif isinstance(value, list):
            return [self._sanitize_value(v) for v in value]
        return value


class HealthCheckAPI(APIView):
    """API para verificar estado del sistema."""
    permission_classes = []
    
    def get(self, request):
        return Response({
            'status': 'healthy',
            'version': '1.0.0',
            'author': 'T&M Technology Ec',
            'support': 'soporte@tymtechnology.shop'
        })
