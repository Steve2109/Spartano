"""
URLs de la API
"""

from django.urls import path
from . import views

urlpatterns = [
    # Proyectos
    path('projects/', views.ProjectListAPI.as_view(), name='api_projects'),
    path('projects/<uuid:pk>/', views.ProjectDetailAPI.as_view(), name='api_project_detail'),
    path('projects/<uuid:pk>/layers/', views.LayerListAPI.as_view(), name='api_layers'),
    
    # Capas
    path('layers/<uuid:pk>/', views.LayerDetailAPI.as_view(), name='api_layer_detail'),
    
    # Recursos
    path('shapes/', views.ShapeLibraryAPI.as_view(), name='api_shapes'),
    path('templates/', views.TemplateListAPI.as_view(), name='api_templates'),
    path('fonts/', views.FontListAPI.as_view(), name='api_fonts'),
    
    # Imágenes
    path('upload-image/', views.ImageUploadAPI.as_view(), name='api_upload_image'),
    path('process-image/', views.ImageProcessAPI.as_view(), name='api_process_image'),
    
    # Exportar
    path('export/', views.ExportAPI.as_view(), name='api_export'),
    
    # Utilidades
    path('health/', views.HealthCheckAPI.as_view(), name='api_health'),
]
