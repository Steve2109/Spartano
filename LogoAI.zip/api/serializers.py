"""
Serializadores de la API
"""

from rest_framework import serializers
from editor.models import Project, Layer, ShapeLibrary, Template, FontLibrary


class LayerSerializer(serializers.ModelSerializer):
    """Serializador de capas."""
    
    class Meta:
        model = Layer
        fields = [
            'id', 'project', 'z_index', 'layer_type', 'name',
            'visible', 'locked', 'opacity',
            'x', 'y', 'width', 'height', 'rotation',
            'scale_x', 'scale_y', 'flip_x', 'flip_y',
            'content_data', 'style_data', 'created_at', 'updated_at'
        ]
        read_only_fields = ['created_at', 'updated_at']


class ProjectSerializer(serializers.ModelSerializer):
    """Serializador de proyectos."""
    layers = LayerSerializer(many=True, read_only=True)
    layer_count = serializers.SerializerMethodField()
    
    class Meta:
        model = Project
        fields = [
            'id', 'name', 'description', 'user',
            'canvas_width', 'canvas_height', 'background_color',
            'export_format', 'export_quality',
            'is_public', 'is_template', 'thumbnail',
            'layers', 'layer_count',
            'created_at', 'updated_at'
        ]
        read_only_fields = ['user', 'created_at', 'updated_at']
    
    def get_layer_count(self, obj):
        return obj.layers.count()
    
    def validate_name(self, value):
        """Validar nombre del proyecto."""
        if not value or len(value.strip()) == 0:
            raise serializers.ValidationError('El nombre es requerido.')
        return value[:200]
    
    def validate_canvas_width(self, value):
        if value < 50 or value > 5000:
            raise serializers.ValidationError('Ancho debe estar entre 50 y 5000.')
        return value
    
    def validate_canvas_height(self, value):
        if value < 50 or value > 5000:
            raise serializers.ValidationError('Alto debe estar entre 50 y 5000.')
        return value


class ShapeLibrarySerializer(serializers.ModelSerializer):
    """Serializador de formas."""
    
    class Meta:
        model = ShapeLibrary
        fields = ['id', 'name', 'shape_type', 'svg_path', 'category']


class TemplateSerializer(serializers.ModelSerializer):
    """Serializador de plantillas."""
    
    class Meta:
        model = Template
        fields = [
            'id', 'name', 'description', 'category',
            'thumbnail', 'is_active', 'is_premium', 'created_at'
        ]


class FontLibrarySerializer(serializers.ModelSerializer):
    """Serializador de fuentes."""
    
    class Meta:
        model = FontLibrary
        fields = [
            'id', 'name', 'family_name', 'category',
            'is_google_font', 'is_active'
        ]
