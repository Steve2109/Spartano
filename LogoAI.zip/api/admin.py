"""
Admin para API (vacío, usa admin del editor)
"""
from django.contrib import admin
