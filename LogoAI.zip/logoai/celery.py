"""
Configuración de Celery para LogoAI
Autor: T&M Technology Ec
"""

import os
from celery import Celery

# Configurar Django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'logoai.settings')

# Crear app Celery
app = Celery('logoai')

# Usar configuración de Django
app.config_from_object('django.conf:settings', namespace='CELERY')

# Auto-discover tasks
app.autodiscover_tasks()


@app.task(bind=True, ignore_result=True)
def debug_task(self):
    """Task de debug."""
    print(f'Request: {self.request!r}')
