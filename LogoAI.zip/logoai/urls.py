"""
URL configuration for logoai project.
"""
from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from django.shortcuts import render


def home_view(request):
    """Vista de inicio."""
    return render(request, 'home.html')


urlpatterns = [
    path('', home_view, name='home'),
    path('admin/', admin.site.urls),
    path('editor/', include('editor.urls')),
    path('api/', include('api.urls')),
    path('accounts/', include('users.urls')),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
