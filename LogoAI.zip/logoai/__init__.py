"""
LogoAI - Creador de Logotipos Profesional
Autor: T&M Technology Ec
Soporte: soporte@tymtechnology.shop
"""

__version__ = '1.0.0'
__author__ = 'T&M Technology Ec'
__contact__ = 'soporte@tymtechnology.shop'
