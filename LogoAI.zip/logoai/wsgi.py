"""
WSGI config for logoai project.
"""

import os

from django.core.wsgi import get_wsgi_application

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'logoai.settings')

application = get_wsgi_application()
