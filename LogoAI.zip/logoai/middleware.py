"""
Middleware personalizado para seguridad y rate limiting
Autor: T&M Technology Ec
"""

import re
import bleach
from django.http import JsonResponse
from django_ratelimit.decorators import ratelimit
from django_ratelimit.exceptions import Ratelimited
from django.utils.deprecation import MiddlewareMixin


class SecurityHeadersMiddleware(MiddlewareMixin):
    """Middleware para agregar headers de seguridad."""
    
    def process_response(self, request, response):
        # Prevenir clickjacking
        response['X-Frame-Options'] = 'SAMEORIGIN'
        # Prevenir MIME sniffing
        response['X-Content-Type-Options'] = 'nosniff'
        # Prevenir XSS
        response['X-XSS-Protection'] = '1; mode=block'
        # Referrer Policy
        response['Referrer-Policy'] = 'strict-origin-when-cross-origin'
        # Content Security Policy
        response['Content-Security-Policy'] = (
            "default-src 'self'; "
            "script-src 'self' 'unsafe-inline' 'unsafe-eval'; "
            "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; "
            "font-src 'self' https://fonts.gstatic.com; "
            "img-src 'self' data: blob:; "
            "connect-src 'self';"
        )
        return response


class RateLimitMiddleware(MiddlewareMixin):
    """Middleware para manejo global de rate limiting."""
    
    def process_exception(self, request, exception):
        if isinstance(exception, Ratelimited):
            return JsonResponse({
                'error': 'Demasiadas solicitudes. Por favor, inténtalo más tarde.',
                'code': 'rate_limited'
            }, status=429)
        return None


class InputSanitizationMiddleware(MiddlewareMixin):
    """Middleware para sanitizar entradas de usuario."""
    
    ALLOWED_TAGS = []
    ALLOWED_ATTRIBUTES = {}
    
    def process_request(self, request):
        """Sanitizar parámetros GET y POST."""
        # Sanitizar GET params
        if request.GET:
            request.GET = self._sanitize_querydict(request.GET)
        
        # Sanitizar POST params (no archivos)
        if request.POST:
            request.POST = self._sanitize_querydict(request.POST)
    
    def _sanitize_querydict(self, querydict):
        """Sanitizar valores de QueryDict."""
        sanitized = querydict.copy()
        for key in sanitized:
            if isinstance(sanitized[key], str):
                sanitized[key] = self._sanitize_string(sanitized[key])
            elif isinstance(sanitized[key], list):
                sanitized.setlist(key, [
                    self._sanitize_string(v) if isinstance(v, str) else v 
                    for v in sanitized.getlist(key)
                ])
        return sanitized
    
    def _sanitize_string(self, value):
        """Sanitizar string con bleach."""
        # Eliminar tags HTML peligrosos
        cleaned = bleach.clean(
            value,
            tags=self.ALLOWED_TAGS,
            attributes=self.ALLOWED_ATTRIBUTES,
            strip=True
        )
        # Prevenir null bytes
        cleaned = cleaned.replace('\x00', '')
        return cleaned


class FileUploadValidationMiddleware(MiddlewareMixin):
    """Middleware para validar archivos subidos."""
    
    ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'svg', 'webp', 'pdf'}
    ALLOWED_MIME_TYPES = {
        'image/png', 'image/jpeg', 'image/gif', 'image/svg+xml', 
        'image/webp', 'application/pdf'
    }
    MAX_FILE_SIZE = 10 * 1024 * 1024  # 10MB
    
    def process_request(self, request):
        """Validar archivos subidos."""
        if request.method in ['POST', 'PUT', 'PATCH'] and request.FILES:
            for field_name, file_obj in request.FILES.items():
                # Validar tamaño
                if file_obj.size > self.MAX_FILE_SIZE:
                    return JsonResponse({
                        'error': f'Archivo {field_name} excede el tamaño máximo de 10MB',
                        'code': 'file_too_large'
                    }, status=413)
                
                # Validar extensión
                ext = file_obj.name.split('.')[-1].lower()
                if ext not in self.ALLOWED_EXTENSIONS:
                    return JsonResponse({
                        'error': f'Extensión .{ext} no permitida',
                        'code': 'invalid_extension'
                    }, status=400)
                
                # Validar MIME type
                if hasattr(file_obj, 'content_type') and file_obj.content_type:
                    if file_obj.content_type not in self.ALLOWED_MIME_TYPES:
                        return JsonResponse({
                            'error': f'Tipo de archivo {file_obj.content_type} no permitido',
                            'code': 'invalid_mime_type'
                        }, status=400)
        return None
