#!/bin/bash
# Script de Despliegue Automático para LogoAI
# Autor: T&M Technology Ec
# Soporte: soporte@tymtechnology.shop

set -e

# Colores
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Funciones
log_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Verificar que estamos en el directorio correcto
if [ ! -f "docker-compose.yml" ]; then
    log_error "No se encontró docker-compose.yml"
    log_error "Ejecutar desde el directorio del proyecto"
    exit 1
fi

# Verificar archivo .env
if [ ! -f ".env" ]; then
    log_warn "Archivo .env no encontrado"
    log_warn "Copiar .env.example a .env y configurar"
    exit 1
fi

log_info "🚀 Iniciando despliegue de LogoAI..."

# Backup antes de actualizar
if [ -f "scripts/backup.sh" ]; then
    log_info "📦 Creando backup..."
    bash scripts/backup.sh || log_warn "Backup falló, continuando..."
fi

# Detener servicios actuales
log_info "🛑 Deteniendo servicios actuales..."
docker compose down

# Actualizar imágenes
log_info "📥 Descargando actualizaciones..."
docker compose pull

# Construir nuevas imágenes
log_info "🔨 Construyendo imágenes..."
docker compose build --no-cache

# Iniciar servicios
log_info "▶️ Iniciando servicios..."
docker compose up -d

# Esperar a que la base de datos esté lista
log_info "⏳ Esperando base de datos..."
sleep 15

# Ejecutar migraciones
log_info "🔄 Ejecutando migraciones..."
docker compose exec -T web python manage.py migrate

# Recolectar archivos estáticos
log_info "📁 Recolectando archivos estáticos..."
docker compose exec -T web python manage.py collectstatic --noinput

# Verificar salud
log_info "🏥 Verificando salud del sistema..."
sleep 5

if curl -f -s http://localhost:32299/api/health/ > /dev/null; then
    log_info "✅ Despliegue exitoso!"
    log_info "🌐 Aplicación disponible en:"
    log_info "   - Local: http://10.0.1.40:32299"
    log_info "   - Público: https://logoai.tymtechnology.shop"
else
    log_error "❌ La aplicación no respondió correctamente"
    log_error "Verificar logs: docker compose logs web"
    exit 1
fi

# Mostrar estado
log_info "📊 Estado de los servicios:"
docker compose ps

echo ""
log_info "📝 Comandos útiles:"
echo "  - Ver logs: docker compose logs -f web"
echo "  - Reiniciar: docker compose restart"
echo "  - Acceder al contenedor: docker compose exec web bash"
echo ""
log_info "📞 Soporte: soporte@tymtechnology.shop"
