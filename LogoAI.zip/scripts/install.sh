#!/bin/bash
# Script de Instalación Automática para LogoAI en Debian 13
# Autor: T&M Technology Ec
# Soporte: soporte@tymtechnology.shop
# IMPORTANTE: Ejecutar desde /opt/logoai (NO desde el directorio home)

set -e

# Configuración
APP_NAME="logoai"
APP_DIR="/opt/logoai"
APP_PORT="32299"
DOMAIN="logoai.tymtechnology.shop"
INSTALL_TYPE=""

# Colores
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

log_info() { echo -e "${GREEN}[INFO]${NC} $1"; }
log_warn() { echo -e "${YELLOW}[WARN]${NC} $1"; }
log_error() { echo -e "${RED}[ERROR]${NC} $1"; }
log_step() { echo -e "${BLUE}[STEP]${NC} $1"; }
log_header() { echo -e "${CYAN}$1${NC}"; }

# ============================================
# MENÚ DE SELECCIÓN
# ============================================
show_menu() {
    clear
    log_header "=========================================="
    log_header "  🎨 Instalador de LogoAI"
    log_header "  T&M Technology Ec"
    log_header "=========================================="
    echo ""
    log_info "📧 Soporte: soporte@tymtechnology.shop"
    echo ""
    echo "Selecciona el método de instalación:"
    echo ""
    echo "  [1] 🐳 Docker (Recomendado)"
    echo "      - Instalación rápida y aislada"
    echo "      - Fácil mantenimiento y actualizaciones"
    echo "      - Ideal para producción"
    echo ""
    echo "  [2] 🐍 Python Manual (Sin Docker)"
    echo "      - Mayor control del sistema"
    echo "      - Ideal para LXC containers o sin Docker"
    echo "      - Requiere PostgreSQL/Redis instalados"
    echo ""
    echo "  [0] ❌ Cancelar"
    echo ""
    
    read -p "Opción [1/2/0]: " choice
    
    case $choice in
        1) INSTALL_TYPE="docker"; log_info "Seleccionado: Instalación con Docker" ;;
        2) INSTALL_TYPE="manual"; log_info "Seleccionado: Instalación Manual Python" ;;
        0) log_info "Instalación cancelada"; exit 0 ;;
        *) log_error "Opción inválida"; sleep 2; show_menu ;;
    esac
    
    echo ""
    read -p "¿Continuar con la instalación? (s/n): " confirm
    [[ ! $confirm =~ ^[Ss]$ ]] && log_info "Instalación cancelada" && exit 0
}

# ============================================
# VERIFICACIONES
# ============================================
check_root() {
    if [ "$EUID" -ne 0 ]; then
        log_error "Este script debe ejecutarse como root (sudo)"
        exit 1
    fi
}

check_os() {
    if ! command -v apt &> /dev/null; then
        log_error "Este script solo funciona en Debian/Ubuntu"
        exit 1
    fi
}

check_location() {
    if [ "$PWD" != "/opt/logoai" ] && [ "$PWD" != "$APP_DIR" ]; then
        log_warn "⚠️  No estás en /opt/logoai/"
        log_info "El script está diseñado para ejecutarse desde: /opt/logoai/"
        log_info "Directorio actual: $PWD"
        echo ""
        log_info "Copia los archivos del proyecto a /opt/logoai/ primero:"
        log_info "  mkdir -p /opt/logoai"
        log_info "  cp -r /ruta/del/repositorio/* /opt/logoai/"
        log_info "  cd /opt/logoai"
        log_info "  sudo bash scripts/install.sh"
        exit 1
    fi
}

# ============================================
# INSTALACIÓN DOCKER
# ============================================
install_docker() {
    log_step "Instalando Docker..."
    
    if ! command -v docker &> /dev/null; then
        curl -fsSL https://get.docker.com | sh
        systemctl enable docker
        systemctl start docker
        SUDO_USER=${SUDO_USER:-$USER}
        usermod -aG docker $SUDO_USER
        log_info "Usuario $SUDO_USER agregado al grupo docker"
    else
        log_info "Docker ya está instalado"
    fi
    
    if ! docker compose version &> /dev/null; then
        apt install -y docker-compose-plugin
    fi
}

configure_env_docker() {
    log_step "Configurando variables de entorno (Docker)..."
    
    SECRET_KEY=$(openssl rand -base64 50 | tr -d '\n')
    DB_PASSWORD=$(openssl rand -base64 32 | tr -d '\n' | cut -c1-20)
    
    cat > $APP_DIR/.env << EOF
# LogoAI - Variables de Entorno (Docker)
# IMPORTANTE: Mantener en /opt/logoai/
SECRET_KEY=$SECRET_KEY
DEBUG=False
ALLOWED_HOSTS=$DOMAIN,localhost,127.0.0.1
DB_PASSWORD=$DB_PASSWORD
RATE_LIMIT_ANON=30/m
RATE_LIMIT_AUTH=100/m
RATE_LIMIT_API=60/m
MAX_UPLOAD_SIZE=10485760
MAX_CANVAS_WIDTH=5000
MAX_CANVAS_HEIGHT=5000
EOF
    
    chmod 600 $APP_DIR/.env
    log_info "✅ Archivo .env creado"
}

finalize_docker() {
    log_step "Creando servicio systemd..."
    
    cat > /etc/systemd/system/logoai.service << EOF
[Unit]
Description=LogoAI Docker Compose
Requires=docker.service
After=docker.service

[Service]
Type=oneshot
RemainAfterExit=yes
WorkingDirectory=$APP_DIR
ExecStart=/usr/bin/docker compose up -d
ExecStop=/usr/bin/docker compose down
TimeoutStartSec=0

[Install]
WantedBy=multi-user.target
EOF
    
    systemctl daemon-reload
    systemctl enable logoai.service
    
    # Script de control
    cat > /usr/local/bin/logoai << 'SCRIPT'
#!/bin/bash
cd /opt/logoai || exit 1
case "$1" in
    start) docker compose up -d && echo "LogoAI iniciado" ;;
    stop) docker compose down && echo "LogoAI detenido" ;;
    restart) docker compose restart && echo "LogoAI reiniciado" ;;
    status) docker compose ps ;;
    logs) docker compose logs -f web ;;
    migrate) docker compose exec web python manage.py migrate ;;
    static) docker compose exec web python manage.py collectstatic --noinput ;;
    shell) docker compose exec web bash ;;
    backup) bash scripts/backup.sh ;;
    update) bash scripts/deploy.sh ;;
    *) echo "Uso: logoai {start|stop|restart|status|logs|migrate|static|shell|backup|update}" ;;
esac
SCRIPT
    chmod +x /usr/local/bin/logoai
    log_info "✅ Comando 'logoai' instalado"
}

# ============================================
# INSTALACIÓN MANUAL
# ============================================
install_manual_deps() {
    log_step "Instalando dependencias Python..."
    
    apt install -y python3.11 python3.11-venv python3.11-dev python3-pip \
        build-essential libpq-dev libmagic1 \
        libfreetype6-dev libjpeg-dev libpng-dev zlib1g-dev libwebp-dev
    
    log_info "Instalando PostgreSQL..."
    apt install -y postgresql-15 postgresql-contrib
    systemctl enable postgresql
    systemctl start postgresql
    
    log_info "Instalando Redis..."
    apt install -y redis-server
    systemctl enable redis-server
    systemctl start redis-server
    
    if redis-cli ping | grep -q "PONG"; then
        log_info "✅ Redis funcionando"
    else
        log_warn "⚠️ Redis puede requerir configuración"
    fi
    
    log_info "Instalando Nginx..."
    apt install -y nginx
    systemctl enable nginx
}

configure_postgresql_manual() {
    log_step "Configurando PostgreSQL..."
    DB_PASSWORD=$(openssl rand -base64 32 | tr -d '\n' | cut -c1-20)
    
    sudo -u postgres psql << EOF
CREATE USER logoai_user WITH PASSWORD '$DB_PASSWORD';
CREATE DATABASE logoai_db OWNER logoai_user;
GRANT ALL PRIVILEGES ON DATABASE logoai_db TO logoai_user;
\q
EOF
    log_info "✅ Base de datos creada"
}

configure_env_manual() {
    log_step "Configurando variables de entorno (Manual)..."
    
    SECRET_KEY=$(openssl rand -base64 50 | tr -d '\n')
    [ -z "$DB_PASSWORD" ] && DB_PASSWORD=$(openssl rand -base64 32 | tr -d '\n' | cut -c1-20)
    
    cat > $APP_DIR/.env << EOF
# LogoAI - Variables de Entorno (Manual)
# IMPORTANTE: Mantener en /opt/logoai/
SECRET_KEY=$SECRET_KEY
DEBUG=False
ALLOWED_HOSTS=$DOMAIN,localhost,127.0.0.1
DB_NAME=logoai_db
DB_USER=logoai_user
DB_PASSWORD=$DB_PASSWORD
DB_HOST=localhost
DB_PORT=5432
REDIS_URL=redis://localhost:6379/0
CELERY_BROKER_URL=redis://localhost:6379/0
CELERY_RESULT_BACKEND=redis://localhost:6379/0
RATE_LIMIT_ANON=30/m
RATE_LIMIT_AUTH=100/m
RATE_LIMIT_API=60/m
MAX_UPLOAD_SIZE=10485760
MAX_CANVAS_WIDTH=5000
MAX_CANVAS_HEIGHT=5000
EOF
    
    chmod 600 $APP_DIR/.env
    log_info "✅ Archivo .env creado"
}

setup_python_env() {
    log_step "Configurando entorno Python..."
    
    cd $APP_DIR
    python3.11 -m venv venv
    source venv/bin/activate
    pip install --upgrade pip
    pip install -r requirements.txt
    
    chown -R www-data:www-data $APP_DIR
    log_info "✅ Entorno Python configurado"
}

create_gunicorn_service() {
    log_step "Creando servicio Gunicorn..."
    
    id -u www-data &>/dev/null || useradd -r -s /bin/false www-data
    
    cat > /etc/systemd/system/logoai.service << EOF
[Unit]
Description=LogoAI Gunicorn Daemon
After=network.target postgresql.service redis.service

[Service]
Type=notify
User=www-data
Group=www-data
WorkingDirectory=$APP_DIR
Environment="PATH=$APP_DIR/venv/bin"
EnvironmentFile=$APP_DIR/.env
ExecStart=$APP_DIR/venv/bin/gunicorn --bind 0.0.0.0:$APP_PORT --workers 4 --threads 2 --worker-class gthread --access-logfile /var/log/logoai/access.log --error-logfile /var/log/logoai/error.log --capture-output --enable-stdio-inheritance logoai.wsgi:application
Restart=on-failure
RestartSec=5s

[Install]
WantedBy=multi-user.target
EOF
    
    mkdir -p /var/log/logoai
    chown www-data:www-data /var/log/logoai
    
    systemctl daemon-reload
    systemctl enable logoai.service
    log_info "✅ Servicio systemd configurado"
}

finalize_manual() {
    log_step "Creando script de control..."
    
    cat > /usr/local/bin/logoai << EOF
#!/bin/bash
case "\$1" in
    start) systemctl start logoai && echo "LogoAI iniciado" ;;
    stop) systemctl stop logoai && echo "LogoAI detenido" ;;
    restart) systemctl restart logoai && echo "LogoAI reiniciado" ;;
    status) systemctl status logoai ;;
    logs) tail -f /var/log/logoai/error.log ;;
    migrate) cd $APP_DIR && source venv/bin/activate && python manage.py migrate ;;
    static) cd $APP_DIR && source venv/bin/activate && python manage.py collectstatic --noinput ;;
    shell) cd $APP_DIR && source venv/bin/activate && python manage.py shell ;;
    *) echo "Uso: logoai {start|stop|restart|status|logs|migrate|static|shell}" ;;
esac
EOF
    chmod +x /usr/local/bin/logoai
    log_info "✅ Comando 'logoai' instalado"
}

# ============================================
# CONFIGURACIÓN COMÚN
# ============================================
configure_firewall() {
    log_step "Configurando firewall..."
    
    ufw default deny incoming
    ufw default allow outgoing
    ufw allow ssh
    ufw allow $APP_PORT/tcp
    ufw allow 80/tcp
    ufw allow 443/tcp
    ufw --force enable
    
    log_info "✅ Firewall configurado"
}

create_directories() {
    log_step "Creando directorios..."
    mkdir -p $APP_DIR /backups/logoai /var/log/logoai
    log_info "✅ Directorios creados"
}

# ============================================
# SCRIPT PRINCIPAL
# ============================================
main() {
    check_root
    check_os
    check_location
    
    log_header "🎨 LogoAI - Instalador"
    log_info "Autor: T&M Technology Ec"
    log_info "Soporte: soporte@tymtechnology.shop"
    echo ""
    
    # Actualizar sistema
    log_step "Actualizando sistema..."
    apt update && apt upgrade -y
    
    # Directorios y firewall (común)
    create_directories
    configure_firewall
    
    # Menú de selección
    show_menu
    
    # Instalación según tipo
    if [ "$INSTALL_TYPE" = "docker" ]; then
        install_docker
        configure_env_docker
        finalize_docker
        
        echo ""
        echo "=========================================="
        echo "  ✅ INSTALACIÓN DOCKER COMPLETADA"
        echo "=========================================="
        echo ""
        echo "📁 Ubicación: $APP_DIR"
        echo "🌐 Puerto: $APP_PORT"
        echo ""
        echo "📋 PASOS FINALES:"
        echo "  1. logoai start          - Iniciar servicios"
        echo "  2. Esperar 30 segundos"
        echo "  3. logoai migrate        - Migraciones"
        echo "  4. logoai shell          - Entrar al contenedor"
        echo "     python manage.py createsuperuser"
        echo "  5. curl http://localhost:$APP_PORT/api/health/"
        echo ""
        
        SUDO_USER=${SUDO_USER:-$USER}
        if groups $SUDO_USER | grep -q '\bdocker\b'; then
            log_warn "⚠️  Cierra sesión y vuelve a iniciar para permisos Docker"
        fi
        
    else
        install_manual_deps
        configure_postgresql_manual
        configure_env_manual
        setup_python_env
        create_gunicorn_service
        finalize_manual
        
        echo ""
        echo "=========================================="
        echo "  ✅ INSTALACIÓN MANUAL COMPLETADA"
        echo "=========================================="
        echo ""
        echo "📁 Ubicación: $APP_DIR"
        echo "🌐 Puerto: $APP_PORT"
        echo ""
        echo "📋 PASOS FINALES:"
        echo "  1. logoai migrate        - Migraciones"
        echo "  2. logoai shell          - Crear superusuario"
        echo "     python manage.py createsuperuser"
        echo "  3. logoai static         - Recolectar estáticos"
        echo "  4. logoai start          - Iniciar servicio"
        echo "  5. curl http://localhost:$APP_PORT/api/health/"
        echo ""
    fi
    
    echo "📧 Soporte: soporte@tymtechnology.shop"
    echo "© 2024 T&M Technology Ec"
    echo ""
}

main
