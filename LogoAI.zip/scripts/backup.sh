#!/bin/bash
# Script de Backup para LogoAI
# Autor: T&M Technology Ec
# Soporte: soporte@tymtechnology.shop

set -e

# Configuración
BACKUP_DIR="/backups/logoai"
RETENTION_DAYS=30
DATE=$(date +%Y%m%d_%H%M%S)
PROJECT_DIR="/home/usuario/logoai"

# Crear directorio de backup
mkdir -p "$BACKUP_DIR"

echo "🔄 Iniciando backup de LogoAI - $DATE"

# Backup de base de datos
if command -v docker &> /dev/null && [ -f "$PROJECT_DIR/docker-compose.yml" ]; then
    echo "📦 Backup de base de datos (Docker)..."
    docker compose -f "$PROJECT_DIR/docker-compose.yml" exec -T db \
        pg_dump -U logoai_user logoai_db > "$BACKUP_DIR/db_$DATE.sql"
else
    echo "📦 Backup de base de datos (PostgreSQL local)..."
    sudo -u postgres pg_dump logoai_db > "$BACKUP_DIR/db_$DATE.sql"
fi

# Backup de archivos de media
if [ -d "$PROJECT_DIR/media" ]; then
    echo "📁 Backup de archivos media..."
    tar -czf "$BACKUP_DIR/media_$DATE.tar.gz" -C "$PROJECT_DIR" media/
fi

# Backup de configuración
echo "⚙️ Backup de configuración..."
if [ -f "$PROJECT_DIR/.env" ]; then
    tar -czf "$BACKUP_DIR/config_$DATE.tar.gz" -C "$PROJECT_DIR" .env docker-compose.yml
fi

# Limpiar backups antiguos
echo "🧹 Limpiando backups antiguos (más de $RETENTION_DAYS días)..."
find "$BACKUP_DIR" -name "*.sql" -mtime +$RETENTION_DAYS -delete
find "$BACKUP_DIR" -name "*.tar.gz" -mtime +$RETENTION_DAYS -delete

# Listar backups
echo "📋 Backups disponibles:"
ls -lh "$BACKUP_DIR"

echo "✅ Backup completado exitosamente!"
echo "📍 Ubicación: $BACKUP_DIR"
