import { Router, Request, Response } from 'express';

const router = Router();

router.get('/', (_req: Request, res: Response) => {
  res.json({
    success: true,
    status: 'healthy',
    timestamp: new Date().toISOString(),
    service: 'Logo AI Creator API',
    version: '1.0.0'
  });
});

router.get('/ready', (_req: Request, res: Response) => {
  res.json({
    success: true,
    ready: true,
    timestamp: new Date().toISOString()
  });
});

export { router as healthRouter };
