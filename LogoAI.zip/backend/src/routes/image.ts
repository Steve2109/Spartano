import { Router, Request, Response } from 'express';
import sharp from 'sharp';
import path from 'path';
import fs from 'fs/promises';
import { asyncHandler, createError } from '../middleware/errorHandler.js';
import { logger } from '../utils/logger.js';
import { z } from 'zod';

const router = Router();

const UPLOADS_DIR = path.join(process.cwd(), 'uploads');

// Validation schemas
const resizeSchema = z.object({
  width: z.number().int().min(1).max(10000).optional(),
  height: z.number().int().min(1).max(10000).optional(),
  fit: z.enum(['cover', 'contain', 'fill', 'inside', 'outside']).default('contain'),
  position: z.enum([
    'center', 'north', 'northeast', 'east', 'southeast', 
    'south', 'southwest', 'west', 'northwest', 'entropy', 'attention'
  ]).default('center'),
});

const filterSchema = z.object({
  filter: z.enum([
    'grayscale', 'sepia', 'blur', 'sharpen', 
    'negate', 'normalize', 'threshold'
  ]),
  intensity: z.number().min(0).max(100).default(50),
});

const cropSchema = z.object({
  left: z.number().int().min(0),
  top: z.number().int().min(0),
  width: z.number().int().min(1),
  height: z.number().int().min(1),
});

const rotateSchema = z.object({
  angle: z.number().min(-360).max(360),
  background: z.string().default('#ffffff'),
});

// Get image metadata
router.get('/metadata/:filename',
  asyncHandler(async (req: Request, res: Response) => {
    const { filename } = req.params;
    const sanitizedFilename = path.basename(filename); // Prevent path traversal
    const filePath = path.join(UPLOADS_DIR, sanitizedFilename);

    // Check if file exists
    try {
      await fs.access(filePath);
    } catch {
      throw createError('Archivo no encontrado', 404);
    }

    const metadata = await sharp(filePath).metadata();

    res.json({
      success: true,
      data: {
        filename: sanitizedFilename,
        format: metadata.format,
        width: metadata.width,
        height: metadata.height,
        space: metadata.space,
        channels: metadata.channels,
        depth: metadata.depth,
        density: metadata.density,
        hasAlpha: metadata.hasAlpha,
        size: (await fs.stat(filePath)).size,
      }
    });
  })
);

// Resize image
router.post('/resize/:filename',
  asyncHandler(async (req: Request, res: Response) => {
    const { filename } = req.params;
    const sanitizedFilename = path.basename(filename);
    const filePath = path.join(UPLOADS_DIR, sanitizedFilename);

    try {
      await fs.access(filePath);
    } catch {
      throw createError('Archivo no encontrado', 404);
    }

    const validated = resizeSchema.safeParse(req.body);
    if (!validated.success) {
      throw createError(`Datos inválidos: ${validated.error.message}`, 400);
    }

    const { width, height, fit, position } = validated.data;

    const outputBuffer = await sharp(filePath)
      .resize(width, height, { fit, position })
      .toBuffer();

    res.setHeader('Content-Type', 'image/png');
    res.send(outputBuffer);

    logger.info(`Image resized: ${filename} -> ${width}x${height}`);
  })
);

// Apply filters
router.post('/filter/:filename',
  asyncHandler(async (req: Request, res: Response) => {
    const { filename } = req.params;
    const sanitizedFilename = path.basename(filename);
    const filePath = path.join(UPLOADS_DIR, sanitizedFilename);

    try {
      await fs.access(filePath);
    } catch {
      throw createError('Archivo no encontrado', 404);
    }

    const validated = filterSchema.safeParse(req.body);
    if (!validated.success) {
      throw createError(`Datos inválidos: ${validated.error.message}`, 400);
    }

    const { filter, intensity } = validated.data;

    let sharpInstance = sharp(filePath);

    switch (filter) {
      case 'grayscale':
        sharpInstance = sharpInstance.grayscale();
        break;
      case 'sepia':
        sharpInstance = sharpInstance.sepia();
        break;
      case 'blur':
        sharpInstance = sharpInstance.blur(intensity / 10);
        break;
      case 'sharpen':
        sharpInstance = sharpInstance.sharpen({
          sigma: intensity / 50,
          m1: 1 + intensity / 100,
          m2: 2 + intensity / 50,
        });
        break;
      case 'negate':
        sharpInstance = sharpInstance.negate();
        break;
      case 'normalize':
        sharpInstance = sharpInstance.normalize();
        break;
      case 'threshold':
        sharpInstance = sharpInstance.threshold(intensity * 2.55);
        break;
    }

    const outputBuffer = await sharpInstance.toBuffer();

    res.setHeader('Content-Type', 'image/png');
    res.send(outputBuffer);

    logger.info(`Filter applied: ${filter} to ${filename}`);
  })
);

// Crop image
router.post('/crop/:filename',
  asyncHandler(async (req: Request, res: Response) => {
    const { filename } = req.params;
    const sanitizedFilename = path.basename(filename);
    const filePath = path.join(UPLOADS_DIR, sanitizedFilename);

    try {
      await fs.access(filePath);
    } catch {
      throw createError('Archivo no encontrado', 404);
    }

    const validated = cropSchema.safeParse(req.body);
    if (!validated.success) {
      throw createError(`Datos inválidos: ${validated.error.message}`, 400);
    }

    const { left, top, width, height } = validated.data;

    // Validate crop bounds
    const metadata = await sharp(filePath).metadata();
    if (left + width > (metadata.width || 0) || top + height > (metadata.height || 0)) {
      throw createError('Las dimensiones de recorte exceden las dimensiones de la imagen', 400);
    }

    const outputBuffer = await sharp(filePath)
      .extract({ left, top, width, height })
      .toBuffer();

    res.setHeader('Content-Type', 'image/png');
    res.send(outputBuffer);

    logger.info(`Image cropped: ${filename} (${left},${top},${width},${height})`);
  })
);

// Rotate image
router.post('/rotate/:filename',
  asyncHandler(async (req: Request, res: Response) => {
    const { filename } = req.params;
    const sanitizedFilename = path.basename(filename);
    const filePath = path.join(UPLOADS_DIR, sanitizedFilename);

    try {
      await fs.access(filePath);
    } catch {
      throw createError('Archivo no encontrado', 404);
    }

    const validated = rotateSchema.safeParse(req.body);
    if (!validated.success) {
      throw createError(`Datos inválidos: ${validated.error.message}`, 400);
    }

    const { angle, background } = validated.data;

    const outputBuffer = await sharp(filePath)
      .rotate(angle, { background })
      .toBuffer();

    res.setHeader('Content-Type', 'image/png');
    res.send(outputBuffer);

    logger.info(`Image rotated: ${filename} ${angle}°`);
  })
);

// Optimize image
router.post('/optimize/:filename',
  asyncHandler(async (req: Request, res: Response) => {
    const { filename } = req.params;
    const sanitizedFilename = path.basename(filename);
    const filePath = path.join(UPLOADS_DIR, sanitizedFilename);

    try {
      await fs.access(filePath);
    } catch {
      throw createError('Archivo no encontrado', 404);
    }

    const metadata = await sharp(filePath).metadata();
    
    let sharpInstance = sharp(filePath);

    // Auto-optimize based on format
    switch (metadata.format) {
      case 'jpeg':
        sharpInstance = sharpInstance.jpeg({ 
          quality: 85, 
          progressive: true,
          mozjpeg: true 
        });
        break;
      case 'png':
        sharpInstance = sharpInstance.png({ 
          quality: 85,
          compressionLevel: 9,
          palette: true 
        });
        break;
      case 'webp':
        sharpInstance = sharpInstance.webp({ 
          quality: 85,
          effort: 6 
        });
        break;
      default:
        sharpInstance = sharpInstance.png({ quality: 85 });
    }

    const outputBuffer = await sharpInstance.toBuffer();

    res.setHeader('Content-Type', `image/${metadata.format || 'png'}`);
    res.setHeader('X-Optimization-Saved', 'true');
    res.send(outputBuffer);

    logger.info(`Image optimized: ${filename}`);
  })
);

export { router as imageRouter };
