import { Router, Request, Response } from 'express';
import sharp from 'sharp';
import path from 'path';
import fs from 'fs/promises';
import { v4 as uuidv4 } from 'uuid';
import { asyncHandler, createError } from '../middleware/errorHandler.js';
import { logger } from '../utils/logger.js';
import { sanitizeSVG } from '../middleware/requestSanitizer.js';
import { z } from 'zod';

const router = Router();

// Validation schema
const exportSchema = z.object({
  format: z.enum(['png', 'jpeg', 'webp', 'svg', 'pdf']),
  width: z.number().int().min(1).max(10000).optional(),
  height: z.number().int().min(1).max(10000).optional(),
  quality: z.number().int().min(1).max(100).default(90),
  svgContent: z.string().optional(),
  backgroundColor: z.string().optional(),
});

// Ensure exports directory exists
const EXPORTS_DIR = path.join(process.cwd(), 'uploads', 'exports');

const ensureExportsDir = async () => {
  try {
    await fs.mkdir(EXPORTS_DIR, { recursive: true });
  } catch (error) {
    logger.error('Failed to create exports directory:', error);
  }
};

// Export from SVG content
router.post('/',
  asyncHandler(async (req: Request, res: Response) => {
    await ensureExportsDir();
    
    const validated = exportSchema.safeParse(req.body);
    if (!validated.success) {
      throw createError(`Datos inválidos: ${validated.error.message}`, 400);
    }

    const { format, width, height, quality, svgContent, backgroundColor } = validated.data;

    if (!svgContent) {
      throw createError('Se requiere contenido SVG', 400);
    }

    // Sanitize SVG content
    const sanitizedSVG = sanitizeSVG(svgContent);
    
    const filename = `export-${uuidv4()}.${format}`;
    const outputPath = path.join(EXPORTS_DIR, filename);

    try {
      if (format === 'svg') {
        // Save SVG directly
        await fs.writeFile(outputPath, sanitizedSVG, 'utf-8');
      } else {
        // Convert SVG to raster using sharp
        const svgBuffer = Buffer.from(sanitizedSVG, 'utf-8');
        
        let sharpInstance = sharp(svgBuffer, {
          density: 300, // High DPI for quality
        });

        // Resize if dimensions provided
        if (width || height) {
          sharpInstance = sharpInstance.resize(width, height, {
            fit: 'contain',
            background: backgroundColor || { r: 0, g: 0, b: 0, alpha: 0 }
          });
        }

        // Apply format and quality
        switch (format) {
          case 'png':
            sharpInstance = sharpInstance.png({
              quality,
              compressionLevel: 9,
              force: true
            });
            break;
          case 'jpeg':
            sharpInstance = sharpInstance.jpeg({
              quality,
              progressive: true,
              force: true
            });
            break;
          case 'webp':
            sharpInstance = sharpInstance.webp({
              quality,
              force: true
            });
            break;
        }

        await sharpInstance.toFile(outputPath);
      }

      // Read file for download
      const fileBuffer = await fs.readFile(outputPath);
      const stats = await fs.stat(outputPath);

      // Set headers for download
      const mimeTypes: Record<string, string> = {
        'png': 'image/png',
        'jpeg': 'image/jpeg',
        'webp': 'image/webp',
        'svg': 'image/svg+xml',
        'pdf': 'application/pdf'
      };

      res.setHeader('Content-Type', mimeTypes[format] || 'application/octet-stream');
      res.setHeader('Content-Length', stats.size);
      res.setHeader('Content-Disposition', `attachment; filename="logo-export.${format}"`);
      res.setHeader('X-Export-Filename', filename);

      res.send(fileBuffer);

      // Cleanup after sending (async, don't block response)
      setTimeout(() => {
        fs.unlink(outputPath).catch(err => {
          logger.warn(`Failed to cleanup export file: ${outputPath}`, err);
        });
      }, 60000); // Delete after 1 minute

      logger.info(`Export successful: ${filename} (${format})`);

    } catch (error) {
      logger.error('Export failed:', error);
      throw createError('Error al exportar la imagen', 500);
    }
  })
);

// Get export info (for preview)
router.post('/preview',
  asyncHandler(async (req: Request, res: Response) => {
    const validated = exportSchema.safeParse(req.body);
    if (!validated.success) {
      throw createError(`Datos inválidos: ${validated.error.message}`, 400);
    }

    const { width, height, svgContent } = validated.data;

    if (!svgContent) {
      throw createError('Se requiere contenido SVG', 400);
    }

    const sanitizedSVG = sanitizeSVG(svgContent);
    const svgBuffer = Buffer.from(sanitizedSVG, 'utf-8');

    try {
      let sharpInstance = sharp(svgBuffer, { density: 150 });

      if (width || height) {
        sharpInstance = sharpInstance.resize(width, height, {
          fit: 'inside',
          withoutEnlargement: true
        });
      }

      // Generate PNG preview
      const previewBuffer = await sharpInstance
        .png({ quality: 80 })
        .toBuffer();

      res.setHeader('Content-Type', 'image/png');
      res.setHeader('Cache-Control', 'private, max-age=300');
      res.send(previewBuffer);

    } catch (error) {
      logger.error('Preview generation failed:', error);
      throw createError('Error al generar la vista previa', 500);
    }
  })
);

export { router as exportRouter };
