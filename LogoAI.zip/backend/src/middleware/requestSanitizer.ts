import { Request, Response, NextFunction } from 'express';
import xss from 'xss';

interface SanitizedBody {
  [key: string]: unknown;
}

const sanitizeValue = (value: unknown): unknown => {
  if (typeof value === 'string') {
    // Use xss library to sanitize HTML
    return xss(value, {
      whiteList: {}, // No tags allowed
      stripIgnoreTag: true,
      stripIgnoreTagBody: ['script'],
    });
  }
  
  if (Array.isArray(value)) {
    return value.map(item => sanitizeValue(item));
  }
  
  if (value !== null && typeof value === 'object') {
    return sanitizeObject(value as Record<string, unknown>);
  }
  
  return value;
};

const sanitizeObject = (obj: Record<string, unknown>): SanitizedBody => {
  const sanitized: SanitizedBody = {};
  
  for (const [key, value] of Object.entries(obj)) {
    // Sanitize keys too (prevent prototype pollution)
    const sanitizedKey = key.replace(/[^a-zA-Z0-9_$]/g, '');
    if (sanitizedKey) {
      sanitized[sanitizedKey] = sanitizeValue(value);
    }
  }
  
  return sanitized;
};

export const requestSanitizer = (req: Request, res: Response, next: NextFunction): void => {
  // Sanitize request body
  if (req.body && typeof req.body === 'object') {
    req.body = sanitizeObject(req.body);
  }
  
  // Sanitize query parameters
  if (req.query && typeof req.query === 'object') {
    req.query = sanitizeObject(req.query) as typeof req.query;
  }
  
  // Sanitize URL parameters
  if (req.params && typeof req.params === 'object') {
    req.params = sanitizeObject(req.params) as typeof req.params;
  }
  
  next();
};

// Specific sanitizer for SVG content
export const sanitizeSVG = (svgContent: string): string => {
  // Remove potentially dangerous elements and attributes
  const dangerousPatterns = [
    /<script[^>]*>.*?<\/script>/gi,
    /javascript:/gi,
    /on\w+\s*=/gi, // event handlers
    /<iframe[^>]*>.*?<\/iframe>/gi,
    /<object[^>]*>.*?<\/object>/gi,
    /<embed[^>]*>.*?<\/embed>/gi,
    /xlink:href\s*=/gi,
  ];
  
  let sanitized = svgContent;
  dangerousPatterns.forEach(pattern => {
    sanitized = sanitized.replace(pattern, '');
  });
  
  return sanitized;
};
