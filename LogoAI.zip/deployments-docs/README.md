# Logo AI Creator - Deployment Documentation

**Author:** T&M Technology Ec <soporte@tymtechnology.shop>  
**Domain:** https://logoai.tymtechnology.shop  
**Server IP:** http://10.0.1.40:32299

## Table of Contents

1. [Quick Deployment with Docker](#1-docker-deployment-recommended)
2. [Nginx Proxy Manager Setup](#2-nginx-proxy-manager-setup)
3. [Manual Deployment](#3-manual-deployment)
4. [Apache Deployment](#4-apache-deployment-alternative)
5. [SSL Certificate Setup](#5-ssl-certificate-setup)

---

## 1. Docker Deployment (Recommended)

### Prerequisites

```bash
# Debian 13
sudo apt update && sudo apt upgrade -y
sudo apt install -y docker.io docker-compose git curl

# Add user to docker group
sudo usermod -aG docker $USER
# Log out and log back in
```

### Clone and Deploy

```bash
# Clone repository
git clone <repository-url> /var/www/logoai
cd /var/www/logoai

# Create environment file
cat > .env << 'EOF'
NODE_ENV=production
PORT=32299
HOST=0.0.0.0
CORS_ORIGIN=https://logoai.tymtechnology.shop
RATE_LIMIT_WINDOW_MS=900000
RATE_LIMIT_MAX_REQUESTS=100
LOG_LEVEL=info
EOF

# Build and start
docker-compose up -d --build

# View logs
docker-compose logs -f

# Stop
docker-compose down
```

---

## 2. Nginx Proxy Manager Setup

Your architecture: Internet → HTTPS → Nginx Proxy Manager → HTTP → Node.js:32299

### NPM Configuration

1. Access NPM web interface (usually at `http://npm-server-ip:81`)
2. Go to **Proxy Hosts** → **Add Proxy Host**

**Configuration:**

| Field | Value |
|-------|-------|
| Domain Names | `logoai.tymtechnology.shop` |
| Scheme | `http` |
| Forward Hostname/IP | `10.0.1.40` |
| Forward Port | `32299` |
| Block Common Exploits | ✅ Checked |
| Websockets Support | ✅ Checked |

**SSL Tab:**

| Field | Value |
|-------|-------|
| SSL Certificate | Request a new SSL Certificate |
| Force SSL | ✅ Checked |
| HTTP/2 Support | ✅ Checked |
| Accept Terms | ✅ Checked |

Click **Save**

---

## 3. Manual Deployment (PM2)

### System Requirements

- Node.js 20.x or higher
- npm 10.x or higher
- PM2 (for process management)

### Installation Steps

```bash
# 1. Install Node.js 20
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs

# 2. Install PM2 globally
sudo npm install -g pm2

# 3. Create project directory
sudo mkdir -p /var/www/logoai
sudo chown $USER:$USER /var/www/logoai
cd /var/www/logoai

# 4. Clone/copy project files
git clone <repository-url> .

# 5. Install dependencies
npm run install:all

# 6. Build applications
npm run build

# 7. Create .env file
cat > backend/.env << 'EOF'
NODE_ENV=production
PORT=32299
HOST=0.0.0.0
CORS_ORIGIN=https://logoai.tymtechnology.shop
RATE_LIMIT_WINDOW_MS=900000
RATE_LIMIT_MAX_REQUESTS=100
LOG_LEVEL=info
EOF

# 8. Create required directories
mkdir -p uploads logs

# 9. Start with PM2
pm2 start ecosystem.config.js

# 10. Save PM2 config and setup startup
pm2 save
pm2 startup systemd
sudo env PATH=$PATH:/usr/bin pm2 startup systemd -u $USER --hp $HOME

# 11. Verify
pm2 status
curl http://localhost:32299/api/health
```

### Useful PM2 Commands

```bash
# View logs
pm2 logs logoai-backend

# Restart
pm2 restart logoai-backend

# Stop
pm2 stop logoai-backend

# Monitor
pm2 monit
```

---

## 4. Apache Deployment (Alternative)

If you prefer Apache over Nginx Proxy Manager:

```bash
# Install Apache
sudo apt install apache2

# Enable required modules
sudo a2enmod proxy
sudo a2enmod proxy_http
sudo a2enmod ssl
sudo a2enmod rewrite
sudo a2enmod headers

# Create virtual host
sudo tee /etc/apache2/sites-available/logoai.conf << 'EOF'
<VirtualHost *:80>
    ServerName logoai.tymtechnology.shop
    ServerAdmin soporte@tymtechnology.shop
    
    RewriteEngine On
    RewriteCond %{HTTPS} off
    RewriteRule ^(.*)$ https://%{HTTP_HOST}$1 [R=301,L]
</VirtualHost>

<VirtualHost *:443>
    ServerName logoai.tymtechnology.shop
    ServerAdmin soporte@tymtechnology.shop
    
    SSLEngine on
    SSLCertificateFile /etc/letsencrypt/live/logoai.tymtechnology.shop/fullchain.pem
    SSLCertificateKeyFile /etc/letsencrypt/live/logoai.tymtechnology.shop/privkey.pem
    
    ProxyPreserveHost On
    ProxyPass / http://10.0.1.40:32299/
    ProxyPassReverse / http://10.0.1.40:32299/
    
    RequestHeader set X-Forwarded-Proto "https"
    RequestHeader set X-Forwarded-Port "443"
    
    <Proxy *>
        Order deny,allow
        Allow from all
    </Proxy>
    
    ErrorLog ${APACHE_LOG_DIR}/logoai-error.log
    CustomLog ${APACHE_LOG_DIR}/logoai-access.log combined
</VirtualHost>
EOF

# Enable site
sudo a2ensite logoai.conf
sudo a2dissite 000-default.conf

# Restart Apache
sudo systemctl restart apache2
```

---

## 5. SSL Certificate Setup (Let's Encrypt)

### Option A: With Nginx Proxy Manager
SSL is handled automatically by NPM.

### Option B: Manual with Certbot

```bash
# Install Certbot
sudo apt install certbot python3-certbot-apache

# Obtain certificate (standalone)
sudo certbot certonly --standalone -d logoai.tymtechnology.shop

# Or with Apache
sudo certbot --apache -d logoai.tymtechnology.shop

# Auto-renewal test
sudo certbot renew --dry-run
```

---

## Troubleshooting

### 502 Bad Gateway

**Cause:** NPM can't connect to backend  
**Solution:**
```bash
# Verify backend is listening
sudo netstat -tlnp | grep 32299
# Should show: 0.0.0.0:32299

# Check if HOST=0.0.0.0 in .env
cat /var/www/logoai/backend/.env | grep HOST

# Restart backend
pm2 restart logoai-backend
```

### Connection Refused

**Cause:** Port closed or firewall blocking  
**Solution:**
```bash
# Check firewall
sudo ufw status
sudo ufw allow 32299/tcp

# Check backend logs
pm2 logs logoai-backend
```

### CORS Errors

**Cause:** CORS_ORIGIN incorrect  
**Solution:**
```bash
# Update .env
# Must match your HTTPS domain exactly
echo "CORS_ORIGIN=https://logoai.tymtechnology.shop" >> backend/.env
pm2 restart logoai-backend
```

---

## Security Checklist

- ✅ API keys stored in `.env` (not committed)
- ✅ Rate limiting enabled (100 requests per 15 min)
- ✅ Input sanitization with xss library
- ✅ Helmet.js security headers
- ✅ Non-root Docker user
- ✅ HTTPS only (Force SSL)
- ✅ CORS configured for specific origin only
- ✅ File upload size limits (10MB)
- ✅ File type validation

---

## Support

**T&M Technology Ec**  
Email: soporte@tymtechnology.shop  
Website: https://tymtechnology.shop
