#!/bin/bash
# LogoAI Deployment Script
# Author: T&M Technology Ec
# Support: soporte@tymtechnology.shop

set -e

echo "=================================="
echo "LogoAI - Deployment Script"
echo "Author: T&M Technology Ec"
echo "=================================="
echo ""

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Check if running as root
if [ "$EUID" -ne 0 ]; then 
    echo -e "${RED}Error: Please run as root or with sudo${NC}"
    exit 1
fi

# Configuration
APP_DIR="/opt/logoai"
DOMAIN="logoai.tymtechnology.shop"
PORT="32299"

echo -e "${YELLOW}Step 1: Creating directories...${NC}"
mkdir -p "$APP_DIR"/{uploads,data,logs}
mkdir -p "$APP_DIR"/{public/js,src/{Core,Controllers,config},templates}

echo -e "${YELLOW}Step 2: Setting permissions...${NC}"
# Will be set after files are copied

echo -e "${YELLOW}Step 3: Checking Docker installation...${NC}"
if ! command -v docker &> /dev/null; then
    echo -e "${RED}Docker not found. Installing...${NC}"
    curl -fsSL https://get.docker.com -o get-docker.sh
    sh get-docker.sh
    rm get-docker.sh
    systemctl enable docker
    systemctl start docker
else
    echo -e "${GREEN}Docker is already installed${NC}"
fi

if ! command -v docker-compose &> /dev/null; then
    echo -e "${RED}Docker Compose not found. Installing...${NC}"
    apt-get update
    apt-get install -y docker-compose-plugin
fi

echo -e "${YELLOW}Step 4: Generating JWT secret...${NC}"
JWT_SECRET=$(openssl rand -hex 32)

echo -e "${YELLOW}Step 5: Creating .env file...${NC}"
cat > "$APP_DIR/.env" << EOF
DB_PATH=/var/www/html/data/logoai.db
JWT_SECRET=$JWT_SECRET
RATE_LIMIT_REQUESTS=100
RATE_LIMIT_WINDOW=60
SESSION_LIFETIME=3600
APP_ENV=production
APP_AUTHOR=T&M Technology Ec
APP_SUPPORT_EMAIL=soporte@tymtechnology.shop
UPLOAD_MAX_SIZE=50M
MAX_IMAGE_DIMENSION=8000
EOF

echo -e "${YELLOW}Step 6: Setting correct permissions...${NC}"
# Find Apache user (usually www-data on Debian/Ubuntu)
APACHE_USER="www-data"
if id "apache" &>/dev/null; then
    APACHE_USER="apache"
fi

chown -R $APACHE_USER:$APACHE_USER "$APP_DIR/uploads"
chown -R $APACHE_USER:$APACHE_USER "$APP_DIR/data"
chown -R $APACHE_USER:$APACHE_USER "$APP_DIR/logs"
chmod 755 "$APP_DIR/uploads"
chmod 755 "$APP_DIR/data"
chmod 755 "$APP_DIR/logs"

echo -e "${YELLOW}Step 7: Building Docker image...${NC}"
cd "$APP_DIR"
docker compose down 2>/dev/null || true
docker compose build --no-cache
docker compose up -d

echo -e "${YELLOW}Step 8: Waiting for service to start...${NC}"
sleep 5

# Check if container is running
if docker ps | grep -q "logoai_app"; then
    echo -e "${GREEN}✓ Container is running${NC}"
else
    echo -e "${RED}✗ Container failed to start. Check logs:${NC}"
    docker logs logoai_app
    exit 1
fi

echo -e "${YELLOW}Step 9: Testing local endpoint...${NC}"
if curl -s -o /dev/null -w "%{http_code}" http://localhost:$PORT | grep -q "200\|302"; then
    echo -e "${GREEN}✓ Service is responding${NC}"
else
    echo -e "${YELLOW}⚠ Service may still be starting...${NC}"
fi

echo ""
echo "=================================="
echo -e "${GREEN}Deployment Complete!${NC}"
echo "=================================="
echo ""
echo "Application Details:"
echo "  - Domain: https://$DOMAIN"
echo "  - Local: http://localhost:$PORT"
echo "  - Directory: $APP_DIR"
echo ""
echo "Next Steps:"
echo "  1. Configure Nginx Proxy Manager to point to port $PORT"
echo "  2. Set up SSL certificate for $DOMAIN"
echo "  3. Configure firewall rules"
echo ""
echo "Useful Commands:"
echo "  - View logs: docker logs -f logoai_app"
echo "  - Restart: docker compose restart"
echo "  - Stop: docker compose down"
echo ""
echo "Support: soporte@tymtechnology.shop"
echo "=================================="
