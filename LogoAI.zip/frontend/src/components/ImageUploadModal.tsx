import { useState, useCallback } from 'react';
import { X, Upload, Image as ImageIcon, Crop, Filter, RotateCw } from 'lucide-react';
import { useDropzone } from 'react-dropzone';
import axios from 'axios';
import toast from 'react-hot-toast';
import * as fabric from 'fabric';
import { useLogoStore } from '../store/logoStore';
import { v4 as uuidv4 } from 'uuid';

export function ImageUploadModal() {
  const [isOpen, setIsOpen] = useState(false);
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [activeTab, setActiveTab] = useState<'crop' | 'filter' | 'adjust'>('crop');

  const { canvas, addElement } = useLogoStore();

  const onDrop = useCallback((acceptedFiles: File[]) => {
    const file = acceptedFiles[0];
    if (file) {
      setUploadedFile(file);
      setPreviewUrl(URL.createObjectURL(file));
      setIsOpen(true);
    }
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'image/*': ['.png', '.jpg', '.jpeg', '.gif', '.webp', '.svg'],
    },
    maxFiles: 1,
  });

  const handleUploadToServer = async () => {
    if (!uploadedFile) return;

    setIsUploading(true);
    const formData = new FormData();
    formData.append('image', uploadedFile);

    try {
      const response = await axios.post('/api/upload', formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
      });

      const { filename, url } = response.data.data;
      
      // Add to canvas
      if (canvas) {
        fabric.FabricImage.fromURL(url, (img) => {
          img.scaleToWidth(300);
          img.set({ left: 100, top: 100 });
          
          const id = uuidv4();
          addElement({
            id,
            type: 'image',
            fabricObject: img,
            name: uploadedFile.name,
            visible: true,
            locked: false,
          });

          canvas.add(img);
          canvas.setActiveObject(img);
          canvas.renderAll();
        });
      }

      toast.success('Imagen cargada exitosamente');
      setIsOpen(false);
      setUploadedFile(null);
      setPreviewUrl(null);
    } catch (error) {
      toast.error('Error al subir la imagen');
    } finally {
      setIsUploading(false);
    }
  };

  if (!isOpen) {
    return (
      <div
        {...getRootProps()}
        className="hidden"
      >
        <input {...getInputProps()} />
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-canva-panel rounded-xl shadow-2xl w-full max-w-3xl mx-4">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-gray-700">
          <h2 className="text-lg font-semibold">Subir y Editar Imagen</h2>
          <button
            onClick={() => setIsOpen(false)}
            className="p-2 hover:bg-gray-700 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex">
          {/* Preview Area */}
          <div className="flex-1 p-4">
            {previewUrl ? (
              <div className="relative bg-gray-800 rounded-lg overflow-hidden">
                <img
                  src={previewUrl}
                  alt="Preview"
                  className="max-h-80 w-full object-contain"
                />
              </div>
            ) : (
              <div
                {...getRootProps()}
                className={`border-2 border-dashed rounded-lg p-12 text-center cursor-pointer transition-colors ${
                  isDragActive ? 'border-primary-500 bg-primary-500/10' : 'border-gray-600'
                }`}
              >
                <input {...getInputProps()} />
                <Upload className="w-12 h-12 mx-auto mb-4 text-gray-400" />
                <p className="text-gray-300">
                  {isDragActive ? 'Suelta la imagen aquí' : 'Arrastra una imagen o haz click para seleccionar'}
                </p>
              </div>
            )}
          </div>

          {/* Edit Controls */}
          <div className="w-64 border-l border-gray-700 p-4">
            {/* Tabs */}
            <div className="flex gap-1 mb-4">
              <button
                onClick={() => setActiveTab('crop')}
                className={`flex-1 p-2 rounded-lg text-sm transition-colors ${
                  activeTab === 'crop' ? 'bg-primary-600' : 'hover:bg-gray-700'
                }`}
              >
                <Crop className="w-4 h-4 mx-auto" />
              </button>
              <button
                onClick={() => setActiveTab('filter')}
                className={`flex-1 p-2 rounded-lg text-sm transition-colors ${
                  activeTab === 'filter' ? 'bg-primary-600' : 'hover:bg-gray-700'
                }`}
              >
                <Filter className="w-4 h-4 mx-auto" />
              </button>
              <button
                onClick={() => setActiveTab('adjust')}
                className={`flex-1 p-2 rounded-lg text-sm transition-colors ${
                  activeTab === 'adjust' ? 'bg-primary-600' : 'hover:bg-gray-700'
                }`}
              >
                <RotateCw className="w-4 h-4 mx-auto" />
              </button>
            </div>

            {/* Tab Content */}
            {activeTab === 'crop' && (
              <div className="space-y-3">
                <p className="text-sm text-gray-400">Haz click y arrastra en la imagen para recortar</p>
                <div className="grid grid-cols-2 gap-2">
                  <button className="p-2 bg-gray-700 rounded text-xs hover:bg-gray-600">1:1</button>
                  <button className="p-2 bg-gray-700 rounded text-xs hover:bg-gray-600">16:9</button>
                  <button className="p-2 bg-gray-700 rounded text-xs hover:bg-gray-600">4:3</button>
                  <button className="p-2 bg-gray-700 rounded text-xs hover:bg-gray-600">Libre</button>
                </div>
              </div>
            )}

            {activeTab === 'filter' && (
              <div className="space-y-2">
                {['Normal', 'Grayscale', 'Sepia', 'Blur', 'Sharpen'].map((filter) => (
                  <button
                    key={filter}
                    className="w-full p-2 text-left text-sm hover:bg-gray-700 rounded transition-colors"
                  >
                    {filter}
                  </button>
                ))}
              </div>
            )}

            {activeTab === 'adjust' && (
              <div className="space-y-3">
                <div>
                  <label className="text-xs text-gray-400">Rotación</label>
                  <input type="range" className="w-full mt-1" min="-180" max="180" />
                </div>
                <div>
                  <label className="text-xs text-gray-400">Brillo</label>
                  <input type="range" className="w-full mt-1" min="0" max="200" />
                </div>
                <div>
                  <label className="text-xs text-gray-400">Contraste</label>
                  <input type="range" className="w-full mt-1" min="0" max="200" />
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-end gap-2 p-4 border-t border-gray-700">
          <button
            onClick={() => {
              setIsOpen(false);
              setUploadedFile(null);
              setPreviewUrl(null);
            }}
            className="px-4 py-2 hover:bg-gray-700 rounded-lg transition-colors"
          >
            Cancelar
          </button>
          <button
            onClick={handleUploadToServer}
            disabled={!uploadedFile || isUploading}
            className="px-4 py-2 bg-primary-600 hover:bg-primary-500 rounded-lg font-medium transition-colors disabled:opacity-50 flex items-center gap-2"
          >
            {isUploading ? (
              <>
                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                Subiendo...
              </>
            ) : (
              <>
                <ImageIcon className="w-4 h-4" />
                Añadir al Canvas
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
}
