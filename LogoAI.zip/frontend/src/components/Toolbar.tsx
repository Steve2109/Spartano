import { useState } from 'react';
import {
  Type,
  Square,
  Circle,
  Triangle,
  Image as ImageIcon,
  Shapes,
  PenTool,
  LayoutTemplate,
  Palette,
  Upload,
  MousePointer,
  Minus,
  Hexagon,
  Star,
} from 'lucide-react';
import { useLogoStore } from '../store/logoStore';
import * as fabric from 'fabric';
import { v4 as uuidv4 } from 'uuid';
import toast from 'react-hot-toast';

const SHAPES = [
  { icon: Square, type: 'rect', name: 'Rectángulo' },
  { icon: Circle, type: 'circle', name: 'Círculo' },
  { icon: Triangle, type: 'triangle', name: 'Triángulo' },
  { icon: Hexagon, type: 'polygon', name: 'Hexágono' },
  { icon: Star, type: 'star', name: 'Estrella' },
  { icon: Minus, type: 'line', name: 'Línea' },
];

export function Toolbar() {
  const [activeTab, setActiveTab] = useState<'tools' | 'shapes' | 'templates'>('tools');
  const [showImageUpload, setShowImageUpload] = useState(false);
  
  const { canvas, addElement, saveState } = useLogoStore();

  const addText = () => {
    if (!canvas) return;
    
    const text = new fabric.Textbox('Doble click para editar', {
      left: 100,
      top: 100,
      fontFamily: 'Inter',
      fontSize: 24,
      fill: '#000000',
      fontWeight: 'normal',
      textAlign: 'center',
      width: 200,
      editable: true,
    });

    const id = uuidv4();
    addElement({
      id,
      type: 'text',
      fabricObject: text,
      name: 'Texto',
      visible: true,
      locked: false,
    });

    canvas.add(text);
    canvas.setActiveObject(text);
    canvas.renderAll();
    saveState();
    toast.success('Texto añadido');
  };

  const addShape = (shapeType: string) => {
    if (!canvas) return;

    let shape: fabric.FabricObject;
    const commonProps = {
      left: 150,
      top: 150,
      fill: '#7c3aed',
      stroke: '#000000',
      strokeWidth: 0,
    };

    switch (shapeType) {
      case 'rect':
        shape = new fabric.Rect({ ...commonProps, width: 100, height: 100 });
        break;
      case 'circle':
        shape = new fabric.Circle({ ...commonProps, radius: 50 });
        break;
      case 'triangle':
        shape = new fabric.Triangle({ ...commonProps, width: 100, height: 100 });
        break;
      case 'polygon':
        // Hexagon
        const hexPoints = [];
        for (let i = 0; i < 6; i++) {
          hexPoints.push({
            x: 50 * Math.cos((i * Math.PI) / 3),
            y: 50 * Math.sin((i * Math.PI) / 3),
          });
        }
        shape = new fabric.Polygon(hexPoints, { ...commonProps });
        break;
      case 'star':
        const starPoints = [];
        for (let i = 0; i < 10; i++) {
          const radius = i % 2 === 0 ? 50 : 25;
          starPoints.push({
            x: radius * Math.cos((i * Math.PI) / 5 - Math.PI / 2),
            y: radius * Math.sin((i * Math.PI) / 5 - Math.PI / 2),
          });
        }
        shape = new fabric.Polygon(starPoints, { ...commonProps });
        break;
      case 'line':
        shape = new fabric.Line([0, 0, 100, 0], {
          ...commonProps,
          strokeWidth: 3,
        });
        break;
      default:
        shape = new fabric.Rect({ ...commonProps, width: 100, height: 100 });
    }

    const id = uuidv4();
    addElement({
      id,
      type: shapeType as any,
      fabricObject: shape,
      name: shapeType.charAt(0).toUpperCase() + shapeType.slice(1),
      visible: true,
      locked: false,
    });

    canvas.add(shape);
    canvas.setActiveObject(shape);
    canvas.renderAll();
    saveState();
    toast.success(`${shapeType} añadido`);
  };

  const handleImageUpload = () => {
    setShowImageUpload(true);
  };

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !canvas) return;

    try {
      const reader = new FileReader();
      reader.onload = (event) => {
        const imgUrl = event.target?.result as string;
        fabric.FabricImage.fromURL(imgUrl, (img) => {
          img.scaleToWidth(200);
          img.set({ left: 100, top: 100 });
          
          const id = uuidv4();
          addElement({
            id,
            type: 'image',
            fabricObject: img,
            name: file.name,
            visible: true,
            locked: false,
          });

          canvas.add(img);
          canvas.setActiveObject(img);
          canvas.renderAll();
          saveState();
          toast.success('Imagen añadida');
        });
      };
      reader.readAsDataURL(file);
    } catch (error) {
      toast.error('Error al cargar la imagen');
    }
    setShowImageUpload(false);
  };

  const tabs = [
    { id: 'tools', icon: MousePointer, label: 'Herramientas' },
    { id: 'shapes', icon: Shapes, label: 'Formas' },
    { id: 'templates', icon: LayoutTemplate, label: 'Plantillas' },
  ];

  return (
    <div className="w-16 bg-canva-panel border-r border-gray-700 flex flex-col shrink-0">
      {/* Tab buttons */}
      <div className="flex flex-col gap-1 p-2">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`p-3 rounded-xl transition-all ${
              activeTab === tab.id
                ? 'bg-primary-600 text-white'
                : 'hover:bg-gray-700 text-gray-400 hover:text-white'
            }`}
            title={tab.label}
          >
            <tab.icon className="w-5 h-5" />
          </button>
        ))}
      </div>

      <div className="h-px bg-gray-700 mx-2 my-2" />

      {/* Tools Content */}
      {activeTab === 'tools' && (
        <div className="flex flex-col gap-1 p-2">
          <button
            onClick={addText}
            className="p-3 hover:bg-gray-700 rounded-xl transition-colors text-gray-300 hover:text-white"
            title="Añadir texto"
          >
            <Type className="w-5 h-5" />
          </button>
          <button
            onClick={handleImageUpload}
            className="p-3 hover:bg-gray-700 rounded-xl transition-colors text-gray-300 hover:text-white"
            title="Subir imagen"
          >
            <Upload className="w-5 h-5" />
          </button>
          <label className="p-3 hover:bg-gray-700 rounded-xl transition-colors text-gray-300 hover:text-white cursor-pointer">
            <ImageIcon className="w-5 h-5" />
            <input
              type="file"
              accept="image/*"
              onChange={handleFileSelect}
              className="hidden"
            />
          </label>
        </div>
      )}

      {/* Shapes Content */}
      {activeTab === 'shapes' && (
        <div className="flex flex-col gap-1 p-2">
          {SHAPES.map((shape) => (
            <button
              key={shape.type}
              onClick={() => addShape(shape.type)}
              className="p-3 hover:bg-gray-700 rounded-xl transition-colors text-gray-300 hover:text-white"
              title={shape.name}
            >
              <shape.icon className="w-5 h-5" />
            </button>
          ))}
        </div>
      )}

      {/* Templates Content */}
      {activeTab === 'templates' && (
        <div className="flex flex-col gap-1 p-2">
          <div className="text-xs text-gray-500 text-center py-4">
            Plantillas<br/>próximamente
          </div>
        </div>
      )}
    </div>
  );
}
