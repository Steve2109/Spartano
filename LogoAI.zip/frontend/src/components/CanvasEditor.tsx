import { useEffect, useRef, useCallback } from 'react';
import * as fabric from 'fabric';
import { useLogoStore } from '../store/logoStore';

declare module 'fabric' {
  interface Canvas {
    wrapperEl?: HTMLDivElement;
  }
}

export function CanvasEditor() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const { 
    setCanvas, 
    canvas, 
    setCanvasSize, 
    backgroundColor,
    selectElement,
    addElement,
    saveState,
    clearSelection,
    elements,
  } = useLogoStore();

  // Initialize Fabric canvas
  useEffect(() => {
    if (!canvasRef.current || !containerRef.current) return;

    const fabricCanvas = new fabric.Canvas(canvasRef.current, {
      width: 800,
      height: 600,
      backgroundColor: '#ffffff',
      preserveObjectStacking: true,
      selection: true,
      uniScaleTransform: false,
    });

    // Enable controls
    fabricCanvas.set({
      controlsAboveOverlay: true,
    });

    // Center canvas in container
    const container = containerRef.current;
    const updateCanvasPosition = () => {
      const canvasEl = fabricCanvas.getElement();
      const wrapper = canvasEl.parentElement;
      if (wrapper) {
        wrapper.style.position = 'absolute';
        wrapper.style.left = '50%';
        wrapper.style.top = '50%';
        wrapper.style.transform = 'translate(-50%, -50%)';
      }
    };

    updateCanvasPosition();
    setCanvas(fabricCanvas);
    setCanvasSize(800, 600);

    // Selection events
    fabricCanvas.on('selection:created', (e: fabric.FabricEvent) => {
      if (e.selected && e.selected[0]) {
        const selectedObj = e.selected[0];
        const element = elements.find(el => el.fabricObject === selectedObj);
        if (element) {
          selectElement(element);
        }
      }
    });

    fabricCanvas.on('selection:updated', (e: fabric.FabricEvent) => {
      if (e.selected && e.selected[0]) {
        const selectedObj = e.selected[0];
        const element = elements.find(el => el.fabricObject === selectedObj);
        if (element) {
          selectElement(element);
        }
      }
    });

    fabricCanvas.on('selection:cleared', () => {
      clearSelection();
    });

    // Object modification events for history
    fabricCanvas.on('object:modified', () => {
      saveState();
    });

    fabricCanvas.on('object:added', () => {
      saveState();
    });

    fabricCanvas.on('object:removed', () => {
      saveState();
    });

    // Keyboard shortcuts
    const handleKeyDown = (e: KeyboardEvent) => {
      // Delete selected object
      if ((e.key === 'Delete' || e.key === 'Backspace') && !e.target || !(e.target as HTMLElement).closest('input, textarea, [contenteditable]')) {
        const activeObject = fabricCanvas.getActiveObject();
        if (activeObject) {
          fabricCanvas.remove(activeObject);
          fabricCanvas.renderAll();
        }
      }

      // Copy (Ctrl+C)
      if (e.ctrlKey && e.key === 'c') {
        const activeObject = fabricCanvas.getActiveObject();
        if (activeObject) {
          activeObject.clone((cloned: fabric.FabricObject) => {
            (fabricCanvas as any).clipboard = cloned;
          });
        }
      }

      // Paste (Ctrl+V)
      if (e.ctrlKey && e.key === 'v') {
        const clipboard = (fabricCanvas as any).clipboard;
        if (clipboard) {
          clipboard.clone((clonedObj: fabric.FabricObject) => {
            clonedObj.set({
              left: (clonedObj.left || 0) + 10,
              top: (clonedObj.top || 0) + 10,
            });
            fabricCanvas.add(clonedObj);
            fabricCanvas.setActiveObject(clonedObj);
            fabricCanvas.renderAll();
            saveState();
          });
        }
      }

      // Duplicate (Ctrl+D)
      if (e.ctrlKey && e.key === 'd') {
        const activeObject = fabricCanvas.getActiveObject();
        if (activeObject) {
          activeObject.clone((cloned: fabric.FabricObject) => {
            cloned.set({
              left: (cloned.left || 0) + 20,
              top: (cloned.top || 0) + 20,
            });
            fabricCanvas.add(cloned);
            fabricCanvas.setActiveObject(cloned);
            fabricCanvas.renderAll();
            
            const { v4: uuidv4 } = require('uuid');
            addElement({
              id: uuidv4(),
              type: 'rect',
              fabricObject: cloned,
              name: 'Duplicado',
              visible: true,
              locked: false,
            });
            saveState();
          });
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      fabricCanvas.dispose();
    };
  }, [setCanvas, setCanvasSize, selectElement, clearSelection, saveState, addElement, elements]);

  // Update background color
  useEffect(() => {
    if (canvas) {
      canvas.backgroundColor = backgroundColor;
      canvas.renderAll();
    }
  }, [canvas, backgroundColor]);

  return (
    <div 
      ref={containerRef}
      className="w-full h-full relative overflow-auto flex items-center justify-center"
    >
      <div className="canvas-wrapper shadow-2xl">
        <canvas
          ref={canvasRef}
          id="logo-canvas"
          className="border border-gray-700"
        />
      </div>
      
      {/* Canvas Size Indicator */}
      <div className="absolute bottom-4 left-4 bg-gray-800/90 px-3 py-1.5 rounded-lg text-xs text-gray-400">
        {useLogoStore((state) => state.canvasWidth)} x {useLogoStore((state) => state.canvasHeight)} px
      </div>
    </div>
  );
}
