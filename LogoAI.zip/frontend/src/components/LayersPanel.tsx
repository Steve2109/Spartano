import { useState } from 'react';
import {
  Layers,
  Eye,
  EyeOff,
  Lock,
  Unlock,
  ChevronUp,
  ChevronDown,
  Type,
  Square,
  Circle,
  Triangle,
  Image as ImageIcon,
  GripVertical,
} from 'lucide-react';
import { useLogoStore } from '../store/logoStore';

const typeIcons: Record<string, React.ElementType> = {
  text: Type,
  rect: Square,
  circle: Circle,
  triangle: Triangle,
  image: ImageIcon,
  line: GripVertical,
  path: GripVertical,
  polygon: GripVertical,
  star: GripVertical,
};

export function LayersPanel() {
  const [isExpanded, setIsExpanded] = useState(true);
  const {
    elements,
    selectedElement,
    selectElement,
    toggleVisibility,
    toggleLock,
    bringToFront,
    sendToBack,
    moveUp,
    moveDown,
  } = useLogoStore();

  // Reverse elements for display (top layer first)
  const reversedElements = [...elements].reverse();

  return (
    <div className={`bg-canva-panel border-t border-gray-700 transition-all duration-300 ${isExpanded ? 'h-48' : 'h-10'}`}>
      {/* Header */}
      <button
        onClick={() => setIsExpanded(!isExpanded)}
        className="w-full h-10 px-4 flex items-center justify-between hover:bg-gray-800/50 transition-colors"
      >
        <div className="flex items-center gap-2">
          <Layers className="w-4 h-4" />
          <span className="text-sm font-medium">Capas ({elements.length})</span>
        </div>
        {isExpanded ? <ChevronDown className="w-4 h-4" /> : <ChevronUp className="w-4 h-4" />}
      </button>

      {/* Layers List */}
      {isExpanded && (
        <div className="h-[calc(12rem-2.5rem)] overflow-y-auto p-2 space-y-1">
          {reversedElements.length === 0 ? (
            <div className="text-center text-gray-500 py-8 text-sm">
              No hay capas. Añade elementos al canvas.
            </div>
          ) : (
            reversedElements.map((element) => {
              const isSelected = selectedElement?.id === element.id;
              const Icon = typeIcons[element.type] || GripVertical;
              const isLocked = element.locked;
              const isVisible = element.visible !== false;

              return (
                <div
                  key={element.id}
                  onClick={() => selectElement(element)}
                  className={`flex items-center gap-2 p-2 rounded-lg cursor-pointer transition-colors ${
                    isSelected ? 'bg-primary-600' : 'hover:bg-gray-800'
                  }`}
                >
                  <Icon className="w-4 h-4 text-gray-400" />
                  <span className="flex-1 text-sm truncate">{element.name}</span>
                  
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      toggleVisibility(element.id);
                    }}
                    className={`p-1 rounded hover:bg-white/10 transition-colors ${!isVisible ? 'text-gray-500' : ''}`}
                  >
                    {isVisible ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
                  </button>
                  
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      toggleLock(element.id);
                    }}
                    className={`p-1 rounded hover:bg-white/10 transition-colors ${isLocked ? 'text-yellow-400' : ''}`}
                  >
                    {isLocked ? <Lock className="w-4 h-4" /> : <Unlock className="w-4 h-4" />}
                  </button>
                </div>
              );
            })
          )}
        </div>
      )}
    </div>
  );
}
