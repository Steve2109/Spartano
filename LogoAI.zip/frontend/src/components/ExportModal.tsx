import { useState } from 'react';
import { X, Download, FileImage, FileText } from 'lucide-react';
import { useLogoStore } from '../store/logoStore';
import toast from 'react-hot-toast';
import axios from 'axios';

const formats = [
  { id: 'png', label: 'PNG', desc: 'Con transparencia', icon: FileImage },
  { id: 'jpeg', label: 'JPEG', desc: 'Sin transparencia', icon: FileImage },
  { id: 'webp', label: 'WebP', desc: 'Formato moderno', icon: FileImage },
  { id: 'svg', label: 'SVG', desc: 'Vector escalable', icon: FileText },
  { id: 'pdf', label: 'PDF', desc: 'Documento', icon: FileText },
] as const;

export function ExportModal() {
  const [isOpen, setIsOpen] = useState(false);
  const [selectedFormat, setSelectedFormat] = useState<'png' | 'jpeg' | 'webp' | 'svg' | 'pdf'>('png');
  const [isExporting, setIsExporting] = useState(false);
  const [width, setWidth] = useState(800);
  const [quality, setQuality] = useState(90);
  
  const { canvas } = useLogoStore();

  const handleExport = async () => {
    if (!canvas) {
      toast.error('No hay canvas para exportar');
      return;
    }

    setIsExporting(true);

    try {
      // Generate SVG from canvas
      const svgContent = canvas.toSVG({
        suppressPreamble: false,
        viewBox: { x: 0, y: 0, width: canvas.width || 800, height: canvas.height || 600 },
      });

      // Call backend API for export
      const response = await axios.post('/api/export', {
        format: selectedFormat,
        width: selectedFormat === 'svg' ? undefined : width,
        quality,
        svgContent,
      }, {
        responseType: 'blob',
      });

      // Download file
      const blob = new Blob([response.data], { type: response.headers['content-type'] });
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `logo-export.${selectedFormat}`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);

      toast.success(`Logo exportado como ${selectedFormat.toUpperCase()}`);
      setIsOpen(false);
    } catch (error) {
      console.error('Export error:', error);
      toast.error('Error al exportar. Intenta de nuevo.');
    } finally {
      setIsExporting(false);
    }
  };

  // Listen for export event from TopBar
  if (typeof window !== 'undefined') {
    window.addEventListener('openExportModal', () => setIsOpen(true));
  }

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-canva-panel rounded-xl shadow-2xl w-full max-w-lg mx-4">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-gray-700">
          <h2 className="text-lg font-semibold">Exportar Logo</h2>
          <button
            onClick={() => setIsOpen(false)}
            className="p-2 hover:bg-gray-700 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 space-y-4">
          {/* Format Selection */}
          <div>
            <label className="text-sm font-medium mb-3 block">Formato</label>
            <div className="grid grid-cols-2 gap-2">
              {formats.map((format) => (
                <button
                  key={format.id}
                  onClick={() => setSelectedFormat(format.id)}
                  className={`p-3 rounded-lg border transition-all flex items-center gap-3 ${
                    selectedFormat === format.id
                      ? 'border-primary-500 bg-primary-500/10'
                      : 'border-gray-700 hover:border-gray-600'
                  }`}
                >
                  <format.icon className="w-5 h-5" />
                  <div className="text-left">
                    <div className="font-medium">{format.label}</div>
                    <div className="text-xs text-gray-400">{format.desc}</div>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Options for raster formats */}
          {selectedFormat !== 'svg' && (
            <>
              <div>
                <label className="text-sm font-medium mb-2 block">Ancho (px)</label>
                <input
                  type="number"
                  value={width}
                  onChange={(e) => setWidth(parseInt(e.target.value))}
                  min="100"
                  max="5000"
                  className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2"
                />
              </div>

              <div>
                <label className="text-sm font-medium mb-2 block">Calidad: {quality}%</label>
                <input
                  type="range"
                  value={quality}
                  onChange={(e) => setQuality(parseInt(e.target.value))}
                  min="1"
                  max="100"
                  className="w-full"
                />
              </div>
            </>
          )}

          {/* Preview info */}
          <div className="bg-gray-800 rounded-lg p-3 text-sm text-gray-400">
            <p>El logo se exportará con el tamaño y formato seleccionados.</p>
            <p className="mt-1">Para SVG: Se exportará como vector escalable.</p>
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-end gap-2 p-4 border-t border-gray-700">
          <button
            onClick={() => setIsOpen(false)}
            className="px-4 py-2 hover:bg-gray-700 rounded-lg transition-colors"
          >
            Cancelar
          </button>
          <button
            onClick={handleExport}
            disabled={isExporting}
            className="px-4 py-2 bg-primary-600 hover:bg-primary-500 rounded-lg font-medium transition-colors disabled:opacity-50 flex items-center gap-2"
          >
            {isExporting ? (
              <>
                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                Exportando...
              </>
            ) : (
              <>
                <Download className="w-4 h-4" />
                Exportar
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
}
