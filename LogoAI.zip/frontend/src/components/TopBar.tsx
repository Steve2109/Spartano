import { useState } from 'react';
import { 
  Download, 
  Undo2, 
  Redo2, 
  Trash2, 
  FilePlus,
  ZoomIn,
  ZoomOut,
  Maximize,
  Save
} from 'lucide-react';
import { useLogoStore } from '../store/logoStore';
import toast from 'react-hot-toast';

export function TopBar() {
  const [showExportModal, setShowExportModal] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  
  const { 
    undo, 
    redo, 
    canUndo, 
    canRedo, 
    clearCanvas, 
    zoom, 
    zoomIn, 
    zoomOut, 
    resetZoom,
    canvas,
    setExportFormat,
  } = useLogoStore();

  const handleUndo = () => {
    undo();
    toast.success('Deshacer');
  };

  const handleRedo = () => {
    redo();
    toast.success('Rehacer');
  };

  const handleClear = () => {
    if (confirm('¿Estás seguro de que quieres limpiar el canvas?')) {
      clearCanvas();
      toast.success('Canvas limpiado');
    }
  };

  const handleSave = () => {
    if (!canvas) return;
    
    setIsSaving(true);
    
    try {
      const json = canvas.toJSON();
      const dataStr = JSON.stringify(json, null, 2);
      const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
      
      const exportFileDefaultName = 'logo-design.json';
      
      const linkElement = document.createElement('a');
      linkElement.setAttribute('href', dataUri);
      linkElement.setAttribute('download', exportFileDefaultName);
      linkElement.click();
      
      toast.success('Diseño guardado');
    } catch (error) {
      toast.error('Error al guardar');
    } finally {
      setIsSaving(false);
    }
  };

  const handleExportClick = () => {
    setShowExportModal(true);
  };

  return (
    <>
      <div className="h-14 bg-canva-panel border-b border-gray-700 flex items-center justify-between px-4 shrink-0">
        {/* Left: Logo and File Operations */}
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-gradient-to-br from-primary-500 to-purple-600 rounded-lg flex items-center justify-center">
              <span className="font-bold text-white text-sm">L</span>
            </div>
            <span className="font-semibold text-white">Logo AI Creator</span>
          </div>
          
          <div className="h-6 w-px bg-gray-600 mx-2" />
          
          <div className="flex items-center gap-1">
            <button
              onClick={handleClear}
              className="p-2 hover:bg-gray-700 rounded-lg transition-colors"
              title="Nuevo diseño"
            >
              <FilePlus className="w-5 h-5" />
            </button>
            <button
              onClick={handleSave}
              disabled={isSaving}
              className="p-2 hover:bg-gray-700 rounded-lg transition-colors disabled:opacity-50"
              title="Guardar diseño"
            >
              <Save className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Center: Undo/Redo */}
        <div className="flex items-center gap-1">
          <button
            onClick={handleUndo}
            disabled={!canUndo()}
            className="p-2 hover:bg-gray-700 rounded-lg transition-colors disabled:opacity-30 disabled:cursor-not-allowed"
            title="Deshacer (Ctrl+Z)"
          >
            <Undo2 className="w-5 h-5" />
          </button>
          <button
            onClick={handleRedo}
            disabled={!canRedo()}
            className="p-2 hover:bg-gray-700 rounded-lg transition-colors disabled:opacity-30 disabled:cursor-not-allowed"
            title="Rehacer (Ctrl+Y)"
          >
            <Redo2 className="w-5 h-5" />
          </button>
          <div className="h-6 w-px bg-gray-600 mx-2" />
          <button
            onClick={handleClear}
            className="p-2 hover:bg-gray-700 rounded-lg transition-colors text-red-400 hover:text-red-300"
            title="Limpiar canvas"
          >
            <Trash2 className="w-5 h-5" />
          </button>
        </div>

        {/* Right: Zoom and Export */}
        <div className="flex items-center gap-3">
          {/* Zoom Controls */}
          <div className="flex items-center gap-1 bg-gray-800 rounded-lg px-2 py-1">
            <button
              onClick={zoomOut}
              className="p-1 hover:bg-gray-700 rounded transition-colors"
              title="Alejar"
            >
              <ZoomOut className="w-4 h-4" />
            </button>
            <button
              onClick={resetZoom}
              className="px-2 text-sm font-medium hover:text-primary-400 transition-colors"
              title="Restablecer zoom"
            >
              {Math.round(zoom * 100)}%
            </button>
            <button
              onClick={zoomIn}
              className="p-1 hover:bg-gray-700 rounded transition-colors"
              title="Acercar"
            >
              <ZoomIn className="w-4 h-4" />
            </button>
          </div>

          {/* Export Button */}
          <button
            onClick={handleExportClick}
            className="flex items-center gap-2 px-4 py-2 bg-primary-600 hover:bg-primary-500 rounded-lg font-medium transition-colors"
          >
            <Download className="w-4 h-4" />
            Exportar
          </button>
        </div>
      </div>
    </>
  );
}
