import { useState, useEffect } from 'react';
import {
  Palette,
  Type,
  Layers,
  AlignLeft,
  AlignCenter,
  AlignRight,
  Bold,
  Italic,
  Underline,
  Trash2,
  Copy,
  Scissors,
  ChevronDown,
  ChevronUp,
  Lock,
  Unlock,
  Eye,
  EyeOff,
  ArrowUp,
  ArrowDown,
} from 'lucide-react';
import { useLogoStore } from '../store/logoStore';
import { HexColorPicker } from 'react-colorful';
import toast from 'react-hot-toast';

export function PropertiesPanel() {
  const [activeSection, setActiveSection] = useState<'fill' | 'text' | 'position' | 'effects'>('fill');
  const [showColorPicker, setShowColorPicker] = useState(false);
  const [colorType, setColorType] = useState<'fill' | 'stroke'>('fill');
  
  const {
    selectedElement,
    canvas,
    removeElement,
    copy,
    paste,
    cut,
    duplicate,
    bringToFront,
    sendToBack,
    moveUp,
    moveDown,
    toggleLock,
    toggleVisibility,
  } = useLogoStore();

  const [properties, setProperties] = useState({
    fill: '#000000',
    stroke: '#000000',
    strokeWidth: 0,
    opacity: 1,
    angle: 0,
    scaleX: 1,
    scaleY: 1,
    left: 0,
    top: 0,
    width: 100,
    height: 100,
    // Text properties
    fontSize: 24,
    fontFamily: 'Inter',
    fontWeight: 'normal',
    fontStyle: 'normal',
    textAlign: 'center',
    underline: false,
    linethrough: false,
  });

  // Update properties when selection changes
  useEffect(() => {
    if (selectedElement && selectedElement.fabricObject) {
      const obj = selectedElement.fabricObject;
      setProperties({
        fill: obj.fill?.toString() || '#000000',
        stroke: obj.stroke?.toString() || '#000000',
        strokeWidth: obj.strokeWidth || 0,
        opacity: obj.opacity || 1,
        angle: obj.angle || 0,
        scaleX: obj.scaleX || 1,
        scaleY: obj.scaleY || 1,
        left: obj.left || 0,
        top: obj.top || 0,
        width: (obj as any).width || 100,
        height: (obj as any).height || 100,
        fontSize: (obj as any).fontSize || 24,
        fontFamily: (obj as any).fontFamily || 'Inter',
        fontWeight: (obj as any).fontWeight || 'normal',
        fontStyle: (obj as any).fontStyle || 'normal',
        textAlign: (obj as any).textAlign || 'center',
        underline: (obj as any).underline || false,
        linethrough: (obj as any).linethrough || false,
      });
    }
  }, [selectedElement]);

  const updateProperty = (key: string, value: any) => {
    if (!selectedElement || !canvas) return;
    
    const obj = selectedElement.fabricObject;
    (obj as any)[key] = value;
    canvas.renderAll();
    
    setProperties(prev => ({ ...prev, [key]: value }));
  };

  const handleDelete = () => {
    if (!selectedElement) return;
    removeElement(selectedElement.id);
    toast.success('Elemento eliminado');
  };

  const handleDuplicate = () => {
    duplicate();
    toast.success('Elemento duplicado');
  };

  const isText = selectedElement?.type === 'text';
  const isLocked = selectedElement?.locked;
  const isVisible = selectedElement?.visible !== false;

  const sections = [
    { id: 'fill', icon: Palette, label: 'Relleno y Trazo' },
    { id: 'text', icon: Type, label: 'Texto', show: isText },
    { id: 'position', icon: Layers, label: 'Posición y Tamaño' },
    { id: 'effects', icon: Eye, label: 'Efectos', show: false },
  ];

  return (
    <div className="w-72 bg-canva-panel border-l border-gray-700 flex flex-col shrink-0 overflow-y-auto">
      {/* Header */}
      <div className="p-4 border-b border-gray-700">
        <h2 className="font-semibold text-white">Propiedades</h2>
        {selectedElement && (
          <p className="text-xs text-gray-400 mt-1">{selectedElement.name}</p>
        )}
      </div>

      {/* No selection message */}
      {!selectedElement ? (
        <div className="flex-1 flex items-center justify-center text-gray-500 p-8 text-center">
          <div>
            <Layers className="w-12 h-12 mx-auto mb-3 opacity-50" />
            <p className="text-sm">Selecciona un elemento para editar sus propiedades</p>
          </div>
        </div>
      ) : (
        <>
          {/* Quick Actions */}
          <div className="p-3 border-b border-gray-700">
            <div className="flex gap-1 flex-wrap">
              <button
                onClick={handleDuplicate}
                className="p-2 hover:bg-gray-700 rounded-lg transition-colors"
                title="Duplicar (Ctrl+D)"
              >
                <Copy className="w-4 h-4" />
              </button>
              <button
                onClick={cut}
                className="p-2 hover:bg-gray-700 rounded-lg transition-colors"
                title="Cortar (Ctrl+X)"
              >
                <Scissors className="w-4 h-4" />
              </button>
              <button
                onClick={() => toggleLock(selectedElement.id)}
                className={`p-2 hover:bg-gray-700 rounded-lg transition-colors ${isLocked ? 'text-yellow-400' : ''}`}
                title={isLocked ? 'Desbloquear' : 'Bloquear'}
              >
                {isLocked ? <Lock className="w-4 h-4" /> : <Unlock className="w-4 h-4" />}
              </button>
              <button
                onClick={() => toggleVisibility(selectedElement.id)}
                className={`p-2 hover:bg-gray-700 rounded-lg transition-colors ${!isVisible ? 'text-gray-500' : ''}`}
                title={isVisible ? 'Ocultar' : 'Mostrar'}
              >
                {isVisible ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
              </button>
              <button
                onClick={handleDelete}
                className="p-2 hover:bg-gray-700 rounded-lg transition-colors text-red-400 hover:text-red-300"
                title="Eliminar (Delete)"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Layer Order */}
          <div className="p-3 border-b border-gray-700">
            <p className="text-xs text-gray-400 mb-2">Orden de capas</p>
            <div className="flex gap-1">
              <button
                onClick={() => bringToFront(selectedElement.id)}
                className="flex-1 px-3 py-1.5 bg-gray-700 hover:bg-gray-600 rounded text-xs transition-colors"
              >
                <ArrowUp className="w-3 h-3 inline mr-1" />
                Frente
              </button>
              <button
                onClick={() => sendToBack(selectedElement.id)}
                className="flex-1 px-3 py-1.5 bg-gray-700 hover:bg-gray-600 rounded text-xs transition-colors"
              >
                <ArrowDown className="w-3 h-3 inline mr-1" />
                Fondo
              </button>
            </div>
            <div className="flex gap-1 mt-1">
              <button
                onClick={() => moveUp(selectedElement.id)}
                className="flex-1 px-3 py-1.5 bg-gray-700 hover:bg-gray-600 rounded text-xs transition-colors"
              >
                Subir
              </button>
              <button
                onClick={() => moveDown(selectedElement.id)}
                className="flex-1 px-3 py-1.5 bg-gray-700 hover:bg-gray-600 rounded text-xs transition-colors"
              >
                Bajar
              </button>
            </div>
          </div>

          {/* Sections */}
          <div className="flex-1">
            {/* Fill & Stroke Section */}
            <div className="border-b border-gray-700">
              <button
                onClick={() => setActiveSection(activeSection === 'fill' ? null as any : 'fill')}
                className="w-full px-4 py-3 flex items-center justify-between hover:bg-gray-800/50 transition-colors"
              >
                <div className="flex items-center gap-2">
                  <Palette className="w-4 h-4" />
                  <span className="text-sm font-medium">Relleno y Trazo</span>
                </div>
                {activeSection === 'fill' ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
              </button>
              
              {activeSection === 'fill' && (
                <div className="px-4 pb-4 space-y-4">
                  {/* Fill Color */}
                  <div>
                    <label className="text-xs text-gray-400 mb-2 block">Color de relleno</label>
                    <div className="flex gap-2">
                      <button
                        onClick={() => { setColorType('fill'); setShowColorPicker(!showColorPicker); }}
                        className="w-10 h-10 rounded-lg border-2 border-gray-600 overflow-hidden"
                        style={{ backgroundColor: properties.fill }}
                      />
                      <input
                        type="text"
                        value={properties.fill}
                        onChange={(e) => updateProperty('fill', e.target.value)}
                        className="flex-1 bg-gray-800 border border-gray-600 rounded-lg px-3 text-sm"
                      />
                    </div>
                  </div>

                  {/* Stroke */}
                  <div>
                    <label className="text-xs text-gray-400 mb-2 block">Color de trazo</label>
                    <div className="flex gap-2 mb-2">
                      <button
                        onClick={() => { setColorType('stroke'); setShowColorPicker(!showColorPicker); }}
                        className="w-10 h-10 rounded-lg border-2 border-gray-600 overflow-hidden"
                        style={{ backgroundColor: properties.stroke }}
                      />
                      <input
                        type="text"
                        value={properties.stroke}
                        onChange={(e) => updateProperty('stroke', e.target.value)}
                        className="flex-1 bg-gray-800 border border-gray-600 rounded-lg px-3 text-sm"
                      />
                    </div>
                    
                    <label className="text-xs text-gray-400 mb-1 block">Grosor del trazo</label>
                    <input
                      type="range"
                      min="0"
                      max="20"
                      value={properties.strokeWidth}
                      onChange={(e) => updateProperty('strokeWidth', parseInt(e.target.value))}
                      className="w-full"
                    />
                  </div>

                  {/* Opacity */}
                  <div>
                    <label className="text-xs text-gray-400 mb-1 block">Opacidad</label>
                    <input
                      type="range"
                      min="0"
                      max="100"
                      value={properties.opacity * 100}
                      onChange={(e) => updateProperty('opacity', parseInt(e.target.value) / 100)}
                      className="w-full"
                    />
                  </div>

                  {/* Color Picker Popover */}
                  {showColorPicker && (
                    <div className="bg-gray-800 p-3 rounded-lg">
                      <HexColorPicker
                        color={colorType === 'fill' ? properties.fill : properties.stroke}
                        onChange={(color) => updateProperty(colorType, color)}
                      />
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Text Section (only for text elements) */}
            {isText && (
              <div className="border-b border-gray-700">
                <button
                  onClick={() => setActiveSection(activeSection === 'text' ? null as any : 'text')}
                  className="w-full px-4 py-3 flex items-center justify-between hover:bg-gray-800/50 transition-colors"
                >
                  <div className="flex items-center gap-2">
                    <Type className="w-4 h-4" />
                    <span className="text-sm font-medium">Texto</span>
                  </div>
                  {activeSection === 'text' ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                </button>
                
                {activeSection === 'text' && (
                  <div className="px-4 pb-4 space-y-4">
                    {/* Font Size */}
                    <div>
                      <label className="text-xs text-gray-400 mb-1 block">Tamaño de fuente</label>
                      <input
                        type="number"
                        value={properties.fontSize}
                        onChange={(e) => updateProperty('fontSize', parseInt(e.target.value))}
                        className="w-full bg-gray-800 border border-gray-600 rounded-lg px-3 py-2 text-sm"
                      />
                    </div>

                    {/* Font Style */}
                    <div>
                      <label className="text-xs text-gray-400 mb-2 block">Estilo</label>
                      <div className="flex gap-1">
                        <button
                          onClick={() => updateProperty('fontWeight', properties.fontWeight === 'bold' ? 'normal' : 'bold')}
                          className={`flex-1 p-2 rounded-lg transition-colors ${properties.fontWeight === 'bold' ? 'bg-primary-600' : 'bg-gray-700 hover:bg-gray-600'}`}
                        >
                          <Bold className="w-4 h-4 mx-auto" />
                        </button>
                        <button
                          onClick={() => updateProperty('fontStyle', properties.fontStyle === 'italic' ? 'normal' : 'italic')}
                          className={`flex-1 p-2 rounded-lg transition-colors ${properties.fontStyle === 'italic' ? 'bg-primary-600' : 'bg-gray-700 hover:bg-gray-600'}`}
                        >
                          <Italic className="w-4 h-4 mx-auto" />
                        </button>
                        <button
                          onClick={() => updateProperty('underline', !properties.underline)}
                          className={`flex-1 p-2 rounded-lg transition-colors ${properties.underline ? 'bg-primary-600' : 'bg-gray-700 hover:bg-gray-600'}`}
                        >
                          <Underline className="w-4 h-4 mx-auto" />
                        </button>
                      </div>
                    </div>

                    {/* Text Align */}
                    <div>
                      <label className="text-xs text-gray-400 mb-2 block">Alineación</label>
                      <div className="flex gap-1">
                        <button
                          onClick={() => updateProperty('textAlign', 'left')}
                          className={`flex-1 p-2 rounded-lg transition-colors ${properties.textAlign === 'left' ? 'bg-primary-600' : 'bg-gray-700 hover:bg-gray-600'}`}
                        >
                          <AlignLeft className="w-4 h-4 mx-auto" />
                        </button>
                        <button
                          onClick={() => updateProperty('textAlign', 'center')}
                          className={`flex-1 p-2 rounded-lg transition-colors ${properties.textAlign === 'center' ? 'bg-primary-600' : 'bg-gray-700 hover:bg-gray-600'}`}
                        >
                          <AlignCenter className="w-4 h-4 mx-auto" />
                        </button>
                        <button
                          onClick={() => updateProperty('textAlign', 'right')}
                          className={`flex-1 p-2 rounded-lg transition-colors ${properties.textAlign === 'right' ? 'bg-primary-600' : 'bg-gray-700 hover:bg-gray-600'}`}
                        >
                          <AlignRight className="w-4 h-4 mx-auto" />
                        </button>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Position & Size Section */}
            <div className="border-b border-gray-700">
              <button
                onClick={() => setActiveSection(activeSection === 'position' ? null as any : 'position')}
                className="w-full px-4 py-3 flex items-center justify-between hover:bg-gray-800/50 transition-colors"
              >
                <div className="flex items-center gap-2">
                  <Layers className="w-4 h-4" />
                  <span className="text-sm font-medium">Posición y Tamaño</span>
                </div>
                {activeSection === 'position' ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
              </button>
              
              {activeSection === 'position' && (
                <div className="px-4 pb-4 space-y-3">
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="text-xs text-gray-400 mb-1 block">X</label>
                      <input
                        type="number"
                        value={Math.round(properties.left)}
                        onChange={(e) => updateProperty('left', parseInt(e.target.value))}
                        className="w-full bg-gray-800 border border-gray-600 rounded-lg px-3 py-2 text-sm"
                      />
                    </div>
                    <div>
                      <label className="text-xs text-gray-400 mb-1 block">Y</label>
                      <input
                        type="number"
                        value={Math.round(properties.top)}
                        onChange={(e) => updateProperty('top', parseInt(e.target.value))}
                        className="w-full bg-gray-800 border border-gray-600 rounded-lg px-3 py-2 text-sm"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="text-xs text-gray-400 mb-1 block">Ancho</label>
                      <input
                        type="number"
                        value={Math.round(properties.width * properties.scaleX)}
                        onChange={(e) => updateProperty('scaleX', parseInt(e.target.value) / properties.width)}
                        className="w-full bg-gray-800 border border-gray-600 rounded-lg px-3 py-2 text-sm"
                      />
                    </div>
                    <div>
                      <label className="text-xs text-gray-400 mb-1 block">Alto</label>
                      <input
                        type="number"
                        value={Math.round(properties.height * properties.scaleY)}
                        onChange={(e) => updateProperty('scaleY', parseInt(e.target.value) / properties.height)}
                        className="w-full bg-gray-800 border border-gray-600 rounded-lg px-3 py-2 text-sm"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-xs text-gray-400 mb-1 block">Rotación</label>
                    <input
                      type="range"
                      min="-180"
                      max="180"
                      value={properties.angle}
                      onChange={(e) => updateProperty('angle', parseInt(e.target.value))}
                      className="w-full"
                    />
                  </div>
                </div>
              )}
            </div>
          </div>
        </>
      )}
    </div>
  );
}
