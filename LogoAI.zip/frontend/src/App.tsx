import { useEffect } from 'react';
import { Toolbar } from './components/Toolbar';
import { CanvasEditor } from './components/CanvasEditor';
import { PropertiesPanel } from './components/PropertiesPanel';
import { LayersPanel } from './components/LayersPanel';
import { TopBar } from './components/TopBar';
import { ExportModal } from './components/ExportModal';
import { ImageUploadModal } from './components/ImageUploadModal';
import { useLogoStore } from './store/logoStore';

function App() {
  const setCanvas = useLogoStore((state) => state.setCanvas);
  const canvas = useLogoStore((state) => state.canvas);

  useEffect(() => {
    // Initialize canvas when component mounts
    if (!canvas) {
      // Canvas will be initialized by CanvasEditor component
    }
  }, [canvas]);

  return (
    <div className="flex flex-col h-screen bg-canva-dark text-white overflow-hidden">
      {/* Top Navigation Bar */}
      <TopBar />

      {/* Main Workspace */}
      <div className="flex flex-1 overflow-hidden">
        {/* Left Toolbar */}
        <Toolbar />

        {/* Center Canvas Area */}
        <div className="flex-1 relative bg-[#0f0f1a] canvas-container overflow-hidden">
          <CanvasEditor />
        </div>

        {/* Right Properties Panel */}
        <PropertiesPanel />
      </div>

      {/* Bottom Layers Panel */}
      <LayersPanel />

      {/* Modals */}
      <ExportModal />
      <ImageUploadModal />
    </div>
  );
}

export default App;
