import { create } from 'zustand';
import type { Canvas, FabricObject, Textbox, Rect, Circle, Triangle, Image } from 'fabric';

export type ElementType = 'text' | 'rect' | 'circle' | 'triangle' | 'image' | 'line' | 'path';

export interface CanvasElement {
  id: string;
  type: ElementType;
  fabricObject: FabricObject;
  name: string;
  locked?: boolean;
  visible?: boolean;
}

export interface LogoState {
  // Canvas
  canvas: Canvas | null;
  canvasWidth: number;
  canvasHeight: number;
  backgroundColor: string;
  
  // Elements
  elements: CanvasElement[];
  selectedElement: CanvasElement | null;
  selectedIds: string[];
  
  // History
  history: string[];
  historyIndex: number;
  
  // Actions
  setCanvas: (canvas: Canvas) => void;
  setCanvasSize: (width: number, height: number) => void;
  setBackgroundColor: (color: string) => void;
  
  // Element Actions
  addElement: (element: CanvasElement) => void;
  updateElement: (id: string, updates: Partial<CanvasElement>) => void;
  removeElement: (id: string) => void;
  selectElement: (element: CanvasElement | null) => void;
  selectMultiple: (ids: string[]) => void;
  clearSelection: () => void;
  bringToFront: (id: string) => void;
  sendToBack: (id: string) => void;
  moveUp: (id: string) => void;
  moveDown: (id: string) => void;
  
  // Layer visibility
  toggleVisibility: (id: string) => void;
  toggleLock: (id: string) => void;
  
  // History Actions
  saveState: () => void;
  undo: () => void;
  redo: () => void;
  canUndo: () => boolean;
  canRedo: () => boolean;
  
  // Clipboard
  clipboard: FabricObject | null;
  copy: () => void;
  paste: () => void;
  cut: () => void;
  duplicate: () => void;
  
  // Zoom
  zoom: number;
  setZoom: (zoom: number) => void;
  zoomIn: () => void;
  zoomOut: () => void;
  resetZoom: () => void;
  
  // Canvas Operations
  clearCanvas: () => void;
  deleteSelected: () => void;
  
  // Export
  exportFormat: 'png' | 'jpeg' | 'webp' | 'svg' | 'pdf';
  setExportFormat: (format: 'png' | 'jpeg' | 'webp' | 'svg' | 'pdf') => void;
}

export const useLogoStore = create<LogoState>((set, get) => ({
  // Initial State
  canvas: null,
  canvasWidth: 800,
  canvasHeight: 600,
  backgroundColor: '#ffffff',
  elements: [],
  selectedElement: null,
  selectedIds: [],
  history: [],
  historyIndex: -1,
  clipboard: null,
  zoom: 1,
  exportFormat: 'png',
  
  // Canvas Actions
  setCanvas: (canvas) => set({ canvas }),
  
  setCanvasSize: (width, height) => {
    const { canvas } = get();
    if (canvas) {
      canvas.setWidth(width);
      canvas.setHeight(height);
      canvas.renderAll();
    }
    set({ canvasWidth: width, canvasHeight: height });
  },
  
  setBackgroundColor: (color) => {
    const { canvas } = get();
    if (canvas) {
      canvas.backgroundColor = color;
      canvas.renderAll();
    }
    set({ backgroundColor: color });
  },
  
  // Element Actions
  addElement: (element) => {
    set((state) => ({
      elements: [...state.elements, element],
    }));
    get().saveState();
  },
  
  updateElement: (id, updates) => {
    set((state) => ({
      elements: state.elements.map((el) =>
        el.id === id ? { ...el, ...updates } : el
      ),
    }));
  },
  
  removeElement: (id) => {
    const { canvas, elements } = get();
    const element = elements.find((el) => el.id === id);
    if (element && canvas) {
      canvas.remove(element.fabricObject);
      canvas.renderAll();
    }
    set((state) => ({
      elements: state.elements.filter((el) => el.id !== id),
      selectedElement: state.selectedElement?.id === id ? null : state.selectedElement,
    }));
    get().saveState();
  },
  
  selectElement: (element) => {
    const { canvas } = get();
    if (canvas) {
      canvas.discardActiveObject();
      if (element) {
        canvas.setActiveObject(element.fabricObject);
      }
      canvas.renderAll();
    }
    set({ selectedElement: element, selectedIds: element ? [element.id] : [] });
  },
  
  selectMultiple: (ids) => {
    set({ selectedIds: ids });
  },
  
  clearSelection: () => {
    const { canvas } = get();
    if (canvas) {
      canvas.discardActiveObject();
      canvas.renderAll();
    }
    set({ selectedElement: null, selectedIds: [] });
  },
  
  bringToFront: (id) => {
    const { canvas, elements } = get();
    const element = elements.find((el) => el.id === id);
    if (element && canvas) {
      element.fabricObject.bringToFront();
      canvas.renderAll();
    }
    get().saveState();
  },
  
  sendToBack: (id) => {
    const { canvas, elements } = get();
    const element = elements.find((el) => el.id === id);
    if (element && canvas) {
      element.fabricObject.sendToBack();
      canvas.renderAll();
    }
    get().saveState();
  },
  
  moveUp: (id) => {
    const { canvas, elements } = get();
    const element = elements.find((el) => el.id === id);
    if (element && canvas) {
      element.fabricObject.moveUp();
      canvas.renderAll();
    }
    get().saveState();
  },
  
  moveDown: (id) => {
    const { canvas, elements } = get();
    const element = elements.find((el) => el.id === id);
    if (element && canvas) {
      element.fabricObject.moveDown();
      canvas.renderAll();
    }
    get().saveState();
  },
  
  toggleVisibility: (id) => {
    const { canvas, elements } = get();
    const element = elements.find((el) => el.id === id);
    if (element && canvas) {
      element.fabricObject.visible = !element.fabricObject.visible;
      element.visible = element.fabricObject.visible;
      canvas.renderAll();
    }
    set((state) => ({
      elements: state.elements.map((el) =>
        el.id === id ? { ...el, visible: el.fabricObject.visible } : el
      ),
    }));
  },
  
  toggleLock: (id) => {
    const { canvas, elements } = get();
    const element = elements.find((el) => el.id === id);
    if (element && canvas) {
      element.fabricObject.selectable = !element.fabricObject.selectable;
      element.fabricObject.evented = !element.fabricObject.evented;
      element.locked = !element.fabricObject.selectable;
      canvas.renderAll();
    }
    set((state) => ({
      elements: state.elements.map((el) =>
        el.id === id ? { ...el, locked: el.fabricObject.selectable === false } : el
      ),
    }));
  },
  
  // History
  saveState: () => {
    const { canvas, history, historyIndex } = get();
    if (!canvas) return;
    
    const json = canvas.toJSON();
    const newHistory = history.slice(0, historyIndex + 1);
    newHistory.push(JSON.stringify(json));
    
    // Limit history to 50 states
    if (newHistory.length > 50) {
      newHistory.shift();
    }
    
    set({
      history: newHistory,
      historyIndex: newHistory.length - 1,
    });
  },
  
  undo: () => {
    const { canvas, history, historyIndex } = get();
    if (!canvas || historyIndex <= 0) return;
    
    const newIndex = historyIndex - 1;
    const state = JSON.parse(history[newIndex]);
    canvas.loadFromJSON(state, () => {
      canvas.renderAll();
    });
    set({ historyIndex: newIndex });
  },
  
  redo: () => {
    const { canvas, history, historyIndex } = get();
    if (!canvas || historyIndex >= history.length - 1) return;
    
    const newIndex = historyIndex + 1;
    const state = JSON.parse(history[newIndex]);
    canvas.loadFromJSON(state, () => {
      canvas.renderAll();
    });
    set({ historyIndex: newIndex });
  },
  
  canUndo: () => {
    const { historyIndex } = get();
    return historyIndex > 0;
  },
  
  canRedo: () => {
    const { history, historyIndex } = get();
    return historyIndex < history.length - 1;
  },
  
  // Clipboard
  copy: () => {
    const { canvas } = get();
    if (!canvas) return;
    
    const activeObject = canvas.getActiveObject();
    if (activeObject) {
      activeObject.clone((cloned: FabricObject) => {
        set({ clipboard: cloned });
      });
    }
  },
  
  paste: () => {
    const { canvas, clipboard } = get();
    if (!canvas || !clipboard) return;
    
    clipboard.clone((clonedObj: FabricObject) => {
      clonedObj.set({
        left: (clonedObj.left || 0) + 10,
        top: (clonedObj.top || 0) + 10,
      });
      canvas.add(clonedObj);
      canvas.setActiveObject(clonedObj);
      canvas.renderAll();
    });
    get().saveState();
  },
  
  cut: () => {
    const { canvas } = get();
    if (!canvas) return;
    
    const activeObject = canvas.getActiveObject();
    if (activeObject) {
      set({ clipboard: activeObject });
      canvas.remove(activeObject);
      canvas.renderAll();
      get().saveState();
    }
  },
  
  duplicate: () => {
    get().copy();
    get().paste();
  },
  
  // Zoom
  setZoom: (zoom) => {
    const { canvas } = get();
    if (canvas) {
      canvas.setZoom(zoom);
      canvas.renderAll();
    }
    set({ zoom });
  },
  
  zoomIn: () => {
    const { zoom } = get();
    const newZoom = Math.min(zoom + 0.1, 3);
    get().setZoom(newZoom);
  },
  
  zoomOut: () => {
    const { zoom } = get();
    const newZoom = Math.max(zoom - 0.1, 0.1);
    get().setZoom(newZoom);
  },
  
  resetZoom: () => {
    get().setZoom(1);
  },
  
  // Canvas Operations
  clearCanvas: () => {
    const { canvas } = get();
    if (canvas) {
      canvas.clear();
      canvas.backgroundColor = '#ffffff';
      canvas.renderAll();
    }
    set({ elements: [], selectedElement: null, selectedIds: [] });
    get().saveState();
  },
  
  deleteSelected: () => {
    const { canvas, selectedElement } = get();
    if (canvas && selectedElement) {
      canvas.remove(selectedElement.fabricObject);
      canvas.renderAll();
      set((state) => ({
        elements: state.elements.filter((el) => el.id !== selectedElement.id),
        selectedElement: null,
        selectedIds: [],
      }));
      get().saveState();
    }
  },
  
  // Export
  setExportFormat: (format) => set({ exportFormat: format }),
}));
