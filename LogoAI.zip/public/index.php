<?php
/**
 * LogoAI - Application Entry Point
 * Author: T&M Technology Ec
 * Support: soporte@tymtechnology.shop
 */

require_once __DIR__ . '/../vendor/autoload.php';

use App\Core\Router;
use App\Core\Request;
use App\Core\Response;
use App\Core\Security;
use App\Core\RateLimiter;

// Cargar configuración
require_once __DIR__ . '/../src/config/config.php';

// Inicializar sesión segura
Security::initSession();

// Rate limiting
$rateLimiter = new RateLimiter();
if (!$rateLimiter->allowRequest($_SERVER['REMOTE_ADDR'])) {
    http_response_code(429);
    echo json_encode(['error' => 'Rate limit exceeded']);
    exit;
}

// Enrutamiento
$router = new Router();

// Rutas API
$router->addRoute('POST', '/api/auth/login', 'AuthController@login');
$router->addRoute('POST', '/api/auth/register', 'AuthController@register');
$router->addRoute('POST', '/api/auth/logout', 'AuthController@logout');
$router->addRoute('GET', '/api/user/profile', 'UserController@profile');
$router->addRoute('POST', '/api/projects', 'ProjectController@create');
$router->addRoute('GET', '/api/projects', 'ProjectController@list');
$router->addRoute('GET', '/api/projects/{id}', 'ProjectController@get');
$router->addRoute('PUT', '/api/projects/{id}', 'ProjectController@update');
$router->addRoute('DELETE', '/api/projects/{id}', 'ProjectController@delete');
$router->addRoute('POST', '/api/upload', 'UploadController@handle');
$router->addRoute('POST', '/api/export', 'ExportController@export');

// Dispatch
$request = new Request();
$response = $router->dispatch($request);
$response->send();
