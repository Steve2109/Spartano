/**
 * LogoAI Editor Core
 * Author: T&M Technology Ec
 * Support: soporte@tymtechnology.shop
 */

class LogoEditor {
    constructor() {
        this.canvas = document.getElementById('editorCanvas');
        this.ctx = this.canvas.getContext('2d');
        this.elements = [];
        this.selectedElement = null;
        this.currentTool = 'select';
        this.history = [];
        this.historyIndex = -1;
        this.zoom = 1;
        this.isDragging = false;
        this.isResizing = false;
        this.dragStart = { x: 0, y: 0 };
        this.resizeHandle = null;
        
        this.init();
    }
    
    init() {
        this.setupEventListeners();
        this.setupSidebarPanels();
        this.setupTools();
        this.setupLayersPanel();
        this.addInitialState();
        this.render();
    }
    
    setupEventListeners() {
        // Canvas mouse events
        this.canvas.addEventListener('mousedown', (e) => this.handleMouseDown(e));
        this.canvas.addEventListener('mousemove', (e) => this.handleMouseMove(e));
        this.canvas.addEventListener('mouseup', (e) => this.handleMouseUp(e));
        this.canvas.addEventListener('wheel', (e) => this.handleWheel(e));
        
        // Keyboard shortcuts
        document.addEventListener('keydown', (e) => this.handleKeyDown(e));
        
        // Zoom
        document.getElementById('zoomSelect')?.addEventListener('change', (e) => {
            this.zoom = parseInt(e.target.value) / 100;
            this.applyZoom();
        });
        
        // Background color
        document.getElementById('bgColorInput')?.addEventListener('change', (e) => {
            this.canvas.style.backgroundColor = e.target.value;
            this.saveState();
        });
        
        // Upload area
        const uploadArea = document.querySelector('.upload-area');
        const fileInput = document.getElementById('imageUpload');
        
        uploadArea?.addEventListener('click', () => fileInput?.click());
        uploadArea?.addEventListener('dragover', (e) => {
            e.preventDefault();
            uploadArea.classList.add('border-primary', 'bg-purple-50');
        });
        uploadArea?.addEventListener('dragleave', () => {
            uploadArea.classList.remove('border-primary', 'bg-purple-50');
        });
        uploadArea?.addEventListener('drop', (e) => {
            e.preventDefault();
            uploadArea.classList.remove('border-primary', 'bg-purple-50');
            this.handleFiles(e.dataTransfer.files);
        });
        
        fileInput?.addEventListener('change', (e) => this.handleFiles(e.target.files));
    }
    
    setupSidebarPanels() {
        const tools = document.querySelectorAll('.sidebar-tool');
        const panels = {
            templates: document.getElementById('panel-templates'),
            elements: document.getElementById('panel-elements'),
            text: document.getElementById('panel-text'),
            uploads: document.getElementById('panel-uploads'),
            background: document.getElementById('panel-background')
        };
        
        tools.forEach(tool => {
            tool.addEventListener('click', () => {
                const panel = tool.dataset.panel;
                
                // Update active states
                tools.forEach(t => t.classList.remove('active', 'bg-purple-100', 'text-primary'));
                tool.classList.add('active', 'bg-purple-100', 'text-primary');
                
                // Show/hide panels
                Object.values(panels).forEach(p => p?.classList.add('hidden'));
                panels[panel]?.classList.remove('hidden');
            });
        });
        
        // Background color options
        document.querySelectorAll('.color-option').forEach(opt => {
            opt.addEventListener('click', () => {
                const color = opt.dataset.color;
                this.canvas.style.backgroundColor = color;
                document.getElementById('bgColorInput').value = color;
            });
        });
        
        document.getElementById('customBgColor')?.addEventListener('change', (e) => {
            this.canvas.style.backgroundColor = e.target.value;
            document.getElementById('bgColorInput').value = e.target.value;
        });
    }
    
    setupTools() {
        // Tool buttons
        document.querySelectorAll('[data-tool]').forEach(btn => {
            btn.addEventListener('click', () => {
                this.currentTool = btn.dataset.tool;
                document.querySelectorAll('[data-tool]').forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
            });
        });
        
        // Action buttons
        document.querySelectorAll('[data-action]').forEach(btn => {
            btn.addEventListener('click', () => {
                const action = btn.dataset.action;
                switch(action) {
                    case 'new': this.newProject(); break;
                    case 'save': this.saveProject(); break;
                    case 'export': this.showExportDialog(); break;
                    case 'undo': this.undo(); break;
                    case 'redo': this.redo(); break;
                }
            });
        });
        
        // Text tool
        document.getElementById('addTextBtn')?.addEventListener('click', () => {
            this.addTextElement();
        });
        
        // Shape elements
        document.querySelectorAll('.shape-item').forEach(item => {
            item.addEventListener('click', () => {
                this.addShapeElement(item.dataset.shape);
            });
        });
    }
    
    setupLayersPanel() {
        document.getElementById('layerUp')?.addEventListener('click', () => this.moveLayerUp());
        document.getElementById('layerDown')?.addEventListener('click', () => this.moveLayerDown());
        document.getElementById('layerDelete')?.addEventListener('click', () => this.deleteSelectedElement());
    }
    
    handleMouseDown(e) {
        const rect = this.canvas.getBoundingClientRect();
        const x = (e.clientX - rect.left) / this.zoom;
        const y = (e.clientY - rect.top) / this.zoom;
        
        // Check for resize handles
        if (this.selectedElement) {
            const handle = this.getResizeHandleAt(x, y);
            if (handle) {
                this.isResizing = true;
                this.resizeHandle = handle;
                this.dragStart = { x, y };
                return;
            }
        }
        
        // Check for element selection
        const clicked = this.getElementAt(x, y);
        if (clicked) {
            this.selectedElement = clicked;
            this.isDragging = true;
            this.dragStart = { x, y };
            this.selectElement(clicked);
        } else {
            this.selectedElement = null;
            this.clearSelection();
        }
        
        this.render();
    }
    
    handleMouseMove(e) {
        if (!this.isDragging && !this.isResizing) return;
        
        const rect = this.canvas.getBoundingClientRect();
        const x = (e.clientX - rect.left) / this.zoom;
        const y = (e.clientY - rect.top) / this.zoom;
        const dx = x - this.dragStart.x;
        const dy = y - this.dragStart.y;
        
        if (this.isDragging && this.selectedElement) {
            this.selectedElement.x += dx;
            this.selectedElement.y += dy;
            this.dragStart = { x, y };
        } else if (this.isResizing && this.selectedElement) {
            this.resizeElement(dx, dy);
            this.dragStart = { x, y };
        }
        
        this.render();
    }
    
    handleMouseUp(e) {
        if (this.isDragging || this.isResizing) {
            this.saveState();
        }
        this.isDragging = false;
        this.isResizing = false;
        this.resizeHandle = null;
    }
    
    handleWheel(e) {
        e.preventDefault();
        const delta = e.deltaY > 0 ? 0.9 : 1.1;
        this.zoom = Math.max(0.25, Math.min(3, this.zoom * delta));
        document.getElementById('zoomSelect').value = Math.round(this.zoom * 100);
        this.applyZoom();
    }
    
    handleKeyDown(e) {
        // Delete key
        if (e.key === 'Delete' && this.selectedElement) {
            this.deleteSelectedElement();
        }
        // Undo/Redo
        if ((e.ctrlKey || e.metaKey) && e.key === 'z') {
            e.preventDefault();
            if (e.shiftKey) {
                this.redo();
            } else {
                this.undo();
            }
        }
        // Escape - deselect
        if (e.key === 'Escape') {
            this.selectedElement = null;
            this.clearSelection();
            this.render();
        }
    }
    
    addTextElement(text = 'Doble clic para editar') {
        const fontSize = parseInt(document.getElementById('fontSizeInput')?.value || 24);
        const fontFamily = document.getElementById('fontSelect')?.value || 'Inter';
        const color = document.getElementById('textColorInput')?.value || '#000000';
        
        const element = {
            id: Date.now(),
            type: 'text',
            text: text,
            x: this.canvas.width / 2 - 50,
            y: this.canvas.height / 2,
            fontSize: fontSize,
            fontFamily: fontFamily,
            color: color,
            width: 200,
            height: fontSize * 1.5,
            rotation: 0,
            opacity: 1,
            visible: true
        };
        
        this.elements.push(element);
        this.selectedElement = element;
        this.selectElement(element);
        this.saveState();
        this.render();
        this.updateLayersList();
    }
    
    addShapeElement(shape) {
        const element = {
            id: Date.now(),
            type: 'shape',
            shape: shape,
            x: this.canvas.width / 2 - 50,
            y: this.canvas.height / 2 - 50,
            width: 100,
            height: 100,
            fill: document.getElementById('textColorInput')?.value || '#7C3AED',
            stroke: null,
            strokeWidth: 0,
            rotation: 0,
            opacity: 1,
            visible: true
        };
        
        this.elements.push(element);
        this.selectedElement = element;
        this.selectElement(element);
        this.saveState();
        this.render();
        this.updateLayersList();
    }
    
    addImageElement(src, width = 200, height = 200) {
        const img = new Image();
        img.crossOrigin = 'anonymous';
        img.onload = () => {
            // Calculate aspect ratio
            const aspect = img.width / img.height;
            let w = width, h = height;
            if (aspect > 1) {
                h = w / aspect;
            } else {
                w = h * aspect;
            }
            
            const element = {
                id: Date.now(),
                type: 'image',
                src: src,
                image: img,
                x: (this.canvas.width - w) / 2,
                y: (this.canvas.height - h) / 2,
                width: w,
                height: h,
                rotation: 0,
                opacity: 1,
                visible: true,
                crop: null
            };
            
            this.elements.push(element);
            this.selectedElement = element;
            this.selectElement(element);
            this.saveState();
            this.render();
            this.updateLayersList();
        };
        img.src = src;
    }
    
    handleFiles(files) {
        Array.from(files).forEach(file => {
            if (!file.type.startsWith('image/')) return;
            
            const reader = new FileReader();
            reader.onload = (e) => {
                // Add to uploads gallery
                this.addToUploadsGallery(e.target.result, file.name);
                // Add to canvas
                this.addImageElement(e.target.result);
            };
            reader.readAsDataURL(file);
        });
    }
    
    addToUploadsGallery(src, name) {
        const container = document.getElementById('uploadedImages');
        if (!container) return;
        
        const div = document.createElement('div');
        div.className = 'relative group cursor-pointer';
        div.innerHTML = `
            <img src="${src}" class="w-full h-24 object-cover rounded-lg" alt="${name}">
            <div class="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-30 transition rounded-lg flex items-center justify-center">
                <button class="opacity-0 group-hover:opacity-100 bg-white text-gray-800 px-3 py-1 rounded-full text-sm font-medium">
                    Usar
                </button>
            </div>
        `;
        div.querySelector('button').addEventListener('click', () => this.addImageElement(src));
        container.appendChild(div);
    }
    
    getElementAt(x, y) {
        // Check from top to bottom (reverse order)
        for (let i = this.elements.length - 1; i >= 0; i--) {
            const el = this.elements[i];
            if (!el.visible) continue;
            
            if (x >= el.x && x <= el.x + el.width &&
                y >= el.y && y <= el.y + el.height) {
                return el;
            }
        }
        return null;
    }
    
    getResizeHandleAt(x, y) {
        if (!this.selectedElement) return null;
        const handles = this.getResizeHandles();
        for (let i = 0; i < handles.length; i++) {
            const h = handles[i];
            if (Math.abs(x - h.x) < 10 && Math.abs(y - h.y) < 10) {
                return i;
            }
        }
        return null;
    }
    
    getResizeHandles() {
        const el = this.selectedElement;
        return [
            { x: el.x, y: el.y, cursor: 'nw-resize' },
            { x: el.x + el.width / 2, y: el.y, cursor: 'n-resize' },
            { x: el.x + el.width, y: el.y, cursor: 'ne-resize' },
            { x: el.x + el.width, y: el.y + el.height / 2, cursor: 'e-resize' },
            { x: el.x + el.width, y: el.y + el.height, cursor: 'se-resize' },
            { x: el.x + el.width / 2, y: el.y + el.height, cursor: 's-resize' },
            { x: el.x, y: el.y + el.height, cursor: 'sw-resize' },
            { x: el.x, y: el.y + el.height / 2, cursor: 'w-resize' }
        ];
    }
    
    resizeElement(dx, dy) {
        const el = this.selectedElement;
        const handle = this.resizeHandle;
        
        const maintainAspect = el.type === 'image';
        const aspect = maintainAspect ? el.width / el.height : null;
        
        // Corner handles resize both dimensions
        if ([0, 2, 4, 6].includes(handle)) {
            if (handle === 4) { // se - bottom right
                el.width = Math.max(20, el.width + dx);
                if (maintainAspect) {
                    el.height = el.width / aspect;
                } else {
                    el.height = Math.max(20, el.height + dy);
                }
            } else if (handle === 0) { // nw - top left
                const newW = Math.max(20, el.width - dx);
                const newH = maintainAspect ? newW / aspect : Math.max(20, el.height - dy);
                el.x += el.width - newW;
                el.y += el.height - newH;
                el.width = newW;
                el.height = newH;
            } else if (handle === 2) { // ne - top right
                el.width = Math.max(20, el.width + dx);
                const newH = maintainAspect ? el.width / aspect : Math.max(20, el.height - dy);
                el.y += el.height - newH;
                el.height = newH;
            } else if (handle === 6) { // sw - bottom left
                const newW = Math.max(20, el.width - dx);
                el.height = maintainAspect ? newW / aspect : Math.max(20, el.height + dy);
                el.x += el.width - newW;
                el.width = newW;
            }
        } else if ([1, 5].includes(handle)) { // N/S - height only
            if (handle === 1) {
                const newH = Math.max(20, el.height - dy);
                el.y += el.height - newH;
                el.height = newH;
            } else {
                el.height = Math.max(20, el.height + dy);
            }
        } else { // E/W - width only
            if (handle === 7) {
                const newW = Math.max(20, el.width - dx);
                el.x += el.width - newW;
                el.width = newW;
            } else {
                el.width = Math.max(20, el.width + dx);
            }
        }
    }
    
    selectElement(element) {
        // Update property panel
        this.updatePropertyPanel(element);
        this.updateLayersList();
    }
    
    clearSelection() {
        this.updateLayersList();
    }
    
    updatePropertyPanel(element) {
        // Update text properties if text element
        if (element.type === 'text') {
            document.getElementById('fontSizeInput').value = element.fontSize;
            document.getElementById('fontSelect').value = element.fontFamily;
            document.getElementById('textColorInput').value = element.color;
        }
    }
    
    updateLayersList() {
        const list = document.getElementById('layersList');
        if (!list) return;
        
        if (this.elements.length === 0) {
            list.innerHTML = '<div class="p-4 text-center text-gray-400 text-sm">Sin capas</div>';
            return;
        }
        
        list.innerHTML = '';
        // Show in reverse order (top layer first)
        [...this.elements].reverse().forEach((el, idx) => {
            const realIdx = this.elements.length - 1 - idx;
            const isSelected = this.selectedElement === el;
            
            const div = document.createElement('div');
            div.className = `layer-item p-3 border-b cursor-pointer flex items-center gap-2 ${isSelected ? 'active' : ''}`;
            div.innerHTML = `
                <i class="fas fa-${this.getLayerIcon(el.type)}"></i>
                <span class="flex-1 text-sm truncate">${el.type === 'text' ? el.text : el.type}</span>
                <button class="layer-visibility ${el.visible ? 'text-primary' : 'text-gray-400'}">
                    <i class="fas fa-eye${el.visible ? '' : '-slash'}"></i>
                </button>
            `;
            
            div.addEventListener('click', () => {
                this.selectedElement = el;
                this.selectElement(el);
                this.render();
            });
            
            div.querySelector('.layer-visibility').addEventListener('click', (e) => {
                e.stopPropagation();
                el.visible = !el.visible;
                this.render();
                this.updateLayersList();
            });
            
            list.appendChild(div);
        });
    }
    
    getLayerIcon(type) {
        const icons = {
            text: 'font',
            image: 'image',
            shape: 'shapes'
        };
        return icons[type] || 'layer-group';
    }
    
    moveLayerUp() {
        if (!this.selectedElement) return;
        const idx = this.elements.indexOf(this.selectedElement);
        if (idx < this.elements.length - 1) {
            [this.elements[idx], this.elements[idx + 1]] = [this.elements[idx + 1], this.elements[idx]];
            this.saveState();
            this.render();
            this.updateLayersList();
        }
    }
    
    moveLayerDown() {
        if (!this.selectedElement) return;
        const idx = this.elements.indexOf(this.selectedElement);
        if (idx > 0) {
            [this.elements[idx], this.elements[idx - 1]] = [this.elements[idx - 1], this.elements[idx]];
            this.saveState();
            this.render();
            this.updateLayersList();
        }
    }
    
    deleteSelectedElement() {
        if (!this.selectedElement) return;
        const idx = this.elements.indexOf(this.selectedElement);
        if (idx > -1) {
            this.elements.splice(idx, 1);
            this.selectedElement = null;
            this.saveState();
            this.render();
            this.updateLayersList();
        }
    }
    
    render() {
        this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
        
        this.elements.forEach(el => {
            if (!el.visible) return;
            
            this.ctx.save();
            this.ctx.globalAlpha = el.opacity;
            
            // Apply rotation around center
            const cx = el.x + el.width / 2;
            const cy = el.y + el.height / 2;
            this.ctx.translate(cx, cy);
            this.ctx.rotate(el.rotation * Math.PI / 180);
            this.ctx.translate(-cx, -cy);
            
            if (el.type === 'shape') {
                this.renderShape(el);
            } else if (el.type === 'text') {
                this.renderText(el);
            } else if (el.type === 'image') {
                this.renderImage(el);
            }
            
            this.ctx.restore();
        });
        
        // Draw selection
        if (this.selectedElement) {
            this.drawSelection();
        }
    }
    
    renderShape(el) {
        this.ctx.fillStyle = el.fill;
        this.ctx.strokeStyle = el.stroke || el.fill;
        this.ctx.lineWidth = el.strokeWidth || 0;
        
        this.ctx.beginPath();
        if (el.shape === 'rectangle') {
            this.ctx.rect(el.x, el.y, el.width, el.height);
        } else if (el.shape === 'circle') {
            this.ctx.arc(el.x + el.width / 2, el.y + el.height / 2, 
                         Math.min(el.width, el.height) / 2, 0, Math.PI * 2);
        } else if (el.shape === 'triangle') {
            this.ctx.moveTo(el.x + el.width / 2, el.y);
            this.ctx.lineTo(el.x + el.width, el.y + el.height);
            this.ctx.lineTo(el.x, el.y + el.height);
            this.ctx.closePath();
        }
        
        this.ctx.fill();
        if (el.strokeWidth > 0) this.ctx.stroke();
    }
    
    renderText(el) {
        this.ctx.fillStyle = el.color;
        this.ctx.font = `${el.fontSize}px ${el.fontFamily}`;
        this.ctx.textAlign = 'left';
        this.ctx.textBaseline = 'top';
        
        // Word wrap
        const words = el.text.split(' ');
        let line = '';
        let y = el.y;
        const lineHeight = el.fontSize * 1.2;
        
        for (let n = 0; n < words.length; n++) {
            const testLine = line + words[n] + ' ';
            const metrics = this.ctx.measureText(testLine);
            const testWidth = metrics.width;
            
            if (testWidth > el.width && n > 0) {
                this.ctx.fillText(line, el.x, y);
                line = words[n] + ' ';
                y += lineHeight;
            } else {
                line = testLine;
            }
        }
        this.ctx.fillText(line, el.x, y);
    }
    
    renderImage(el) {
        if (el.image) {
            // Apply crop if exists
            if (el.crop) {
                this.ctx.drawImage(
                    el.image,
                    el.crop.x, el.crop.y, el.crop.width, el.crop.height,
                    el.x, el.y, el.width, el.height
                );
            } else {
                this.ctx.drawImage(el.image, el.x, el.y, el.width, el.height);
            }
        }
    }
    
    drawSelection() {
        const el = this.selectedElement;
        
        this.ctx.save();
        this.ctx.strokeStyle = '#7C3AED';
        this.ctx.lineWidth = 2;
        this.ctx.setLineDash([5, 5]);
        
        const cx = el.x + el.width / 2;
        const cy = el.y + el.height / 2;
        this.ctx.translate(cx, cy);
        this.ctx.rotate(el.rotation * Math.PI / 180);
        this.ctx.translate(-cx, -cy);
        
        this.ctx.strokeRect(el.x - 2, el.y - 2, el.width + 4, el.height + 4);
        
        // Draw resize handles
        this.ctx.setLineDash([]);
        this.ctx.fillStyle = '#7C3AED';
        const handles = [
            [el.x, el.y],
            [el.x + el.width / 2, el.y],
            [el.x + el.width, el.y],
            [el.x + el.width, el.y + el.height / 2],
            [el.x + el.width, el.y + el.height],
            [el.x + el.width / 2, el.y + el.height],
            [el.x, el.y + el.height],
            [el.x, el.y + el.height / 2]
        ];
        
        handles.forEach(([x, y]) => {
            this.ctx.beginPath();
            this.ctx.arc(x, y, 5, 0, Math.PI * 2);
            this.ctx.fill();
        });
        
        this.ctx.restore();
    }
    
    applyZoom() {
        const wrapper = document.getElementById('canvasWrapper');
        if (wrapper) {
            wrapper.style.transform = `scale(${this.zoom})`;
            wrapper.style.transformOrigin = 'center center';
        }
    }
    
    saveState() {
        // Remove future states if we're not at the end
        this.history = this.history.slice(0, this.historyIndex + 1);
        
        // Save deep copy
        const state = JSON.parse(JSON.stringify(this.elements));
        this.history.push(state);
        this.historyIndex++;
        
        // Limit history size
        if (this.history.length > 50) {
            this.history.shift();
            this.historyIndex--;
        }
    }
    
    addInitialState() {
        this.saveState();
    }
    
    undo() {
        if (this.historyIndex > 0) {
            this.historyIndex--;
            this.elements = JSON.parse(JSON.stringify(this.history[this.historyIndex]));
            this.selectedElement = null;
            this.render();
            this.updateLayersList();
        }
    }
    
    redo() {
        if (this.historyIndex < this.history.length - 1) {
            this.historyIndex++;
            this.elements = JSON.parse(JSON.stringify(this.history[this.historyIndex]));
            this.selectedElement = null;
            this.render();
            this.updateLayersList();
        }
    }
    
    newProject() {
        if (confirm('¿Descartar cambios no guardados?')) {
            this.elements = [];
            this.selectedElement = null;
            this.history = [];
            this.historyIndex = -1;
            this.canvas.style.backgroundColor = '#ffffff';
            this.saveState();
            this.render();
            this.updateLayersList();
        }
    }
    
    saveProject() {
        const project = {
            elements: this.elements,
            background: this.canvas.style.backgroundColor,
            timestamp: Date.now()
        };
        
        // Save to localStorage for now
        localStorage.setItem('logoai_project', JSON.stringify(project));
        alert('Proyecto guardado localmente');
    }
    
    showExportDialog() {
        const formats = ['PNG', 'JPG', 'SVG', 'PDF'];
        const format = prompt('Formato de exportación (PNG/JPG/SVG/PDF):', 'PNG');
        if (format && formats.includes(format.toUpperCase())) {
            this.export(format.toLowerCase());
        }
    }
    
    export(format = 'png') {
        if (format === 'svg') {
            return this.exportSVG();
        }
        
        // Create temporary canvas for export
        const tempCanvas = document.createElement('canvas');
        tempCanvas.width = this.canvas.width;
        tempCanvas.height = this.canvas.height;
        const ctx = tempCanvas.getContext('2d');
        
        // Fill background
        ctx.fillStyle = this.canvas.style.backgroundColor || '#ffffff';
        ctx.fillRect(0, 0, tempCanvas.width, tempCanvas.height);
        
        // Draw all elements
        ctx.drawImage(this.canvas, 0, 0);
        
        // Download
        const link = document.createElement('a');
        link.download = `logo.${format}`;
        link.href = tempCanvas.toDataURL(`image/${format === 'jpg' ? 'jpeg' : format}`);
        link.click();
    }
    
    exportSVG() {
        const bg = this.canvas.style.backgroundColor || '#ffffff';
        let svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${this.canvas.width}" height="${this.canvas.height}">`;
        svg += `<rect width="100%" height="100%" fill="${bg}"/>`;
        
        this.elements.forEach(el => {
            if (!el.visible) return;
            
            const transform = el.rotation ? 
                `transform="rotate(${el.rotation} ${el.x + el.width/2} ${el.y + el.height/2})"` : '';
            const opacity = el.opacity !== 1 ? `opacity="${el.opacity}"` : '';
            
            if (el.type === 'shape') {
                if (el.shape === 'rectangle') {
                    svg += `<rect x="${el.x}" y="${el.y}" width="${el.width}" height="${el.height}" fill="${el.fill}" ${transform} ${opacity}/>`;
                } else if (el.shape === 'circle') {
                    const r = Math.min(el.width, el.height) / 2;
                    svg += `<circle cx="${el.x + r}" cy="${el.y + r}" r="${r}" fill="${el.fill}" ${transform} ${opacity}/>`;
                }
            } else if (el.type === 'text') {
                svg += `<text x="${el.x}" y="${el.y + el.fontSize}" font-family="${el.fontFamily}" font-size="${el.fontSize}" fill="${el.color}" ${transform} ${opacity}>${el.text}</text>`;
            } else if (el.type === 'image' && el.src) {
                // For data URLs, embed directly
                svg += `<image href="${el.src}" x="${el.x}" y="${el.y}" width="${el.width}" height="${el.height}" ${transform} ${opacity}/>`;
            }
        });
        
        svg += '</svg>';
        
        const blob = new Blob([svg], { type: 'image/svg+xml' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.download = 'logo.svg';
        link.href = url;
        link.click();
        URL.revokeObjectURL(url);
    }
}

// Initialize editor
document.addEventListener('DOMContentLoaded', () => {
    window.editor = new LogoEditor();
});
