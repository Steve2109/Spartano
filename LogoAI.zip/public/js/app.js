/**
 * LogoAI - Main Application
 * Author: T&M Technology Ec
 * Support: soporte@tymtechnology.shop
 */

// API Configuration
const API_BASE = '/api';

// State Management
const AppState = {
    user: null,
    token: localStorage.getItem('logoai_token'),
    currentProject: null,
    unsavedChanges: false
};

// Utility Functions
const Utils = {
    // Debounce function for performance
    debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    },

    // Throttle function
    throttle(func, limit) {
        let inThrottle;
        return function(...args) {
            if (!inThrottle) {
                func.apply(this, args);
                inThrottle = true;
                setTimeout(() => inThrottle = false, limit);
            }
        };
    },

    // Format file size
    formatFileSize(bytes) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    },

    // Generate unique ID
    generateId() {
        return Date.now().toString(36) + Math.random().toString(36).substr(2);
    },

    // Sanitize HTML to prevent XSS
    sanitizeHtml(html) {
        const div = document.createElement('div');
        div.textContent = html;
        return div.innerHTML;
    },

    // Deep clone object
    deepClone(obj) {
        return JSON.parse(JSON.stringify(obj));
    },

    // Check if element is in viewport
    isInViewport(element) {
        const rect = element.getBoundingClientRect();
        return (
            rect.top >= 0 &&
            rect.left >= 0 &&
            rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
            rect.right <= (window.innerWidth || document.documentElement.clientWidth)
        );
    }
};

// API Client
const API = {
    async request(endpoint, options = {}) {
        const url = `${API_BASE}${endpoint}`;
        const headers = {
            'Content-Type': 'application/json',
            ...options.headers
        };

        if (AppState.token) {
            headers['Authorization'] = `Bearer ${AppState.token}`;
        }

        try {
            const response = await fetch(url, {
                ...options,
                headers
            });

            if (!response.ok) {
                if (response.status === 401) {
                    // Token expired, logout
                    Auth.logout();
                    throw new Error('Session expired');
                }
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }

            return await response.json();
        } catch (error) {
            console.error('API Error:', error);
            throw error;
        }
    },

    get(endpoint) {
        return this.request(endpoint, { method: 'GET' });
    },

    post(endpoint, data) {
        return this.request(endpoint, {
            method: 'POST',
            body: JSON.stringify(data)
        });
    },

    put(endpoint, data) {
        return this.request(endpoint, {
            method: 'PUT',
            body: JSON.stringify(data)
        });
    },

    delete(endpoint) {
        return this.request(endpoint, { method: 'DELETE' });
    }
};

// Authentication Module
const Auth = {
    async login(email, password) {
        try {
            const data = await API.post('/auth/login', { email, password });
            AppState.token = data.token;
            AppState.user = data.user;
            localStorage.setItem('logoai_token', data.token);
            localStorage.setItem('logoai_user', JSON.stringify(data.user));
            return data;
        } catch (error) {
            throw error;
        }
    },

    async register(name, email, password) {
        try {
            const data = await API.post('/auth/register', { name, email, password });
            AppState.token = data.token;
            AppState.user = data.user;
            localStorage.setItem('logoai_token', data.token);
            localStorage.setItem('logoai_user', JSON.stringify(data.user));
            return data;
        } catch (error) {
            throw error;
        }
    },

    logout() {
        AppState.token = null;
        AppState.user = null;
        localStorage.removeItem('logoai_token');
        localStorage.removeItem('logoai_user');
        window.location.href = '/';
    },

    isAuthenticated() {
        return !!AppState.token;
    },

    init() {
        const token = localStorage.getItem('logoai_token');
        const user = localStorage.getItem('logoai_user');
        if (token && user) {
            AppState.token = token;
            AppState.user = JSON.parse(user);
        }
    }
};

// Project Management
const Projects = {
    async list() {
        return await API.get('/projects');
    },

    async get(id) {
        return await API.get(`/projects/${id}`);
    },

    async create(name, options = {}) {
        const data = await API.post('/projects', {
            name,
            width: options.width || 800,
            height: options.height || 600,
            background_color: options.backgroundColor || '#ffffff'
        });
        return data;
    },

    async update(id, data) {
        return await API.put(`/projects/${id}`, data);
    },

    async delete(id) {
        return await API.delete(`/projects/${id}`);
    },

    async saveThumbnail(id, thumbnailData) {
        return await API.put(`/projects/${id}`, { thumbnail: thumbnailData });
    }
};

// File Upload
const Upload = {
    async image(file) {
        const formData = new FormData();
        formData.append('file', file);

        const response = await fetch(`${API_BASE}/upload`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${AppState.token}`
            },
            body: formData
        });

        if (!response.ok) {
            throw new Error('Upload failed');
        }

        return await response.json();
    }
};

// Export Module
const ExportManager = {
    async export(format, canvas, options = {}) {
        const data = await API.post('/export', {
            format,
            canvas,
            width: options.width || 800,
            height: options.height || 600,
            quality: options.quality || 90,
            transparent: options.transparent || false
        });
        return data;
    }
};

// Toast Notifications
const Toast = {
    container: null,

    init() {
        this.container = document.createElement('div');
        this.container.className = 'fixed bottom-4 right-4 z-50 flex flex-col gap-2';
        document.body.appendChild(this.container);
    },

    show(message, type = 'info', duration = 3000) {
        if (!this.container) this.init();

        const toast = document.createElement('div');
        const colors = {
            success: 'bg-green-500',
            error: 'bg-red-500',
            warning: 'bg-yellow-500',
            info: 'bg-blue-500'
        };

        toast.className = `${colors[type]} text-white px-6 py-3 rounded-lg shadow-lg transform transition-all duration-300 translate-x-full`;
        toast.innerHTML = `
            <div class="flex items-center gap-2">
                <i class="fas fa-${type === 'success' ? 'check' : type === 'error' ? 'exclamation' : 'info'}-circle"></i>
                <span>${message}</span>
            </div>
        `;

        this.container.appendChild(toast);

        // Animate in
        requestAnimationFrame(() => {
            toast.classList.remove('translate-x-full');
        });

        // Remove after duration
        setTimeout(() => {
            toast.classList.add('translate-x-full');
            setTimeout(() => toast.remove(), 300);
        }, duration);
    }
};

// Initialize application
document.addEventListener('DOMContentLoaded', () => {
    Auth.init();
    Toast.init();

    // Update UI based on auth state
    if (Auth.isAuthenticated()) {
        document.body.classList.add('authenticated');
    }

    // Setup global error handler
    window.onerror = (message, source, lineno, colno, error) => {
        console.error('Global error:', error);
        Toast.show('An error occurred', 'error');
        return false;
    };

    // Unsaved changes warning
    window.addEventListener('beforeunload', (e) => {
        if (AppState.unsavedChanges) {
            e.preventDefault();
            e.returnValue = '';
        }
    });
});

// Expose to global scope
window.AppState = AppState;
window.Utils = Utils;
window.API = API;
window.Auth = Auth;
window.Projects = Projects;
window.Upload = Upload;
window.Toast = Toast;
