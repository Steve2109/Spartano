/**
 * LogoAI Export Manager
 * Author: T&M Technology Ec
 */

class ExportManager {
    constructor(editor) {
        this.editor = editor;
        this.init();
    }
    
    init() {
        this.setupExportModal();
    }
    
    setupExportModal() {
        const modal = document.createElement('div');
        modal.id = 'exportModal';
        modal.className = 'fixed inset-0 bg-black bg-opacity-50 z-50 hidden items-center justify-center';
        modal.innerHTML = `
            <div class="bg-white rounded-2xl shadow-2xl max-w-lg w-full mx-4 transform scale-95 opacity-0 transition-all duration-300">
                <div class="p-6 border-b">
                    <div class="flex justify-between items-center">
                        <h3 class="text-xl font-semibold">Exportar Diseño</h3>
                        <button id="closeExport" class="text-gray-400 hover:text-gray-600">
                            <i class="fas fa-times text-xl"></i>
                        </button>
                    </div>
                </div>
                <div class="p-6">
                    <div class="mb-4">
                        <label class="block text-sm font-medium text-gray-700 mb-2">Formato</label>
                        <div class="grid grid-cols-3 gap-3">
                            <button class="format-btn p-3 border-2 border-primary bg-purple-50 text-primary rounded-lg font-medium" data-format="png">
                                <i class="fas fa-image mb-1"></i><br>PNG
                            </button>
                            <button class="format-btn p-3 border-2 border-gray-200 hover:border-primary hover:text-primary rounded-lg font-medium" data-format="jpg">
                                <i class="fas fa-file-image mb-1"></i><br>JPG
                            </button>
                            <button class="format-btn p-3 border-2 border-gray-200 hover:border-primary hover:text-primary rounded-lg font-medium" data-format="svg">
                                <i class="fas fa-vector-square mb-1"></i><br>SVG
                            </button>
                        </div>
                    </div>
                    
                    <div class="mb-4">
                        <label class="block text-sm font-medium text-gray-700 mb-2">Tamaño</label>
                        <div class="flex gap-3 mb-3">
                            <div class="flex-1">
                                <label class="text-xs text-gray-500">Ancho (px)</label>
                                <input type="number" id="exportWidth" value="800" class="w-full p-2 border rounded-lg">
                            </div>
                            <div class="flex items-end pb-2">
                                <i class="fas fa-times text-gray-400"></i>
                            </div>
                            <div class="flex-1">
                                <label class="text-xs text-gray-500">Alto (px)</label>
                                <input type="number" id="exportHeight" value="600" class="w-full p-2 border rounded-lg">
                            </div>
                            <div class="flex items-end">
                                <button id="lockRatio" class="p-2 text-primary" title="Mantener proporción">
                                    <i class="fas fa-lock"></i>
                                </button>
                            </div>
                        </div>
                        <div class="flex gap-2">
                            <button class="preset-size px-3 py-1 text-sm bg-gray-100 rounded hover:bg-gray-200" data-w="800" data-h="600">800×600</button>
                            <button class="preset-size px-3 py-1 text-sm bg-gray-100 rounded hover:bg-gray-200" data-w="1200" data-h="800">1200×800</button>
                            <button class="preset-size px-3 py-1 text-sm bg-gray-100 rounded hover:bg-gray-200" data-w="1080" data-h="1080">1:1</button>
                            <button class="preset-size px-3 py-1 text-sm bg-gray-100 rounded hover:bg-gray-200" data-w="1920" data-h="1080">16:9</button>
                        </div>
                    </div>
                    
                    <div id="jpgOptions" class="mb-4 hidden">
                        <label class="block text-sm font-medium text-gray-700 mb-2">Calidad JPG</label>
                        <input type="range" id="jpgQuality" min="1" max="100" value="90" class="w-full">
                        <div class="flex justify-between text-xs text-gray-500 mt-1">
                            <span>Baja calidad (menor tamaño)</span>
                            <span id="qualityValue">90%</span>
                            <span>Alta calidad</span>
                        </div>
                    </div>
                    
                    <div class="mb-4">
                        <label class="flex items-center gap-2 cursor-pointer">
                            <input type="checkbox" id="transparentBg">
                            <span class="text-sm">Fondo transparente (solo PNG/SVG)</span>
                        </label>
                    </div>
                </div>
                <div class="p-6 border-t bg-gray-50 rounded-b-2xl">
                    <button id="downloadBtn" class="w-full py-3 bg-primary text-white font-semibold rounded-xl hover:bg-primary-dark transition flex items-center justify-center gap-2">
                        <i class="fas fa-download"></i>
                        Descargar
                    </button>
                </div>
            </div>
        `;
        
        document.body.appendChild(modal);
        
        // Event listeners
        let selectedFormat = 'png';
        let lockedRatio = true;
        const aspectRatio = 800 / 600;
        
        document.querySelectorAll('.format-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                document.querySelectorAll('.format-btn').forEach(b => {
                    b.classList.remove('border-primary', 'bg-purple-50', 'text-primary');
                    b.classList.add('border-gray-200');
                });
                btn.classList.add('border-primary', 'bg-purple-50', 'text-primary');
                btn.classList.remove('border-gray-200');
                selectedFormat = btn.dataset.format;
                
                document.getElementById('jpgOptions').classList.toggle('hidden', selectedFormat !== 'jpg');
            });
        });
        
        document.getElementById('exportWidth').addEventListener('input', (e) => {
            if (lockedRatio) {
                document.getElementById('exportHeight').value = Math.round(e.target.value / aspectRatio);
            }
        });
        
        document.getElementById('exportHeight').addEventListener('input', (e) => {
            if (lockedRatio) {
                document.getElementById('exportWidth').value = Math.round(e.target.value * aspectRatio);
            }
        });
        
        document.getElementById('lockRatio').addEventListener('click', function() {
            lockedRatio = !lockedRatio;
            this.innerHTML = lockedRatio ? '<i class="fas fa-lock"></i>' : '<i class="fas fa-lock-open"></i>';
        });
        
        document.querySelectorAll('.preset-size').forEach(btn => {
            btn.addEventListener('click', () => {
                document.getElementById('exportWidth').value = btn.dataset.w;
                document.getElementById('exportHeight').value = btn.dataset.h;
            });
        });
        
        document.getElementById('jpgQuality').addEventListener('input', (e) => {
            document.getElementById('qualityValue').textContent = e.target.value + '%';
        });
        
        document.getElementById('closeExport').addEventListener('click', () => this.hideModal(modal));
        document.getElementById('downloadBtn').addEventListener('click', () => {
            this.performExport(selectedFormat);
            this.hideModal(modal);
        });
        
        modal.addEventListener('click', (e) => {
            if (e.target === modal) this.hideModal(modal);
        });
        
        // Store modal reference
        this.exportModal = modal;
    }
    
    showModal() {
        this.exportModal.classList.remove('hidden');
        this.exportModal.classList.add('flex');
        setTimeout(() => {
            const content = this.exportModal.querySelector('.bg-white');
            content.classList.remove('scale-95', 'opacity-0');
            content.classList.add('scale-100', 'opacity-100');
        }, 10);
    }
    
    hideModal(modal) {
        const content = modal.querySelector('.bg-white');
        content.classList.remove('scale-100', 'opacity-100');
        content.classList.add('scale-95', 'opacity-0');
        setTimeout(() => {
            modal.classList.add('hidden');
            modal.classList.remove('flex');
        }, 300);
    }
    
    performExport(format) {
        const width = parseInt(document.getElementById('exportWidth').value);
        const height = parseInt(document.getElementById('exportHeight').value);
        const transparent = document.getElementById('transparentBg').checked;
        
        if (format === 'svg') {
            this.exportSVG(width, height);
        } else {
            this.exportRaster(format, width, height, transparent);
        }
    }
    
    exportRaster(format, width, height, transparent) {
        const tempCanvas = document.createElement('canvas');
        tempCanvas.width = width;
        tempCanvas.height = height;
        const ctx = tempCanvas.getContext('2d');
        
        // Scale factor
        const scaleX = width / this.editor.canvas.width;
        const scaleY = height / this.editor.canvas.height;
        
        // Background
        if (!transparent) {
            ctx.fillStyle = this.editor.canvas.style.backgroundColor || '#ffffff';
            ctx.fillRect(0, 0, width, height);
        }
        
        // Render elements scaled
        ctx.save();
        ctx.scale(scaleX, scaleY);
        
        this.editor.elements.forEach(el => {
            if (!el.visible) return;
            
            ctx.save();
            ctx.globalAlpha = el.opacity;
            
            // Transformations
            const cx = el.x + el.width / 2;
            const cy = el.y + el.height / 2;
            ctx.translate(cx, cy);
            ctx.rotate(el.rotation * Math.PI / 180);
            ctx.translate(-cx, -cy);
            
            if (el.type === 'shape') {
                this.renderShape(ctx, el);
            } else if (el.type === 'text') {
                this.renderText(ctx, el);
            } else if (el.type === 'image' && el.image) {
                this.renderImage(ctx, el);
            }
            
            ctx.restore();
        });
        
        ctx.restore();
        
        // Download
        const quality = parseInt(document.getElementById('jpgQuality')?.value || 90) / 100;
        const mimeType = format === 'jpg' ? 'image/jpeg' : `image/${format}`;
        const dataUrl = tempCanvas.toDataURL(mimeType, quality);
        
        const link = document.createElement('a');
        link.download = `logo_${Date.now()}.${format}`;
        link.href = dataUrl;
        link.click();
    }
    
    exportSVG(width, height) {
        const transparent = document.getElementById('transparentBg').checked;
        const bg = transparent ? 'transparent' : (this.editor.canvas.style.backgroundColor || '#ffffff');
        
        let svg = `<?xml version="1.0" encoding="UTF-8"?>\n`;
        svg += `<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="${width}" height="${height}" viewBox="0 0 ${this.editor.canvas.width} ${this.editor.canvas.height}">\n`;
        
        if (!transparent) {
            svg += `  <rect width="100%" height="100%" fill="${bg}"/>\n`;
        }
        
        this.editor.elements.forEach(el => {
            if (!el.visible) return;
            svg += this.elementToSVG(el);
        });
        
        svg += `</svg>`;
        
        const blob = new Blob([svg], { type: 'image/svg+xml;charset=utf-8' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.download = `logo_${Date.now()}.svg`;
        link.href = url;
        link.click();
        URL.revokeObjectURL(url);
    }
    
    renderShape(ctx, el) {
        ctx.fillStyle = el.fill;
        ctx.strokeStyle = el.stroke || el.fill;
        ctx.lineWidth = el.strokeWidth || 0;
        
        ctx.beginPath();
        if (el.shape === 'rectangle') {
            ctx.rect(el.x, el.y, el.width, el.height);
        } else if (el.shape === 'circle') {
            ctx.arc(el.x + el.width / 2, el.y + el.height / 2, 
                    Math.min(el.width, el.height) / 2, 0, Math.PI * 2);
        }
        
        ctx.fill();
        if (el.strokeWidth > 0) ctx.stroke();
    }
    
    renderText(ctx, el) {
        ctx.fillStyle = el.color;
        ctx.font = `${el.fontSize}px ${el.fontFamily}`;
        ctx.textAlign = 'left';
        ctx.textBaseline = 'top';
        ctx.fillText(el.text, el.x, el.y);
    }
    
    renderImage(ctx, el) {
        if (el.crop) {
            ctx.drawImage(
                el.image,
                el.crop.x, el.crop.y, el.crop.width, el.crop.height,
                el.x, el.y, el.width, el.height
            );
        } else {
            ctx.drawImage(el.image, el.x, el.y, el.width, el.height);
        }
    }
    
    elementToSVG(el) {
        const transform = el.rotation ? 
            ` transform="rotate(${el.rotation} ${el.x + el.width/2} ${el.y + el.height/2})"` : '';
        const opacity = el.opacity !== 1 ? ` opacity="${el.opacity}"` : '';
        
        let svg = '';
        
        if (el.type === 'shape') {
            if (el.shape === 'rectangle') {
                svg += `  <rect x="${el.x}" y="${el.y}" width="${el.width}" height="${el.height}" fill="${el.fill}"${transform}${opacity}/>\n`;
            } else if (el.shape === 'circle') {
                const r = Math.min(el.width, el.height) / 2;
                svg += `  <circle cx="${el.x + r}" cy="${el.y + r}" r="${r}" fill="${el.fill}"${transform}${opacity}/>\n`;
            }
        } else if (el.type === 'text') {
            svg += `  <text x="${el.x}" y="${el.y + el.fontSize}" font-family="${el.fontFamily}" font-size="${el.fontSize}" fill="${el.color}"${transform}${opacity}>${this.escapeXml(el.text)}</text>\n`;
        } else if (el.type === 'image' && el.src) {
            // Convert to base64 if data URL, or use as-is
            const href = el.src.startsWith('data:') ? el.src : el.src;
            svg += `  <image href="${href}" x="${el.x}" y="${el.y}" width="${el.width}" height="${el.height}"${transform}${opacity}/>\n`;
        }
        
        return svg;
    }
    
    escapeXml(text) {
        return text.replace(/[<>&'"]/g, c => ({
            '<': '&lt;',
            '>': '&gt;',
            '&': '&amp;',
            "'": '&apos;',
            '"': '&quot;'
        })[c]);
    }
}

// Override editor's showExportDialog
window.ExportManager = ExportManager;
