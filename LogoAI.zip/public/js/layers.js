/**
 * LogoAI Layers Manager
 * Author: T&M Technology Ec
 */

class LayersManager {
    constructor(editor) {
        this.editor = editor;
        this.init();
    }
    
    init() {
        this.setupEventListeners();
    }
    
    setupEventListeners() {
        // Context menu for layers
        document.getElementById('layersList')?.addEventListener('contextmenu', (e) => {
            e.preventDefault();
            const layerItem = e.target.closest('.layer-item');
            if (layerItem) {
                this.showContextMenu(e.pageX, e.pageY, layerItem);
            }
        });
    }
    
    showContextMenu(x, y, layerItem) {
        const menu = document.createElement('div');
        menu.className = 'absolute bg-white shadow-lg rounded-lg py-2 z-50 min-w-[150px]';
        menu.style.left = `${x}px`;
        menu.style.top = `${y}px`;
        
        menu.innerHTML = `
            <button class="w-full text-left px-4 py-2 hover:bg-gray-100 flex items-center gap-2" data-action="duplicate">
                <i class="fas fa-copy text-gray-400"></i> Duplicar
            </button>
            <button class="w-full text-left px-4 py-2 hover:bg-gray-100 flex items-center gap-2" data-action="lock">
                <i class="fas fa-lock text-gray-400"></i> Bloquear
            </button>
            <button class="w-full text-left px-4 py-2 hover:bg-red-50 text-red-600 flex items-center gap-2" data-action="delete">
                <i class="fas fa-trash"></i> Eliminar
            </button>
        `;
        
        document.body.appendChild(menu);
        
        const closeMenu = () => menu.remove();
        setTimeout(() => {
            document.addEventListener('click', closeMenu, { once: true });
        }, 100);
        
        menu.querySelectorAll('button').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.stopPropagation();
                const action = btn.dataset.action;
                this.handleLayerAction(action);
                closeMenu();
            });
        });
    }
    
    handleLayerAction(action) {
        const el = this.editor.selectedElement;
        if (!el) return;
        
        switch(action) {
            case 'duplicate':
                this.duplicateLayer(el);
                break;
            case 'lock':
                el.locked = !el.locked;
                this.editor.updateLayersList();
                break;
            case 'delete':
                this.editor.deleteSelectedElement();
                break;
        }
    }
    
    duplicateLayer(el) {
        const duplicate = JSON.parse(JSON.stringify(el));
        duplicate.id = Date.now();
        duplicate.x += 20;
        duplicate.y += 20;
        
        // Deep copy image if exists
        if (el.image) {
            duplicate.image = el.image;
        }
        
        this.editor.elements.push(duplicate);
        this.editor.selectedElement = duplicate;
        this.editor.selectElement(duplicate);
        this.editor.saveState();
        this.editor.render();
        this.editor.updateLayersList();
    }
    
    // Advanced crop functionality
    initCropTool(element) {
        if (element.type !== 'image' || !element.image) return;
        
        const cropOverlay = document.createElement('div');
        cropOverlay.className = 'fixed inset-0 bg-black bg-opacity-80 z-50 flex items-center justify-center';
        cropOverlay.innerHTML = `
            <div class="bg-white rounded-xl p-6 max-w-4xl w-full mx-4">
                <div class="flex justify-between items-center mb-4">
                    <h3 class="text-lg font-semibold">Recortar Imagen</h3>
                    <button id="closeCrop" class="text-gray-400 hover:text-gray-600">
                        <i class="fas fa-times text-xl"></i>
                    </button>
                </div>
                <div class="relative bg-gray-100 rounded-lg overflow-hidden" style="height: 400px;">
                    <canvas id="cropCanvas" class="max-w-full max-h-full"></canvas>
                    <div id="cropArea" class="absolute border-2 border-white shadow-lg" 
                         style="left: 0; top: 0; width: 100%; height: 100%;">
                        <div class="absolute inset-0 bg-black bg-opacity-50"></div>
                        <div class="absolute inset-0 overflow-hidden">
                            <img id="cropPreview" class="w-full h-full object-cover" src="${element.src}">
                        </div>
                        <div class="resize-handle absolute top-0 left-0 cursor-nw-resize" style="width: 12px; height: 12px; background: white; margin: -4px;"></div>
                        <div class="resize-handle absolute top-0 right-0 cursor-ne-resize" style="width: 12px; height: 12px; background: white; margin: -4px;"></div>
                        <div class="resize-handle absolute bottom-0 left-0 cursor-sw-resize" style="width: 12px; height: 12px; background: white; margin: -4px;"></div>
                        <div class="resize-handle absolute bottom-0 right-0 cursor-se-resize" style="width: 12px; height: 12px; background: white; margin: -4px;"></div>
                    </div>
                </div>
                <div class="flex justify-end gap-3 mt-4">
                    <button id="resetCrop" class="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-lg">Restablecer</button>
                    <button id="applyCrop" class="px-4 py-2 bg-primary text-white rounded-lg hover:bg-primary-dark">Aplicar</button>
                </div>
            </div>
        `;
        
        document.body.appendChild(cropOverlay);
        
        // Setup crop interaction
        const cropArea = document.getElementById('cropArea');
        const cropPreview = document.getElementById('cropPreview');
        let cropRect = { x: 0, y: 0, width: element.width, height: element.height };
        let isDragging = false;
        let dragStart = { x: 0, y: 0 };
        
        cropArea.addEventListener('mousedown', (e) => {
            isDragging = true;
            dragStart = { x: e.clientX, y: e.clientY };
        });
        
        document.addEventListener('mousemove', (e) => {
            if (!isDragging) return;
            const dx = e.clientX - dragStart.x;
            const dy = e.clientY - dragStart.y;
            cropRect.x += dx;
            cropRect.y += dy;
            dragStart = { x: e.clientX, y: e.clientY };
            updateCropArea();
        });
        
        document.addEventListener('mouseup', () => isDragging = false);
        
        function updateCropArea() {
            cropArea.style.left = `${cropRect.x}px`;
            cropArea.style.top = `${cropRect.y}px`;
            cropArea.style.width = `${cropRect.width}px`;
            cropArea.style.height = `${cropRect.height}px`;
            cropPreview.style.objectPosition = `-${cropRect.x}px -${cropRect.y}px`;
        }
        
        document.getElementById('closeCrop').addEventListener('click', () => cropOverlay.remove());
        document.getElementById('resetCrop').addEventListener('click', () => {
            cropRect = { x: 0, y: 0, width: element.width, height: element.height };
            updateCropArea();
        });
        document.getElementById('applyCrop').addEventListener('click', () => {
            element.crop = { ...cropRect };
            this.editor.render();
            cropOverlay.remove();
        });
    }
    
    // Blend modes for layers
    getBlendModes() {
        return [
            'normal', 'multiply', 'screen', 'overlay', 'darken', 'lighten',
            'color-dodge', 'color-burn', 'hard-light', 'soft-light',
            'difference', 'exclusion', 'hue', 'saturation', 'color', 'luminosity'
        ];
    }
    
    applyBlendMode(element, mode) {
        element.blendMode = mode;
        this.editor.render();
    }
}

// Export for use with editor
window.LayersManager = LayersManager;
