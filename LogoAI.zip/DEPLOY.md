# Guía de Despliegue - LogoAI
## Creador de Logotipos Profesional
**Autor:** T&M Technology Ec  
**Soporte:** soporte@tymtechnology.shop  
**Dominio:** https://logoai.tymtechnology.shop  
**Puerto:** 32299  
**IP Interna:** 10.0.1.40:32299

---

## ⚠️ IMPORTANTE: Ubicación de Instalación

> **El proyecto DEBE instalarse en `/opt/logoai/`**
> 
> Todos los scripts de instalación, servicios systemd y configuraciones están preparados para esta ruta específica. **No funcionará correctamente** si lo instalas en otra ubicación.
> 
> **Pasos correctos:**
> ```bash
> sudo mkdir -p /opt/logoai
> cd /opt/logoai
> git clone https://github.com/tmtechnology/logoai.git .
> sudo bash scripts/install.sh
> ```
> 
> **Ubicaciones incorrectas:** ❌ `~/logoai/`, ❌ `/root/logoai/`, ❌ `/home/usuario/logoai/`

---

## 📋 Tabla de Contenidos
1. [Requisitos](#requisitos)
2. [Opciones de Instalación](#opciones-de-instalación)
3. [Opción 1: Docker (Recomendada)](#opción-1-docker-recomendada)
4. [Opción 2: Instalación Manual Python](#opción-2-instalación-manual-python)
5. [Configuración Nginx Proxy Manager](#configuración-nginx-proxy-manager)
6. [SSL Let's Encrypt](#ssl-lets-encrypt)
7. [Verificación del Despliegue](#verificación-del-despliegue)
8. [Solución de Problemas](#solución-de-problemas)

---

## 🔧 Requisitos

### Hardware Mínimo
- **CPU:** 2 vCPUs
- **RAM:** 4 GB
- **Disco:** 20 GB SSD
- **OS:** Debian 13 (Trixie) o Ubuntu 22.04+

### Red
- IP estática: `10.0.1.40`
- Puerto disponible: `32299`
- Acceso a Internet para certificados SSL

### Software
- Docker y Docker Compose (Opción 1)
- Python 3.11+ (Opción 2)
- PostgreSQL 15+ (Opción 2)
- Redis 7+ (Opción 2)

---

## 🚀 Opciones de Instalación

| Método | Dificultad | Tiempo | Recomendado para |
|--------|-----------|--------|------------------|
| Docker | ⭐ Fácil | 15 min | Producción |
| Python Manual | ⭐⭐⭐ Difícil | 45 min | Desarrollo/Custom |

---

## 🐳 Opción 1: Docker (Recomendada)

### 🚀 Método Rápido: Usar install.sh (Recomendado)

El script `install.sh` automatiza todo el proceso y te permite elegir entre Docker o instalación manual:

```bash
# 1. Preparar directorio (IMPORTANTE: debe ser /opt/logoai)
sudo mkdir -p /opt/logoai
cd /opt/logoai

# 2. Descargar archivos del proyecto
# Opción A: Clonar desde GitHub (si está disponible)
git clone https://github.com/tmtechnology/logoai.git .

# Opción B: Copiar archivos manualmente
# scp -r /local/path/logoai/* root@10.0.1.40:/opt/logoai/

# 3. Ejecutar instalador
sudo bash scripts/install.sh
```

**El script mostrará un menú interactivo:**
```
==========================================
  🎨 Instalador de LogoAI
  T&M Technology Ec
==========================================

Selecciona el método de instalación:

  [1] 🐳 Docker (Recomendado)
      - Instalación rápida y aislada
      - Fácil mantenimiento y actualizaciones
      - Ideal para producción

  [2] 🐍 Python Manual (Sin Docker)
      - Mayor control del sistema
      - Ideal para LXC containers o servidores sin Docker
      - Requiere configuración adicional de PostgreSQL/Redis

  [0] ❌ Cancelar

Opción [1/2/0]:
```

Selecciona **1** para Docker y el script se encargará de todo.

---

### 📋 Método Manual (Si prefieres hacerlo paso a paso)

#### Paso 1: Preparar el Servidor

```bash
# Conectarse al servidor
ssh usuario@10.0.1.40

# Actualizar el sistema
sudo apt update && sudo apt upgrade -y

# Instalar dependencias básicas
sudo apt install -y curl wget git htop nano ufw

# Instalar Docker
curl -fsSL https://get.docker.com | sh

# Agregar usuario al grupo docker
sudo usermod -aG docker $USER
newgrp docker

# Verificar instalación
docker --version
docker compose version
```

### Paso 2: Configurar Firewall

```bash
# Configurar UFW
sudo ufw default deny incoming
sudo ufw default allow outgoing
sudo ufw allow ssh
sudo ufw allow 32299/tcp
sudo ufw enable

# Verificar
sudo ufw status
```

### Paso 3: Preparar el Proyecto

```bash
# Crear directorio de la aplicación
mkdir -p ~/logoai
cd ~/logoai

# Copiar archivos del proyecto
# (Copiar todos los archivos del proyecto aquí)

# Crear archivo .env
cat > .env << 'EOF'
# Seguridad - ¡Cambiar en producción!
SECRET_KEY=tu_clave_secreta_larga_y_aleatoria_aqui_minimo_50_caracteres
DEBUG=False

# Dominios permitidos
ALLOWED_HOSTS=logoai.tymtechnology.shop,10.0.1.40,localhost,127.0.0.1

# Base de datos
DB_PASSWORD=tu_password_segura_postgres_aqui

# Rate limiting
RATE_LIMIT_ANON=30/m
RATE_LIMIT_AUTH=100/m
RATE_LIMIT_API=60/m

# Tamaños máximos
MAX_UPLOAD_SIZE=10485760
MAX_CANVAS_WIDTH=5000
MAX_CANVAS_HEIGHT=5000

# Email (opcional)
EMAIL_HOST=smtp.gmail.com
EMAIL_PORT=587
EMAIL_USE_TLS=True
EMAIL_HOST_USER=soporte@tymtechnology.shop
EMAIL_HOST_PASSWORD=tu_password_email
DEFAULT_FROM_EMAIL=soporte@tymtechnology.shop
EOF

# Generar secret key seguro (opcional)
openssl rand -base64 50
```

### Paso 4: Construir e Iniciar

```bash
# Construir imágenes
docker compose build

# Iniciar servicios
docker compose up -d

# Verificar logs
docker compose logs -f web

# Esperar a que la base de datos esté lista (30-60 segundos)
```

### Paso 5: Migraciones y Superusuario

```bash
# Ejecutar migraciones
docker compose exec web python manage.py migrate

# Crear superusuario
docker compose exec web python manage.py createsuperuser

# Recolectar archivos estáticos
docker compose exec web python manage.py collectstatic --noinput

# Crear plantillas iniciales (opcional)
docker compose exec web python manage.py shell << 'PYEOF'
from editor.models import ShapeLibrary, FontLibrary

# Crear formas básicas
shapes = [
    ('Rectángulo', 'rectangle', '<rect width="100" height="100"/>'),
    ('Círculo', 'circle', '<circle cx="50" cy="50" r="50"/>'),
    ('Triángulo', 'triangle', '<polygon points="50,10 90,90 10,90"/>'),
]
for name, shape_type, svg in shapes:
    ShapeLibrary.objects.get_or_create(name=name, defaults={'shape_type': shape_type, 'svg_path': svg, 'category': 'general'})

# Crear fuentes básicas
fonts = ['Arial', 'Helvetica', 'Times New Roman', 'Georgia', 'Verdana']
for font in fonts:
    FontLibrary.objects.get_or_create(name=font, defaults={'family_name': font, 'is_google_font': False})

print('Datos iniciales creados')
PYEOF
```

### Paso 6: Verificar Instalación Docker

```bash
# Verificar contenedores
docker compose ps

# Verificar salud
curl http://10.0.1.40:32299/api/health/

# Debería retornar:
# {"status":"healthy","version":"1.0.0"}
```

---

## 🐍 Opción 2: Instalación Manual Python

### Paso 1: Instalar Dependencias del Sistema

```bash
# Actualizar sistema
sudo apt update && sudo apt upgrade -y

# Instalar Python y dependencias
sudo apt install -y python3.11 python3.11-venv python3.11-dev python3-pip

# Instalar dependencias de compilación
sudo apt install -y build-essential libpq-dev libmagic1

# Instalar dependencias de Pillow
sudo apt install -y libfreetype6-dev libjpeg-dev libpng-dev zlib1g-dev libwebp-dev

# Instalar PostgreSQL
sudo apt install -y postgresql-15 postgresql-contrib

# Instalar Redis
sudo apt install -y redis-server

# Instalar Nginx
sudo apt install -y nginx
```

### Paso 2: Configurar PostgreSQL

```bash
# Iniciar servicio
sudo systemctl enable postgresql
sudo systemctl start postgresql

# Crear usuario y base de datos
sudo -u postgres psql << 'EOF'
CREATE USER logoai_user WITH PASSWORD 'tu_password_segura';
CREATE DATABASE logoai_db OWNER logoai_user;
GRANT ALL PRIVILEGES ON DATABASE logoai_db TO logoai_user;
\q
EOF
```

### Paso 3: Configurar Redis

```bash
# Verificar Redis
sudo systemctl enable redis-server
sudo systemctl start redis-server
redis-cli ping  # Debería responder: PONG
```

### Paso 4: Preparar Ambiente Python

```bash
# Crear directorio
mkdir -p ~/logoai
cd ~/logoai

# Crear virtual environment
python3.11 -m venv venv
source venv/bin/activate

# Instalar dependencias
pip install --upgrade pip
pip install -r requirements.txt
```

### Paso 5: Configurar Variables de Entorno

```bash
cat > .env << 'EOF'
SECRET_KEY=tu_clave_secreta_larga_y_aleatoria_aqui
DEBUG=False
ALLOWED_HOSTS=logoai.tymtechnology.shop,10.0.1.40,localhost,127.0.0.1

DB_NAME=logoai_db
DB_USER=logoai_user
DB_PASSWORD=tu_password_segura
DB_HOST=localhost
DB_PORT=5432

REDIS_URL=redis://localhost:6379/0
CELERY_BROKER_URL=redis://localhost:6379/0
CELERY_RESULT_BACKEND=redis://localhost:6379/0

RATE_LIMIT_ANON=30/m
RATE_LIMIT_AUTH=100/m
RATE_LIMIT_API=60/m
EOF
```

### Paso 6: Migraciones y Estáticos

```bash
# Activar entorno
source venv/bin/activate

# Migraciones
python manage.py migrate

# Crear superusuario
python manage.py createsuperuser

# Recolectar estáticos
python manage.py collectstatic --noinput
```

### Paso 7: Configurar Gunicorn

```bash
# Instalar gunicorn
pip install gunicorn

# Crear archivo de servicio systemd
sudo tee /etc/systemd/system/logoai.service << 'EOF'
[Unit]
Description=LogoAI Gunicorn Daemon
After=network.target postgresql.service redis.service

[Service]
Type=notify
User=www-data
Group=www-data
WorkingDirectory=/home/usuario/logoai
Environment="PATH=/home/usuario/logoai/venv/bin"
EnvironmentFile=/home/usuario/logoai/.env
ExecStart=/home/usuario/logoai/venv/bin/gunicorn \
    --bind 0.0.0.0:32299 \
    --workers 4 \
    --threads 2 \
    --worker-class gthread \
    --access-logfile - \
    --error-logfile - \
    --capture-output \
    --enable-stdio-inheritance \
    logoai.wsgi:application

[Install]
WantedBy=multi-user.target
EOF

# Ajustar permisos
sudo chown -R www-data:www-data /home/usuario/logoai

# Iniciar servicio
sudo systemctl daemon-reload
sudo systemctl enable logoai
sudo systemctl start logoai
sudo systemctl status logoai
```

### Paso 8: Configurar Celery (Opcional)

```bash
# Crear servicio Celery Worker
sudo tee /etc/systemd/system/logoai-celery.service << 'EOF'
[Unit]
Description=Celery Service for LogoAI
After=network.target redis.service

[Service]
Type=forking
User=www-data
Group=www-data
WorkingDirectory=/home/usuario/logoai
Environment="PATH=/home/usuario/logoai/venv/bin"
EnvironmentFile=/home/usuario/logoai/.env
ExecStart=/home/usuario/logoai/venv/bin/celery \
    -A logoai worker \
    --loglevel=info \
    --detach

[Install]
WantedBy=multi-user.target
EOF

sudo systemctl daemon-reload
sudo systemctl enable logoai-celery
sudo systemctl start logoai-celery
```

---

## 🌐 Configuración Nginx Proxy Manager

### Paso 1: Acceder a NPM

```
URL: http://ip-de-npm:81
Usuario: admin@example.com
Password: changeme (cambiar al primer inicio)
```

### Paso 2: Crear Proxy Host

1. Ir a **Hosts** → **Proxy Hosts**
2. Click en **Add Proxy Host**
3. Configurar:

```
Domain Names: logoai.tymtechnology.shop
Scheme: http
Forward Hostname / IP: 10.0.1.40
Forward Port: 32299
```

4. En **Cache Assets**: Deshabilitado (opcional)
5. En **Block Common Exploits**: Habilitado ✅

### Paso 3: Configurar SSL

1. Ir a la pestaña **SSL**
2. Seleccionar **Request a new SSL Certificate**
3. Habilitar:
   - ✅ **Force SSL**
   - ✅ **HTTP/2 Support**
   - ✅ **HSTS Enabled**
4. Aceptar términos de Let's Encrypt
5. Click **Save**

### Paso 4: Configuración Avanzada (Opcional)

En la pestaña **Advanced**, agregar:

```nginx
# Aumentar límites para uploads
client_max_body_size 20M;

# Timeout para procesamiento de imágenes
proxy_read_timeout 300s;
proxy_connect_timeout 300s;
proxy_send_timeout 300s;

# Headers de seguridad
add_header X-Frame-Options "SAMEORIGIN" always;
add_header X-Content-Type-Options "nosniff" always;
add_header X-XSS-Protection "1; mode=block" always;
add_header Referrer-Policy "strict-origin-when-cross-origin" always;
```

---

## 🔒 SSL Let's Encrypt

### Verificación del Certificado

```bash
# Desde el servidor LogoAI
openssl s_client -connect logoai.tymtechnology.shop:443 -servername logoai.tymtechnology.shop

# Verificar expiración
echo | openssl s_client -servername logoai.tymtechnology.shop -connect logoai.tymtechnology.shop:443 2>/dev/null | openssl x509 -noout -dates
```

### Renovación Automática

Nginx Proxy Manager maneja la renovación automáticamente. Para verificar:

```bash
# En el servidor NPM (si es separado)
docker logs nginx-proxy-manager | grep -i "renew"
```

---

## ✅ Verificación del Despliegue

### Checklist de Verificación

- [ ] Contenedores/Servicios corriendo
- [ ] Base de datos accesible
- [ ] Redis funcionando
- [ ] Puerto 32299 accesible desde NPM
- [ ] SSL configurado y válido
- [ ] Dominio resolviendo correctamente
- [ ] Login funciona
- [ ] Editor carga
- [ ] Exportación de imágenes funciona

### Comandos de Verificación

```bash
# 1. Verificar servicios (Docker)
docker compose ps

# 2. Verificar servicios (Systemd)
sudo systemctl status logoai

# 3. Probar endpoint de salud
curl -s https://logoai.tymtechnology.shop/api/health/ | jq

# 4. Verificar base de datos
docker compose exec db psql -U logoai_user -d logoai_db -c "\dt"

# 5. Verificar Redis
docker compose exec redis redis-cli ping

# 6. Logs recientes
docker compose logs --tail=50 web
```

---

## 🔧 Solución de Problemas

### Problema: "Connection refused" en puerto 32299

```bash
# Verificar qué proceso usa el puerto
sudo ss -tlnp | grep 32299

# Verificar firewall
sudo ufw status
sudo iptables -L -n | grep 32299
```

### Problema: Error 502 en Nginx Proxy Manager

```bash
# Verificar que la app responde
curl http://10.0.1.40:32299/api/health/

# Verificar logs de la app
docker compose logs web | tail -50
```

### Problema: Certificado SSL no válido

```bash
# Verificar DNS
dig logoai.tymtechnology.shop
nslookup logoai.tymtechnology.shop

# Verificar que el dominio apunta al NPM correcto
ping logoai.tymtechnology.shop
```

### Problema: Permisos de archivos

```bash
# Docker
sudo chown -R 999:999 media/
sudo chmod -R 755 media/

# Instalación manual
sudo chown -R www-data:www-data /home/usuario/logoai
sudo chmod -R 755 /home/usuario/logoai
```

### Problema: Base de datos no conecta

```bash
# Verificar PostgreSQL
sudo -u postgres psql -c "\l"
sudo -u postgres psql -c "\du"

# Verificar conexión desde contenedor
docker compose exec web python -c "import psycopg2; conn = psycopg2.connect(host='db', database='logoai_db', user='logoai_user', password='tu_password')"
```

---

## 📝 Comandos Útiles

### Docker

```bash
# Ver logs en tiempo real
docker compose logs -f web

# Reiniciar servicios
docker compose restart

# Reconstruir imágenes
docker compose down
docker compose build --no-cache
docker compose up -d

# Acceder al contenedor
docker compose exec web bash

# Backup de base de datos
docker compose exec db pg_dump -U logoai_user logoai_db > backup_$(date +%Y%m%d).sql

# Restaurar base de datos
docker compose exec -T db psql -U logoai_user logoai_db < backup_20240101.sql
```

### Sistema

```bash
# Monitoreo de recursos
htop

# Espacio en disco
df -h

# Tamaño de contenedores
docker system df -v

# Limpiar Docker
docker system prune -a
```

---

## 📞 Soporte

- **Email:** soporte@tymtechnology.shop
- **Desarrollador:** T&M Technology Ec
- **Documentación:** Este archivo

---

## 🔄 Actualizaciones

Para actualizar la aplicación:

```bash
cd ~/logoai

# Backup
./scripts/backup.sh

# Actualizar código
git pull origin main  # o actualizar archivos manualmente

# Reconstruir y reiniciar (Docker)
docker compose down
docker compose build --no-cache
docker compose up -d
docker compose exec web python manage.py migrate
docker compose exec web python manage.py collectstatic --noinput
```

---

**© 2024 T&M Technology Ec - Todos los derechos reservados**
