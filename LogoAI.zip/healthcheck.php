<?php
/**
 * LogoAI Health Check
 * Author: T&M Technology Ec
 * Support: soporte@tymtechnology.shop
 */

header('Content-Type: application/json');

$checks = [
    'status' => 'healthy',
    'timestamp' => date('Y-m-d H:i:s'),
    'version' => '1.0.0',
    'checks' => []
];

// Database check
$dbPath = $_ENV['DB_PATH'] ?? '/var/www/html/data/logoai.db';
$checks['checks']['database'] = [
    'status' => file_exists($dbPath) ? 'ok' : 'warning',
    'writable' => is_writable(dirname($dbPath))
];

// Uploads directory
$uploadsPath = '/var/www/html/uploads';
$checks['checks']['uploads'] = [
    'status' => is_dir($uploadsPath) ? 'ok' : 'error',
    'writable' => is_writable($uploadsPath)
];

// PHP extensions
$checks['checks']['php_extensions'] = [
    'gd' => extension_loaded('gd') ? 'ok' : 'error',
    'pdo_sqlite' => extension_loaded('pdo_sqlite') ? 'ok' : 'error',
    'mbstring' => extension_loaded('mbstring') ? 'ok' : 'error',
    'zip' => extension_loaded('zip') ? 'ok' : 'error'
];

// Memory
$checks['checks']['memory'] = [
    'limit' => ini_get('memory_limit'),
    'usage' => memory_get_usage(true) / 1024 / 1024 . ' MB',
    'peak' => memory_get_peak_usage(true) / 1024 / 1024 . ' MB'
];

// Determine overall status
foreach ($checks['checks'] as $check) {
    if (is_array($check) && isset($check['status'])) {
        if ($check['status'] === 'error') {
            $checks['status'] = 'unhealthy';
            break;
        } elseif ($check['status'] === 'warning' && $checks['status'] === 'healthy') {
            $checks['status'] = 'degraded';
        }
    }
}

http_response_code($checks['status'] === 'healthy' ? 200 : 503);
echo json_encode($checks, JSON_PRETTY_PRINT);
