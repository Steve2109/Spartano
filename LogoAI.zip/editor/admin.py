"""
Configuración de admin para el editor
"""

from django.contrib import admin
from .models import Project, Layer, ShapeLibrary, Template, FontLibrary, ExportHistory


@admin.register(Project)
class ProjectAdmin(admin.ModelAdmin):
    list_display = ['name', 'user', 'canvas_width', 'canvas_height', 'is_template', 'updated_at']
    list_filter = ['is_template', 'is_public', 'created_at']
    search_fields = ['name', 'user__username', 'description']
    readonly_fields = ['id', 'created_at', 'updated_at']


@admin.register(Layer)
class LayerAdmin(admin.ModelAdmin):
    list_display = ['name', 'project', 'layer_type', 'z_index', 'visible', 'updated_at']
    list_filter = ['layer_type', 'visible', 'created_at']
    search_fields = ['name', 'project__name']
    readonly_fields = ['id', 'created_at', 'updated_at']


@admin.register(ShapeLibrary)
class ShapeLibraryAdmin(admin.ModelAdmin):
    list_display = ['name', 'shape_type', 'category', 'created_at']
    list_filter = ['shape_type', 'category']
    search_fields = ['name']


@admin.register(Template)
class TemplateAdmin(admin.ModelAdmin):
    list_display = ['name', 'category', 'is_active', 'is_premium', 'created_at']
    list_filter = ['category', 'is_active', 'is_premium']
    search_fields = ['name', 'description']


@admin.register(FontLibrary)
class FontLibraryAdmin(admin.ModelAdmin):
    list_display = ['name', 'family_name', 'category', 'is_google_font', 'is_active']
    list_filter = ['category', 'is_google_font', 'is_active']
    search_fields = ['name', 'family_name']


@admin.register(ExportHistory)
class ExportHistoryAdmin(admin.ModelAdmin):
    list_display = ['project', 'user', 'format', 'file_size', 'exported_at']
    list_filter = ['format', 'exported_at']
    search_fields = ['project__name', 'user__username']
    readonly_fields = ['exported_at']
