"""
Configuración de la app editor
"""

from django.apps import AppConfig


class EditorConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'editor'
    verbose_name = 'Editor'
