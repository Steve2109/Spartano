"""
Utilidades para el editor
"""

import re
import bleach
from django.core.exceptions import ValidationError
from PIL import Image


def sanitize_filename(filename):
    """
    Sanitiza nombres de archivo.
    Elimina caracteres peligrosos y limita longitud.
    """
    # Eliminar path traversal
    filename = filename.replace('..', '').replace('/', '').replace('\\', '')
    
    # Eliminar caracteres no permitidos
    filename = re.sub(r'[^\w\s.-]', '', filename)
    
    # Limitar longitud
    name, ext = filename.rsplit('.', 1) if '.' in filename else (filename, '')
    name = name[:100]
    ext = ext[:10]
    
    return f"{name}.{ext}" if ext else name


def sanitize_text(text, max_length=5000):
    """
    Sanitiza texto de entrada.
    Elimina HTML y limita longitud.
    """
    if not text:
        return ""
    
    # Eliminar tags HTML
    cleaned = bleach.clean(text, tags=[], strip=True)
    
    # Limitar longitud
    return cleaned[:max_length]


def validate_hex_color(color):
    """
    Valida formato de color hexadecimal.
    """
    if not color:
        return '#000000'
    
    # Agregar # si no está presente
    if not color.startswith('#'):
        color = '#' + color
    
    # Validar formato
    pattern = r'^#[0-9A-Fa-f]{6}$'
    if not re.match(pattern, color):
        raise ValidationError(f'Color inválido: {color}. Use formato #RRGGBB')
    
    return color


def hex_to_rgb(hex_color):
    """
    Convierte color hex a tupla RGB.
    """
    hex_color = hex_color.lstrip('#')
    return tuple(int(hex_color[i:i+2], 16) for i in (0, 2, 4))


def rgb_to_hex(rgb):
    """
    Convierte tupla RGB a hex.
    """
    return '#{:02x}{:02x}{:02x}'.format(rgb[0], rgb[1], rgb[2])


def validate_image_file(file):
    """
    Valida archivo de imagen.
    """
    max_size = 10 * 1024 * 1024  # 10MB
    allowed_types = ['image/jpeg', 'image/png', 'image/gif', 'image/webp', 'image/svg+xml']
    
    if file.size > max_size:
        raise ValidationError(f'Archivo excede 10MB: {file.size} bytes')
    
    # Verificar tipo con Pillow
    try:
        img = Image.open(file)
        file.seek(0)
        
        if img.format not in ['JPEG', 'PNG', 'GIF', 'WEBP', 'SVG']:
            raise ValidationError(f'Formato no soportado: {img.format}')
            
    except Exception as e:
        raise ValidationError(f'Archivo de imagen inválido: {str(e)}')
    
    return True


def get_image_dimensions(file):
    """
    Obtiene dimensiones de imagen.
    """
    try:
        img = Image.open(file)
        return img.width, img.height
    except:
        return None, None


def calculate_aspect_ratio(width, height):
    """
    Calcula ratio de aspecto.
    """
    if height == 0:
        return 0
    return width / height


def resize_maintain_aspect(width, height, max_width, max_height):
    """
    Redimensiona manteniendo aspecto.
    """
    if width <= max_width and height <= max_height:
        return width, height
    
    ratio = min(max_width / width, max_height / height)
    return int(width * ratio), int(height * ratio)


def generate_slug(text):
    """
    Genera slug a partir de texto.
    """
    # Eliminar acentos
    import unicodedata
    text = unicodedata.normalize('NFKD', text)
    text = text.encode('ascii', 'ignore').decode('utf-8')
    
    # Convertir a minúsculas y reemplazar espacios
    text = text.lower().strip()
    text = re.sub(r'[^\w\s-]', '', text)
    text = re.sub(r'[-\s]+', '-', text)
    
    return text[:100]


def truncate_text(text, length=50, suffix='...'):
    """
    Trunca texto con sufijo.
    """
    if len(text) <= length:
        return text
    return text[:length - len(suffix)] + suffix


def format_file_size(size_bytes):
    """
    Formatea tamaño de archivo legible.
    """
    if size_bytes < 1024:
        return f"{size_bytes} B"
    elif size_bytes < 1024 * 1024:
        return f"{size_bytes / 1024:.1f} KB"
    elif size_bytes < 1024 * 1024 * 1024:
        return f"{size_bytes / (1024 * 1024):.1f} MB"
    else:
        return f"{size_bytes / (1024 * 1024 * 1024):.2f} GB"


def validate_canvas_dimensions(width, height):
    """
    Valida dimensiones de canvas.
    """
    min_dim = 50
    max_dim = 5000
    
    if width < min_dim or width > max_dim:
        raise ValidationError(f'Ancho debe estar entre {min_dim} y {max_dim}')
    
    if height < min_dim or height > max_dim:
        raise ValidationError(f'Alto debe estar entre {min_dim} y {max_dim}')
    
    return True


def is_safe_url(url, allowed_hosts=None):
    """
    Verifica si URL es segura.
    """
    if not url:
        return False
    
    # Verificar protocolo
    if url.startswith('javascript:'):
        return False
    
    if url.startswith('data:'):
        return False
    
    # Verificar dominios permitidos si se especifica
    if allowed_hosts:
        from urllib.parse import urlparse
        parsed = urlparse(url)
        if parsed.hostname and parsed.hostname not in allowed_hosts:
            return False
    
    return True


def normalize_rotation(rotation):
    """
    Normaliza ángulo de rotación a 0-360.
    """
    rotation = rotation % 360
    if rotation < 0:
        rotation += 360
    return rotation


def interpolate_color(color1, color2, factor):
    """
    Interpola entre dos colores.
    """
    rgb1 = hex_to_rgb(color1)
    rgb2 = hex_to_rgb(color2)
    
    r = int(rgb1[0] + (rgb2[0] - rgb1[0]) * factor)
    g = int(rgb1[1] + (rgb2[1] - rgb1[1]) * factor)
    b = int(rgb1[2] + (rgb2[2] - rgb1[2]) * factor)
    
    return rgb_to_hex((r, g, b))


def parse_font_size(size_str):
    """
    Parsea tamaño de fuente de string.
    """
    try:
        # Extraer número
        size = int(re.findall(r'\d+', str(size_str))[0])
        return max(8, min(200, size))
    except:
        return 24  # Default


class LayerZIndexManager:
    """
    Gestiona z-index de capas.
    """
    
    @staticmethod
    def get_next_z_index(layers):
        """Obtiene el siguiente z-index disponible."""
        if not layers:
            return 0
        return max(layer.z_index for layer in layers) + 1
    
    @staticmethod
    def reorder_layers(layers):
        """Reordena z-index de capas secuencialmente."""
        sorted_layers = sorted(layers, key=lambda l: l.z_index)
        for i, layer in enumerate(sorted_layers):
            layer.z_index = i
            layer.save(update_fields=['z_index'])
        return sorted_layers
