"""
Vistas del editor
"""

import json
import bleach
from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import JsonResponse, HttpResponse
from django.db import transaction
from django_ratelimit.decorators import ratelimit
from django.views.decorators.http import require_http_methods
from django.views.decorators.csrf import csrf_exempt

from .models import Project, Layer, ShapeLibrary, Template, FontLibrary
from .forms import ProjectForm
from .image_processor import ImageProcessor


def sanitize_json_input(data):
    """Sanitizar entrada JSON."""
    if isinstance(data, dict):
        return {k: sanitize_json_input(v) for k, v in data.items()}
    elif isinstance(data, list):
        return [sanitize_json_input(item) for item in data]
    elif isinstance(data, str):
        return bleach.clean(data, tags=[], strip=True)
    return data


@login_required
def dashboard_view(request):
    """Vista del dashboard principal."""
    recent_projects = Project.objects.filter(
        user=request.user
    ).exclude(is_template=True).order_by('-updated_at')[:6]
    
    templates = Template.objects.filter(is_active=True)[:6]
    
    return render(request, 'editor/dashboard.html', {
        'recent_projects': recent_projects,
        'templates': templates,
    })


@login_required
def project_list_view(request):
    """Vista de lista de proyectos."""
    projects = Project.objects.filter(
        user=request.user
    ).exclude(is_template=True).order_by('-updated_at')
    
    return render(request, 'editor/project_list.html', {
        'projects': projects,
    })


@login_required
def editor_new_view(request):
    """Crear nuevo proyecto en el editor."""
    if request.method == 'POST':
        form = ProjectForm(request.POST)
        if form.is_valid():
            project = form.save(commit=False)
            project.user = request.user
            project.save()
            messages.success(request, 'Proyecto creado exitosamente.')
            return redirect('editor_edit', project_id=project.id)
    else:
        # Valores por defecto del usuario
        settings = request.user.settings
        initial = {
            'canvas_width': settings.default_canvas_width,
            'canvas_height': settings.default_canvas_height,
            'export_format': settings.default_format,
        }
        form = ProjectForm(initial=initial)
    
    return render(request, 'editor/new_project.html', {'form': form})


@login_required
def editor_edit_view(request, project_id):
    """Vista principal del editor."""
    project = get_object_or_404(Project, id=project_id, user=request.user)
    
    # Cargar capas existentes
    layers = Layer.objects.filter(project=project).order_by('z_index')
    
    # Cargar recursos
    shapes = ShapeLibrary.objects.filter(category='general')[:20]
    fonts = FontLibrary.objects.filter(is_active=True)
    
    return render(request, 'editor/editor.html', {
        'project': project,
        'layers_json': json.dumps([layer_to_dict(l) for l in layers]),
        'shapes': shapes,
        'fonts': fonts,
    })


@login_required
def editor_template_view(request, template_id):
    """Usar plantilla para crear nuevo proyecto."""
    template = get_object_or_404(Template, id=template_id, is_active=True)
    
    # Clonar el proyecto base
    with transaction.atomic():
        new_project = Project.objects.create(
            user=request.user,
            name=f"{template.name} (copia)",
            canvas_width=template.base_project.canvas_width,
            canvas_height=template.base_project.canvas_height,
            background_color=template.base_project.background_color,
            export_format=request.user.settings.default_format,
        )
        
        # Copiar capas
        for layer in template.base_project.layers.all():
            Layer.objects.create(
                project=new_project,
                z_index=layer.z_index,
                layer_type=layer.layer_type,
                name=layer.name,
                visible=layer.visible,
                locked=layer.locked,
                opacity=layer.opacity,
                x=layer.x,
                y=layer.y,
                width=layer.width,
                height=layer.height,
                rotation=layer.rotation,
                scale_x=layer.scale_x,
                scale_y=layer.scale_y,
                flip_x=layer.flip_x,
                flip_y=layer.flip_y,
                content_data=layer.content_data,
                style_data=layer.style_data,
            )
    
    messages.success(request, f'Plantilla "{template.name}" cargada.')
    return redirect('editor_edit', project_id=new_project.id)


@login_required
@ratelimit(key='user', rate='30/m', method='POST')
@require_http_methods(['POST'])
def save_project_view(request, project_id):
    """Guardar proyecto con capas."""
    project = get_object_or_404(Project, id=project_id, user=request.user)
    
    try:
        data = json.loads(request.body)
        data = sanitize_json_input(data)
        
        with transaction.atomic():
            # Actualizar proyecto
            project.name = data.get('name', project.name)[:200]
            project.canvas_width = min(max(data.get('width', 800), 50), 5000)
            project.canvas_height = min(max(data.get('height', 600), 50), 5000)
            project.background_color = data.get('background', '#ffffff')[:7]
            project.save()
            
            # Eliminar capas existentes y recrear
            project.layers.all().delete()
            
            for layer_data in data.get('layers', []):
                Layer.objects.create(
                    project=project,
                    z_index=layer_data.get('zIndex', 0),
                    layer_type=layer_data.get('type', 'text'),
                    name=layer_data.get('name', 'Capa')[:100],
                    visible=layer_data.get('visible', True),
                    locked=layer_data.get('locked', False),
                    opacity=min(max(layer_data.get('opacity', 1.0), 0.0), 1.0),
                    x=float(layer_data.get('x', 0)),
                    y=float(layer_data.get('y', 0)),
                    width=float(layer_data.get('width', 100)),
                    height=float(layer_data.get('height', 100)),
                    rotation=float(layer_data.get('rotation', 0)),
                    scale_x=float(layer_data.get('scaleX', 1.0)),
                    scale_y=float(layer_data.get('scaleY', 1.0)),
                    flip_x=layer_data.get('flipX', False),
                    flip_y=layer_data.get('flipY', False),
                    content_data=layer_data.get('content', {}),
                    style_data=layer_data.get('style', {}),
                )
        
        return JsonResponse({'success': True, 'message': 'Proyecto guardado'})
    
    except json.JSONDecodeError:
        return JsonResponse({'error': 'JSON inválido'}, status=400)
    except Exception as e:
        return JsonResponse({'error': str(e)}, status=500)


@login_required
def duplicate_project_view(request, project_id):
    """Duplicar proyecto existente."""
    project = get_object_or_404(Project, id=project_id, user=request.user)
    
    with transaction.atomic():
        new_project = Project.objects.create(
            user=request.user,
            name=f"{project.name} (copia)",
            canvas_width=project.canvas_width,
            canvas_height=project.canvas_height,
            background_color=project.background_color,
            export_format=project.export_format,
        )
        
        for layer in project.layers.all():
            Layer.objects.create(
                project=new_project,
                z_index=layer.z_index,
                layer_type=layer.layer_type,
                name=layer.name,
                visible=layer.visible,
                locked=layer.locked,
                opacity=layer.opacity,
                x=layer.x,
                y=layer.y,
                width=layer.width,
                height=layer.height,
                rotation=layer.rotation,
                scale_x=layer.scale_x,
                scale_y=layer.scale_y,
                flip_x=layer.flip_x,
                flip_y=layer.flip_y,
                content_data=layer.content_data,
                style_data=layer.style_data,
            )
    
    messages.success(request, 'Proyecto duplicado exitosamente.')
    return redirect('editor_edit', project_id=new_project.id)


@login_required
def delete_project_view(request, project_id):
    """Eliminar proyecto."""
    project = get_object_or_404(Project, id=project_id, user=request.user)
    
    if request.method == 'POST':
        project.delete()
        messages.success(request, 'Proyecto eliminado.')
        return redirect('project_list')
    
    return render(request, 'editor/confirm_delete.html', {'project': project})


@login_required
@ratelimit(key='user', rate='10/m', method='POST')
def export_project_view(request, project_id):
    """Exportar proyecto a imagen/PDF."""
    project = get_object_or_404(Project, id=project_id, user=request.user)
    
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            format_type = data.get('format', 'png').lower()
            quality = min(int(data.get('quality', 100)), 100)
            
            processor = ImageProcessor()
            result = processor.export_project(project, format_type, quality)
            
            return JsonResponse({
                'success': True,
                'download_url': result['url'],
                'filename': result['filename']
            })
        
        except Exception as e:
            return JsonResponse({'error': str(e)}, status=500)
    
    return JsonResponse({'error': 'Método no permitido'}, status=405)


def shape_library_view(request):
    """Obtener biblioteca de formas."""
    shapes = ShapeLibrary.objects.filter(category='general')
    return JsonResponse({
        'shapes': [
            {
                'id': str(s.id),
                'name': s.name,
                'type': s.shape_type,
                'svg': s.svg_path,
                'category': s.category,
            }
            for s in shapes
        ]
    })


def template_list_view(request):
    """Listar plantillas disponibles."""
    templates = Template.objects.filter(is_active=True).select_related('base_project')
    return render(request, 'editor/template_list.html', {
        'templates': templates,
    })


def font_list_view(request):
    """Obtener lista de fuentes."""
    fonts = FontLibrary.objects.filter(is_active=True)
    return JsonResponse({
        'fonts': [
            {
                'id': str(f.id),
                'name': f.name,
                'family': f.family_name,
                'category': f.category,
                'google': f.is_google_font,
            }
            for f in fonts
        ]
    })


def layer_to_dict(layer):
    """Convertir capa a diccionario para JSON."""
    return {
        'id': str(layer.id),
        'type': layer.layer_type,
        'name': layer.name,
        'zIndex': layer.z_index,
        'visible': layer.visible,
        'locked': layer.locked,
        'opacity': layer.opacity,
        'x': layer.x,
        'y': layer.y,
        'width': layer.width,
        'height': layer.height,
        'rotation': layer.rotation,
        'scaleX': layer.scale_x,
        'scaleY': layer.scale_y,
        'flipX': layer.flip_x,
        'flipY': layer.flip_y,
        'content': layer.content_data,
        'style': layer.style_data,
    }
