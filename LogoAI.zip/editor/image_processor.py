"""
Procesador de imágenes para el editor
Autor: T&M Technology Ec
"""

import io
import os
import uuid
from PIL import Image, ImageDraw, ImageFont, ImageFilter, ImageEnhance, ImageOps
from reportlab.pdfgen import canvas as pdf_canvas
from reportlab.lib.pagesizes import letter, A4
from reportlab.lib.utils import ImageReader
from svglib.svglib import svg2rlg
from io import BytesIO
import base64
import numpy as np

from django.conf import settings
from django.core.files.base import ContentFile
from django.core.files.storage import default_storage


class ImageProcessor:
    """Procesador de imágenes para exportación y manipulación."""
    
    SUPPORTED_FORMATS = ['png', 'jpg', 'jpeg', 'svg', 'pdf']
    
    def __init__(self):
        self.temp_dir = os.path.join(settings.MEDIA_ROOT, 'temp')
        os.makedirs(self.temp_dir, exist_ok=True)
    
    def export_project(self, project, format_type='png', quality=100):
        """Exportar proyecto a imagen o PDF."""
        if format_type not in self.SUPPORTED_FORMATS:
            raise ValueError(f"Formato no soportado: {format_type}")
        
        # Crear canvas base
        canvas = Image.new(
            'RGBA' if format_type in ['png', 'svg'] else 'RGB',
            (project.canvas_width, project.canvas_height),
            project.background_color
        )
        
        # Renderizar capas
        for layer in project.layers.filter(visible=True).order_by('z_index'):
            canvas = self._render_layer(canvas, layer)
        
        # Generar nombre de archivo
        filename = f"{project.name.replace(' ', '_')}_{uuid.uuid4().hex[:8]}.{format_type}"
        
        if format_type in ['png', 'jpg', 'jpeg']:
            return self._export_raster(canvas, filename, format_type, quality)
        elif format_type == 'pdf':
            return self._export_pdf(canvas, project, filename)
        elif format_type == 'svg':
            return self._export_svg(project, filename)
    
    def _render_layer(self, canvas, layer):
        """Renderizar una capa sobre el canvas."""
        if layer.layer_type == 'image' and layer.image_file:
            return self._render_image_layer(canvas, layer)
        elif layer.layer_type == 'text':
            return self._render_text_layer(canvas, layer)
        elif layer.layer_type == 'shape':
            return self._render_shape_layer(canvas, layer)
        return canvas
    
    def _render_image_layer(self, canvas, layer):
        """Renderizar capa de imagen."""
        try:
            # Cargar imagen
            img = Image.open(layer.image_file.path).convert('RGBA')
            
            # Aplicar transformaciones
            # 1. Escalar
            new_width = int(layer.width * layer.scale_x)
            new_height = int(layer.height * layer.scale_y)
            img = img.resize((new_width, new_height), Image.Resampling.LANCZOS)
            
            # 2. Rotar
            if layer.rotation != 0:
                img = img.rotate(-layer.rotation, expand=True, resample=Image.Resampling.BICUBIC)
            
            # 3. Flip
            if layer.flip_x:
                img = ImageOps.mirror(img)
            if layer.flip_y:
                img = ImageOps.flip(img)
            
            # 4. Opacidad
            if layer.opacity < 1.0:
                alpha = img.split()[3]
                alpha = alpha.point(lambda p: int(p * layer.opacity))
                img.putalpha(alpha)
            
            # 5. Pegar en canvas
            x = int(layer.x)
            y = int(layer.y)
            canvas.paste(img, (x, y), img)
            
        except Exception as e:
            print(f"Error renderizando imagen: {e}")
        
        return canvas
    
    def _render_text_layer(self, canvas, layer):
        """Renderizar capa de texto."""
        try:
            content = layer.content_data
            style = layer.style_data
            
            text = content.get('text', '')
            font_family = style.get('fontFamily', 'Arial')
            font_size = int(style.get('fontSize', 24))
            color = style.get('color', '#000000')
            
            # Crear capa de texto
            draw = ImageDraw.Draw(canvas)
            
            # Intentar cargar fuente
            try:
                font = ImageFont.truetype(f"{font_family}.ttf", font_size)
            except:
                font = ImageFont.load_default()
            
            # Calcular posición
            x = int(layer.x)
            y = int(layer.y)
            
            # Convertir color hex a RGB
            rgb_color = self._hex_to_rgb(color)
            
            # Dibujar texto
            draw.text((x, y), text, fill=rgb_color, font=font)
            
        except Exception as e:
            print(f"Error renderizando texto: {e}")
        
        return canvas
    
    def _render_shape_layer(self, canvas, layer):
        """Renderizar capa de forma."""
        try:
            content = layer.content_data
            style = layer.style_data
            
            shape_type = content.get('shapeType', 'rectangle')
            fill_color = style.get('fill', '#000000')
            stroke_color = style.get('stroke', '#000000')
            stroke_width = int(style.get('strokeWidth', 0))
            
            draw = ImageDraw.Draw(canvas)
            x, y = int(layer.x), int(layer.y)
            w, h = int(layer.width), int(layer.height)
            
            fill_rgb = self._hex_to_rgb(fill_color)
            stroke_rgb = self._hex_to_rgb(stroke_color) if stroke_width > 0 else None
            
            if shape_type == 'rectangle':
                draw.rectangle(
                    [x, y, x + w, y + h],
                    fill=fill_rgb,
                    outline=stroke_rgb,
                    width=stroke_width
                )
            elif shape_type == 'circle':
                draw.ellipse(
                    [x, y, x + w, y + h],
                    fill=fill_rgb,
                    outline=stroke_rgb,
                    width=stroke_width
                )
            
        except Exception as e:
            print(f"Error renderizando forma: {e}")
        
        return canvas
    
    def _export_raster(self, image, filename, format_type, quality):
        """Exportar imagen raster (PNG/JPG)."""
        buffer = BytesIO()
        
        if format_type == 'png':
            image.save(buffer, format='PNG', optimize=True)
        else:  # jpeg
            # Convertir a RGB para JPEG
            if image.mode == 'RGBA':
                # Crear fondo blanco
                background = Image.new('RGB', image.size, (255, 255, 255))
                background.paste(image, mask=image.split()[3])
                image = background
            image.save(buffer, format='JPEG', quality=quality, optimize=True)
        
        buffer.seek(0)
        
        # Guardar en storage
        path = f"exports/{filename}"
        saved_path = default_storage.save(path, ContentFile(buffer.getvalue()))
        
        return {
            'url': f"{settings.MEDIA_URL}{saved_path}",
            'filename': filename,
            'path': saved_path
        }
    
    def _export_pdf(self, image, project, filename):
        """Exportar a PDF."""
        buffer = BytesIO()
        
        # Convertir imagen a modo RGB si es necesario
        if image.mode == 'RGBA':
            background = Image.new('RGB', image.size, (255, 255, 255))
            background.paste(image, mask=image.split()[3])
            image = background
        
        # Guardar imagen temporalmente
        temp_img = BytesIO()
        image.save(temp_img, format='PNG')
        temp_img.seek(0)
        
        # Crear PDF
        c = pdf_canvas.Canvas(buffer, pagesize=(project.canvas_width, project.canvas_height))
        img_reader = ImageReader(temp_img)
        c.drawImage(img_reader, 0, 0, width=project.canvas_width, height=project.canvas_height)
        c.save()
        
        buffer.seek(0)
        
        # Guardar
        path = f"exports/{filename}"
        saved_path = default_storage.save(path, ContentFile(buffer.getvalue()))
        
        return {
            'url': f"{settings.MEDIA_URL}{saved_path}",
            'filename': filename,
            'path': saved_path
        }
    
    def _export_svg(self, project, filename):
        """Exportar a SVG (generación básica)."""
        svg_parts = [
            f'<?xml version="1.0" encoding="UTF-8"?>',
            f'<svg xmlns="http://www.w3.org/2000/svg" width="{project.canvas_width}" height="{project.canvas_height}">',
            f'<rect width="100%" height="100%" fill="{project.background_color}"/>'
        ]
        
        for layer in project.layers.filter(visible=True).order_by('z_index'):
            svg_element = self._layer_to_svg(layer)
            if svg_element:
                svg_parts.append(svg_element)
        
        svg_parts.append('</svg>')
        svg_content = '\n'.join(svg_parts)
        
        # Guardar
        path = f"exports/{filename}"
        saved_path = default_storage.save(path, ContentFile(svg_content.encode('utf-8')))
        
        return {
            'url': f"{settings.MEDIA_URL}{saved_path}",
            'filename': filename,
            'path': saved_path
        }
    
    def _layer_to_svg(self, layer):
        """Convertir capa a elemento SVG."""
        if layer.layer_type == 'shape':
            content = layer.content_data
            style = layer.style_data
            shape_type = content.get('shapeType', 'rectangle')
            
            x, y = layer.x, layer.y
            w, h = layer.width, layer.height
            fill = style.get('fill', '#000000')
            
            if shape_type == 'rectangle':
                return f'<rect x="{x}" y="{y}" width="{w}" height="{h}" fill="{fill}"/>'
            elif shape_type == 'circle':
                cx, cy = x + w/2, y + h/2
                r = min(w, h) / 2
                return f'<circle cx="{cx}" cy="{cy}" r="{r}" fill="{fill}"/>'
        
        elif layer.layer_type == 'text':
            content = layer.content_data
            style = layer.style_data
            text = content.get('text', '')
            x, y = layer.x, layer.y
            font_size = style.get('fontSize', 24)
            fill = style.get('color', '#000000')
            
            # Escapar caracteres especiales
            text = text.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')
            
            return f'<text x="{x}" y="{y + font_size}" font-size="{font_size}" fill="{fill}">{text}</text>'
        
        return None
    
    def _hex_to_rgb(self, hex_color):
        """Convertir color hex a tupla RGB."""
        hex_color = hex_color.lstrip('#')
        return tuple(int(hex_color[i:i+2], 16) for i in (0, 2, 4))
    
    def crop_image(self, image_path, x, y, width, height):
        """Recortar imagen."""
        with Image.open(image_path) as img:
            cropped = img.crop((x, y, x + width, y + height))
            buffer = BytesIO()
            cropped.save(buffer, format=img.format or 'PNG')
            buffer.seek(0)
            return buffer
    
    def resize_image(self, image_path, width, height, maintain_aspect=True):
        """Redimensionar imagen."""
        with Image.open(image_path) as img:
            if maintain_aspect:
                img.thumbnail((width, height), Image.Resampling.LANCZOS)
            else:
                img = img.resize((width, height), Image.Resampling.LANCZOS)
            
            buffer = BytesIO()
            img.save(buffer, format=img.format or 'PNG')
            buffer.seek(0)
            return buffer
    
    def apply_filter(self, image_path, filter_type, **params):
        """Aplicar filtros a imagen."""
        with Image.open(image_path) as img:
            if filter_type == 'blur':
                radius = params.get('radius', 2)
                img = img.filter(ImageFilter.GaussianBlur(radius))
            elif filter_type == 'sharpen':
                img = img.filter(ImageFilter.SHARPEN)
            elif filter_type == 'brightness':
                factor = params.get('factor', 1.0)
                enhancer = ImageEnhance.Brightness(img)
                img = enhancer.enhance(factor)
            elif filter_type == 'contrast':
                factor = params.get('factor', 1.0)
                enhancer = ImageEnhance.Contrast(img)
                img = enhancer.enhance(factor)
            elif filter_type == 'saturation':
                factor = params.get('factor', 1.0)
                enhancer = ImageEnhance.Color(img)
                img = enhancer.enhance(factor)
            elif filter_type == 'grayscale':
                img = ImageOps.grayscale(img)
            elif filter_type == 'sepia':
                img = self._apply_sepia(img)
            
            buffer = BytesIO()
            img.save(buffer, format='PNG')
            buffer.seek(0)
            return buffer
    
    def _apply_sepia(self, image):
        """Aplicar efecto sepia."""
        # Convertir a escala de grises primero
        grayscale = ImageOps.grayscale(image)
        # Aplicar tono sepia
        sepia = ImageOps.colorize(grayscale, '#704214', '#C0C080')
        return sepia
    
    def remove_background(self, image_path):
        """Eliminar fondo simple (basado en color)."""
        with Image.open(image_path) as img:
            if img.mode != 'RGBA':
                img = img.convert('RGBA')
            
            # Obtener color del primer píxel como referencia
            datas = img.getdata()
            bg_color = datas[0][:3]
            
            new_data = []
            for item in datas:
                # Si el color es similar al fondo, hacer transparente
                if self._color_similar(item[:3], bg_color, threshold=30):
                    new_data.append((255, 255, 255, 0))
                else:
                    new_data.append(item)
            
            img.putdata(new_data)
            
            buffer = BytesIO()
            img.save(buffer, format='PNG')
            buffer.seek(0)
            return buffer
    
    def _color_similar(self, color1, color2, threshold=30):
        """Verificar si dos colores son similares."""
        return all(abs(c1 - c2) < threshold for c1, c2 in zip(color1, color2))
