"""
URLs del editor
"""

from django.urls import path
from . import views

urlpatterns = [
    # Dashboard
    path('', views.dashboard_view, name='dashboard'),
    path('projects/', views.project_list_view, name='project_list'),
    
    # Editor
    path('new/', views.editor_new_view, name='editor_new'),
    path('edit/<uuid:project_id>/', views.editor_edit_view, name='editor_edit'),
    path('template/<uuid:template_id>/', views.editor_template_view, name='editor_template'),
    
    # Operaciones
    path('project/<uuid:project_id>/save/', views.save_project_view, name='save_project'),
    path('project/<uuid:project_id>/duplicate/', views.duplicate_project_view, name='duplicate_project'),
    path('project/<uuid:project_id>/delete/', views.delete_project_view, name='delete_project'),
    path('project/<uuid:project_id>/export/', views.export_project_view, name='export_project'),
    
    # Recursos
    path('shapes/', views.shape_library_view, name='shape_library'),
    path('templates/', views.template_list_view, name='template_list'),
    path('fonts/', views.font_list_view, name='font_list'),
]
