"""
Tareas Celery para el editor
"""

from celery import shared_task
from django.core.files.storage import default_storage
from .models import Project, ExportHistory
from .image_processor import ImageProcessor
import logging

logger = logging.getLogger('logoai')


@shared_task(bind=True, max_retries=3)
def export_project_task(self, project_id, format_type, quality, user_id):
    """
    Tarea asíncrona para exportar proyectos.
    
    Args:
        project_id: UUID del proyecto
        format_type: Formato de exportación (png, jpg, svg, pdf)
        quality: Calidad de exportación (1-100)
        user_id: ID del usuario que solicitó la exportación
    """
    try:
        project = Project.objects.get(id=project_id)
        processor = ImageProcessor()
        
        # Ejecutar exportación
        result = processor.export_project(project, format_type, quality)
        
        # Registrar en historial
        ExportHistory.objects.create(
            project=project,
            user_id=user_id,
            format=format_type,
            file=result['path'],
            file_size=default_storage.size(result['path']),
            dimensions=f"{project.canvas_width}x{project.canvas_height}"
        )
        
        logger.info(f"Exportación exitosa: {project.name} -> {result['filename']}")
        
        return {
            'success': True,
            'download_url': result['url'],
            'filename': result['filename']
        }
        
    except Project.DoesNotExist:
        logger.error(f"Proyecto no encontrado: {project_id}")
        return {'success': False, 'error': 'Proyecto no encontrado'}
        
    except Exception as exc:
        logger.error(f"Error en exportación: {str(exc)}")
        # Reintentar en caso de error temporal
        raise self.retry(exc=exc, countdown=60)


@shared_task
def cleanup_old_exports():
    """
    Limpia archivos de exportación antiguos (más de 30 días).
    """
    from datetime import datetime, timedelta
    
    cutoff_date = datetime.now() - timedelta(days=30)
    old_exports = ExportHistory.objects.filter(exported_at__lt=cutoff_date)
    
    deleted_count = 0
    for export in old_exports:
        try:
            if export.file:
                default_storage.delete(export.file.name)
            export.delete()
            deleted_count += 1
        except Exception as e:
            logger.warning(f"Error eliminando exportación {export.id}: {e}")
    
    logger.info(f"Limpieza completada: {deleted_count} exportaciones eliminadas")
    return deleted_count


@shared_task
def generate_project_thumbnail(project_id):
    """
    Genera thumbnail para un proyecto.
    """
    try:
        project = Project.objects.get(id=project_id)
        processor = ImageProcessor()
        
        # Exportar a menor resolución para thumbnail
        result = processor.export_project(project, 'png', 80)
        
        # TODO: Redimensionar a thumbnail
        project.thumbnail = result['path']
        project.save(update_fields=['thumbnail'])
        
        logger.info(f"Thumbnail generado: {project.name}")
        return True
        
    except Exception as e:
        logger.error(f"Error generando thumbnail: {e}")
        return False


@shared_task
def process_image_async(layer_id, operation, params=None):
    """
    Procesa una imagen en background.
    
    Args:
        layer_id: ID de la capa
        operation: Operación a realizar (crop, resize, filter, etc.)
        params: Parámetros de la operación
    """
    from .models import Layer
    
    try:
        layer = Layer.objects.get(id=layer_id)
        processor = ImageProcessor()
        
        if not layer.image_file:
            return {'success': False, 'error': 'Capa sin imagen'}
        
        # Ejecutar operación
        if operation == 'crop':
            result = processor.crop_image(
                layer.image_file.path,
                params.get('x', 0),
                params.get('y', 0),
                params.get('width', 100),
                params.get('height', 100)
            )
        elif operation == 'resize':
            result = processor.resize_image(
                layer.image_file.path,
                params.get('width', 100),
                params.get('height', 100),
                params.get('maintain_aspect', True)
            )
        elif operation == 'filter':
            result = processor.apply_filter(
                layer.image_file.path,
                params.get('filter_type', 'blur'),
                **params.get('params', {})
            )
        else:
            return {'success': False, 'error': 'Operación no soportada'}
        
        # Guardar resultado
        from django.core.files.base import ContentFile
        import uuid
        
        filename = f"processed_{uuid.uuid4().hex[:8]}.png"
        saved_path = default_storage.save(
            f'processed/{filename}',
            ContentFile(result.getvalue())
        )
        
        # Actualizar capa
        layer.image_file = saved_path
        layer.save(update_fields=['image_file'])
        
        return {
            'success': True,
            'url': f'/media/{saved_path}',
            'filename': filename
        }
        
    except Layer.DoesNotExist:
        return {'success': False, 'error': 'Capa no encontrada'}
    except Exception as e:
        logger.error(f"Error procesando imagen: {e}")
        return {'success': False, 'error': str(e)}
