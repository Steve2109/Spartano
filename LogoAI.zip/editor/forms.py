"""
Formularios del editor
"""

from django import forms
from .models import Project


class ProjectForm(forms.ModelForm):
    """Formulario para crear/editar proyecto."""
    
    class Meta:
        model = Project
        fields = ['name', 'canvas_width', 'canvas_height', 'background_color', 'export_format', 'description']
        widgets = {
            'name': forms.TextInput(attrs={'maxlength': 200}),
            'canvas_width': forms.NumberInput(attrs={'min': 50, 'max': 5000}),
            'canvas_height': forms.NumberInput(attrs={'min': 50, 'max': 5000}),
            'background_color': forms.TextInput(attrs={'type': 'color'}),
            'description': forms.Textarea(attrs={'rows': 3}),
        }
    
    def clean_name(self):
        """Sanitizar nombre."""
        name = self.cleaned_data.get('name', '').strip()
        if not name:
            raise forms.ValidationError('El nombre es requerido.')
        return name[:200]
    
    def clean_background_color(self):
        """Validar color hexadecimal."""
        color = self.cleaned_data.get('background_color', '#ffffff')
        if not color.startswith('#') or len(color) != 7:
            raise forms.ValidationError('Color inválido. Use formato #RRGGBB')
        return color
