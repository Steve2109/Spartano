"""
Modelos del editor de logos
Autor: T&M Technology Ec
"""

import uuid
from django.db import models
from django.contrib.auth.models import User
from django.core.validators import MinValueValidator, MaxValueValidator


class Project(models.Model):
    """Proyecto de diseño de logo."""
    
    FORMAT_CHOICES = [
        ('png', 'PNG'),
        ('jpg', 'JPEG'),
        ('svg', 'SVG'),
        ('pdf', 'PDF'),
    ]
    
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='projects')
    name = models.CharField(max_length=200, default='Proyecto sin nombre')
    description = models.TextField(blank=True)
    
    # Dimensiones del canvas
    canvas_width = models.IntegerField(
        default=800,
        validators=[MinValueValidator(50), MaxValueValidator(5000)]
    )
    canvas_height = models.IntegerField(
        default=600,
        validators=[MinValueValidator(50), MaxValueValidator(5000)]
    )
    background_color = models.CharField(max_length=7, default='#ffffff')
    
    # Configuración de exportación
    export_format = models.CharField(max_length=10, choices=FORMAT_CHOICES, default='png')
    export_quality = models.IntegerField(
        default=100,
        validators=[MinValueValidator(1), MaxValueValidator(100)]
    )
    
    # Metadatos
    is_public = models.BooleanField(default=False)
    is_template = models.BooleanField(default=False)
    thumbnail = models.ImageField(upload_to='thumbnails/', blank=True, null=True)
    
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        ordering = ['-updated_at']
        verbose_name = 'Proyecto'
        verbose_name_plural = 'Proyectos'
    
    def __str__(self):
        return self.name


class Layer(models.Model):
    """Capa individual en un proyecto."""
    
    LAYER_TYPES = [
        ('text', 'Texto'),
        ('image', 'Imagen'),
        ('shape', 'Forma'),
        ('group', 'Grupo'),
    ]
    
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    project = models.ForeignKey(Project, on_delete=models.CASCADE, related_name='layers')
    
    # Orden de la capa
    z_index = models.IntegerField(default=0)
    
    # Tipo de capa
    layer_type = models.CharField(max_length=20, choices=LAYER_TYPES, default='text')
    name = models.CharField(max_length=100, default='Capa')
    
    # Visibilidad y bloqueo
    visible = models.BooleanField(default=True)
    locked = models.BooleanField(default=False)
    opacity = models.FloatField(
        default=1.0,
        validators=[MinValueValidator(0.0), MaxValueValidator(1.0)]
    )
    
    # Transformaciones
    x = models.FloatField(default=0)
    y = models.FloatField(default=0)
    width = models.FloatField(default=100)
    height = models.FloatField(default=100)
    rotation = models.FloatField(default=0)
    scale_x = models.FloatField(default=1.0)
    scale_y = models.FloatField(default=1.0)
    
    # Flip
    flip_x = models.BooleanField(default=False)
    flip_y = models.BooleanField(default=False)
    
    # Datos específicos según tipo (JSON)
    content_data = models.JSONField(default=dict)
    style_data = models.JSONField(default=dict)
    
    # Para imágenes
    image_file = models.ImageField(upload_to='layer_images/', blank=True, null=True)
    
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        ordering = ['z_index', 'created_at']
        verbose_name = 'Capa'
        verbose_name_plural = 'Capas'
    
    def __str__(self):
        return f"{self.name} ({self.layer_type}) - {self.project.name}"


class ShapeLibrary(models.Model):
    """Biblioteca de formas predefinidas."""
    
    SHAPE_TYPES = [
        ('rectangle', 'Rectángulo'),
        ('circle', 'Círculo'),
        ('triangle', 'Triángulo'),
        ('polygon', 'Polígono'),
        ('star', 'Estrella'),
        ('heart', 'Corazón'),
        ('arrow', 'Flecha'),
        ('custom', 'Personalizada'),
    ]
    
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    name = models.CharField(max_length=100)
    shape_type = models.CharField(max_length=20, choices=SHAPE_TYPES)
    svg_path = models.TextField()
    category = models.CharField(max_length=50, default='general')
    
    # Preview
    preview = models.ImageField(upload_to='shape_previews/', blank=True, null=True)
    
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        verbose_name = 'Forma'
        verbose_name_plural = 'Formas'
        ordering = ['category', 'name']
    
    def __str__(self):
        return self.name


class Template(models.Model):
    """Plantillas predefinidas para logos."""
    
    CATEGORY_CHOICES = [
        ('business', 'Negocios'),
        ('technology', 'Tecnología'),
        ('food', 'Comida'),
        ('fashion', 'Moda'),
        ('sports', 'Deportes'),
        ('education', 'Educación'),
        ('health', 'Salud'),
        ('music', 'Música'),
        ('other', 'Otros'),
    ]
    
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    name = models.CharField(max_length=200)
    description = models.TextField(blank=True)
    category = models.CharField(max_length=20, choices=CATEGORY_CHOICES, default='other')
    
    # El proyecto base que se clona
    base_project = models.OneToOneField(
        Project,
        on_delete=models.CASCADE,
        related_name='template_instance'
    )
    
    thumbnail = models.ImageField(upload_to='template_thumbnails/')
    is_active = models.BooleanField(default=True)
    is_premium = models.BooleanField(default=False)
    
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        verbose_name = 'Plantilla'
        verbose_name_plural = 'Plantillas'
        ordering = ['category', 'name']
    
    def __str__(self):
        return self.name


class FontLibrary(models.Model):
    """Biblioteca de fuentes disponibles."""
    
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    name = models.CharField(max_length=100)
    family_name = models.CharField(max_length=100)
    font_file = models.FileField(upload_to='fonts/')
    is_google_font = models.BooleanField(default=False)
    google_font_url = models.URLField(blank=True)
    category = models.CharField(max_length=50, default='sans-serif')
    
    is_active = models.BooleanField(default=True)
    
    class Meta:
        verbose_name = 'Fuente'
        verbose_name_plural = 'Fuentes'
    
    def __str__(self):
        return self.name


class ExportHistory(models.Model):
    """Historial de exportaciones."""
    
    FORMAT_CHOICES = [
        ('png', 'PNG'),
        ('jpg', 'JPEG'),
        ('svg', 'SVG'),
        ('pdf', 'PDF'),
    ]
    
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    project = models.ForeignKey(Project, on_delete=models.CASCADE, related_name='exports')
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='export_history')
    
    format = models.CharField(max_length=10, choices=FORMAT_CHOICES)
    file = models.FileField(upload_to='exports/')
    file_size = models.IntegerField()
    dimensions = models.CharField(max_length=50)
    
    exported_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        verbose_name = 'Exportación'
        verbose_name_plural = 'Exportaciones'
        ordering = ['-exported_at']
    
    def __str__(self):
        return f"{self.project.name} - {self.format.upper()}"
