#!/bin/bash
# Logo AI Creator - Installation Script for Debian 13
# Author: T&M Technology Ec <soporte@tymtechnology.shop>
# Website: https://logoai.tymtechnology.shop

set -e  # Exit on any error

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
INSTALL_DIR="/var/www/logoai"
APP_PORT=32299
DOMAIN="logoai.tymtechnology.shop"
NODE_VERSION=20

# Function to print colored messages
print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check if running as root
check_root() {
    if [[ $EUID -eq 0 ]]; then
        print_error "This script should not be run as root for security reasons"
        print_status "Please run as a regular user with sudo privileges"
        exit 1
    fi
}

# Check Debian version
check_debian_version() {
    if [[ ! -f /etc/debian_version ]]; then
        print_error "This script is designed for Debian systems only"
        exit 1
    fi
    
    local version=$(cat /etc/debian_version | cut -d. -f1)
    if [[ "$version" != "13" && "$version" != "12" ]]; then
        print_warning "This script is optimized for Debian 13. You have version: $(cat /etc/debian_version)"
        read -p "Do you want to continue anyway? (y/N): " continue_anyway
        if [[ ! $continue_anyway =~ ^[Yy]$ ]]; then
            exit 1
        fi
    fi
}

# Update system packages
update_system() {
    print_status "Updating system packages..."
    sudo apt update && sudo apt upgrade -y
    print_success "System updated"
}

# Install essential packages
install_essentials() {
    print_status "Installing essential packages..."
    sudo apt install -y \
        curl \
        wget \
        git \
        build-essential \
        python3 \
        make \
        g++ \
        ca-certificates \
        gnupg \
        lsb-release \
        apt-transport-https \
        software-properties-common
    print_success "Essential packages installed"
}

# Install Node.js 20
install_nodejs() {
    print_status "Installing Node.js ${NODE_VERSION}..."
    
    # Add NodeSource repository
    curl -fsSL https://deb.nodesource.com/setup_${NODE_VERSION}.x | sudo -E bash -
    
    # Install Node.js
    sudo apt install -y nodejs
    
    # Verify installation
    node_version=$(node --version)
    npm_version=$(npm --version)
    
    print_success "Node.js ${node_version} installed"
    print_success "npm ${npm_version} installed"
}

# Install PM2
install_pm2() {
    print_status "Installing PM2 process manager..."
    sudo npm install -g pm2
    
    # Setup PM2 startup script
    sudo env PATH=$PATH:/usr/bin pm2 startup systemd -u $USER --hp $HOME
    
    print_success "PM2 installed"
}

# Install Docker (optional)
install_docker() {
    read -p "Do you want to install Docker? (y/N): " install_docker
    if [[ $install_docker =~ ^[Yy]$ ]]; then
        print_status "Installing Docker..."
        
        # Add Docker's official GPG key
        sudo install -m 0755 -d /etc/apt/keyrings
        curl -fsSL https://download.docker.com/linux/debian/gpg | sudo gpg --dearmor -o /etc/apt/keyrings/docker.gpg
        sudo chmod a+r /etc/apt/keyrings/docker.gpg
        
        # Add Docker repository
        echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/debian $(lsb_release -cs) stable" | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null
        
        # Update and install Docker
        sudo apt update
        sudo apt install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
        
        # Add user to docker group
        sudo usermod -aG docker $USER
        
        print_success "Docker installed"
        print_warning "You need to log out and log back in for Docker permissions to take effect"
    fi
}

# Create application directory
setup_app_directory() {
    print_status "Setting up application directory..."
    
    # Create directory
    sudo mkdir -p ${INSTALL_DIR}
    sudo chown $USER:$USER ${INSTALL_DIR}
    
    print_success "Directory ${INSTALL_DIR} created"
}

# Clone or copy application
deploy_application() {
    print_status "Deploying Logo AI Creator..."
    
    cd ${INSTALL_DIR}
    
    # Check if git repository exists
    if [ -d ".git" ]; then
        print_status "Updating existing repository..."
        git pull
    else
        print_status "Please copy the application files to ${INSTALL_DIR}"
        print_status "Or provide the git repository URL to clone:"
        read -p "Git repository URL (leave empty to skip): " repo_url
        
        if [[ ! -z $repo_url ]]; then
            git clone $repo_url .
        else
            print_warning "No repository URL provided. Please manually copy the files to ${INSTALL_DIR}"
            print_status "Press Enter when files are in place..."
            read
        fi
    fi
    
    print_success "Application deployed"
}

# Install dependencies
install_dependencies() {
    print_status "Installing dependencies..."
    
    cd ${INSTALL_DIR}
    
    # Install root dependencies
    npm install
    
    # Install backend dependencies
    cd backend
    npm install
    
    # Install frontend dependencies
    cd ../frontend
    npm install
    
    cd ${INSTALL_DIR}
    print_success "Dependencies installed"
}

# Build application
build_application() {
    print_status "Building application..."
    
    cd ${INSTALL_DIR}
    
    # Build frontend
    cd frontend
    npm run build
    
    # Build backend
    cd ../backend
    npm run build
    
    cd ${INSTALL_DIR}
    print_success "Application built"
}

# Create environment file
create_env_file() {
    print_status "Creating environment configuration..."
    
    cd ${INSTALL_DIR}/backend
    
    cat > .env << EOF
NODE_ENV=production
PORT=${APP_PORT}
HOST=0.0.0.0
CORS_ORIGIN=https://${DOMAIN}
RATE_LIMIT_WINDOW_MS=900000
RATE_LIMIT_MAX_REQUESTS=100
MAX_FILE_SIZE=10485760
MAX_UPLOADS_PER_HOUR=50
LOG_LEVEL=info
EOF
    
    print_success "Environment file created"
}

# Create required directories
create_directories() {
    print_status "Creating required directories..."
    
    cd ${INSTALL_DIR}
    
    mkdir -p uploads logs
    
    print_success "Directories created"
}

# Configure firewall
configure_firewall() {
    print_status "Configuring firewall..."
    
    # Check if ufw is installed
    if command -v ufw &> /dev/null; then
        sudo ufw allow ${APP_PORT}/tcp comment 'Logo AI Creator'
        sudo ufw allow ssh
        print_success "Firewall configured"
    else
        print_warning "UFW not installed, skipping firewall configuration"
    fi
}

# Start application with PM2
start_application() {
    print_status "Starting application with PM2..."
    
    cd ${INSTALL_DIR}
    
    # Check if already running
    if pm2 list | grep -q "logoai-backend"; then
        print_status "Application already running, restarting..."
        pm2 restart ecosystem.config.js
    else
        pm2 start ecosystem.config.js
    fi
    
    # Save PM2 configuration
    pm2 save
    
    print_success "Application started"
}

# Setup Nginx (optional)
setup_nginx() {
    read -p "Do you want to install and configure Nginx? (y/N): " setup_nginx
    if [[ $setup_nginx =~ ^[Yy]$ ]]; then
        print_status "Installing Nginx..."
        sudo apt install -y nginx
        
        # Create Nginx configuration
        sudo tee /etc/nginx/sites-available/logoai << 'EOF'
server {
    listen 80;
    server_name logoai.tymtechnology.shop;
    
    location / {
        proxy_pass http://127.0.0.1:32299;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }
}
EOF
        
        # Enable site
        sudo ln -sf /etc/nginx/sites-available/logoai /etc/nginx/sites-enabled/logoai
        sudo nginx -t && sudo systemctl restart nginx
        
        print_success "Nginx configured"
        
        # SSL with Let's Encrypt
        read -p "Do you want to setup SSL with Let's Encrypt? (y/N): " setup_ssl
        if [[ $setup_ssl =~ ^[Yy]$ ]]; then
            sudo apt install -y certbot python3-certbot-nginx
            sudo certbot --nginx -d ${DOMAIN}
            print_success "SSL certificate installed"
        fi
    fi
}

# Display final information
display_info() {
    echo ""
    echo "========================================"
    echo "  Logo AI Creator - Installation Complete"
    echo "========================================"
    echo ""
    print_success "Application installed at: ${INSTALL_DIR}"
    print_success "Application running on: http://localhost:${APP_PORT}"
    print_success "Health check: http://localhost:${APP_PORT}/api/health"
    echo ""
    echo "Useful commands:"
    echo "  pm2 status              - Check application status"
    echo "  pm2 logs logoai-backend - View logs"
    echo "  pm2 restart all         - Restart application"
    echo "  pm2 stop all            - Stop application"
    echo ""
    echo "Configuration file:"
    echo "  ${INSTALL_DIR}/backend/.env"
    echo ""
    echo "For Nginx Proxy Manager setup, see:"
    echo "  deployments-docs/README.md"
    echo ""
    echo "Support: soporte@tymtechnology.shop"
    echo "========================================"
}

# Main installation function
main() {
    echo ""
    echo "========================================"
    echo "  Logo AI Creator - Debian 13 Installer"
    echo "  T&M Technology Ec"
    echo "========================================"
    echo ""
    
    check_root
    check_debian_version
    
    print_status "Starting installation..."
    
    update_system
    install_essentials
    install_nodejs
    install_pm2
    install_docker
    setup_app_directory
    deploy_application
    install_dependencies
    build_application
    create_env_file
    create_directories
    configure_firewall
    start_application
    setup_nginx
    
    display_info
}

# Run main function
main "$@"
