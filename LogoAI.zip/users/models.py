"""
Modelos de usuarios extendidos
"""

from django.contrib.auth.models import User
from django.db import models


class UserProfile(models.Model):
    """Perfil extendido de usuario."""
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='profile')
    avatar = models.ImageField(upload_to='avatars/', blank=True, null=True)
    company = models.CharField(max_length=200, blank=True)
    phone = models.CharField(max_length=20, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return f"Perfil de {self.user.username}"


class UserSettings(models.Model):
    """Configuraciones de usuario."""
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='settings')
    default_canvas_width = models.IntegerField(default=800)
    default_canvas_height = models.IntegerField(default=600)
    default_format = models.CharField(max_length=10, default='png')
    auto_save = models.BooleanField(default=True)
    theme = models.CharField(max_length=20, default='light')
    
    def __str__(self):
        return f"Configuraciones de {self.user.username}"
