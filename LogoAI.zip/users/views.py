"""
Vistas de usuarios
"""

from django.shortcuts import render, redirect
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.db import transaction
from .forms import UserRegisterForm, UserProfileForm, UserSettingsForm
from .models import UserProfile, UserSettings


def register_view(request):
    """Vista de registro de usuario."""
    if request.user.is_authenticated:
        return redirect('home')
    
    if request.method == 'POST':
        form = UserRegisterForm(request.POST)
        if form.is_valid():
            try:
                with transaction.atomic():
                    user = form.save()
                    # Crear perfil y configuraciones
                    UserProfile.objects.create(user=user)
                    UserSettings.objects.create(user=user)
                    login(request, user)
                    messages.success(request, '¡Cuenta creada exitosamente!')
                    return redirect('home')
            except Exception as e:
                messages.error(request, f'Error al crear cuenta: {str(e)}')
    else:
        form = UserRegisterForm()
    
    return render(request, 'users/register.html', {'form': form})


@login_required
def profile_view(request):
    """Vista de perfil de usuario."""
    user = request.user
    profile, _ = UserProfile.objects.get_or_create(user=user)
    settings, _ = UserSettings.objects.get_or_create(user=user)
    
    if request.method == 'POST':
        profile_form = UserProfileForm(request.POST, request.FILES, instance=profile)
        settings_form = UserSettingsForm(request.POST, instance=settings)
        
        if profile_form.is_valid() and settings_form.is_valid():
            profile_form.save()
            settings_form.save()
            messages.success(request, 'Perfil actualizado exitosamente.')
            return redirect('profile')
    else:
        profile_form = UserProfileForm(instance=profile)
        settings_form = UserSettingsForm(instance=settings)
    
    return render(request, 'users/profile.html', {
        'profile_form': profile_form,
        'settings_form': settings_form
    })
