"""
Configuración de admin para usuarios
"""

from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from django.contrib.auth.models import User
from .models import UserProfile, UserSettings


class UserProfileInline(admin.StackedInline):
    model = UserProfile
    can_delete = False
    verbose_name = 'Perfil'
    verbose_name_plural = 'Perfil'


class UserSettingsInline(admin.StackedInline):
    model = UserSettings
    can_delete = False
    verbose_name = 'Configuración'
    verbose_name_plural = 'Configuraciones'


class UserAdmin(BaseUserAdmin):
    inlines = (UserProfileInline, UserSettingsInline)
    list_display = ('username', 'email', 'first_name', 'last_name', 'is_staff', 'date_joined')
    list_filter = ('is_staff', 'is_superuser', 'is_active', 'date_joined')
    search_fields = ('username', 'email', 'first_name', 'last_name')


admin.site.unregister(User)
admin.site.register(User, UserAdmin)
admin.site.register(UserProfile)
admin.site.register(UserSettings)
