"""
Formularios de usuarios
"""

from django import forms
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm
from django.core.validators import RegexValidator
from .models import UserProfile, UserSettings


class UserRegisterForm(UserCreationForm):
    """Formulario de registro de usuario."""
    email = forms.EmailField(required=True)
    first_name = forms.CharField(max_length=30, required=True, label='Nombre')
    last_name = forms.CharField(max_length=30, required=True, label='Apellido')
    
    class Meta:
        model = User
        fields = ['username', 'first_name', 'last_name', 'email', 'password1', 'password2']
    
    def clean_email(self):
        """Validar que el email sea único."""
        email = self.cleaned_data.get('email')
        if User.objects.filter(email=email).exists():
            raise forms.ValidationError('Este correo electrónico ya está registrado.')
        return email
    
    def clean_username(self):
        """Validar formato de username."""
        username = self.cleaned_data.get('username')
        if not username.isalnum():
            raise forms.ValidationError('El nombre de usuario solo puede contener letras y números.')
        return username


class UserProfileForm(forms.ModelForm):
    """Formulario de perfil de usuario."""
    phone_regex = RegexValidator(
        regex=r'^(\+?593|0)?[0-9]{9,10}$',
        message='Ingrese un número de teléfono válido de Ecuador.'
    )
    phone = forms.CharField(
        validators=[phone_regex],
        max_length=20,
        required=False,
        label='Teléfono'
    )
    
    class Meta:
        model = UserProfile
        fields = ['avatar', 'company', 'phone']
        widgets = {
            'avatar': forms.FileInput(attrs={'accept': 'image/*'}),
        }


class UserSettingsForm(forms.ModelForm):
    """Formulario de configuraciones de usuario."""
    
    class Meta:
        model = UserSettings
        fields = ['default_canvas_width', 'default_canvas_height', 'default_format', 'auto_save', 'theme']
        widgets = {
            'default_canvas_width': forms.NumberInput(attrs={'min': 100, 'max': 5000}),
            'default_canvas_height': forms.NumberInput(attrs={'min': 100, 'max': 5000}),
            'default_format': forms.Select(choices=[('png', 'PNG'), ('jpg', 'JPEG'), ('svg', 'SVG'), ('pdf', 'PDF')]),
            'theme': forms.Select(choices=[('light', 'Claro'), ('dark', 'Oscuro'), ('auto', 'Automático')]),
        }
