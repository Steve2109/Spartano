# Guía de Instalación - LogoAI en Debian 13

**Autor:** T&M Technology Ec  
**Soporte:** soporte@tymtechnology.shop  
**Dominio:** http://logoai.tymtechnology.shop/  
**Puerto:** 32299

---

## Arquitectura de Despliegue

```
Internet → HTTPS (443) → Nginx Proxy Manager → HTTP (80) → Docker → LogoAI (32299)
                ↑                                 ↑
         Let's Encrypt                      10.0.1.40:32299
```

---

## Paso 1: Preparar el Servidor Debian 13

### 1.1 Actualizar el sistema

```bash
sudo apt update && sudo apt upgrade -y
sudo apt install -y curl wget git nano htop
```

### 1.2 Instalar Docker y Docker Compose

```bash
# Eliminar versiones antiguas si existen
for pkg in docker.io docker-doc docker-compose podman-docker containerd runc; do sudo apt remove $pkg; done

# Instalar Docker desde el repositorio oficial
sudo apt update
sudo apt install -y ca-certificates curl gnupg

sudo install -m 0755 -d /etc/apt/keyrings
curl -fsSL https://download.docker.com/linux/debian/gpg | sudo gpg --dearmor -o /etc/apt/keyrings/docker.gpg
sudo chmod a+r /etc/apt/keyrings/docker.gpg

echo "deb [arch="$(dpkg --print-architecture)" signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/debian \
  "$(. /etc/os-release && echo "$VERSION_CODENAME")" stable" | \
  sudo tee /etc/apt/sources.list.d/docker.list > /dev/null

sudo apt update
sudo apt install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin

# Verificar instalación
sudo docker run hello-world
sudo systemctl enable docker
sudo systemctl start docker

# Agregar usuario al grupo docker
sudo usermod -aG docker $USER
newgrp docker
```

---

## Paso 2: Configurar el Proyecto

### 2.1 Crear directorio del proyecto

```bash
sudo mkdir -p /opt/logoai
cd /opt/logoai
sudo chown $USER:$USER /opt/logoai
```

### 2.2 Copiar archivos del proyecto

Transfiere todos los archivos del proyecto al servidor:

```bash
# Desde tu máquina local (usando scp o rsync)
scp -r ./* usuario@10.0.1.40:/opt/logoai/

# O clonar desde repositorio si está en git
git clone <tu-repositorio> /opt/logoai
```

### 2.3 Crear archivo de entorno

```bash
cd /opt/logoapi
cat > .env << 'EOF'
DB_PATH=/var/www/html/data/logoai.db
JWT_SECRET=$(openssl rand -hex 32)
RATE_LIMIT_REQUESTS=100
RATE_LIMIT_WINDOW=60
SESSION_LIFETIME=3600
APP_ENV=production
APP_AUTHOR=T&M Technology Ec
APP_SUPPORT_EMAIL=soporte@tymtechnology.shop
UPLOAD_MAX_SIZE=50M
EOF
```

---

## Paso 3: Construir y Desplegar con Docker

### 3.1 Construir imagen Docker

```bash
cd /opt/logoai

# Instalar dependencias de Composer localmente
composer install --no-dev --optimize-autoloader

# Construir imagen Docker
docker compose build

# Iniciar contenedor
docker compose up -d

# Verificar estado
docker compose ps
docker compose logs -f
```

### 3.2 Verificar que el servicio responde

```bash
curl http://localhost:32299
# Debería mostrar el contenido HTML
```

---

## Paso 4: Configurar Nginx Proxy Manager

### 4.1 Acceder a Nginx Proxy Manager

```
URL: http://<IP-NPM>:81 (admin@example.com / changeme)
```

### 4.2 Crear Proxy Host

1. Ir a **Hosts** → **Proxy Hosts**
2. Click en **Add Proxy Host**
3. Configurar:
   - **Domain Names:** `logoai.tymtechnology.shop`
   - **Scheme:** `http`
   - **Forward Hostname / IP:** `10.0.1.40` (o `logoai` si en la misma red Docker)
   - **Forward Port:** `32299`
   - **Cache Assets:** Habilitar
   - **Block Common Exploits:** Habilitar

### 4.3 Configurar SSL

1. En el mismo Proxy Host, ir a la pestaña **SSL**
2. **SSL Certificate:** Request a new SSL Certificate
3. **Email for Let's Encrypt:** `soporte@tymtechnology.shop`
4. **I Agree:** Sí
5. Click en **Save**

### 4.4 Configuración avanzada (opcional)

En **Advanced**, agregar:

```nginx
# Aumentar límite de subida
client_max_body_size 50M;

# Headers de seguridad
add_header X-Frame-Options "SAMEORIGIN" always;
add_header X-Content-Type-Options "nosniff" always;
add_header X-XSS-Protection "1; mode=block" always;
add_header Referrer-Policy "strict-origin-when-cross-origin" always;

# Compresión
gzip on;
gzip_types text/plain text/css application/json application/javascript text/xml;
```

---

## Paso 5: Configurar Firewall

### 5.1 Configurar UFW

```bash
sudo apt install -y ufw

# Políticas por defecto
sudo ufw default deny incoming
sudo ufw default allow outgoing

# Permitir SSH
sudo ufw allow 22/tcp

# Permitir Nginx Proxy Manager
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
sudo ufw allow 81/tcp

# Permitir LogoAI solo desde red interna (si NPM está en la misma máquina)
# Si NPM está en otra máquina, permitir desde esa IP
sudo ufw allow from 10.0.1.0/24 to any port 32299

# Habilitar firewall
sudo ufw enable
sudo ufw status verbose
```

---

## Paso 6: Configuración de Seguridad

### 6.1 Crear directorios seguros

```bash
sudo mkdir -p /opt/logoai/data /opt/logoai/uploads /opt/logoai/logs
sudo chown -R www-data:www-data /opt/logoai/data /opt/logoai/uploads /opt/logoai/logs
sudo chmod 755 /opt/logoai/data /opt/logoai/uploads /opt/logoai/logs
```

### 6.2 Configurar backup automático

```bash
# Crear script de backup
sudo tee /usr/local/bin/backup-logoai.sh << 'EOF'
#!/bin/bash
BACKUP_DIR="/opt/backups/logoai"
DATE=$(date +%Y%m%d_%H%M%S)
mkdir -p $BACKUP_DIR

# Backup de la base de datos
docker cp logoai_app:/var/www/html/data/logoai.db $BACKUP_DIR/logoai_$DATE.db

# Backup de uploads
tar -czf $BACKUP_DIR/uploads_$DATE.tar.gz /opt/logoai/uploads

# Mantener solo últimos 7 días
find $BACKUP_DIR -type f -mtime +7 -delete

# Log
logger "LogoAI backup completed: $DATE"
EOF

sudo chmod +x /usr/local/bin/backup-logoai.sh

# Agregar a crontab (diario a las 3 AM)
(crontab -l 2>/dev/null; echo "0 3 * * * /usr/local/bin/backup-logoai.sh") | crontab -
```

---

## Paso 7: Configurar Auto-Start

### 7.1 Configurar Docker Compose para iniciar automáticamente

```bash
# El servicio ya está configurado con restart: unless-stopped
# Verificar que Docker inicie en boot
sudo systemctl enable docker

# Verificar servicio
sudo docker compose -f /opt/logoai/docker-compose.yml ps
```

---

## Paso 8: Verificación Final

### 8.1 Comandos de verificación

```bash
# Verificar contenedores
docker ps

# Ver logs
docker logs logoai_app

# Verificar puerto está escuchando
ss -tlnp | grep 32299

# Probar desde local
curl -I http://10.0.1.40:32299

# Probar HTTPS desde externo
curl -I https://logoai.tymtechnology.shop
```

### 8.2 Checklist de verificación

- [ ] Docker está corriendo
- [ ] Contenedor logoai_app está UP
- [ ] Puerto 32299 está abierto
- [ ] Nginx Proxy Manager redirige correctamente
- [ ] SSL/TLS está activo con Let's Encrypt
- [ ] El sitio carga en https://logoai.tymtechnology.shop
- [ ] Login y registro funcionan
- [ ] Subida de imágenes funciona
- [ ] Exportar diseños funciona
- [ ] Base de datos persiste
- [ ] Backups automáticos configurados

---

## Comandos Útiles de Mantenimiento

### Reiniciar servicio

```bash
cd /opt/logoai
docker compose restart
```

### Actualizar aplicación

```bash
cd /opt/logoai
docker compose down
git pull  # o actualizar archivos manualmente
docker compose build --no-cache
docker compose up -d
```

### Ver estadísticas

```bash
# Uso de recursos
docker stats logoai_app

# Logs en tiempo real
docker logs -f logoai_app

# Espacio en disco
docker system df
```

### Limpieza

```bash
# Limpiar contenedores/deteniudos
docker container prune -f

# Limpiar imágenes no usadas
docker image prune -af

# Limpiar volúmenes no usados
docker volume prune -f
```

---

## Troubleshooting

### Problema: Puerto 32299 ya está en uso

```bash
# Encontrar proceso usando el puerto
sudo lsof -i :32299

# Matar proceso o cambiar puerto en docker-compose.yml
```

### Problema: Permisos en uploads

```bash
# Corregir permisos
sudo chown -R www-data:www-data /opt/logoai/uploads
sudo chmod -R 775 /opt/logoai/uploads
```

### Problema: Error de conexión a base de datos

```bash
# Verificar que el directorio data exista
ls -la /opt/logoai/data/

# Crear directorio si no existe
sudo mkdir -p /opt/logoai/data
sudo chown www-data:www-data /opt/logoai/data
```

### Problema: Certificado SSL no válido

```bash
# En Nginx Proxy Manager, eliminar certificado y recrear
# Verificar que el dominio apunta a la IP correcta
dig logoai.tymtechnology.shop +short
```

---

## Soporte

Para soporte técnico contactar a:

- **Email:** soporte@tymtechnology.shop
- **Autor:** T&M Technology Ec

---

## Licencia

Copyright (c) 2024 T&M Technology Ec. Todos los derechos reservados.
