<?php
namespace App\Core;

class RateLimiter {
    private $db;
    private $requests;
    private $window;
    
    public function __construct() {
        $this->db = new \SQLite3(DB_PATH);
        $this->requests = RATE_LIMIT_REQUESTS;
        $this->window = RATE_LIMIT_WINDOW;
        $this->initTable();
    }
    
    private function initTable(): void {
        $this->db->exec("CREATE TABLE IF NOT EXISTS rate_limits (
            ip TEXT PRIMARY KEY,
            requests INTEGER DEFAULT 0,
            window_start INTEGER DEFAULT 0
        )");
    }
    
    public function allowRequest(string $ip): bool {
        $now = time();
        $windowStart = $now - $this->window;
        
        $stmt = $this->db->prepare("SELECT requests, window_start FROM rate_limits WHERE ip = :ip");
        $stmt->bindValue(':ip', $ip, SQLITE3_TEXT);
        $result = $stmt->execute();
        $row = $result->fetchArray(SQLITE3_ASSOC);
        
        if (!$row || $row['window_start'] < $windowStart) {
            $this->resetCounter($ip, $now);
            return true;
        }
        
        if ($row['requests'] >= $this->requests) {
            return false;
        }
        
        $this->incrementCounter($ip);
        return true;
    }
    
    private function resetCounter(string $ip, int $time): void {
        $stmt = $this->db->prepare("INSERT OR REPLACE INTO rate_limits (ip, requests, window_start) VALUES (:ip, 1, :time)");
        $stmt->bindValue(':ip', $ip, SQLITE3_TEXT);
        $stmt->bindValue(':time', $time, SQLITE3_INTEGER);
        $stmt->execute();
    }
    
    private function incrementCounter(string $ip): void {
        $stmt = $this->db->prepare("UPDATE rate_limits SET requests = requests + 1 WHERE ip = :ip");
        $stmt->bindValue(':ip', $ip, SQLITE3_TEXT);
        $stmt->execute();
    }
}
