<?php
namespace App\Core;

class Request {
    private $data = [];
    private $headers = [];
    
    public function __construct() {
        $this->headers = getallheaders();
        
        // Parse JSON body
        $input = file_get_contents('php://input');
        if (!empty($input)) {
            $json = json_decode($input, true);
            if ($json) {
                $this->data = $json;
            } else {
                parse_str($input, $this->data);
            }
        }
        
        // Merge POST data
        $this->data = array_merge($this->data, $_POST);
    }
    
    public function getMethod(): string {
        return $_SERVER['REQUEST_METHOD'];
    }
    
    public function getUri(): string {
        $uri = $_SERVER['REQUEST_URI'];
        return parse_url($uri, PHP_URL_PATH);
    }
    
    public function get(string $key, $default = null) {
        return Security::sanitizeInput($this->data[$key] ?? $default);
    }
    
    public function getRaw(string $key, $default = null) {
        return $this->data[$key] ?? $default;
    }
    
    public function all(): array {
        return Security::sanitizeInput($this->data);
    }
    
    public function getHeader(string $key): ?string {
        return $this->headers[$key] ?? null;
    }
    
    public function getAuthToken(): ?string {
        $auth = $this->getHeader('Authorization');
        if ($auth && str_starts_with($auth, 'Bearer ')) {
            return substr($auth, 7);
        }
        return null;
    }
    
    public function getUserId(): ?int {
        $token = $this->getAuthToken();
        if (!$token) return null;
        
        $payload = Security::validateJWT($token);
        return $payload['user_id'] ?? null;
    }
}
