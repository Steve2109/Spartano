<?php
namespace App\Core;

class Router {
    private $routes = [];
    private $params = [];
    
    public function addRoute(string $method, string $route, string $handler): void {
        $route = preg_replace('/\{(\w+)\}/', '(?P<$1>[^/]+)', $route);
        $route = '#^' . $route . '$#';
        $this->routes[$method][$route] = $handler;
    }
    
    public function dispatch(Request $request): Response {
        $method = $request->getMethod();
        $uri = $request->getUri();
        
        if (!isset($this->routes[$method])) {
            return new Response(['error' => 'Method not allowed'], 405);
        }
        
        foreach ($this->routes[$method] as $route => $handler) {
            if (preg_match($route, $uri, $matches)) {
                $this->params = array_filter($matches, 'is_string', ARRAY_FILTER_USE_KEY);
                return $this->executeHandler($handler, $request);
            }
        }
        
        // Si no es API, servir frontend
        if (!str_starts_with($uri, '/api/')) {
            return $this->serveFrontend($uri);
        }
        
        return new Response(['error' => 'Not found'], 404);
    }
    
    private function executeHandler(string $handler, Request $request): Response {
        list($controller, $method) = explode('@', $handler);
        $controllerClass = "App\\Controllers\\$controller";
        
        if (!class_exists($controllerClass) || !method_exists($controllerClass, $method)) {
            return new Response(['error' => 'Handler not found'], 500);
        }
        
        $instance = new $controllerClass();
        return $instance->$method($request, $this->params);
    }
    
    private function serveFrontend(string $uri): Response {
        // Eliminar query string
        $uri = parse_url($uri, PHP_URL_PATH);
        
        // Archivo específico
        if ($uri !== '/' && file_exists(__DIR__ . '/../../public' . $uri)) {
            return new Response(file_get_contents(__DIR__ . '/../../public' . $uri), 200, $this->getContentType($uri));
        }
        
        // Servir index.html para rutas SPA
        return new Response(file_get_contents(__DIR__ . '/../../templates/index.html'), 200, 'text/html');
    }
    
    private function getContentType(string $uri): string {
        $ext = pathinfo($uri, PATHINFO_EXTENSION);
        $types = [
            'css' => 'text/css',
            'js' => 'application/javascript',
            'png' => 'image/png',
            'jpg' => 'image/jpeg',
            'jpeg' => 'image/jpeg',
            'gif' => 'image/gif',
            'svg' => 'image/svg+xml',
            'woff' => 'font/woff',
            'woff2' => 'font/woff2',
            'ttf' => 'font/ttf'
        ];
        return $types[$ext] ?? 'application/octet-stream';
    }
}
