<?php
namespace App\Core;

class Response {
    private $data;
    private $statusCode;
    private $contentType;
    
    public function __construct($data, int $statusCode = 200, string $contentType = 'application/json') {
        $this->data = $data;
        $this->statusCode = $statusCode;
        $this->contentType = $contentType;
    }
    
    public function send(): void {
        http_response_code($this->statusCode);
        header("Content-Type: {$this->contentType}");
        header("X-Frame-Options: DENY");
        header("X-Content-Type-Options: nosniff");
        header("X-XSS-Protection: 1; mode=block");
        header("Referrer-Policy: strict-origin-when-cross-origin");
        
        if (is_array($this->data) || is_object($this->data)) {
            echo json_encode($this->data);
        } else {
            echo $this->data;
        }
    }
}
