<?php
// Configuración segura - cargar desde variables de entorno
define('DB_PATH', $_ENV['DB_PATH'] ?? __DIR__ . '/../../data/logoai.db');
define('UPLOAD_PATH', __DIR__ . '/../../uploads/');
define('MAX_UPLOAD_SIZE', 50 * 1024 * 1024); // 50MB
define('JWT_SECRET', $_ENV['JWT_SECRET'] ?? bin2hex(random_bytes(32)));
define('JWT_EXPIRY', 3600); // 1 hora
define('RATE_LIMIT_REQUESTS', $_ENV['RATE_LIMIT_REQUESTS'] ?? 100);
define('RATE_LIMIT_WINDOW', $_ENV['RATE_LIMIT_WINDOW'] ?? 60);
define('APP_AUTHOR', $_ENV['APP_AUTHOR'] ?? 'T&M Technology Ec');
define('APP_SUPPORT_EMAIL', $_ENV['APP_SUPPORT_EMAIL'] ?? 'soporte@tymtechnology.shop');
define('ALLOWED_IMAGE_TYPES', ['image/jpeg', 'image/png', 'image/gif', 'image/webp', 'image/svg+xml']);
define('MAX_IMAGE_DIMENSION', 8000);
