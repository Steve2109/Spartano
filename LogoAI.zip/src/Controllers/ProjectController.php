<?php
namespace App\Controllers;

use App\Core\Request;
use App\Core\Response;
use App\Core\Database;
use App\Core\Security;

class ProjectController {
    private function auth(Request $request): ?int {
        return $request->getUserId();
    }
    
    public function create(Request $request): Response {
        $userId = $this->auth($request);
        if (!$userId) {
            return new Response(['error' => 'Unauthorized'], 401);
        }
        
        $data = $request->all();
        
        if (empty($data['name'])) {
            return new Response(['error' => 'Project name is required'], 400);
        }
        
        $name = Security::sanitizeInput($data['name']);
        $width = filter_var($data['width'] ?? 800, FILTER_VALIDATE_INT) ?: 800;
        $height = filter_var($data['height'] ?? 600, FILTER_VALIDATE_INT) ?: 600;
        $background = Security::sanitizeInput($data['background_color'] ?? '#ffffff');
        
        $projectData = json_encode([
            'layers' => [],
            'elements' => [],
            'history' => [],
            'version' => 1
        ]);
        
        $db = Database::getInstance();
        $db->query("INSERT INTO projects (user_id, name, width, height, background_color, data) 
                    VALUES (:user_id, :name, :width, :height, :bg, :data)", [
            ':user_id' => $userId,
            ':name' => $name,
            ':width' => max(100, min(8000, $width)),
            ':height' => max(100, min(8000, $height)),
            ':bg' => $background,
            ':data' => $projectData
        ]);
        
        return new Response([
            'id' => $db->lastInsertId(),
            'name' => $name,
            'width' => $width,
            'height' => $height,
            'background_color' => $background
        ], 201);
    }
    
    public function list(Request $request): Response {
        $userId = $this->auth($request);
        if (!$userId) {
            return new Response(['error' => 'Unauthorized'], 401);
        }
        
        $db = Database::getInstance();
        $projects = $db->fetchAll("SELECT id, name, width, height, thumbnail, created_at, updated_at 
                                   FROM projects WHERE user_id = :user_id ORDER BY updated_at DESC", [
            ':user_id' => $userId
        ]);
        
        return new Response(['projects' => $projects]);
    }
    
    public function get(Request $request, array $params): Response {
        $userId = $this->auth($request);
        if (!$userId) {
            return new Response(['error' => 'Unauthorized'], 401);
        }
        
        $id = filter_var($params['id'], FILTER_VALIDATE_INT);
        if (!$id) {
            return new Response(['error' => 'Invalid project ID'], 400);
        }
        
        $db = Database::getInstance();
        $project = $db->fetch("SELECT * FROM projects WHERE id = :id AND user_id = :user_id", [
            ':id' => $id,
            ':user_id' => $userId
        ]);
        
        if (!$project) {
            return new Response(['error' => 'Project not found'], 404);
        }
        
        $project['data'] = json_decode($project['data'], true);
        return new Response($project);
    }
    
    public function update(Request $request, array $params): Response {
        $userId = $this->auth($request);
        if (!$userId) {
            return new Response(['error' => 'Unauthorized'], 401);
        }
        
        $id = filter_var($params['id'], FILTER_VALIDATE_INT);
        if (!$id) {
            return new Response(['error' => 'Invalid project ID'], 400);
        }
        
        $data = $request->all();
        $db = Database::getInstance();
        
        $updates = [];
        $params = [':id' => $id, ':user_id' => $userId];
        
        if (isset($data['name'])) {
            $updates[] = "name = :name";
            $params[':name'] = Security::sanitizeInput($data['name']);
        }
        if (isset($data['data'])) {
            $updates[] = "data = :data";
            $params[':data'] = json_encode($data['data']);
        }
        if (isset($data['thumbnail'])) {
            $updates[] = "thumbnail = :thumbnail";
            $params[':thumbnail'] = Security::sanitizeInput($data['thumbnail']);
        }
        
        if (empty($updates)) {
            return new Response(['error' => 'No data to update'], 400);
        }
        
        $updates[] = "updated_at = strftime('%s', 'now')";
        $sql = "UPDATE projects SET " . implode(', ', $updates) . " WHERE id = :id AND user_id = :user_id";
        
        $db->query($sql, $params);
        
        return new Response(['message' => 'Project updated']);
    }
    
    public function delete(Request $request, array $params): Response {
        $userId = $this->auth($request);
        if (!$userId) {
            return new Response(['error' => 'Unauthorized'], 401);
        }
        
        $id = filter_var($params['id'], FILTER_VALIDATE_INT);
        if (!$id) {
            return new Response(['error' => 'Invalid project ID'], 400);
        }
        
        $db = Database::getInstance();
        $db->query("DELETE FROM projects WHERE id = :id AND user_id = :user_id", [
            ':id' => $id,
            ':user_id' => $userId
        ]);
        
        return new Response(['message' => 'Project deleted']);
    }
}
