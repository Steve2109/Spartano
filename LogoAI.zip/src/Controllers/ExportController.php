<?php
namespace App\Controllers;

use App\Core\Request;
use App\Core\Response;
use Intervention\Image\ImageManagerStatic as Image;

class ExportController {
    public function export(Request $request): Response {
        $userId = $request->getUserId();
        if (!$userId) {
            return new Response(['error' => 'Unauthorized'], 401);
        }
        
        $data = $request->all();
        
        if (empty($data['canvas']) || empty($data['format'])) {
            return new Response(['error' => 'Canvas data and format required'], 400);
        }
        
        $format = in_array($data['format'], ['png', 'jpg', 'webp', 'svg', 'pdf']) ? $data['format'] : 'png';
        $width = filter_var($data['width'] ?? 800, FILTER_VALIDATE_INT) ?: 800;
        $height = filter_var($data['height'] ?? 600, FILTER_VALIDATE_INT) ?: 600;
        $quality = filter_var($data['quality'] ?? 90, FILTER_VALIDATE_INT) ?: 90;
        $quality = max(1, min(100, $quality));
        
        $canvas = $data['canvas'];
        
        // Crear imagen base
        if ($format === 'svg') {
            $svg = $this->generateSVG($canvas, $width, $height);
            $filename = 'export_' . time() . '.svg';
            file_put_contents(UPLOAD_PATH . $filename, $svg);
            return new Response(['url' => '/uploads/' . $filename, 'filename' => $filename]);
        }
        
        // Raster formats
        $img = Image::canvas($width, $height, $canvas['background'] ?? '#ffffff');
        
        // Renderizar capas
        if (!empty($canvas['layers'])) {
            foreach ($canvas['layers'] as $layer) {
                $this->renderLayer($img, $layer);
            }
        }
        
        // Generar archivo
        $filename = 'export_' . time() . '.' . $format;
        $filepath = UPLOAD_PATH . $filename;
        
        switch ($format) {
            case 'jpg':
                $img->encode('jpg', $quality)->save($filepath);
                break;
            case 'webp':
                $img->encode('webp', $quality)->save($filepath);
                break;
            case 'png':
            default:
                $img->encode('png')->save($filepath);
                break;
        }
        
        return new Response([
            'url' => '/uploads/' . $filename,
            'filename' => $filename,
            'width' => $width,
            'height' => $height,
            'format' => $format
        ]);
    }
    
    private function renderLayer($img, array $layer): void {
        if (!$layer['visible']) return;
        
        $x = $layer['x'] ?? 0;
        $y = $layer['y'] ?? 0;
        $opacity = ($layer['opacity'] ?? 100) / 100;
        $rotation = $layer['rotation'] ?? 0;
        
        switch ($layer['type']) {
            case 'image':
                if (!empty($layer['src'])) {
                    try {
                        $image = Image::make(str_replace('/uploads/', UPLOAD_PATH, $layer['src']));
                        if ($rotation) $image->rotate(-$rotation);
                        $image->opacity($opacity * 100);
                        $img->insert($image, 'top-left', (int)$x, (int)$y);
                    } catch (\Exception $e) {}
                }
                break;
                
            case 'text':
                $text = $layer['text'] ?? '';
                $color = $layer['color'] ?? '#000000';
                $size = $layer['fontSize'] ?? 24;
                $font = $layer['fontFamily'] ?? 'Arial';
                
                $img->text($text, (int)$x, (int)$y, function($font) use ($size, $color) {
                    $font->size($size);
                    $font->color($color);
                    $font->align('left');
                    $font->valign('top');
                });
                break;
                
            case 'shape':
                $shape = $layer['shape'] ?? 'rectangle';
                $color = $layer['fill'] ?? '#000000';
                $w = $layer['width'] ?? 100;
                $h = $layer['height'] ?? 100;
                
                if ($shape === 'rectangle') {
                    $img->rectangle((int)$x, (int)$y, (int)($x + $w), (int)($y + $h), function ($draw) use ($color) {
                        $draw->background($color);
                    });
                } elseif ($shape === 'circle') {
                    $radius = min($w, $h) / 2;
                    $img->circle((int)$radius, (int)($x + $radius), (int)($y + $radius), function ($draw) use ($color) {
                        $draw->background($color);
                    });
                }
                break;
        }
    }
    
    private function generateSVG(array $canvas, int $width, int $height): string {
        $bg = $canvas['background'] ?? '#ffffff';
        $svg = '<svg width="' . $width . '" height="' . $height . '" xmlns="http://www.w3.org/2000/svg">';
        $svg .= '<rect width="100%" height="100%" fill="' . htmlspecialchars($bg) . '"/>';
        
        if (!empty($canvas['layers'])) {
            foreach ($canvas['layers'] as $layer) {
                if (!$layer['visible']) continue;
                $svg .= $this->renderSVGLayer($layer);
            }
        }
        
        $svg .= '</svg>';
        return $svg;
    }
    
    private function renderSVGLayer(array $layer): string {
        $x = $layer['x'] ?? 0;
        $y = $layer['y'] ?? 0;
        $opacity = ($layer['opacity'] ?? 100) / 100;
        $transform = '';
        if (!empty($layer['rotation'])) {
            $centerX = $x + ($layer['width'] ?? 100) / 2;
            $centerY = $y + ($layer['height'] ?? 100) / 2;
            $transform = ' transform="rotate(' . $layer['rotation'] . ' ' . $centerX . ' ' . $centerY . ')"';
        }
        
        switch ($layer['type']) {
            case 'text':
                return '<text x="' . $x . '" y="' . $y . '"' . $transform . ' fill="' . htmlspecialchars($layer['color'] ?? '#000') . '" font-size="' . ($layer['fontSize'] ?? 24) . '" font-family="' . htmlspecialchars($layer['fontFamily'] ?? 'Arial') . '" opacity="' . $opacity . '">' . htmlspecialchars($layer['text'] ?? '') . '</text>';
                
            case 'shape':
                $shape = $layer['shape'] ?? 'rectangle';
                $fill = htmlspecialchars($layer['fill'] ?? '#000');
                if ($shape === 'rectangle') {
                    return '<rect x="' . $x . '" y="' . $y . '" width="' . ($layer['width'] ?? 100) . '" height="' . ($layer['height'] ?? 100) . '"' . $transform . ' fill="' . $fill . '" opacity="' . $opacity . '"/>';
                } elseif ($shape === 'circle') {
                    $r = min($layer['width'] ?? 100, $layer['height'] ?? 100) / 2;
                    return '<circle cx="' . ($x + $r) . '" cy="' . ($y + $r) . '" r="' . $r . '"' . $transform . ' fill="' . $fill . '" opacity="' . $opacity . '"/>';
                }
                break;
        }
        return '';
    }
}
