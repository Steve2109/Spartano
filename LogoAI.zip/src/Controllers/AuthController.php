<?php
namespace App\Controllers;

use App\Core\Request;
use App\Core\Response;
use App\Core\Security;
use App\Core\Database;

class AuthController {
    public function login(Request $request): Response {
        $data = $request->all();
        
        if (empty($data['email']) || empty($data['password'])) {
            return new Response(['error' => 'Email and password are required'], 400);
        }
        
        $email = filter_var($data['email'], FILTER_SANITIZE_EMAIL);
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return new Response(['error' => 'Invalid email format'], 400);
        }
        
        $db = Database::getInstance();
        $user = $db->fetch("SELECT id, email, password, name FROM users WHERE email = :email", [':email' => $email]);
        
        if (!$user || !password_verify($data['password'], $user['password'])) {
            return new Response(['error' => 'Invalid credentials'], 401);
        }
        
        $token = Security::generateJWT([
            'user_id' => $user['id'],
            'email' => $user['email']
        ]);
        
        return new Response([
            'token' => $token,
            'user' => [
                'id' => $user['id'],
                'email' => $user['email'],
                'name' => $user['name']
            ]
        ]);
    }
    
    public function register(Request $request): Response {
        $data = $request->all();
        
        if (empty($data['email']) || empty($data['password']) || empty($data['name'])) {
            return new Response(['error' => 'All fields are required'], 400);
        }
        
        $email = filter_var($data['email'], FILTER_SANITIZE_EMAIL);
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return new Response(['error' => 'Invalid email format'], 400);
        }
        
        if (strlen($data['password']) < 8) {
            return new Response(['error' => 'Password must be at least 8 characters'], 400);
        }
        
        $name = Security::sanitizeInput($data['name']);
        $hashedPassword = password_hash($data['password'], PASSWORD_ARGON2ID);
        
        $db = Database::getInstance();
        
        try {
            $db->query("INSERT INTO users (email, password, name) VALUES (:email, :password, :name)", [
                ':email' => $email,
                ':password' => $hashedPassword,
                ':name' => $name
            ]);
            
            $userId = $db->lastInsertId();
            
            $token = Security::generateJWT([
                'user_id' => $userId,
                'email' => $email
            ]);
            
            return new Response([
                'token' => $token,
                'user' => [
                    'id' => $userId,
                    'email' => $email,
                    'name' => $name
                ]
            ], 201);
        } catch (\Exception $e) {
            if (str_contains($e->getMessage(), 'UNIQUE constraint failed')) {
                return new Response(['error' => 'Email already exists'], 409);
            }
            return new Response(['error' => 'Registration failed'], 500);
        }
    }
    
    public function logout(Request $request): Response {
        return new Response(['message' => 'Logged out successfully']);
    }
}
