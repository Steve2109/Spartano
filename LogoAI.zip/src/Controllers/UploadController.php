<?php
namespace App\Controllers;

use App\Core\Request;
use App\Core\Response;
use App\Core\Database;
use App\Core\Security;
use Intervention\Image\ImageManagerStatic as Image;

class UploadController {
    private function auth(Request $request): ?int {
        return $request->getUserId();
    }
    
    public function handle(Request $request): Response {
        $userId = $this->auth($request);
        if (!$userId) {
            return new Response(['error' => 'Unauthorized'], 401);
        }
        
        if (empty($_FILES['file'])) {
            return new Response(['error' => 'No file uploaded'], 400);
        }
        
        $file = $_FILES['file'];
        
        // Validar errores de subida
        if ($file['error'] !== UPLOAD_ERR_OK) {
            return new Response(['error' => 'Upload failed: ' . $this->getUploadError($file['error'])], 400);
        }
        
        // Validar tipo
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mimeType = finfo_file($finfo, $file['tmp_name']);
        finfo_close($finfo);
        
        if (!in_array($mimeType, ALLOWED_IMAGE_TYPES)) {
            return new Response(['error' => 'Invalid file type. Allowed: JPG, PNG, GIF, WebP, SVG'], 400);
        }
        
        // Validar tamaño
        if ($file['size'] > MAX_UPLOAD_SIZE) {
            return new Response(['error' => 'File too large. Max 50MB'], 400);
        }
        
        // Generar nombre único
        $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
        $filename = bin2hex(random_bytes(16)) . '.' . $extension;
        $filepath = UPLOAD_PATH . $filename;
        
        // Crear directorio si no existe
        if (!is_dir(UPLOAD_PATH)) {
            mkdir(UPLOAD_PATH, 0755, true);
        }
        
        // Mover archivo
        if (!move_uploaded_file($file['tmp_name'], $filepath)) {
            return new Response(['error' => 'Failed to save file'], 500);
        }
        
        // Procesar imagen
        $dimensions = ['width' => null, 'height' => null];
        if ($mimeType !== 'image/svg+xml') {
            try {
                $img = Image::make($filepath);
                $dimensions['width'] = $img->width();
                $dimensions['height'] = $img->height();
                
                // Limitar dimensiones
                if ($img->width() > MAX_IMAGE_DIMENSION || $img->height() > MAX_IMAGE_DIMENSION) {
                    $img->resize(MAX_IMAGE_DIMENSION, MAX_IMAGE_DIMENSION, function ($constraint) {
                        $constraint->aspectRatio();
                        $constraint->upsize();
                    });
                    $img->save($filepath, 90);
                }
            } catch (\Exception $e) {
                unlink($filepath);
                return new Response(['error' => 'Invalid image file'], 400);
            }
        }
        
        // Guardar en BD
        $db = Database::getInstance();
        $db->query("INSERT INTO assets (user_id, name, type, path, width, height, size) 
                    VALUES (:user_id, :name, :type, :path, :width, :height, :size)", [
            ':user_id' => $userId,
            ':name' => Security::sanitizeInput($file['name']),
            ':type' => $mimeType,
            ':path' => $filename,
            ':width' => $dimensions['width'],
            ':height' => $dimensions['height'],
            ':size' => $file['size']
        ]);
        
        return new Response([
            'id' => $db->lastInsertId(),
            'name' => $file['name'],
            'url' => '/uploads/' . $filename,
            'width' => $dimensions['width'],
            'height' => $dimensions['height'],
            'type' => $mimeType
        ], 201);
    }
    
    private function getUploadError(int $code): string {
        $errors = [
            UPLOAD_ERR_INI_SIZE => 'File exceeds upload_max_filesize',
            UPLOAD_ERR_FORM_SIZE => 'File exceeds MAX_FILE_SIZE',
            UPLOAD_ERR_PARTIAL => 'File partially uploaded',
            UPLOAD_ERR_NO_FILE => 'No file uploaded',
            UPLOAD_ERR_NO_TMP_DIR => 'Missing temp folder',
            UPLOAD_ERR_CANT_WRITE => 'Failed to write file',
            UPLOAD_ERR_EXTENSION => 'Upload stopped by extension'
        ];
        return $errors[$code] ?? 'Unknown error';
    }
}
