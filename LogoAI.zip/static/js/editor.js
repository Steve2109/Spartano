/**
 * LogoAI - Editor Canvas
 * Editor profesional tipo Canva
 * Autor: T&M Technology Ec
 * Soporte: soporte@tymtechnology.shop
 */

class LogoEditor {
    constructor() {
        this.canvas = document.getElementById('mainCanvas');
        this.ctx = this.canvas.getContext('2d');
        this.container = document.getElementById('canvasContainer');
        
        // Estado del proyecto
        this.project = {
            id: window.projectData?.id || null,
            name: window.projectData?.name || 'Sin nombre',
            width: window.projectData?.width || 800,
            height: window.projectData?.height || 600,
            backgroundColor: window.projectData?.backgroundColor || '#ffffff'
        };
        
        // Capas
        this.layers = window.projectData?.layers || [];
        this.selectedLayerId = null;
        
        // Historial para undo/redo
        this.history = [];
        this.historyIndex = -1;
        this.maxHistory = 50;
        
        // Estado de herramientas
        this.currentTool = 'select';
        this.zoom = 1;
        this.isDragging = false;
        this.isResizing = false;
        this.isRotating = false;
        this.dragStart = { x: 0, y: 0 };
        this.resizeHandle = null;
        
        // Estado de selección
        this.selection = {
            x: 0, y: 0, width: 0, height: 0, rotation: 0
        };
        
        this.init();
    }
    
    init() {
        this.setupCanvas();
        this.setupEventListeners();
        this.setupTools();
        this.setupPropertiesPanel();
        this.renderLayers();
        this.saveState();
        this.setupKeyboardShortcuts();
    }
    
    setupCanvas() {
        // Ajustar canvas según el proyecto
        this.canvas.width = this.project.width;
        this.canvas.height = this.project.height;
        this.canvas.style.width = `${this.project.width}px`;
        this.canvas.style.height = `${this.project.height}px`;
        
        // Renderizar capas iniciales
        this.render();
        this.updateLayersList();
    }
    
    setupEventListeners() {
        // Eventos del canvas
        this.canvas.addEventListener('mousedown', this.handleMouseDown.bind(this));
        this.canvas.addEventListener('mousemove', this.handleMouseMove.bind(this));
        this.canvas.addEventListener('mouseup', this.handleMouseUp.bind(this));
        this.canvas.addEventListener('dblclick', this.handleDoubleClick.bind(this));
        
        // Prevenir menú contextual
        this.canvas.addEventListener('contextmenu', (e) => e.preventDefault());
        
        // Eventos del documento
        document.addEventListener('mouseup', () => {
            this.isDragging = false;
            this.isResizing = false;
            this.isRotating = false;
            this.canvas.style.cursor = this.currentTool === 'select' ? 'default' : 'crosshair';
        });
        
        // Botón de nombre del proyecto
        document.getElementById('projectName')?.addEventListener('change', (e) => {
            this.project.name = e.target.value;
        });
        
        // Zoom
        this.container.addEventListener('wheel', (e) => {
            if (e.ctrlKey || e.metaKey) {
                e.preventDefault();
                const delta = e.deltaY > 0 ? -0.1 : 0.1;
                this.setZoom(this.zoom + delta);
            }
        });
    }
    
    setupTools() {
        document.querySelectorAll('.tool-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                this.setTool(btn.dataset.tool);
            });
        });
        
        document.querySelectorAll('.shape-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                this.addShapeLayer(btn.dataset.shape);
            });
        });
    }
    
    setupPropertiesPanel() {
        // Posición y tamaño
        ['propX', 'propY', 'propW', 'propH', 'propRotation', 'propOpacity'].forEach(id => {
            document.getElementById(id)?.addEventListener('input', (e) => {
                this.updateLayerFromProperty(id, e.target.value);
            });
        });
        
        // Propiedades de texto
        ['textContent', 'textFont', 'textSize', 'textColor'].forEach(id => {
            document.getElementById(id)?.addEventListener('input', (e) => {
                this.updateTextProperty(id, e.target.value);
            });
        });
        
        // Propiedades de forma
        ['shapeFill', 'shapeStroke', 'shapeStrokeWidth'].forEach(id => {
            document.getElementById(id)?.addEventListener('input', (e) => {
                this.updateShapeProperty(id, e.target.value);
            });
        });
    }
    
    setupKeyboardShortcuts() {
        document.addEventListener('keydown', (e) => {
            // Ctrl/Cmd + S = Guardar
            if ((e.ctrlKey || e.metaKey) && e.key === 's') {
                e.preventDefault();
                this.saveProject();
            }
            
            // Ctrl/Cmd + Z = Deshacer
            if ((e.ctrlKey || e.metaKey) && e.key === 'z' && !e.shiftKey) {
                e.preventDefault();
                this.undo();
            }
            
            // Ctrl/Cmd + Shift + Z = Rehacer
            if ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key === 'z') {
                e.preventDefault();
                this.redo();
            }
            
            // Delete / Backspace = Eliminar capa seleccionada
            if ((e.key === 'Delete' || e.key === 'Backspace') && this.selectedLayerId) {
                e.preventDefault();
                this.deleteSelected();
            }
            
            // V = Herramienta seleccionar
            if (e.key === 'v' || e.key === 'V') {
                this.setTool('select');
            }
            
            // T = Herramienta texto
            if (e.key === 't' || e.key === 'T') {
                this.setTool('text');
            }
            
            // I = Herramienta imagen
            if (e.key === 'i' || e.key === 'I') {
                this.showUploadModal();
            }
        });
    }
    
    // ==================== RENDERIZADO ====================
    
    render() {
        // Limpiar canvas
        this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
        
        // Fondo
        this.ctx.fillStyle = this.project.backgroundColor;
        this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);
        
        // Renderizar capas visibles (de menor a mayor z-index)
        const sortedLayers = [...this.layers].sort((a, b) => a.zIndex - b.zIndex);
        
        for (const layer of sortedLayers) {
            if (layer.visible) {
                this.renderLayer(layer);
            }
        }
        
        // Actualizar selección visual
        this.updateSelectionOverlay();
    }
    
    renderLayer(layer) {
        this.ctx.save();
        
        // Aplicar transformaciones
        this.ctx.globalAlpha = layer.opacity;
        this.ctx.translate(layer.x + layer.width / 2, layer.y + layer.height / 2);
        this.ctx.rotate((layer.rotation * Math.PI) / 180);
        
        // Flip
        const scaleX = layer.flipX ? -layer.scaleX : layer.scaleX;
        const scaleY = layer.flipY ? -layer.scaleY : layer.scaleY;
        this.ctx.scale(scaleX, scaleY);
        
        this.ctx.translate(-layer.width / 2, -layer.height / 2);
        
        // Renderizar según tipo
        switch (layer.type) {
            case 'text':
                this.renderTextLayer(layer);
                break;
            case 'shape':
                this.renderShapeLayer(layer);
                break;
            case 'image':
                this.renderImageLayer(layer);
                break;
        }
        
        this.ctx.restore();
    }
    
    renderTextLayer(layer) {
        const content = layer.content || {};
        const style = layer.style || {};
        
        this.ctx.font = `${style.fontWeight || 'normal'} ${style.fontSize || 24}px ${style.fontFamily || 'Arial'}`;
        this.ctx.fillStyle = style.color || '#000000';
        this.ctx.textAlign = style.textAlign || 'left';
        this.ctx.textBaseline = 'top';
        
        const text = content.text || '';
        const lines = text.split('\n');
        const lineHeight = (style.fontSize || 24) * 1.2;
        
        lines.forEach((line, index) => {
            this.ctx.fillText(line, 0, index * lineHeight);
        });
    }
    
    renderShapeLayer(layer) {
        const content = layer.content || {};
        const style = layer.style || {};
        const shapeType = content.shapeType || 'rectangle';
        
        this.ctx.fillStyle = style.fill || '#000000';
        this.ctx.strokeStyle = style.stroke || '#000000';
        this.ctx.lineWidth = style.strokeWidth || 0;
        
        const w = layer.width;
        const h = layer.height;
        
        this.ctx.beginPath();
        
        switch (shapeType) {
            case 'rectangle':
                this.ctx.rect(0, 0, w, h);
                break;
            case 'circle':
                this.ctx.ellipse(w / 2, h / 2, w / 2, h / 2, 0, 0, 2 * Math.PI);
                break;
            case 'triangle':
                this.ctx.moveTo(w / 2, 0);
                this.ctx.lineTo(w, h);
                this.ctx.lineTo(0, h);
                this.ctx.closePath();
                break;
            case 'star':
                this.drawStar(w / 2, h / 2, 5, w / 2, w / 4);
                break;
            case 'heart':
                this.drawHeart(w / 2, h / 2, Math.min(w, h) / 2);
                break;
            case 'arrow':
                this.drawArrow(0, h / 2, w, h / 2, h / 3);
                break;
        }
        
        this.ctx.fill();
        if (style.strokeWidth > 0) {
            this.ctx.stroke();
        }
    }
    
    renderImageLayer(layer) {
        if (layer.imageElement) {
            this.ctx.drawImage(layer.imageElement, 0, 0, layer.width, layer.height);
        }
    }
    
    // ==================== FORMAS AUXILIARES ====================
    
    drawStar(cx, cy, spikes, outerRadius, innerRadius) {
        let rot = Math.PI / 2 * 3;
        let x = cx;
        let y = cy;
        let step = Math.PI / spikes;
        
        this.ctx.beginPath();
        this.ctx.moveTo(cx, cy - outerRadius);
        for (let i = 0; i < spikes; i++) {
            x = cx + Math.cos(rot) * outerRadius;
            y = cy + Math.sin(rot) * outerRadius;
            this.ctx.lineTo(x, y);
            rot += step;
            
            x = cx + Math.cos(rot) * innerRadius;
            y = cy + Math.sin(rot) * innerRadius;
            this.ctx.lineTo(x, y);
            rot += step;
        }
        this.ctx.lineTo(cx, cy - outerRadius);
        this.ctx.closePath();
    }
    
    drawHeart(x, y, size) {
        this.ctx.beginPath();
        this.ctx.moveTo(x, y + size / 4);
        this.ctx.quadraticCurveTo(x, y, x + size / 4, y);
        this.ctx.quadraticCurveTo(x + size / 2, y, x + size / 2, y + size / 4);
        this.ctx.quadraticCurveTo(x + size / 2, y, x + size * 3 / 4, y);
        this.ctx.quadraticCurveTo(x + size, y, x + size, y + size / 4);
        this.ctx.quadraticCurveTo(x + size, y + size / 2, x + size / 2, y + size);
        this.ctx.quadraticCurveTo(x, y + size / 2, x, y + size / 4);
        this.ctx.closePath();
    }
    
    drawArrow(x1, y1, x2, y2, headLength) {
        const dx = x2 - x1;
        const dy = y2 - y1;
        const angle = Math.atan2(dy, dx);
        
        this.ctx.beginPath();
        this.ctx.moveTo(x1, y1);
        this.ctx.lineTo(x2, y2);
        this.ctx.lineTo(
            x2 - headLength * Math.cos(angle - Math.PI / 6),
            y2 - headLength * Math.sin(angle - Math.PI / 6)
        );
        this.ctx.moveTo(x2, y2);
        this.ctx.lineTo(
            x2 - headLength * Math.cos(angle + Math.PI / 6),
            y2 - headLength * Math.sin(angle + Math.PI / 6)
        );
    }
    
    // ==================== MANEJO DE EVENTOS ====================
    
    handleMouseDown(e) {
        const rect = this.canvas.getBoundingClientRect();
        const x = (e.clientX - rect.left) / this.zoom;
        const y = (e.clientY - rect.top) / this.zoom;
        
        this.dragStart = { x, y };
        
        // Verificar si se hizo clic en una capa
        const clickedLayer = this.getLayerAt(x, y);
        
        if (clickedLayer) {
            this.selectLayer(clickedLayer.id);
            
            if (this.currentTool === 'select') {
                // Verificar handles de redimensionamiento
                const handle = this.getResizeHandleAt(x, y);
                if (handle) {
                    this.isResizing = true;
                    this.resizeHandle = handle;
                } else if (this.isRotationHandleAt(x, y)) {
                    this.isRotating = true;
                } else {
                    this.isDragging = true;
                }
            }
        } else {
            this.deselectLayer();
            
            // Si es herramienta texto, crear texto
            if (this.currentTool === 'text') {
                this.addTextLayer(x, y);
            }
        }
    }
    
    handleMouseMove(e) {
        const rect = this.canvas.getBoundingClientRect();
        const x = (e.clientX - rect.left) / this.zoom;
        const y = (e.clientY - rect.top) / this.zoom;
        
        if (this.isDragging && this.selectedLayerId) {
            const layer = this.getLayer(this.selectedLayerId);
            if (layer && !layer.locked) {
                layer.x += x - this.dragStart.x;
                layer.y += y - this.dragStart.y;
                this.dragStart = { x, y };
                this.render();
                this.updatePropertiesPanel();
            }
        } else if (this.isResizing && this.selectedLayerId) {
            this.resizeLayer(x, y);
        } else if (this.isRotating && this.selectedLayerId) {
            this.rotateLayer(x, y);
        } else {
            // Actualizar cursor según posición
            this.updateCursor(x, y);
        }
    }
    
    handleMouseUp(e) {
        if (this.isDragging || this.isResizing || this.isRotating) {
            this.saveState();
        }
        
        this.isDragging = false;
        this.isResizing = false;
        this.isRotating = false;
    }
    
    handleDoubleClick(e) {
        const rect = this.canvas.getBoundingClientRect();
        const x = (e.clientX - rect.left) / this.zoom;
        const y = (e.clientY - rect.top) / this.zoom;
        
        const layer = this.getLayerAt(x, y);
        
        if (layer && layer.type === 'text') {
            this.editTextLayer(layer);
        }
    }
    
    // ==================== CAPAS ====================
    
    addTextLayer(x, y) {
        const layer = {
            id: Utils.generateId(),
            type: 'text',
            name: 'Texto',
            zIndex: this.layers.length,
            x: x - 50,
            y: y - 15,
            width: 100,
            height: 30,
            rotation: 0,
            scaleX: 1,
            scaleY: 1,
            opacity: 1,
            visible: true,
            locked: false,
            flipX: false,
            flipY: false,
            content: { text: 'Doble clic para editar' },
            style: {
                fontFamily: 'Arial',
                fontSize: 24,
                color: '#000000',
                textAlign: 'left'
            }
        };
        
        this.layers.push(layer);
        this.selectLayer(layer.id);
        this.render();
        this.updateLayersList();
        this.saveState();
        
        // Mostrar propiedades de texto
        this.showTextProperties();
    }
    
    addShapeLayer(shapeType) {
        const layer = {
            id: Utils.generateId(),
            type: 'shape',
            name: shapeType.charAt(0).toUpperCase() + shapeType.slice(1),
            zIndex: this.layers.length,
            x: this.canvas.width / 2 - 50,
            y: this.canvas.height / 2 - 50,
            width: 100,
            height: 100,
            rotation: 0,
            scaleX: 1,
            scaleY: 1,
            opacity: 1,
            visible: true,
            locked: false,
            flipX: false,
            flipY: false,
            content: { shapeType },
            style: {
                fill: '#6366f1',
                stroke: '#000000',
                strokeWidth: 0
            }
        };
        
        this.layers.push(layer);
        this.selectLayer(layer.id);
        this.setTool('select');
        this.render();
        this.updateLayersList();
        this.saveState();
        
        this.showShapeProperties();
    }
    
    addImageLayer(imageUrl, file) {
        const img = new Image();
        img.onload = () => {
            // Calcular dimensiones manteniendo aspecto
            const maxSize = 300;
            let w = img.width;
            let h = img.height;
            
            if (w > h) {
                if (w > maxSize) {
                    h = (h * maxSize) / w;
                    w = maxSize;
                }
            } else {
                if (h > maxSize) {
                    w = (w * maxSize) / h;
                    h = maxSize;
                }
            }
            
            const layer = {
                id: Utils.generateId(),
                type: 'image',
                name: file?.name || 'Imagen',
                zIndex: this.layers.length,
                x: (this.canvas.width - w) / 2,
                y: (this.canvas.height - h) / 2,
                width: w,
                height: h,
                rotation: 0,
                scaleX: 1,
                scaleY: 1,
                opacity: 1,
                visible: true,
                locked: false,
                flipX: false,
                flipY: false,
                content: { src: imageUrl },
                style: { filter: 'none' },
                imageElement: img
            };
            
            this.layers.push(layer);
            this.selectLayer(layer.id);
            this.setTool('select');
            this.render();
            this.updateLayersList();
            this.saveState();
            this.showImageProperties();
        };
        img.src = imageUrl;
    }
    
    deleteLayer(layerId) {
        const index = this.layers.findIndex(l => l.id === layerId);
        if (index > -1) {
            this.layers.splice(index, 1);
            if (this.selectedLayerId === layerId) {
                this.deselectLayer();
            }
            this.render();
            this.updateLayersList();
            this.saveState();
        }
    }
    
    deleteSelected() {
        if (this.selectedLayerId) {
            confirmAction('¿Eliminar esta capa?', () => {
                this.deleteLayer(this.selectedLayerId);
                Toast.success('Capa eliminada');
            });
        }
    }
    
    // ==================== SELECCIÓN ====================
    
    selectLayer(layerId) {
        this.selectedLayerId = layerId;
        const layer = this.getLayer(layerId);
        
        if (layer) {
            this.selection = {
                x: layer.x,
                y: layer.y,
                width: layer.width,
                height: layer.height,
                rotation: layer.rotation
            };
            
            this.updateSelectionOverlay();
            this.updatePropertiesPanel();
            this.updateLayersList();
            
            // Mostrar propiedades según tipo
            if (layer.type === 'text') this.showTextProperties();
            else if (layer.type === 'shape') this.showShapeProperties();
            else if (layer.type === 'image') this.showImageProperties();
        }
    }
    
    deselectLayer() {
        this.selectedLayerId = null;
        document.getElementById('selectionOverlay')?.classList.add('hidden');
        this.hideAllProperties();
    }
    
    getLayer(id) {
        return this.layers.find(l => l.id === id);
    }
    
    getLayerAt(x, y) {
        // Buscar de arriba hacia abajo (mayor z-index primero)
        const sorted = [...this.layers]
            .filter(l => l.visible)
            .sort((a, b) => b.zIndex - a.zIndex);
        
        for (const layer of sorted) {
            if (this.isPointInLayer(x, y, layer)) {
                return layer;
            }
        }
        return null;
    }
    
    isPointInLayer(x, y, layer) {
        // Simplificación: verificar bounding box
        // Considerando rotación requeriría transformación inversa
        return x >= layer.x && x <= layer.x + layer.width &&
               y >= layer.y && y <= layer.y + layer.height;
    }
    
    // ==================== OVERLAY DE SELECCIÓN ====================
    
    updateSelectionOverlay() {
        const overlay = document.getElementById('selectionOverlay');
        if (!overlay || !this.selectedLayerId) {
            overlay?.classList.add('hidden');
            return;
        }
        
        const layer = this.getLayer(this.selectedLayerId);
        if (!layer || !layer.visible) {
            overlay.classList.add('hidden');
            return;
        }
        
        overlay.classList.remove('hidden');
        
        const box = overlay.querySelector('.selection-box');
        box.style.left = `${layer.x * this.zoom}px`;
        box.style.top = `${layer.y * this.zoom}px`;
        box.style.width = `${layer.width * this.zoom}px`;
        box.style.height = `${layer.height * this.zoom}px`;
        box.style.transform = `rotate(${layer.rotation}deg)`;
        box.style.transformOrigin = 'center center';
    }
    
    getResizeHandleAt(x, y) {
        if (!this.selectedLayerId) return null;
        
        const layer = this.getLayer(this.selectedLayerId);
        const handles = [
            { name: 'nw', x: layer.x, y: layer.y },
            { name: 'n', x: layer.x + layer.width / 2, y: layer.y },
            { name: 'ne', x: layer.x + layer.width, y: layer.y },
            { name: 'w', x: layer.x, y: layer.y + layer.height / 2 },
            { name: 'e', x: layer.x + layer.width, y: layer.y + layer.height / 2 },
            { name: 'sw', x: layer.x, y: layer.y + layer.height },
            { name: 's', x: layer.x + layer.width / 2, y: layer.y + layer.height },
            { name: 'se', x: layer.x + layer.width, y: layer.y + layer.height }
        ];
        
        const threshold = 10 / this.zoom;
        for (const handle of handles) {
            if (Math.abs(x - handle.x) < threshold && Math.abs(y - handle.y) < threshold) {
                return handle.name;
            }
        }
        return null;
    }
    
    isRotationHandleAt(x, y) {
        if (!this.selectedLayerId) return false;
        
        const layer = this.getLayer(this.selectedLayerId);
        const handleX = layer.x + layer.width / 2;
        const handleY = layer.y - 25;
        const threshold = 15 / this.zoom;
        
        return Math.abs(x - handleX) < threshold && Math.abs(y - handleY) < threshold;
    }
    
    updateCursor(x, y) {
        const handle = this.getResizeHandleAt(x, y);
        
        if (handle) {
            const cursors = {
                nw: 'nw-resize', n: 'n-resize', ne: 'ne-resize',
                w: 'w-resize', e: 'e-resize',
                sw: 'sw-resize', s: 's-resize', se: 'se-resize'
            };
            this.canvas.style.cursor = cursors[handle] || 'default';
        } else if (this.isRotationHandleAt(x, y)) {
            this.canvas.style.cursor = 'grab';
        } else {
            this.canvas.style.cursor = this.currentTool === 'select' ? 'default' : 'crosshair';
        }
    }
    
    // ==================== TRANSFORMACIONES ====================
    
    resizeLayer(x, y) {
        const layer = this.getLayer(this.selectedLayerId);
        if (!layer || layer.locked) return;
        
        const handle = this.resizeHandle;
        const startX = this.dragStart.x;
        const startY = this.dragStart.y;
        
        // Calcular deltas
        let dx = x - startX;
        let dy = y - startY;
        
        // Aplicar redimensionamiento según handle
        if (handle.includes('e')) {
            layer.width = Math.max(10, layer.width + dx);
        }
        if (handle.includes('w')) {
            const newWidth = Math.max(10, layer.width - dx);
            layer.x = layer.x + (layer.width - newWidth);
            layer.width = newWidth;
        }
        if (handle.includes('s')) {
            layer.height = Math.max(10, layer.height + dy);
        }
        if (handle.includes('n')) {
            const newHeight = Math.max(10, layer.height - dy);
            layer.y = layer.y + (layer.height - newHeight);
            layer.height = newHeight;
        }
        
        this.dragStart = { x, y };
        this.render();
        this.updatePropertiesPanel();
    }
    
    rotateLayer(x, y) {
        const layer = this.getLayer(this.selectedLayerId);
        if (!layer || layer.locked) return;
        
        const centerX = layer.x + layer.width / 2;
        const centerY = layer.y + layer.height / 2;
        
        const angle = Math.atan2(y - centerY, x - centerX);
        layer.rotation = (angle * 180 / Math.PI) - 90;
        
        this.render();
        this.updatePropertiesPanel();
    }
    
    flipHorizontal() {
        const layer = this.getLayer(this.selectedLayerId);
        if (layer && !layer.locked) {
            layer.flipX = !layer.flipX;
            this.render();
            this.saveState();
        }
    }
    
    flipVertical() {
        const layer = this.getLayer(this.selectedLayerId);
        if (layer && !layer.locked) {
            layer.flipY = !layer.flipY;
            this.render();
            this.saveState();
        }
    }
    
    // ==================== PROPIEDADES ====================
    
    updatePropertiesPanel() {
        const layer = this.getLayer(this.selectedLayerId);
        if (!layer) return;
        
        document.getElementById('propX').value = Math.round(layer.x);
        document.getElementById('propY').value = Math.round(layer.y);
        document.getElementById('propW').value = Math.round(layer.width);
        document.getElementById('propH').value = Math.round(layer.height);
        document.getElementById('propRotation').value = Math.round(layer.rotation);
        document.getElementById('propOpacity').value = Math.round(layer.opacity * 100);
    }
    
    updateLayerFromProperty(propId, value) {
        const layer = this.getLayer(this.selectedLayerId);
        if (!layer || layer.locked) return;
        
        const numValue = parseFloat(value);
        if (isNaN(numValue)) return;
        
        switch (propId) {
            case 'propX': layer.x = numValue; break;
            case 'propY': layer.y = numValue; break;
            case 'propW': layer.width = Math.max(1, numValue); break;
            case 'propH': layer.height = Math.max(1, numValue); break;
            case 'propRotation': layer.rotation = numValue; break;
            case 'propOpacity': layer.opacity = Math.max(0, Math.min(1, numValue / 100)); break;
        }
        
        this.render();
        this.updateSelectionOverlay();
    }
    
    updateTextProperty(propId, value) {
        const layer = this.getLayer(this.selectedLayerId);
        if (!layer || layer.type !== 'text' || layer.locked) return;
        
        if (!layer.content) layer.content = {};
        if (!layer.style) layer.style = {};
        
        switch (propId) {
            case 'textContent': layer.content.text = value; break;
            case 'textFont': layer.style.fontFamily = value; break;
            case 'textSize': layer.style.fontSize = parseInt(value); break;
            case 'textColor': layer.style.color = value; break;
        }
        
        this.render();
    }
    
    updateShapeProperty(propId, value) {
        const layer = this.getLayer(this.selectedLayerId);
        if (!layer || layer.type !== 'shape' || layer.locked) return;
        
        if (!layer.style) layer.style = {};
        
        switch (propId) {
            case 'shapeFill': layer.style.fill = value; break;
            case 'shapeStroke': layer.style.stroke = value; break;
            case 'shapeStrokeWidth': layer.style.strokeWidth = parseInt(value); break;
        }
        
        this.render();
    }
    
    showTextProperties() {
        document.getElementById('textProperties')?.classList.remove('hidden');
        document.getElementById('shapeProperties')?.classList.add('hidden');
        document.getElementById('imageProperties')?.classList.add('hidden');
    }
    
    showShapeProperties() {
        document.getElementById('textProperties')?.classList.add('hidden');
        document.getElementById('shapeProperties')?.classList.remove('hidden');
        document.getElementById('imageProperties')?.classList.add('hidden');
    }
    
    showImageProperties() {
        document.getElementById('textProperties')?.classList.add('hidden');
        document.getElementById('shapeProperties')?.classList.add('hidden');
        document.getElementById('imageProperties')?.classList.remove('hidden');
    }
    
    hideAllProperties() {
        document.getElementById('textProperties')?.classList.add('hidden');
        document.getElementById('shapeProperties')?.classList.add('hidden');
        document.getElementById('imageProperties')?.classList.add('hidden');
    }
    
    // ==================== LISTA DE CAPAS ====================
    
    updateLayersList() {
        const container = document.getElementById('layersList');
        if (!container) return;
        
        const sorted = [...this.layers].sort((a, b) => b.zIndex - a.zIndex);
        
        container.innerHTML = sorted.map(layer => {
            const icons = {
                text: '📝',
                image: '🖼️',
                shape: '🔷'
            };
            
            const isSelected = layer.id === this.selectedLayerId;
            const isLocked = layer.locked;
            const isHidden = !layer.visible;
            
            return `
                <div class="layer-item ${isSelected ? 'active' : ''} ${isLocked ? 'locked' : ''} ${isHidden ? 'hidden-layer' : ''}"
                     data-id="${layer.id}"
                     onclick="editor.selectLayer('${layer.id}')">
                    <span class="layer-icon">${icons[layer.type] || '📄'}</span>
                    <span class="layer-name">${Utils.sanitize(layer.name)}</span>
                    ${isLocked ? '<span class="layer-status">🔒</span>' : ''}
                    ${isHidden ? '<span class="layer-status">👁️‍🗨️</span>' : ''}
                </div>
            `;
        }).join('');
    }
    
    moveLayerUp() {
        const layer = this.getLayer(this.selectedLayerId);
        if (layer) {
            layer.zIndex++;
            this.render();
            this.updateLayersList();
            this.saveState();
        }
    }
    
    moveLayerDown() {
        const layer = this.getLayer(this.selectedLayerId);
        if (layer && layer.zIndex > 0) {
            layer.zIndex--;
            this.render();
            this.updateLayersList();
            this.saveState();
        }
    }
    
    lockLayer() {
        const layer = this.getLayer(this.selectedLayerId);
        if (layer) {
            layer.locked = !layer.locked;
            this.updateLayersList();
            Toast.info(layer.locked ? 'Capa bloqueada' : 'Capa desbloqueada');
        }
    }
    
    toggleLayerVisibility() {
        const layer = this.getLayer(this.selectedLayerId);
        if (layer) {
            layer.visible = !layer.visible;
            this.render();
            this.updateLayersList();
        }
    }
    
    // ==================== HERRAMIENTAS ====================
    
    setTool(tool) {
        this.currentTool = tool;
        
        document.querySelectorAll('.tool-btn').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.tool === tool);
        });
        
        this.canvas.dataset.tool = tool;
        
        // Mostrar/ocultar panel de formas
        const shapesPanel = document.getElementById('shapesPanel');
        if (shapesPanel) {
            shapesPanel.style.display = tool === 'shape' ? 'block' : 'none';
        }
    }
    
    // ==================== ZOOM ====================
    
    zoomIn() {
        this.setZoom(Math.min(this.zoom + 0.1, 3));
    }
    
    zoomOut() {
        this.setZoom(Math.max(this.zoom - 0.1, 0.25));
    }
    
    resetZoom() {
        this.setZoom(1);
    }
    
    setZoom(level) {
        this.zoom = Math.max(0.25, Math.min(3, level));
        
        this.canvas.style.transform = `scale(${this.zoom})`;
        this.canvas.style.transformOrigin = 'center center';
        
        document.getElementById('zoomLevel').textContent = `${Math.round(this.zoom * 100)}%`;
        
        this.updateSelectionOverlay();
    }
    
    // ==================== HISTORIAL ====================
    
    saveState() {
        // Eliminar estados futuros si estamos en medio del historial
        if (this.historyIndex < this.history.length - 1) {
            this.history = this.history.slice(0, this.historyIndex + 1);
        }
        
        // Guardar estado actual
        const state = JSON.stringify(this.layers);
        this.history.push(state);
        
        // Limitar historial
        if (this.history.length > this.maxHistory) {
            this.history.shift();
        } else {
            this.historyIndex++;
        }
    }
    
    undo() {
        if (this.historyIndex > 0) {
            this.historyIndex--;
            this.layers = JSON.parse(this.history[this.historyIndex]);
            this.render();
            this.updateLayersList();
            Toast.info('Deshacer');
        }
    }
    
    redo() {
        if (this.historyIndex < this.history.length - 1) {
            this.historyIndex++;
            this.layers = JSON.parse(this.history[this.historyIndex]);
            this.render();
            this.updateLayersList();
            Toast.info('Rehacer');
        }
    }
    
    // ==================== GUARDAR Y EXPORTAR ====================
    
    async saveProject() {
        try {
            const data = {
                name: this.project.name,
                width: this.project.width,
                height: this.project.height,
                background: this.project.backgroundColor,
                layers: this.layers.map(l => ({
                    id: l.id,
                    type: l.type,
                    name: l.name,
                    zIndex: l.zIndex,
                    visible: l.visible,
                    locked: l.locked,
                    opacity: l.opacity,
                    x: l.x,
                    y: l.y,
                    width: l.width,
                    height: l.height,
                    rotation: l.rotation,
                    scaleX: l.scaleX,
                    scaleY: l.scaleY,
                    flipX: l.flipX,
                    flipY: l.flipY,
                    content: l.content,
                    style: l.style
                }))
            };
            
            const result = await API.post(
                `/editor/project/${this.project.id}/save/`,
                data
            );
            
            if (result.success) {
                Toast.success('Proyecto guardado');
            } else {
                throw new Error(result.error || 'Error al guardar');
            }
        } catch (error) {
            console.error('Error:', error);
            Toast.error('Error al guardar: ' + error.message);
        }
    }
    
    showExportModal() {
        document.getElementById('exportModal')?.classList.remove('hidden');
        this.updateExportPreview();
    }
    
    hideExportModal() {
        document.getElementById('exportModal')?.classList.add('hidden');
    }
    
    updateExportPreview() {
        const previewCanvas = document.getElementById('exportPreviewCanvas');
        if (!previewCanvas) return;
        
        const ctx = previewCanvas.getContext('2d');
        
        // Escala para preview
        const scale = Math.min(
            previewCanvas.width / this.canvas.width,
            previewCanvas.height / this.canvas.height
        ) * 0.8;
        
        ctx.clearRect(0, 0, previewCanvas.width, previewCanvas.height);
        ctx.save();
        ctx.translate(
            (previewCanvas.width - this.canvas.width * scale) / 2,
            (previewCanvas.height - this.canvas.height * scale) / 2
        );
        ctx.scale(scale, scale);
        
        // Dibujar fondo
        ctx.fillStyle = this.project.backgroundColor;
        ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);
        
        // Dibujar capas
        const sortedLayers = [...this.layers]
            .filter(l => l.visible)
            .sort((a, b) => a.zIndex - b.zIndex);
        
        // Simplified rendering for preview
        sortedLayers.forEach(layer => {
            ctx.save();
            ctx.globalAlpha = layer.opacity;
            ctx.translate(layer.x + layer.width / 2, layer.y + layer.height / 2);
            ctx.rotate((layer.rotation * Math.PI) / 180);
            ctx.translate(-layer.width / 2, -layer.height / 2);
            
            if (layer.type === 'text') {
                const content = layer.content || {};
                const style = layer.style || {};
                ctx.font = `${style.fontSize || 24}px ${style.fontFamily || 'Arial'}`;
                ctx.fillStyle = style.color || '#000000';
                ctx.fillText(content.text || '', 0, parseInt(style.fontSize || 24));
            } else if (layer.type === 'shape') {
                const style = layer.style || {};
                ctx.fillStyle = style.fill || '#6366f1';
                ctx.fillRect(0, 0, layer.width, layer.height);
            } else if (layer.type === 'image' && layer.imageElement) {
                ctx.drawImage(layer.imageElement, 0, 0, layer.width, layer.height);
            }
            
            ctx.restore();
        });
        
        ctx.restore();
    }
    
    async exportProject() {
        try {
            const format = document.getElementById('exportFormat').value;
            const quality = document.getElementById('exportQuality').value;
            
            const result = await API.post('/api/export/', {
                project_id: this.project.id,
                format: format,
                quality: parseInt(quality)
            });
            
            if (result.success) {
                Utils.downloadFile(result.download_url, result.filename);
                Toast.success('Exportación exitosa');
                this.hideExportModal();
            } else {
                throw new Error(result.error || 'Error al exportar');
            }
        } catch (error) {
            console.error('Error:', error);
            Toast.error('Error al exportar: ' + error.message);
        }
    }
    
    // ==================== IMÁGENES ====================
    
    showUploadModal() {
        const modal = document.getElementById('uploadModal');
        const fileInput = document.getElementById('imageUpload');
        const uploadArea = document.getElementById('uploadArea');
        
        modal?.classList.remove('hidden');
        
        // Click para subir
        uploadArea?.addEventListener('click', () => fileInput?.click());
        
        // Cambio de archivo
        fileInput?.addEventListener('change', (e) => {
            this.handleImageUpload(e.target.files[0]);
        });
        
        // Drag and drop
        uploadArea?.addEventListener('dragover', (e) => {
            e.preventDefault();
            uploadArea.classList.add('dragover');
        });
        
        uploadArea?.addEventListener('dragleave', () => {
            uploadArea.classList.remove('dragover');
        });
        
        uploadArea?.addEventListener('drop', (e) => {
            e.preventDefault();
            uploadArea.classList.remove('dragover');
            this.handleImageUpload(e.dataTransfer.files[0]);
        });
    }
    
    hideUploadModal() {
        document.getElementById('uploadModal')?.classList.add('hidden');
    }
    
    handleImageUpload(file) {
        if (!file) return;
        
        // Validar
        const validation = FileValidator.validate(file);
        if (!validation.valid) {
            Toast.error(validation.errors.join(', '));
            return;
        }
        
        const reader = new FileReader();
        reader.onload = (e) => {
            this.addImageLayer(e.target.result, file);
            this.hideUploadModal();
            Toast.success('Imagen agregada');
        };
        reader.readAsDataURL(file);
    }
    
    cropImage() {
        const layer = this.getLayer(this.selectedLayerId);
        if (!layer || layer.type !== 'image') {
            Toast.warning('Selecciona una imagen para recortar');
            return;
        }
        
        // Implementación básica de crop
        Toast.info('Función de recorte - selecciona el área en el canvas');
    }
    
    async removeBackground() {
        const layer = this.getLayer(this.selectedLayerId);
        if (!layer || layer.type !== 'image' || !layer.content?.src) {
            Toast.warning('Selecciona una imagen');
            return;
        }
        
        try {
            Toast.info('Procesando...');
            
            const result = await API.post('/api/process-image/', {
                operation: 'remove_bg',
                image_path: layer.content.src
            });
            
            if (result.success) {
                // Actualizar imagen
                const img = new Image();
                img.onload = () => {
                    layer.imageElement = img;
                    layer.content.src = result.url;
                    this.render();
                    Toast.success('Fondo eliminado');
                };
                img.src = result.url;
            }
        } catch (error) {
            Toast.error('Error al procesar imagen');
        }
    }
}

// Inicializar editor cuando el DOM esté listo
document.addEventListener('DOMContentLoaded', () => {
    if (document.getElementById('mainCanvas')) {
        window.editor = new LogoEditor();
        
        // Actualizar preview de calidad
        document.getElementById('exportQuality')?.addEventListener('input', (e) => {
            document.getElementById('qualityValue').textContent = e.target.value + '%';
        });
    }
});
