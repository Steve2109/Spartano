# LogoAI 🎨

**Creador de Logotipos Profesional al estilo Canva**

[![Python](https://img.shields.io/badge/Python-3.11-blue)](https://www.python.org/)
[![Django](https://img.shields.io/badge/Django-4.2-green)](https://www.djangoproject.com/)
[![License](https://img.shields.io/badge/License-MIT-yellow)](LICENSE)

**Autor:** T&M Technology Ec  
**Soporte:** [soporte@tymtechnology.shop](mailto:soporte@tymtechnology.shop)  
**Dominio:** https://logoai.tymtechnology.shop

---

## ⚠️ IMPORTANTE: Ubicación de Instalación

> **El proyecto DEBE estar ubicado en `/opt/logoai/` para funcionar correctamente.**
> 
> El script de instalación y los servicios systemd están configurados para esta ruta.
> NO instales en el directorio home (`~`) o en otras ubicaciones.
>
> ```bash
> # Ubicación correcta:
> /opt/logoai/
> 
> # ❌ Incorrecto:
> ~/logoai/
> /root/logoai/
> /home/usuario/logoai/
> ```

---

## ✨ Características

- 🎨 **Editor Canvas Intuitivo** - Diseño profesional tipo Canva con canvas interactivo
- 📝 **Capas y Elementos** - Sistema completo de capas con textos, formas e imágenes
- ✂️ **Edición de Imágenes** - Recorte, redimensionamiento, filtros y efectos
- 🖼️ **Múltiples Formatos** - Exporta en PNG, JPG, SVG y PDF en alta calidad
- 📱 **Plantillas Profesionales** - Biblioteca de plantillas para diversas categorías
- 🔒 **Seguridad** - Sanitización de entradas, rate limiting, protección CSRF
- 🐳 **Docker Ready** - Despliegue simplificado con Docker Compose

---

## 🚀 Tecnologías

| Componente | Tecnología |
|------------|-----------|
| Backend | Django 4.2 + Django REST Framework |
| Frontend | HTML5 Canvas + Vanilla JS |
| Procesamiento | Pillow (PIL) |
| Base de datos | PostgreSQL 15 |
| Cache/Queue | Redis 7 + Celery |
| Servidor | Gunicorn + WhiteNoise |
| Contenedores | Docker + Docker Compose |

---

## 📋 Requisitos

- Docker y Docker Compose (recomendado)
- O: Python 3.11+, PostgreSQL 15+, Redis 7+
- 4GB RAM mínimo, 8GB recomendado
- 20GB espacio en disco

---

## 🛠️ Instalación Automática (Recomendada)

El script `install.sh` soporta **DOS métodos de instalación** y te permite elegir:

| Método | Descripción | Ideal para |
|--------|-------------|------------|
| 🐳 **Docker** | Instalación rápida y aislada | Producción, VPS |
| 🐍 **Python Manual** | Sin contenedores, mayor control | LXC, servidores sin Docker |

```bash
# 1. Clonar repositorio en /opt/logoai (OBLIGATORIO esta ruta)
sudo mkdir -p /opt/logoai
cd /opt/logoai
git clone https://github.com/tmtechnology/logoai.git .

# 2. Ejecutar instalador (selecciona Docker o Manual)
sudo bash scripts/install.sh

# 3. Seguir las instrucciones del script
# El menú te guiará por todo el proceso

# 4. Después de la instalación:
# Docker:
#   logoai start
#   logoai migrate
#   logoai shell → python manage.py createsuperuser
#
# Manual:
#   logoai migrate
#   logoai shell → python manage.py createsuperuser
#   logoai start
```

📖 **Guía completa:** [DEPLOY.md](DEPLOY.md) | 📄 **Instalación manual:** Ver DEPLOY.md sección "Opción 2"

---

## 📁 Estructura del Proyecto

```
logoai/
├── logoai/                 # Configuración Django principal
│   ├── settings.py         # Configuración de settings
│   ├── urls.py            # URLs principales
│   ├── wsgi.py            # WSGI config
│   ├── asgi.py            # ASGI config
│   ├── celery.py          # Configuración Celery
│   └── middleware.py      # Middleware personalizado
│
├── editor/                 # App del editor
│   ├── models.py          # Modelos: Project, Layer, Template
│   ├── views.py           # Vistas del editor
│   ├── image_processor.py # Procesamiento de imágenes
│   └── tasks.py           # Tareas Celery
│
├── api/                    # API REST
│   ├── views.py           # Endpoints API
│   ├── serializers.py     # Serializadores DRF
│   └── urls.py            # Rutas API
│
├── users/                  # Gestión de usuarios
│   ├── models.py          # Perfiles y configuraciones
│   ├── forms.py           # Formularios de auth
│   └── views.py           # Vistas de usuarios
│
├── templates/              # Templates HTML
│   ├── base.html          # Template base
│   ├── home.html          # Página de inicio
│   ├── editor/            # Templates del editor
│   └── users/             # Templates de usuarios
│
├── static/                 # Archivos estáticos
│   ├── css/               # Hojas de estilo
│   └── js/                # JavaScript
│
├── scripts/                # Scripts de utilidad
│   ├── install.sh         # Instalador automático
│   ├── deploy.sh          # Script de despliegue
│   └── backup.sh          # Script de backup
│
├── Dockerfile              # Dockerfile para producción
├── docker-compose.yml      # Docker Compose
├── requirements.txt        # Dependencias Python
└── DEPLOY.md              # Guía de despliegue
```

---

## 🔐 Seguridad

- ✅ **No expone API Keys** - Variables en `.env`
- ✅ **Sanitización completa** - Entradas validadas con bleach
- ✅ **Rate limiting** - Protección contra abuso (30-100 req/min)
- ✅ **CSRF protection** - Tokens en formularios y API
- ✅ **SQL injection safe** - Uso de ORM Django
- ✅ **XSS protection** - Escapado automático en templates
- ✅ **Secure headers** - CSP, HSTS, X-Frame-Options
- ✅ **Password validation** - Mínimo 12 caracteres

---

## 🎨 Funcionalidades del Editor

### Herramientas
- **Selección** - Mover, redimensionar, rotar elementos
- **Texto** - Múltiples fuentes, tamaños, colores
- **Formas** - Rectángulos, círculos, triángulos, estrellas, corazones
- **Imágenes** - Upload, drag & drop, filtros
- **Capas** - Ordenar, bloquear, ocultar, agrupar

### Propiedades
- Posición (X, Y)
- Dimensiones (W, H)
- Rotación (0-360°)
- Opacidad (0-100%)
- Flip horizontal/vertical
- Colores de relleno y borde

### Exportación
- **PNG** - Con transparencia
- **JPEG** - Calidad ajustable
- **SVG** - Formato vectorial
- **PDF** - Para impresión

---

## 🔧 API Endpoints

```
GET  /api/health/           # Verificación de salud
GET  /api/projects/         # Listar proyectos
POST /api/projects/         # Crear proyecto
GET  /api/projects/{id}/    # Detalle de proyecto
POST /api/upload-image/     # Subir imagen
POST /api/process-image/    # Procesar imagen
POST /api/export/           # Exportar proyecto
```

---

## 📝 Configuración Nginx Proxy Manager

```
Domain Names: logoai.tymtechnology.shop
Scheme: http
Forward Hostname: 10.0.1.40
Forward Port: 32299

SSL: Request a new SSL Certificate
✓ Force SSL
✓ HTTP/2 Support
✓ HSTS Enabled
```

---

## 🐛 Desarrollo

```bash
# Instalar dependencias
pip install -r requirements.txt

# Configurar base de datos local
python manage.py migrate

# Crear superusuario
python manage.py createsuperuser

# Iniciar servidor de desarrollo
python manage.py runserver 0.0.0.0:32299

# En otra terminal: Celery worker
celery -A logoai worker --loglevel=info
```

---

## 📊 Monitoreo

```bash
# Ver logs
docker compose logs -f web

# Estado de servicios
docker compose ps

# Uso de recursos
docker stats

# Health check
curl https://logoai.tymtechnology.shop/api/health/
```

---

## 🔄 Backup y Restore

```bash
# Backup automático
bash scripts/backup.sh

# Manual backup
pg_dump -U logoai_user logoai_db > backup.sql

# Restore
psql -U logoai_user logoai_db < backup.sql
```

---

## 📞 Soporte

- **Email:** [soporte@tymtechnology.shop](mailto:soporte@tymtechnology.shop)
- **Desarrollador:** T&M Technology Ec
- **Issues:** GitHub Issues (si aplica)

---

## 📜 Licencia

Copyright © 2024 T&M Technology Ec. Todos los derechos reservados.

---

**Hecho con ❤️ en Ecuador**
