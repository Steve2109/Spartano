# LogoAI - Creador de Logotipos Profesional

**Un diseñador de logotipos tipo Canva con PHP, Pug, Tailwind CSS y JavaScript.**

---

## Información del Proyecto

- **Autor:** T&M Technology Ec
- **Soporte:** soporte@tymtechnology.shop
- **Dominio:** http://logoai.tymtechnology.shop/
- **Puerto:** 32299
- **IP Interna:** 10.0.1.40:32299

---

## Características

### Editor Visual Tipo Canva
- Canvas interactivo con arrastrar y soltar
- Sistema de capas avanzado
- Múltiples herramientas de diseño
- Zoom y navegación fluida

### Elementos de Diseño
- Texto con múltiples fuentes y estilos
- Formas geométricas (rectángulos, círculos, triángulos, estrellas)
- Imágenes con soporte para arrastrar y soltar
- Líneas y flechas

### Edición Avanzada
- **Recortar imágenes:** Herramienta de crop integrada
- **Redimensionar:** Handles de resize con proporciones
- **Rotación:** Rotación libre de elementos
- **Opacidad:** Control de transparencia
- **Blend modes:** Modos de mezcla de capas

### Sistema de Capas
- Ordenar capas (arriba/abajo)
- Visibilidad toggle
- Duplicar capas
- Eliminar capas
- Bloquear capas

### Exportación
- **Formatos:** PNG, JPG, WebP, SVG
- **Tamaños personalizados:** Configurable
- **Calidad ajustable:** Especialmente para JPG
- **Fondo transparente:** Soporte para PNG y SVG

### Seguridad
- Sanitización de todas las entradas
- Rate limiting en rutas API
- JWT para autenticación
- Protección CSRF
- Headers de seguridad
- No expone API keys

---

## Arquitectura

```
Internet → HTTPS → Nginx Proxy Manager → HTTP → Docker → PHP:32299
                                              ↑
                                       SQLite + Uploads
```

### Tecnologías
- **Backend:** PHP 8.2, SQLite
- **Frontend:** Pug, Tailwind CSS, JavaScript Vanilla
- **Infraestructura:** Docker, Docker Compose
- **Proxy:** Nginx Proxy Manager (Let's Encrypt SSL)

---

## Estructura del Proyecto

```
.
├── docker-compose.yml          # Configuración Docker
├── Dockerfile                  # Imagen PHP-Apache
├── apache.conf                 # Configuración Apache
├── composer.json               # Dependencias PHP
├── .env.example                # Variables de entorno
├── .htaccess                   # Reglas Apache
├── README.md                   # Este archivo
├── INSTALL_DEBIAN13.md        # Guía de instalación
├── public/                     # Document root
│   ├── index.php              # Punto de entrada
│   └── js/                    # JavaScript frontend
│       ├── editor.js          # Editor principal
│       ├── layers.js          # Gestión de capas
│       └── export.js          # Exportación
├── src/                        # Código fuente PHP
│   ├── config/
│   │   └── config.php         # Configuración
│   ├── Core/
│   │   ├── Database.php       # Base de datos SQLite
│   │   ├── Request.php        # Manejo de requests
│   │   ├── Response.php       # Manejo de responses
│   │   ├── Router.php         # Enrutamiento
│   │   ├── Security.php       # Seguridad y JWT
│   │   └── RateLimiter.php    # Rate limiting
│   └── Controllers/
│       ├── AuthController.php
│       ├── ProjectController.php
│       ├── UploadController.php
│       └── ExportController.php
├── templates/                  # Templates Pug
│   ├── layout.pug             # Layout base
│   ├── index.pug              # Página principal
│   └── editor.html            # Editor (HTML compilado)
├── uploads/                    # Imágenes subidas
├── data/                       # Base de datos SQLite
└── logs/                       # Logs de aplicación
```

---

## Instalación Rápida

### Requisitos
- Docker y Docker Compose
- Nginx Proxy Manager (recomendado) o Nginx/Apache

### Pasos

```bash
# 1. Clonar o copiar archivos
cd /opt/logoai

# 2. Configurar variables de entorno
cp .env.example .env
# Editar .env con tus valores

# 3. Construir e iniciar
docker compose up -d

# 4. Configurar Nginx Proxy Manager
# - Crear proxy host: logoai.tymtechnology.shop → 10.0.1.40:32299
# - Solicitar certificado SSL
```

Ver `INSTALL_DEBIAN13.md` para instalación completa en Debian 13.

---

## Uso

### Editor Principal
1. Abrir `https://logoai.tymtechnology.shop/editor`
2. Seleccionar herramienta del sidebar
3. Agregar elementos al canvas
4. Editar propiedades en el panel derecho
5. Exportar desde el botón superior

### Atajos de Teclado
- `Ctrl+Z` - Deshacer
- `Ctrl+Y` - Rehacer
- `Delete` - Eliminar selección
- `Escape` - Deseleccionar
- `Ctrl+S` - Guardar proyecto

---

## API Endpoints

### Autenticación
```
POST /api/auth/login
POST /api/auth/register
POST /api/auth/logout
```

### Proyectos
```
GET    /api/projects          # Listar proyectos
POST   /api/projects          # Crear proyecto
GET    /api/projects/{id}     # Obtener proyecto
PUT    /api/projects/{id}     # Actualizar proyecto
DELETE /api/projects/{id}     # Eliminar proyecto
```

### Subidas
```
POST /api/upload              # Subir imagen
```

### Exportación
```
POST /api/export              # Exportar diseño (PNG, JPG, SVG)
```

---

## Variables de Entorno

| Variable | Descripción | Default |
|----------|-------------|---------|
| `DB_PATH` | Ruta base de datos | `/var/www/html/data/logoai.db` |
| `JWT_SECRET` | Secret para JWT | Auto-generado |
| `RATE_LIMIT_REQUESTS` | Requests por ventana | 100 |
| `RATE_LIMIT_WINDOW` | Ventana rate limit (seg) | 60 |
| `APP_ENV` | Entorno | `production` |
| `UPLOAD_MAX_SIZE` | Tamaño máximo upload | 50M |

---

## Seguridad

1. **Rate Limiting:** 100 requests/minuto por IP
2. **Input Sanitization:** Todas las entradas son sanitizadas
3. **JWT Authentication:** Tokens con expiración de 1 hora
4. **File Upload Security:** Validación MIME y dimensiones
5. **Security Headers:** X-Frame-Options, X-XSS-Protection, etc.
6. **SQL Injection Protection:** Uso de prepared statements

---

## Licencia

Copyright (c) 2024 T&M Technology Ec

Todos los derechos reservados.

---

## Soporte

Para soporte técnico:
- **Email:** soporte@tymtechnology.shop
- **Desarrollador:** T&M Technology Ec
