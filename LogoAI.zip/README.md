# Logo AI Creator

**Author:** T&M Technology Ec <soporte@tymtechnology.shop>  
**Website:** https://logoai.tymtechnology.shop

A powerful Canva-style logo design application built with modern web technologies.

## Features

### Design Tools
- **Canvas Editor:** Professional-grade design canvas with drag & drop
- **Text Tool:** Rich text editing with fonts, styling, and effects
- **Shapes:** Rectangles, circles, triangles, hexagons, stars, polygons
- **Image Upload:** Support for PNG, JPG, WEBP, SVG, GIF
- **Layer Management:** Full layer control with visibility, locking, ordering
- **Properties Panel:** Fine-tune colors, sizes, positions, opacity

### Export Options
- **Formats:** PNG, JPEG, WebP, SVG, PDF
- **Custom Sizes:** Export at any resolution
- **Quality Control:** Adjustable compression settings
- **Transparent Background:** PNG and WebP support

### Security
- Input sanitization with XSS protection
- Rate limiting on all API endpoints
- Helmet.js security headers
- CORS protection
- Non-root Docker container

## Quick Start

### Development

```bash
# Install all dependencies
npm run install:all

# Start development servers
npm run dev

# Backend: http://localhost:32299
# Frontend: http://localhost:5173
```

### Production Deployment

#### Option 1: Docker (Recommended)

```bash
# Build and start
docker-compose up -d --build

# View logs
docker-compose logs -f
```

#### Option 2: Manual with PM2

```bash
# Run installation script
chmod +x install-debian13.sh
./install-debian13.sh

# Or manually:
npm run install:all
npm run build
npm start
```

See [deployments-docs/README.md](deployments-docs/README.md) for detailed deployment instructions.

## Architecture

```
Internet → HTTPS → Nginx Proxy Manager → HTTP → Node.js:32299
                     (NPM máquina)          (LogoAI máquina 10.0.1.40)
```

### Tech Stack

**Backend:**
- Node.js 20
- Express.js with TypeScript
- Sharp (image processing)
- Multer (file uploads)
- Winston (logging)

**Frontend:**
- React 18 with TypeScript
- Fabric.js (canvas engine)
- Zustand (state management)
- Tailwind CSS (styling)
- Lucide React (icons)

## Configuration

Create `backend/.env`:

```env
NODE_ENV=production
PORT=32299
HOST=0.0.0.0
CORS_ORIGIN=https://logoai.tymtechnology.shop
RATE_LIMIT_WINDOW_MS=900000
RATE_LIMIT_MAX_REQUESTS=100
LOG_LEVEL=info
```

## API Endpoints

| Endpoint | Description |
|----------|-------------|
| `GET /api/health` | Health check |
| `POST /api/upload` | Upload images |
| `POST /api/export` | Export logo (PNG, JPG, WebP, SVG, PDF) |
| `POST /api/export/preview` | Generate preview |
| `GET /api/image/metadata/:filename` | Get image metadata |
| `POST /api/image/resize/:filename` | Resize image |
| `POST /api/image/crop/:filename` | Crop image |
| `POST /api/image/rotate/:filename` | Rotate image |
| `POST /api/image/filter/:filename` | Apply filters |
| `POST /api/image/optimize/:filename` | Optimize image |

## Keyboard Shortcuts

| Shortcut | Action |
|----------|--------|
| `Ctrl + Z` | Undo |
| `Ctrl + Y` | Redo |
| `Ctrl + C` | Copy |
| `Ctrl + V` | Paste |
| `Ctrl + D` | Duplicate |
| `Delete` | Delete selected |
| `Ctrl + +` | Zoom in |
| `Ctrl + -` | Zoom out |
| `Ctrl + 0` | Reset zoom |

## File Structure

```
logoai-creator/
├── backend/
│   ├── src/
│   │   ├── routes/
│   │   ├── middleware/
│   │   ├── utils/
│   │   └── server.ts
│   ├── uploads/
│   └── dist/
├── frontend/
│   ├── src/
│   │   ├── components/
│   │   ├── store/
│   │   └── App.tsx
│   └── dist/
├── deployments-docs/
├── Dockerfile
├── docker-compose.yml
└── install-debian13.sh
```

## Security Considerations

1. **API Keys:** Never commit `.env` files with real credentials
2. **Rate Limiting:** Configured at 100 requests per 15 minutes
3. **File Uploads:** Limited to 10MB, validated MIME types
4. **Input Sanitization:** All inputs sanitized with xss library
5. **CORS:** Restricted to specific origin only
6. **Helmet:** Security headers enabled

## License

© 2024 T&M Technology Ec. All rights reserved.

## Support

- **Email:** soporte@tymtechnology.shop
- **Website:** https://tymtechnology.shop
- **Documentation:** See `deployments-docs/` directory

---

Built with ❤️ by T&M Technology Ec
