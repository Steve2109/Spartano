# 🌐 Despliegue con Apache Nativo

Guía para desplegar LogoAI usando Apache en Debian 13 sin Docker.

## 📋 Requisitos

- Debian 13 (Bookworm)
- Node.js 20 LTS
- Apache 2.4+
- PM2 (para gestión de procesos)
- mod_proxy y mod_proxy_http habilitados

## 🔧 Instalación Paso a Paso

### 1. Actualizar Sistema

```bash
sudo apt update && sudo apt upgrade -y
```

### 2. Instalar Node.js 20 LTS

```bash
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo bash -
sudo apt install -y nodejs

# Verificar
node --version  # v20.x.x
npm --version   # 10.x.x
```

### 3. Instalar Apache y Módulos

```bash
sudo apt install -y apache2
sudo a2enmod proxy
sudo a2enmod proxy_http
sudo a2enmod rewrite
sudo a2enmod headers
sudo a2enmod deflate
sudo a2enmod ssl
sudo systemctl restart apache2
sudo systemctl enable apache2
```

### 4. Instalar PM2

```bash
sudo npm install -g pm2
```

### 5. Preparar la Aplicación

```bash
# Crear directorio
sudo mkdir -p /var/www/logoai
sudo chown -R $USER:$USER /var/www/logoai
cd /var/www/logoai

# Copiar archivos (git clone o scp)
git clone <tu-repo-url> .

# Instalar dependencias
npm run install:all

# Compilar
npm run build
```

### 6. Configurar Variables de Entorno

```bash
cat > /var/www/logoai/backend/.env << 'EOF'
NODE_ENV=production
PORT=32299
HOST=0.0.0.0
EOF
```

### 7. Configurar PM2

```bash
cat > /var/www/logoai/ecosystem.config.js << 'EOF'
module.exports = {
  apps: [{
    name: 'logoai',
    script: './backend/dist/server.js',
    cwd: '/var/www/logoai',
    instances: 1,
    exec_mode: 'fork',
    env: {
      NODE_ENV: 'production',
      PORT: 32299,
      HOST: '0.0.0.0'
    },
    log_file: '/var/log/logoai/combined.log',
    out_file: '/var/log/logoai/out.log',
    error_file: '/var/log/logoai/error.log',
    time: true
  }]
};
EOF

sudo mkdir -p /var/log/logoai
sudo chown -R $USER:$USER /var/log/logoai

# Iniciar
pm2 start ecosystem.config.js
pm2 save
pm2 startup systemd
```

### 8. Configurar Apache Virtual Host

Crear el archivo de configuración:

```bash
sudo tee /etc/apache2/sites-available/logoai.conf << 'EOF'
<VirtualHost *:32299>
    ServerName localhost
    DocumentRoot /var/www/logoai/frontend/dist
    
    # Logs
    ErrorLog ${APACHE_LOG_DIR}/logoai-error.log
    CustomLog ${APACHE_LOG_DIR}/logoai-access.log combined
    
    # Directorio raíz (frontend estático)
    <Directory /var/www/logoai/frontend/dist>
        Options -Indexes +FollowSymLinks
        AllowOverride All
        Require all granted
        
        # Cache estático
        <IfModule mod_expires.c>
            ExpiresActive On
            ExpiresDefault "access plus 1 hour"
        </IfModule>
    </Directory>
    
    # Compresión
    <IfModule mod_deflate.c>
        AddOutputFilterByType DEFLATE text/html text/plain text/xml text/css application/javascript application/json
    </IfModule>
    
    # Proxy para API
    <Location /api/>
        ProxyPass http://localhost:32299/api/
        ProxyPassReverse http://localhost:32299/api/
        ProxyPreserveHost On
        RequestHeader set X-Forwarded-Proto "http"
        RequestHeader set X-Forwarded-Port "32299"
    </Location>
    
    # Health check
    <Location /health>
        ProxyPass http://localhost:32299/health
        ProxyPassReverse http://localhost:32299/health
    </Location>
    
    # Uploads
    Alias /uploads /var/www/logoai/uploads
    <Directory /var/www/logoai/uploads>
        Options -Indexes
        Require all granted
    </Directory>
    
    # Tamaño máximo de upload
    LimitRequestBody 52428800  # 50MB
</VirtualHost>
EOF
```

Habilitar el sitio:

```bash
# Deshabilitar default
sudo a2dissite 000-default

# Habilitar logoai
sudo a2ensite logoai

# Verificar configuración
sudo apache2ctl configtest

# Recargar Apache
sudo systemctl reload apache2
```

### 9. Configurar .htaccess para SPA

```bash
sudo tee /var/www/logoai/frontend/dist/.htaccess << 'EOF'
<IfModule mod_rewrite.c>
    RewriteEngine On
    RewriteBase /
    RewriteRule ^index\.html$ - [L]
    RewriteCond %{REQUEST_FILENAME} !-f
    RewriteCond %{REQUEST_FILENAME} !-d
    RewriteRule . /index.html [L]
</IfModule>

# Compresión
<IfModule mod_deflate.c>
  AddOutputFilterByType DEFLATE text/html text/plain text/xml text/css application/javascript application/json image/svg+xml
</IfModule>

# Cache
<IfModule mod_expires.c>
  ExpiresActive On
  ExpiresByType text/css "access plus 1 week"
  ExpiresByType application/javascript "access plus 1 week"
  ExpiresByType image/svg+xml "access plus 1 month"
</IfModule>
EOF

sudo chown -R www-data:www-data /var/www/logoai/frontend/dist
sudo chmod -R 755 /var/www/logoai/frontend/dist
```

### 10. Configurar Puerto 32299

```bash
# Agregar puerto a Apache
sudo tee /etc/apache2/ports.conf << 'EOF'
# If you just change the port or add more ports here, you will likely also
# have to change the VirtualHost statement in
# /etc/apache2/sites-enabled/000-default.conf

Listen 80
Listen 32299

<IfModule ssl_module>
    Listen 443
</IfModule>

<IfModule mod_gnutls.c>
    Listen 443
</IfModule>
EOF

sudo systemctl restart apache2
```

### 11. Verificar Despliegue

```bash
# Verificar Apache
curl -I http://localhost:32299

# Verificar health check
curl http://localhost:32299/health

# Ver logs
sudo tail -f /var/log/apache2/logoai-error.log
pm2 logs logoai
```

## 🔄 Actualización

```bash
cd /var/www/logoai

# Backup
sudo cp -r uploads uploads-backup-$(date +%Y%m%d)

# Actualizar
git pull origin main
npm run install:all
npm run build

# Reiniciar
pm2 restart logoai
sudo systemctl reload apache2
```

## 🛠️ Solución de Problemas

### Error 503 Service Unavailable

```bash
# Verificar que Node.js está corriendo
pm2 status
pm2 logs logoai

# Verificar conexión directa
curl http://localhost:32299/health
```

### Apache no escucha en puerto 32299

```bash
# Verificar configuración
sudo apache2ctl configtest
sudo apache2ctl -S

# Verificar puerto
sudo netstat -tulpn | grep apache

# Firewall
sudo ufw status
sudo ufw allow 32299/tcp
```

### Permisos denegados

```bash
sudo chown -R www-data:www-data /var/www/logoai/frontend/dist
sudo chmod -R 755 /var/www/logoai/uploads
sudo chown -R $USER:$USER /var/www/logoai/uploads
```

### Error AH00072: make_sock: could not bind

```bash
# Verificar si el puerto está en uso
sudo lsof -i :32299

# Cambiar puerto o matar proceso
sudo kill -9 <PID>
```

## 🔒 Seguridad

```bash
# UFW
sudo apt install ufw
sudo ufw allow 32299/tcp comment 'LogoAI'
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
sudo ufw enable

# Fail2Ban
sudo apt install fail2ban
sudo systemctl enable fail2ban
```

## 📊 Gestión

```bash
# Apache
sudo systemctl status apache2
sudo systemctl restart apache2
sudo apache2ctl graceful

# PM2
pm2 status
pm2 logs
pm2 restart logoai
pm2 monit
```

---

✅ **¡Listo!** LogoAI debería estar funcionando en http://logoai.tymtechnology.shop
