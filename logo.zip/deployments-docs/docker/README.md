# 🐳 Despliegue con Docker Compose (Recomendado)

Esta es la forma más rápida y sencilla de desplegar LogoAI en tu servidor Debian 13.

## Requisitos

- Docker 20.10+ instalado
- Docker Compose 2.0+ instalado
- Acceso SSH al servidor (10.0.1.40)
- Nginx Proxy Manager ya configurado

## Instalación de Docker (si no está instalado)

```bash
# Actualizar sistema
sudo apt update && sudo apt upgrade -y

# Instalar dependencias
sudo apt install -y apt-transport-https ca-certificates curl gnupg lsb-release

# Agregar clave GPG de Docker
curl -fsSL https://download.docker.com/linux/debian/gpg | sudo gpg --dearmor -o /usr/share/keyrings/docker-archive-keyring.gpg

# Agregar repositorio
echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/docker-archive-keyring.gpg] https://download.docker.com/linux/debian $(lsb_release -cs) stable" | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null

# Instalar Docker
sudo apt update
sudo apt install -y docker-ce docker-ce-cli containerd.io docker-compose-plugin

# Verificar instalación
sudo docker --version
sudo docker compose version

# Agregar usuario al grupo docker (opcional, para no usar sudo)
sudo usermod -aG docker $USER
newgrp docker
```

## Pasos de Despliegue

### 1. Preparar el Servidor

```bash
# Crear directorio de la aplicación
sudo mkdir -p /opt/logoai
sudo chown $USER:$USER /opt/logoai
cd /opt/logoai

# Copiar los archivos del proyecto
# Opción A: Desde git
git clone <tu-repo> .

# Opción B: Desde local con scp (ejecutar desde tu máquina)
# scp -r logoai/* usuario@10.0.1.40:/opt/logoai/
```

### 2. Estructura del Proyecto

```
/opt/logoai/
├── docker-compose.yml
├── Dockerfile
├── package.json
├── frontend/
│   ├── package.json
│   ├── vite.config.ts
│   └── src/
└── backend/
    ├── package.json
    └── src/
```

### 3. Configurar Variables de Entorno (Opcional)

```bash
# Crear archivo .env si necesitas personalizar
cat > .env << 'EOF'
NODE_ENV=production
PORT=32299
HOST=0.0.0.0
EOF
```

### 4. Desplegar la Aplicación

```bash
# Construir y levantar
docker compose up -d --build

# Ver logs en tiempo real
docker compose logs -f

# Verificar estado
docker compose ps
```

### 5. Verificar el Despliegue

```bash
# Health check
curl http://localhost:32299/health

# Debería retornar:
# {"status":"ok","timestamp":"2024-...","uptime":...}
```

### 6. Configurar Nginx Proxy Manager (si no está listo)

Tu dominio ya está configurado con Nginx Proxy Manager, pero verifica:

1. Accede a Nginx Proxy Manager (normalmente en puerto 81 o 82)
2. Verifica que el proxy host `logoai.tymtechnology.shop` apunte a:
   - **Forward Hostname/IP**: `10.0.1.40`
   - **Forward Port**: `32299`
3. El certificado Let's Encrypt ya debería estar activo

### 7. Probar desde el Dominio

```bash
# Desde tu máquina local
curl http://logoai.tymtechnology.shop/health
```

## Comandos Útiles

```bash
# Ver logs
docker compose logs -f app

# Reiniciar
docker compose restart

# Detener
docker compose down

# Actualizar (después de cambios en código)
docker compose down
docker compose up -d --build

# Shell dentro del contenedor
docker compose exec app sh

# Limpiar imágenes viejas
docker system prune -a
```

## Solución de Problemas

### El contenedor no inicia
```bash
# Ver logs de error
docker compose logs app

# Verificar puerto no está ocupado
sudo netstat -tulpn | grep 32299
sudo lsof -i :32299

# Si está ocupado, cambia en docker-compose.yml o mata el proceso
sudo kill -9 <PID>
```

### Permisos de archivos
```bash
# Fix permisos de uploads
sudo chown -R 1001:1001 /opt/logoai/uploads
```

### Problemas de build nativo (Sharp)
Si ves errores de compilación nativa:
```bash
# Rebuild sin cache
docker compose build --no-cache
docker compose up -d
```

### Memoria insuficiente
```bash
# Ver uso de recursos
docker stats

# Aumentar swap si es necesario
sudo fallocate -l 2G /swapfile
sudo chmod 600 /swapfile
sudo mkswap /swapfile
sudo swapon /swapfile
```

## Actualización de la Aplicación

```bash
cd /opt/logoai

# 1. Backup (opcional)
cp -r uploads uploads-backup-$(date +%Y%m%d)

# 2. Obtener cambios
git pull origin main

# 3. Rebuild y restart
docker compose down
docker compose up -d --build

# 4. Verificar
docker compose ps
curl http://localhost:32299/health
```

## Seguridad Adicional (Opcional)

### Firewall UFW
```bash
sudo ufw allow 32299/tcp comment 'LogoAI App'
sudo ufw allow 80/tcp comment 'HTTP'
sudo ufw allow 443/tcp comment 'HTTPS'
sudo ufw enable
```

### Fail2Ban
```bash
sudo apt install fail2ban -y
sudo systemctl enable fail2ban
```

## Monitoreo Básico

```bash
# Crear script de monitoreo
cat > /opt/logoai/monitor.sh << 'EOF'
#!/bin/bash
if ! curl -f http://localhost:32299/health > /dev/null 2>&1; then
    echo "$(date): LogoAI is down, restarting..." >> /var/log/logoai-monitor.log
    cd /opt/logoai && docker compose restart
fi
EOF
chmod +x /opt/logoai/monitor.sh

# Agregar a crontab cada 5 minutos
echo "*/5 * * * * /opt/logoai/monitor.sh" | sudo crontab -
```

---

✅ **¡Listo!** Tu aplicación debería estar funcionando en http://logoai.tymtechnology.shop
