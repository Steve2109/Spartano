# 🌐 Despliegue con Nginx Nativo

Guía para desplegar LogoAI usando Nginx directamente en Debian 13 sin Docker.

## 📋 Requisitos

- Debian 13 (Bookworm)
- Node.js 20 LTS
- Nginx
- PM2 (para gestión de procesos)
- Git

## 🔧 Instalación Paso a Paso

### 1. Actualizar Sistema

```bash
sudo apt update && sudo apt upgrade -y
```

### 2. Instalar Node.js 20 LTS

```bash
# Usar NodeSource
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo bash -
sudo apt install -y nodejs

# Verificar
node --version  # v20.x.x
npm --version   # 10.x.x
```

### 3. Instalar Nginx

```bash
sudo apt install -y nginx
sudo systemctl enable nginx
sudo systemctl start nginx
```

### 4. Instalar PM2 Globalmente

```bash
sudo npm install -g pm2
```

### 5. Configurar la Aplicación

```bash
# Crear directorio
sudo mkdir -p /var/www/logoai
sudo chown -R $USER:$USER /var/www/logoai

# Clonar o copiar el proyecto
cd /var/www/logoai
git clone <tu-repo-url> .

# O copiar desde local con scp:
# scp -r logoai/* usuario@10.0.1.40:/var/www/logoai/
```

### 6. Instalar Dependencias y Compilar

```bash
cd /var/www/logoai

# Instalar todas las dependencias
npm run install:all

# Compilar frontend y backend
npm run build
```

### 7. Configurar Variables de Entorno

```bash
cat > /var/www/logoai/backend/.env << 'EOF'
NODE_ENV=production
PORT=32299
HOST=0.0.0.0
EOF
```

### 8. Crear Script de Inicio con PM2

```bash
cat > /var/www/logoai/ecosystem.config.js << 'EOF'
module.exports = {
  apps: [{
    name: 'logoai',
    script: './backend/dist/server.js',
    cwd: '/var/www/logoai',
    instances: 1,
    exec_mode: 'fork',
    env: {
      NODE_ENV: 'production',
      PORT: 32299,
      HOST: '0.0.0.0'
    },
    log_file: '/var/log/logoai/combined.log',
    out_file: '/var/log/logoai/out.log',
    error_file: '/var/log/logoai/error.log',
    time: true,
    watch: false,
    max_memory_restart: '500M',
    restart_delay: 3000,
    max_restarts: 5,
    min_uptime: '10s'
  }]
};
EOF

# Crear directorio de logs
sudo mkdir -p /var/log/logoai
sudo chown -R $USER:$USER /var/log/logoai
```

### 9. Iniciar la Aplicación con PM2

```bash
cd /var/www/logoai

# Iniciar
pm2 start ecosystem.config.js

# Guardar configuración
pm2 save

# Configurar inicio automático
pm2 startup systemd
sudo env PATH=$PATH:/usr/bin pm2 startup systemd -u $USER --hp $HOME
```

### 10. Configurar Nginx como Reverse Proxy

Crea el archivo de configuración:

```bash
sudo tee /etc/nginx/sites-available/logoai << 'EOF'
server {
    listen 32299;
    server_name localhost;
    
    # Logs
    access_log /var/log/nginx/logoai-access.log;
    error_log /var/log/nginx/logoai-error.log;

    # Gzip
    gzip on;
    gzip_vary on;
    gzip_min_length 1024;
    gzip_types text/plain text/css application/json application/javascript text/xml application/xml application/xml+rss text/javascript;

    # Client body size (for image uploads)
    client_max_body_size 50M;

    # Static files (frontend)
    location / {
        root /var/www/logoai/frontend/dist;
        try_files $uri $uri/ /index.html;
        expires 1h;
        add_header Cache-Control "public, immutable";
    }

    # API routes
    location /api/ {
        proxy_pass http://localhost:32299/api/;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
        proxy_read_timeout 86400;
    }

    # Health check
    location /health {
        proxy_pass http://localhost:32299/health;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        access_log off;
    }

    # Uploads
    location /uploads/ {
        alias /var/www/logoai/uploads/;
        expires 1d;
        add_header Cache-Control "public";
    }
}
EOF
```

Habilitar el sitio:

```bash
# Deshabilitar default si existe
sudo rm -f /etc/nginx/sites-enabled/default

# Habilitar logoai
sudo ln -sf /etc/nginx/sites-available/logoai /etc/nginx/sites-enabled/logoai

# Testear configuración
sudo nginx -t

# Recargar Nginx
sudo systemctl reload nginx
```

### 11. Verificar Despliegue

```bash
# Verificar que la app está corriendo
curl http://localhost:32299/health

# Verificar Nginx
curl -I http://localhost:32299

# Ver logs
pm2 logs logoai
sudo tail -f /var/log/nginx/logoai-error.log
```

## 🔄 Actualización de la Aplicación

```bash
cd /var/www/logoai

# 1. Backup
sudo cp -r uploads uploads-backup-$(date +%Y%m%d)

# 2. Obtener cambios
git pull origin main

# 3. Reinstalar dependencias (si cambió package.json)
npm run install:all

# 4. Recompilar
npm run build

# 5. Reiniciar
pm2 restart logoai

# 6. Verificar
pm2 status
curl http://localhost:32299/health
```

## 📊 Gestión con PM2

```bash
# Ver estado
pm2 status
pm2 monit

# Logs
pm2 logs logoai
pm2 logs logoai --lines 100

# Reiniciar
pm2 restart logoai

# Detener
pm2 stop logoai

# Eliminar
pm2 delete logoai
```

## 🔒 Seguridad

### Firewall (UFW)

```bash
sudo apt install ufw -y
sudo ufw default deny incoming
sudo ufw default allow outgoing
sudo ufw allow 32299/tcp comment 'LogoAI App'
sudo ufw allow 80/tcp comment 'HTTP'
sudo ufw allow 443/tcp comment 'HTTPS'
sudo ufw allow 22/tcp comment 'SSH'
sudo ufw enable
```

### Fail2Ban

```bash
sudo apt install fail2ban -y
sudo systemctl enable fail2ban
sudo systemctl start fail2ban
```

### Certbot (Let's Encrypt) - Opcional si no usas Nginx Proxy Manager

```bash
sudo apt install certbot python3-certbot-nginx -y

# Obtener certificado
sudo certbot --nginx -d logoai.tymtechnology.shop

# Auto-renewal test
sudo certbot renew --dry-run
```

## 🛠️ Solución de Problemas

### Puerto 32299 ocupado

```bash
# Encontrar proceso
sudo lsof -i :32299
sudo netstat -tulpn | grep 32299

# Matar proceso
sudo kill -9 <PID>

# O cambiar puerto en ecosystem.config.js y Nginx config
```

### Permisos denegados

```bash
# Fix permisos
sudo chown -R $USER:$USER /var/www/logoai
sudo chmod -R 755 /var/www/logoai/frontend/dist
sudo chmod -R 755 /var/www/logoai/uploads
```

### Error 502 Bad Gateway

```bash
# Verificar que Node.js app está corriendo
pm2 status
pm2 logs logoai

# Verificar Nginx puede conectar
curl http://localhost:32299/health

# Verificar SELinux (si está habilitado)
sudo getenforce
sudo setenforce 0  # Temporal para probar
```

### Dependencias nativas fallan

```bash
# Instalar build-essential
sudo apt install -y build-essential python3 make g++

# Reinstalar módulos nativos
cd /var/www/logoai/backend
rm -rf node_modules
npm install

# Verificar sharp
npm rebuild sharp
```

### Nginx no inicia

```bash
# Verificar sintaxis
sudo nginx -t

# Ver logs
sudo tail -f /var/log/nginx/error.log

# Verificar puertos en uso
sudo netstat -tulpn | grep :80
sudo netstat -tulpn | grep :443
```

## 📝 Configuración de Nginx Proxy Manager

Tu Nginx Proxy Manager ya debería estar configurado, pero verifica:

1. **Proxy Hosts** → Add Proxy Host:
   - **Domain Names**: `logoai.tymtechnology.shop`
   - **Scheme**: `http`
   - **Forward Hostname/IP**: `10.0.1.40`
   - **Forward Port**: `32299`

2. **SSL** → SSL Certificate:
   - **SSL Certificate**: `logoai.tymtechnology.shop`
   - **Force SSL**: ✅
   - **HTTP/2 Support**: ✅
   - **HSTS Enabled**: ✅

3. **Advanced**:
   ```nginx
   # Añadir headers adicionales si es necesario
   proxy_set_header X-Forwarded-Host $host;
   proxy_set_header X-Forwarded-Port $server_port;
   ```

## 🎯 Optimización de Rendimiento

### Nginx Tuning

```bash
sudo tee /etc/nginx/conf.d/optimization.conf << 'EOF'
# Worker processes
worker_processes auto;
worker_rlimit_nofile 65535;

# Events
events {
    worker_connections 4096;
    use epoll;
    multi_accept on;
}

# HTTP
gzip on;
gzip_vary on;
gzip_proxied any;
gzip_comp_level 6;
gzip_types text/plain text/css text/xml application/json application/javascript application/rss+xml application/atom+xml image/svg+xml;
EOF

sudo nginx -t && sudo systemctl reload nginx
```

### Node.js Optimización

```bash
# Editar ecosystem.config.js para más instancias (si tienes múltiples CPUs)
cat > /var/www/logoai/ecosystem.config.js << 'EOF'
module.exports = {
  apps: [{
    name: 'logoai',
    script: './backend/dist/server.js',
    cwd: '/var/www/logoai',
    instances: 'max',  # Usar todos los CPUs
    exec_mode: 'cluster',
    env: {
      NODE_ENV: 'production',
      PORT: 32299,
      HOST: '0.0.0.0',
      NODE_OPTIONS: '--max-old-space-size=1024'
    },
    # ... resto de config
  }]
};
EOF
```

---

✅ **¡Listo!** LogoAI debería estar funcionando en http://logoai.tymtechnology.shop
