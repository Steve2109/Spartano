# 🚀 Guías de Despliegue - LogoAI Generator

Esta carpeta contiene las guías de despliegue para diferentes configuraciones en Debian 13.

## Opciones Disponibles

| Método | Dificultad | Recomendado Para | Archivo |
|--------|-----------|------------------|---------|
| **Docker Compose** | ⭐ Fácil | Producción rápida | [docker/README.md](./docker/README.md) |
| **Nginx Nativo** | ⭐⭐ Medio | Control total del servidor | [nginx/README.md](./nginx/README.md) |
| **Apache Nativo** | ⭐⭐ Medio | Si ya usas Apache | [apache/README.md](./apache/README.md) |

## Tu Configuración

- **Dominio**: `http://logoai.tymtechnology.shop/`
- **Puerto**: `32299`
- **IP Interna**: `http://10.0.1.40:32299`
- **Proxy**: Nginx Proxy Manager (ya configurado)
- **Certificado**: Let's Encrypt (ya configurado)

## Recomendación

Usa **Docker Compose** - Es la opción más rápida y mantenible para tu setup actual con Nginx Proxy Manager.

## Pasos Rápidos (Docker Compose)

```bash
# 1. Conectar al servidor Debian 13
ssh tu-usuario@10.0.1.40

# 2. Clonar o copiar el proyecto
cd /opt
sudo git clone <repo-url> logoai
sudo chown -R $USER:$USER logoai
cd logoai

# 3. Desplegar
docker-compose up -d --build

# 4. Verificar
docker-compose ps
curl http://localhost:32299/health
```

El dominio `logoai.tymtechnology.shop` ya está propagado y Nginx Proxy Manager ya redirige al puerto 32299.

## Solución de Problemas

Si encuentras problemas, revisa:
1. Logs: `docker-compose logs -f`
2. Permisos: `sudo chown -R 1001:1001 uploads/`
3. Puerto ocupado: `sudo netstat -tulpn | grep 32299`
