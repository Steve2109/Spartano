import { useState } from 'react'
import Header from './components/Header'
import Sidebar from './components/Sidebar'
import CanvasEditor from './components/CanvasEditor'
import PropertiesPanel from './components/PropertiesPanel'
import ExportModal from './components/ExportModal'
import TemplatesModal from './components/TemplatesModal'

function App() {
  const [showExportModal, setShowExportModal] = useState(false)
  const [showTemplatesModal, setShowTemplatesModal] = useState(false)

  return (
    <div className="flex flex-col h-screen bg-slate-900">
      <Header 
        onExport={() => setShowExportModal(true)}
        onTemplates={() => setShowTemplatesModal(true)}
      />
      
      <div className="flex flex-1 overflow-hidden">
        <Sidebar />
        
        <main className="flex-1 flex items-center justify-center bg-slate-950 relative overflow-auto p-8">
          <CanvasEditor />
        </main>
        
        <PropertiesPanel />
      </div>

      {showExportModal && (
        <ExportModal onClose={() => setShowExportModal(false)} />
      )}
      
      {showTemplatesModal && (
        <TemplatesModal onClose={() => setShowTemplatesModal(false)} />
      )}
    </div>
  )
}

export default App
