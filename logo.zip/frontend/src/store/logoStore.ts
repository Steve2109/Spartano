import { create } from 'zustand'
import { persist } from 'zustand/middleware'

export interface LogoElement {
  id: string
  type: 'text' | 'shape' | 'image'
  x: number
  y: number
  width: number
  height: number
  rotation: number
  scaleX: number
  scaleY: number
  draggable: boolean
}

export interface TextElement extends LogoElement {
  type: 'text'
  text: string
  fontFamily: string
  fontSize: number
  fill: string
  fontStyle: string
  textDecoration: string
  align: 'left' | 'center' | 'right'
}

export interface ShapeElement extends LogoElement {
  type: 'shape'
  shapeType: 'rect' | 'circle' | 'triangle' | 'star' | 'polygon'
  fill: string
  stroke: string
  strokeWidth: number
  cornerRadius?: number
  sides?: number
}

export interface ImageElement extends LogoElement {
  type: 'image'
  src: string
  opacity: number
}

export type Element = TextElement | ShapeElement | ImageElement

export interface CanvasState {
  width: number
  height: number
  backgroundColor: string
  showGrid: boolean
  snapToGrid: boolean
}

interface LogoState {
  elements: Element[]
  selectedId: string | null
  canvas: CanvasState
  history: Element[][]
  historyIndex: number
  
  // Actions
  addElement: (element: Element) => void
  updateElement: (id: string, updates: Partial<Element>) => void
  removeElement: (id: string) => void
  setSelectedId: (id: string | null) => void
  updateCanvas: (updates: Partial<CanvasState>) => void
  moveElement: (id: string, x: number, y: number) => void
  bringToFront: (id: string) => void
  sendToBack: (id: string) => void
  undo: () => void
  redo: () => void
  saveToHistory: () => void
  clearCanvas: () => void
  loadFromData: (data: { elements: Element[]; canvas: CanvasState }) => void
}

const defaultCanvas: CanvasState = {
  width: 800,
  height: 600,
  backgroundColor: '#ffffff',
  showGrid: true,
  snapToGrid: false,
}

export const useLogoStore = create<LogoState>()(
  persist(
    (set, get) => ({
      elements: [],
      selectedId: null,
      canvas: defaultCanvas,
      history: [[]],
      historyIndex: 0,

      addElement: (element) => {
        get().saveToHistory()
        set((state) => ({
          elements: [...state.elements, element],
          selectedId: element.id,
        }))
      },

      updateElement: (id, updates) => {
        set((state) => ({
          elements: state.elements.map((el) =>
            el.id === id ? { ...el, ...updates } : el
          ),
        }))
      },

      removeElement: (id) => {
        get().saveToHistory()
        set((state) => ({
          elements: state.elements.filter((el) => el.id !== id),
          selectedId: state.selectedId === id ? null : state.selectedId,
        }))
      },

      setSelectedId: (id) => set({ selectedId: id }),

      updateCanvas: (updates) => {
        set((state) => ({
          canvas: { ...state.canvas, ...updates },
        }))
      },

      moveElement: (id, x, y) => {
        set((state) => ({
          elements: state.elements.map((el) =>
            el.id === id ? { ...el, x, y } : el
          ),
        }))
      },

      bringToFront: (id) => {
        get().saveToHistory()
        set((state) => {
          const element = state.elements.find((el) => el.id === id)
          if (!element) return state
          return {
            elements: [
              ...state.elements.filter((el) => el.id !== id),
              element,
            ],
          }
        })
      },

      sendToBack: (id) => {
        get().saveToHistory()
        set((state) => {
          const element = state.elements.find((el) => el.id === id)
          if (!element) return state
          return {
            elements: [
              element,
              ...state.elements.filter((el) => el.id !== id),
            ],
          }
        })
      },

      saveToHistory: () => {
        const { elements, history, historyIndex } = get()
        const newHistory = history.slice(0, historyIndex + 1)
        newHistory.push(JSON.parse(JSON.stringify(elements)))
        set({
          history: newHistory,
          historyIndex: newHistory.length - 1,
        })
      },

      undo: () => {
        const { historyIndex } = get()
        if (historyIndex > 0) {
          set({
            historyIndex: historyIndex - 1,
            elements: JSON.parse(JSON.stringify(get().history[historyIndex - 1])),
          })
        }
      },

      redo: () => {
        const { history, historyIndex } = get()
        if (historyIndex < history.length - 1) {
          set({
            historyIndex: historyIndex + 1,
            elements: JSON.parse(JSON.stringify(history[historyIndex + 1])),
          })
        }
      },

      clearCanvas: () => {
        get().saveToHistory()
        set({ elements: [], selectedId: null })
      },

      loadFromData: (data) => {
        get().saveToHistory()
        set({
          elements: data.elements,
          canvas: { ...defaultCanvas, ...data.canvas },
        })
      },
    }),
    {
      name: 'logoai-storage',
      partialize: (state) => ({
        elements: state.elements,
        canvas: state.canvas,
      }),
    }
  )
)
