import { Download, Layout, Undo, Redo, Trash2, FolderOpen, Save } from 'lucide-react'
import { useLogoStore } from '../store/logoStore'

interface HeaderProps {
  onExport: () => void
  onTemplates: () => void
}

export default function Header({ onExport, onTemplates }: HeaderProps) {
  const { undo, redo, clearCanvas } = useLogoStore()

  return (
    <header className="h-16 bg-slate-800 border-b border-slate-700 flex items-center justify-between px-4">
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-primary-600 rounded-lg flex items-center justify-center">
            <span className="text-white font-bold text-lg">L</span>
          </div>
          <h1 className="text-xl font-bold text-white">LogoAI</h1>
        </div>
        
        <div className="h-8 w-px bg-slate-600 mx-2" />
        
        <div className="flex items-center gap-2">
          <button
            onClick={undo}
            className="p-2 hover:bg-slate-700 rounded-lg transition-colors"
            title="Deshacer (Ctrl+Z)"
          >
            <Undo className="w-5 h-5 text-slate-300" />
          </button>
          <button
            onClick={redo}
            className="p-2 hover:bg-slate-700 rounded-lg transition-colors"
            title="Rehacer (Ctrl+Y)"
          >
            <Redo className="w-5 h-5 text-slate-300" />
          </button>
          <button
            onClick={clearCanvas}
            className="p-2 hover:bg-slate-700 rounded-lg transition-colors"
            title="Limpiar canvas"
          >
            <Trash2 className="w-5 h-5 text-red-400" />
          </button>
        </div>
      </div>

      <div className="flex items-center gap-2">
        <button
          onClick={onTemplates}
          className="btn-secondary flex items-center gap-2"
        >
          <Layout className="w-4 h-4" />
          <span>Plantillas</span>
        </button>
        
        <button
          onClick={onExport}
          className="btn-primary flex items-center gap-2"
        >
          <Download className="w-4 h-4" />
          <span>Exportar</span>
        </button>
      </div>
    </header>
  )
}
