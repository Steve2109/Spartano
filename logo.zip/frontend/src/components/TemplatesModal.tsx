import { X, Sparkles } from 'lucide-react'
import { useLogoStore, TextElement, ShapeElement } from '../store/logoStore'

interface TemplatesModalProps {
  onClose: () => void
}

interface Template {
  id: string
  name: string
  description: string
  elements: (TextElement | ShapeElement)[]
  canvas: { backgroundColor: string; width: number; height: number }
}

const templates: Template[] = [
  {
    id: 'tech-startup',
    name: 'Tech Startup',
    description: 'Moderno y minimalista para startups tecnológicas',
    canvas: { backgroundColor: '#ffffff', width: 800, height: 600 },
    elements: [
      {
        id: 'shape-1',
        type: 'shape',
        shapeType: 'circle',
        x: 300,
        y: 200,
        width: 200,
        height: 200,
        rotation: 0,
        scaleX: 1,
        scaleY: 1,
        draggable: true,
        fill: '#3b82f6',
        stroke: '#1e40af',
        strokeWidth: 0,
      },
      {
        id: 'text-1',
        type: 'text',
        text: 'TECH',
        x: 300,
        y: 420,
        width: 200,
        height: 60,
        rotation: 0,
        scaleX: 1,
        scaleY: 1,
        draggable: true,
        fontFamily: 'Inter',
        fontSize: 48,
        fill: '#1f2937',
        fontStyle: 'bold',
        textDecoration: '',
        align: 'center',
      },
    ],
  },
  {
    id: 'elegant-luxe',
    name: 'Elegant Luxe',
    description: 'Sofisticado y elegante para marcas de lujo',
    canvas: { backgroundColor: '#0f172a', width: 800, height: 600 },
    elements: [
      {
        id: 'shape-1',
        type: 'shape',
        shapeType: 'rect',
        x: 350,
        y: 150,
        width: 100,
        height: 100,
        rotation: 45,
        scaleX: 1,
        scaleY: 1,
        draggable: true,
        fill: '#fbbf24',
        stroke: '#f59e0b',
        strokeWidth: 2,
      },
      {
        id: 'text-1',
        type: 'text',
        text: 'LUXE',
        x: 300,
        y: 300,
        width: 200,
        height: 60,
        rotation: 0,
        scaleX: 1,
        scaleY: 1,
        draggable: true,
        fontFamily: 'Georgia',
        fontSize: 52,
        fill: '#fbbf24',
        fontStyle: 'normal',
        textDecoration: '',
        align: 'center',
      },
    ],
  },
  {
    id: 'creative-agency',
    name: 'Creative Agency',
    description: 'Colorido y dinámico para agencias creativas',
    canvas: { backgroundColor: '#fef3c7', width: 800, height: 600 },
    elements: [
      {
        id: 'shape-1',
        type: 'shape',
        shapeType: 'star',
        x: 350,
        y: 150,
        width: 100,
        height: 100,
        rotation: 0,
        scaleX: 1,
        scaleY: 1,
        draggable: true,
        fill: '#ec4899',
        stroke: '#db2777',
        strokeWidth: 0,
      },
      {
        id: 'shape-2',
        type: 'shape',
        shapeType: 'circle',
        x: 320,
        y: 180,
        width: 40,
        height: 40,
        rotation: 0,
        scaleX: 1,
        scaleY: 1,
        draggable: true,
        fill: '#fbbf24',
        stroke: '#f59e0b',
        strokeWidth: 0,
      },
      {
        id: 'text-1',
        type: 'text',
        text: 'CREATE',
        x: 250,
        y: 300,
        width: 300,
        height: 70,
        rotation: 0,
        scaleX: 1,
        scaleY: 1,
        draggable: true,
        fontFamily: 'Impact',
        fontSize: 56,
        fill: '#1f2937',
        fontStyle: 'normal',
        textDecoration: '',
        align: 'center',
      },
    ],
  },
  {
    id: 'simple-clean',
    name: 'Simple Clean',
    description: 'Minimalista y profesional para cualquier marca',
    canvas: { backgroundColor: '#ffffff', width: 800, height: 600 },
    elements: [
      {
        id: 'shape-1',
        type: 'shape',
        shapeType: 'rect',
        x: 375,
        y: 200,
        width: 50,
        height: 50,
        rotation: 0,
        scaleX: 1,
        scaleY: 1,
        draggable: true,
        fill: '#10b981',
        stroke: '#059669',
        strokeWidth: 0,
        cornerRadius: 8,
      },
      {
        id: 'text-1',
        type: 'text',
        text: 'PURE',
        x: 325,
        y: 280,
        width: 150,
        height: 50,
        rotation: 0,
        scaleX: 1,
        scaleY: 1,
        draggable: true,
        fontFamily: 'Inter',
        fontSize: 42,
        fill: '#374151',
        fontStyle: 'normal',
        textDecoration: '',
        align: 'center',
      },
    ],
  },
  {
    id: 'geometric-art',
    name: 'Geometric Art',
    description: 'Formas geométricas abstractas modernas',
    canvas: { backgroundColor: '#1e293b', width: 800, height: 600 },
    elements: [
      {
        id: 'shape-1',
        type: 'shape',
        shapeType: 'triangle',
        x: 400,
        y: 150,
        width: 120,
        height: 120,
        rotation: 0,
        scaleX: 1,
        scaleY: 1,
        draggable: true,
        fill: '#8b5cf6',
        stroke: '#7c3aed',
        strokeWidth: 0,
      },
      {
        id: 'shape-2',
        type: 'shape',
        shapeType: 'polygon',
        x: 360,
        y: 130,
        width: 80,
        height: 80,
        rotation: 0,
        scaleX: 1,
        scaleY: 1,
        draggable: true,
        fill: '#06b6d4',
        stroke: '#0891b2',
        strokeWidth: 0,
      },
      {
        id: 'text-1',
        type: 'text',
        text: 'GEO',
        x: 340,
        y: 300,
        width: 120,
        height: 60,
        rotation: 0,
        scaleX: 1,
        scaleY: 1,
        draggable: true,
        fontFamily: 'Verdana',
        fontSize: 40,
        fill: '#e2e8f0',
        fontStyle: 'bold',
        textDecoration: '',
        align: 'center',
      },
    ],
  },
  {
    id: 'bold-impact',
    name: 'Bold Impact',
    description: 'Tipografía audaz para marcas impactantes',
    canvas: { backgroundColor: '#000000', width: 800, height: 600 },
    elements: [
      {
        id: 'text-1',
        type: 'text',
        text: 'BOLD',
        x: 250,
        y: 220,
        width: 300,
        height: 100,
        rotation: 0,
        scaleX: 1,
        scaleY: 1,
        draggable: true,
        fontFamily: 'Impact',
        fontSize: 80,
        fill: '#ef4444',
        fontStyle: 'normal',
        textDecoration: '',
        align: 'center',
      },
      {
        id: 'shape-1',
        type: 'shape',
        shapeType: 'rect',
        x: 280,
        y: 350,
        width: 240,
        height: 8,
        rotation: 0,
        scaleX: 1,
        scaleY: 1,
        draggable: true,
        fill: '#ef4444',
        stroke: '#dc2626',
        strokeWidth: 0,
      },
    ],
  },
]

export default function TemplatesModal({ onClose }: TemplatesModalProps) {
  const { loadFromData, updateCanvas } = useLogoStore()

  const applyTemplate = (template: Template) => {
    // Update canvas settings
    updateCanvas({
      backgroundColor: template.canvas.backgroundColor,
      width: template.canvas.width,
      height: template.canvas.height,
    })
    
    // Load template elements
    loadFromData({
      elements: template.elements,
      canvas: { backgroundColor: template.canvas.backgroundColor },
    })
    
    onClose()
  }

  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50">
      <div className="bg-slate-800 rounded-2xl shadow-2xl w-full max-w-4xl max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-slate-700">
          <div className="flex items-center gap-3">
            <Sparkles className="w-6 h-6 text-primary-400" />
            <h2 className="text-xl font-bold text-white">Plantillas de Logos</h2>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-slate-700 rounded-lg transition-colors"
          >
            <X className="w-5 h-5 text-slate-400" />
          </button>
        </div>

        {/* Templates Grid */}
        <div className="p-6 overflow-y-auto max-h-[60vh]">
          <p className="text-slate-400 mb-6">
            Selecciona una plantilla para comenzar. Puedes personalizarla completamente después.
          </p>
          
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            {templates.map((template) => (
              <button
                key={template.id}
                onClick={() => applyTemplate(template)}
                className="group relative bg-slate-700 rounded-xl p-4 border-2 border-transparent hover:border-primary-500 transition-all text-left"
              >
                {/* Preview */}
                <div 
                  className="w-full aspect-video rounded-lg mb-3 overflow-hidden"
                  style={{ backgroundColor: template.canvas.backgroundColor }}
                >
                  <svg 
                    viewBox={`0 0 ${template.canvas.width} ${template.canvas.height}`}
                    className="w-full h-full"
                    preserveAspectRatio="xMidYMid meet"
                  >
                    {template.elements.map((el) => {
                      if (el.type === 'shape') {
                        const shapeEl = el as ShapeElement
                        if (shapeEl.shapeType === 'rect') {
                          return (
                            <rect
                              key={el.id}
                              x={el.x}
                              y={el.y}
                              width={el.width}
                              height={el.height}
                              rx={(el as ShapeElement).cornerRadius || 0}
                              fill={shapeEl.fill}
                              transform={`rotate(${el.rotation}, ${el.x + el.width/2}, ${el.y + el.height/2})`}
                            />
                          )
                        } else if (shapeEl.shapeType === 'circle') {
                          return (
                            <circle
                              key={el.id}
                              cx={el.x + el.width/2}
                              cy={el.y + el.height/2}
                              r={el.width/2}
                              fill={shapeEl.fill}
                            />
                          )
                        } else if (shapeEl.shapeType === 'triangle') {
                          return (
                            <polygon
                              key={el.id}
                              points={`${el.x + el.width/2},${el.y} ${el.x + el.width},${el.y + el.height} ${el.x},${el.y + el.height}`}
                              fill={shapeEl.fill}
                            />
                          )
                        } else if (shapeEl.shapeType === 'star') {
                          return (
                            <polygon
                              key={el.id}
                              points={`${el.x + el.width/2},${el.y} ${el.x + el.width*0.8},${el.y + el.height*0.4} ${el.x + el.width},${el.y + el.height*0.4} ${el.x + el.width*0.85},${el.y + el.height*0.65} ${el.x + el.width*0.95},${el.y + el.height} ${el.x + el.width/2},${el.y + el.height*0.8} ${el.x + el.width*0.05},${el.y + el.height} ${el.x + el.width*0.15},${el.y + el.height*0.65} ${el.x},${el.y + el.height*0.4} ${el.x + el.width*0.2},${el.y + el.height*0.4}`}
                              fill={shapeEl.fill}
                            />
                          )
                        }
                      } else if (el.type === 'text') {
                        const textEl = el as TextElement
                        return (
                          <text
                            key={el.id}
                            x={el.x + el.width/2}
                            y={el.y + el.height/2}
                            textAnchor="middle"
                            dominantBaseline="middle"
                            fontSize={textEl.fontSize * 0.5}
                            fill={textEl.fill}
                            fontFamily={textEl.fontFamily}
                            fontWeight={textEl.fontStyle === 'bold' ? 'bold' : 'normal'}
                            fontStyle={textEl.fontStyle === 'italic' ? 'italic' : 'normal'}
                          >
                            {textEl.text}
                          </text>
                        )
                      }
                      return null
                    })}
                  </svg>
                </div>
                
                {/* Info */}
                <h3 className="font-semibold text-white mb-1 group-hover:text-primary-400 transition-colors">
                  {template.name}
                </h3>
                <p className="text-sm text-slate-400">
                  {template.description}
                </p>
                
                {/* Hover overlay */}
                <div className="absolute inset-0 bg-primary-500/10 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none" />
              </button>
            ))}
          </div>
        </div>

        {/* Footer */}
        <div className="flex justify-end gap-3 p-6 border-t border-slate-700">
          <button
            onClick={onClose}
            className="btn-secondary"
          >
            Cancelar
          </button>
        </div>
      </div>
    </div>
  )
}
