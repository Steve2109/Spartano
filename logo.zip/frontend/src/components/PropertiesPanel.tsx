import { Trash2, ArrowUp, ArrowDown, Type, Palette, Settings } from 'lucide-react'
import { useLogoStore, TextElement, ShapeElement } from '../store/logoStore'

const fontFamilies = [
  'Inter', 'Arial', 'Helvetica', 'Times New Roman', 'Georgia',
  'Verdana', 'Impact', 'Comic Sans MS', 'Courier New', 'Trebuchet MS'
]

export default function PropertiesPanel() {
  const { 
    elements, 
    selectedId, 
    updateElement, 
    removeElement, 
    bringToFront, 
    sendToBack 
  } = useLogoStore()

  const selectedElement = elements.find(el => el.id === selectedId)

  if (!selectedElement) {
    return (
      <aside className="w-72 bg-slate-800 border-l border-slate-700 flex flex-col">
        <div className="p-4 flex-1 flex items-center justify-center">
          <div className="text-center">
            <Settings className="w-12 h-12 text-slate-600 mx-auto mb-3" />
            <p className="text-slate-400 text-sm">
              Selecciona un elemento para editar sus propiedades
            </p>
          </div>
        </div>
      </aside>
    )
  }

  const updateText = (updates: Partial<TextElement>) => {
    if (selectedElement.type === 'text') {
      updateElement(selectedElement.id, updates)
    }
  }

  const updateShape = (updates: Partial<ShapeElement>) => {
    if (selectedElement.type === 'shape') {
      updateElement(selectedElement.id, updates)
    }
  }

  return (
    <aside className="w-72 bg-slate-800 border-l border-slate-700 flex flex-col overflow-y-auto">
      {/* Element Actions */}
      <div className="p-4 border-b border-slate-700">
        <div className="flex items-center justify-between">
          <span className="text-sm font-medium text-slate-300 capitalize">
            {selectedElement.type === 'text' ? 'Texto' : 'Forma'}
          </span>
          <div className="flex gap-1">
            <button
              onClick={() => sendToBack(selectedElement.id)}
              className="p-2 hover:bg-slate-700 rounded-lg transition-colors"
              title="Enviar al fondo"
            >
              <ArrowDown className="w-4 h-4 text-slate-400" />
            </button>
            <button
              onClick={() => bringToFront(selectedElement.id)}
              className="p-2 hover:bg-slate-700 rounded-lg transition-colors"
              title="Traer al frente"
            >
              <ArrowUp className="w-4 h-4 text-slate-400" />
            </button>
            <button
              onClick={() => removeElement(selectedElement.id)}
              className="p-2 hover:bg-red-900/50 rounded-lg transition-colors"
              title="Eliminar"
            >
              <Trash2 className="w-4 h-4 text-red-400" />
            </button>
          </div>
        </div>
      </div>

      {/* Text Properties */}
      {selectedElement.type === 'text' && (
        <div className="p-4 border-b border-slate-700">
          <h3 className="text-sm font-semibold text-slate-300 uppercase tracking-wider mb-3 flex items-center gap-2">
            <Type className="w-4 h-4" />
            Propiedades de Texto
          </h3>
          
          <div className="space-y-4">
            <div>
              <label className="text-xs text-slate-400 block mb-1">Contenido</label>
              <input
                type="text"
                value={(selectedElement as TextElement).text}
                onChange={(e) => updateText({ text: e.target.value })}
                className="w-full px-3 py-2 bg-slate-700 rounded-lg text-white text-sm"
              />
            </div>

            <div>
              <label className="text-xs text-slate-400 block mb-1">Fuente</label>
              <select
                value={(selectedElement as TextElement).fontFamily}
                onChange={(e) => updateText({ fontFamily: e.target.value })}
                className="w-full px-3 py-2 bg-slate-700 rounded-lg text-white text-sm"
              >
                {fontFamilies.map(font => (
                  <option key={font} value={font} style={{ fontFamily: font }}>
                    {font}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-xs text-slate-400 block mb-1">
                Tamaño: {(selectedElement as TextElement).fontSize}px
              </label>
              <input
                type="range"
                min="8"
                max="200"
                value={(selectedElement as TextElement).fontSize}
                onChange={(e) => updateText({ fontSize: parseInt(e.target.value) })}
                className="w-full"
              />
            </div>

            <div>
              <label className="text-xs text-slate-400 block mb-1">Color</label>
              <div className="flex items-center gap-2">
                <input
                  type="color"
                  value={(selectedElement as TextElement).fill}
                  onChange={(e) => updateText({ fill: e.target.value })}
                />
                <span className="text-sm text-slate-400">
                  {(selectedElement as TextElement).fill}
                </span>
              </div>
            </div>

            <div className="flex gap-2">
              <button
                onClick={() => updateText({ 
                  fontStyle: (selectedElement as TextElement).fontStyle === 'bold' ? 'normal' : 'bold'
                })}
                className={`flex-1 py-2 rounded-lg text-sm font-bold transition-colors ${
                  (selectedElement as TextElement).fontStyle === 'bold'
                    ? 'bg-primary-600 text-white'
                    : 'bg-slate-700 text-slate-300 hover:bg-slate-600'
                }`}
              >
                B
              </button>
              <button
                onClick={() => updateText({ 
                  fontStyle: (selectedElement as TextElement).fontStyle === 'italic' ? 'normal' : 'italic'
                })}
                className={`flex-1 py-2 rounded-lg text-sm italic transition-colors ${
                  (selectedElement as TextElement).fontStyle === 'italic'
                    ? 'bg-primary-600 text-white'
                    : 'bg-slate-700 text-slate-300 hover:bg-slate-600'
                }`}
              >
                I
              </button>
              <button
                onClick={() => updateText({ 
                  textDecoration: (selectedElement as TextElement).textDecoration === 'underline' ? '' : 'underline'
                })}
                className={`flex-1 py-2 rounded-lg text-sm underline transition-colors ${
                  (selectedElement as TextElement).textDecoration === 'underline'
                    ? 'bg-primary-600 text-white'
                    : 'bg-slate-700 text-slate-300 hover:bg-slate-600'
                }`}
              >
                U
              </button>
            </div>

            <div>
              <label className="text-xs text-slate-400 block mb-1">Alineación</label>
              <div className="flex gap-1">
                {(['left', 'center', 'right'] as const).map((align) => (
                  <button
                    key={align}
                    onClick={() => updateText({ align })}
                    className={`flex-1 py-2 rounded-lg text-sm capitalize transition-colors ${
                      (selectedElement as TextElement).align === align
                        ? 'bg-primary-600 text-white'
                        : 'bg-slate-700 text-slate-300 hover:bg-slate-600'
                    }`}
                  >
                    {align === 'left' ? '←' : align === 'center' ? '↔' : '→'}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Shape Properties */}
      {selectedElement.type === 'shape' && (
        <div className="p-4 border-b border-slate-700">
          <h3 className="text-sm font-semibold text-slate-300 uppercase tracking-wider mb-3 flex items-center gap-2">
            <Palette className="w-4 h-4" />
            Propiedades de Forma
          </h3>
          
          <div className="space-y-4">
            <div>
              <label className="text-xs text-slate-400 block mb-1">Color de Relleno</label>
              <div className="flex items-center gap-2">
                <input
                  type="color"
                  value={(selectedElement as ShapeElement).fill}
                  onChange={(e) => updateShape({ fill: e.target.value })}
                />
                <span className="text-sm text-slate-400">
                  {(selectedElement as ShapeElement).fill}
                </span>
              </div>
            </div>

            <div>
              <label className="text-xs text-slate-400 block mb-1">Color de Borde</label>
              <div className="flex items-center gap-2">
                <input
                  type="color"
                  value={(selectedElement as ShapeElement).stroke}
                  onChange={(e) => updateShape({ stroke: e.target.value })}
                />
                <span className="text-sm text-slate-400">
                  {(selectedElement as ShapeElement).stroke}
                </span>
              </div>
            </div>

            <div>
              <label className="text-xs text-slate-400 block mb-1">
                Grosor del Borde: {(selectedElement as ShapeElement).strokeWidth}px
              </label>
              <input
                type="range"
                min="0"
                max="20"
                value={(selectedElement as ShapeElement).strokeWidth}
                onChange={(e) => updateShape({ strokeWidth: parseInt(e.target.value) })}
                className="w-full"
              />
            </div>

            {(selectedElement as ShapeElement).shapeType === 'rect' && (
              <div>
                <label className="text-xs text-slate-400 block mb-1">
                  Radio de Esquina: {(selectedElement as ShapeElement).cornerRadius || 0}px
                </label>
                <input
                  type="range"
                  min="0"
                  max="50"
                  value={(selectedElement as ShapeElement).cornerRadius || 0}
                  onChange={(e) => updateShape({ cornerRadius: parseInt(e.target.value) })}
                  className="w-full"
                />
              </div>
            )}
          </div>
        </div>
      )}

      {/* Position & Size */}
      <div className="p-4">
        <h3 className="text-sm font-semibold text-slate-300 uppercase tracking-wider mb-3">
          Posición y Tamaño
        </h3>
        
        <div className="space-y-3">
          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="text-xs text-slate-400 block mb-1">X</label>
              <input
                type="number"
                value={Math.round(selectedElement.x)}
                onChange={(e) => updateElement(selectedElement.id, { x: parseInt(e.target.value) || 0 })}
                className="w-full px-3 py-2 bg-slate-700 rounded-lg text-white text-sm"
              />
            </div>
            <div>
              <label className="text-xs text-slate-400 block mb-1">Y</label>
              <input
                type="number"
                value={Math.round(selectedElement.y)}
                onChange={(e) => updateElement(selectedElement.id, { y: parseInt(e.target.value) || 0 })}
                className="w-full px-3 py-2 bg-slate-700 rounded-lg text-white text-sm"
              />
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="text-xs text-slate-400 block mb-1">Ancho</label>
              <input
                type="number"
                value={Math.round(selectedElement.width)}
                onChange={(e) => updateElement(selectedElement.id, { width: parseInt(e.target.value) || 1 })}
                className="w-full px-3 py-2 bg-slate-700 rounded-lg text-white text-sm"
              />
            </div>
            <div>
              <label className="text-xs text-slate-400 block mb-1">Alto</label>
              <input
                type="number"
                value={Math.round(selectedElement.height)}
                onChange={(e) => updateElement(selectedElement.id, { height: parseInt(e.target.value) || 1 })}
                className="w-full px-3 py-2 bg-slate-700 rounded-lg text-white text-sm"
              />
            </div>
          </div>

          <div>
            <label className="text-xs text-slate-400 block mb-1">
              Rotación: {Math.round(selectedElement.rotation)}°
            </label>
            <input
              type="range"
              min="-180"
              max="180"
              value={Math.round(selectedElement.rotation)}
              onChange={(e) => updateElement(selectedElement.id, { rotation: parseInt(e.target.value) })}
              className="w-full"
            />
          </div>
        </div>
      </div>
    </aside>
  )
}
