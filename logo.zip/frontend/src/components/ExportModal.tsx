import { useState, useRef } from 'react'
import { X, Download, FileImage, FileText, Layers, Check } from 'lucide-react'
import { useLogoStore } from '../store/logoStore'
import html2canvas from 'html2canvas'
import jsPDF from 'jspdf'

interface ExportModalProps {
  onClose: () => void
}

type ExportFormat = 'png' | 'svg' | 'favicon' | 'pdf'

interface ExportSize {
  name: string
  width: number
  height: number
}

const pngSizes: ExportSize[] = [
  { name: 'Pequeño (512x512)', width: 512, height: 512 },
  { name: 'Mediano (1024x1024)', width: 1024, height: 1024 },
  { name: 'Grande (2048x2048)', width: 2048, height: 2048 },
  { name: 'HD (4096x4096)', width: 4096, height: 4096 },
]

const faviconSizes = [16, 32, 48, 64, 128, 180, 192, 512]

export default function ExportModal({ onClose }: ExportModalProps) {
  const [format, setFormat] = useState<ExportFormat>('png')
  const [selectedSize, setSelectedSize] = useState<ExportSize>(pngSizes[1])
  const [isExporting, setIsExporting] = useState(false)
  const [exportedFiles, setExportedFiles] = useState<string[]>([])
  const { elements, canvas } = useLogoStore()
  const canvasRef = useRef<HTMLDivElement>(null)

  const generateSVGElement = (): string => {
    const svgWidth = canvas.width
    const svgHeight = canvas.height
    
    let svgContent = `<svg xmlns="http://www.w3.org/2000/svg" width="${svgWidth}" height="${svgHeight}" viewBox="0 0 ${svgWidth} ${svgHeight}">`
    svgContent += `<rect width="${svgWidth}" height="${svgHeight}" fill="${canvas.backgroundColor}"/>`
    
    elements.forEach(el => {
      if (el.type === 'text') {
        const textEl = el as any
        svgContent += `<text x="${el.x + el.width/2}" y="${el.y + el.height/2}" font-family="${textEl.fontFamily}" font-size="${textEl.fontSize}" fill="${textEl.fill}" text-anchor="middle" dominant-baseline="middle" transform="rotate(${el.rotation}, ${el.x + el.width/2}, ${el.y + el.height/2})">${textEl.text}</text>`
      } else if (el.type === 'shape') {
        const shapeEl = el as any
        if (shapeEl.shapeType === 'rect') {
          svgContent += `<rect x="${el.x}" y="${el.y}" width="${el.width}" height="${el.height}" rx="${shapeEl.cornerRadius || 0}" fill="${shapeEl.fill}" stroke="${shapeEl.stroke}" stroke-width="${shapeEl.strokeWidth}" transform="rotate(${el.rotation}, ${el.x + el.width/2}, ${el.y + el.height/2})"/>`
        } else if (shapeEl.shapeType === 'circle') {
          svgContent += `<circle cx="${el.x + el.width/2}" cy="${el.y + el.height/2}" r="${el.width/2}" fill="${shapeEl.fill}" stroke="${shapeEl.stroke}" stroke-width="${shapeEl.strokeWidth}"/>`
        }
      }
    })
    
    svgContent += '</svg>'
    return svgContent
  }

  const exportPNG = async () => {
    const canvasEl = document.querySelector('.konvajs-content canvas') as HTMLCanvasElement
    if (!canvasEl) return

    const exportCanvas = document.createElement('canvas')
    exportCanvas.width = selectedSize.width
    exportCanvas.height = selectedSize.height
    const ctx = exportCanvas.getContext('2d')
    if (!ctx) return

    ctx.fillStyle = canvas.backgroundColor
    ctx.fillRect(0, 0, selectedSize.width, selectedSize.height)
    ctx.drawImage(canvasEl, 0, 0, selectedSize.width, selectedSize.height)

    const link = document.createElement('a')
    link.download = `logo-${selectedSize.width}x${selectedSize.height}.png`
    link.href = exportCanvas.toDataURL('image/png')
    link.click()
    
    setExportedFiles([link.download])
  }

  const exportSVG = () => {
    const svgContent = generateSVGElement()
    const blob = new Blob([svgContent], { type: 'image/svg+xml' })
    const url = URL.createObjectURL(blob)
    
    const link = document.createElement('a')
    link.download = 'logo.svg'
    link.href = url
    link.click()
    
    URL.revokeObjectURL(url)
    setExportedFiles(['logo.svg'])
  }

  const exportFavicon = async () => {
    const canvasEl = document.querySelector('.konvajs-content canvas') as HTMLCanvasElement
    if (!canvasEl) return

    const files: string[] = []
    
    for (const size of faviconSizes) {
      const exportCanvas = document.createElement('canvas')
      exportCanvas.width = size
      exportCanvas.height = size
      const ctx = exportCanvas.getContext('2d')
      if (!ctx) continue

      ctx.fillStyle = canvas.backgroundColor
      ctx.fillRect(0, 0, size, size)
      ctx.drawImage(canvasEl, 0, 0, size, size)

      const link = document.createElement('a')
      link.download = `favicon-${size}x${size}.png`
      link.href = exportCanvas.toDataURL('image/png')
      link.click()
      files.push(link.download)
    }
    
    // Generate ICO file (32x32)
    const link = document.createElement('a')
    link.download = 'favicon.ico'
    link.href = canvasEl.toDataURL('image/x-icon')
    link.click()
    files.push('favicon.ico')
    
    // Generate SVG favicon
    const svgContent = generateSVGElement()
    const blob = new Blob([svgContent], { type: 'image/svg+xml' })
    const url = URL.createObjectURL(blob)
    const svgLink = document.createElement('a')
    svgLink.download = 'favicon.svg'
    svgLink.href = url
    svgLink.click()
    URL.revokeObjectURL(url)
    files.push('favicon.svg')
    
    setExportedFiles(files)
  }

  const exportPDF = async () => {
    const canvasEl = document.querySelector('.konvajs-content canvas') as HTMLCanvasElement
    if (!canvasEl) return

    const imgData = canvasEl.toDataURL('image/png')
    
    const pdf = new jsPDF({
      orientation: canvas.width > canvas.height ? 'landscape' : 'portrait',
      unit: 'px',
      format: [canvas.width, canvas.height]
    })
    
    pdf.addImage(imgData, 'PNG', 0, 0, canvas.width, canvas.height)
    pdf.save('logo.pdf')
    
    setExportedFiles(['logo.pdf'])
  }

  const handleExport = async () => {
    setIsExporting(true)
    setExportedFiles([])
    
    try {
      switch (format) {
        case 'png':
          await exportPNG()
          break
        case 'svg':
          exportSVG()
          break
        case 'favicon':
          await exportFavicon()
          break
        case 'pdf':
          await exportPDF()
          break
      }
    } catch (error) {
      console.error('Export error:', error)
    } finally {
      setIsExporting(false)
    }
  }

  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50">
      <div className="bg-slate-800 rounded-2xl shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-slate-700">
          <h2 className="text-xl font-bold text-white">Exportar Logotipo</h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-slate-700 rounded-lg transition-colors"
          >
            <X className="w-5 h-5 text-slate-400" />
          </button>
        </div>

        <div className="p-6 space-y-6">
          {/* Format Selection */}
          <div>
            <h3 className="text-sm font-semibold text-slate-300 uppercase tracking-wider mb-3">
              Formato de Exportación
            </h3>
            <div className="grid grid-cols-4 gap-3">
              <button
                onClick={() => setFormat('png')}
                className={`p-4 rounded-xl border-2 transition-all ${
                  format === 'png'
                    ? 'border-primary-500 bg-primary-500/10'
                    : 'border-slate-600 hover:border-slate-500'
                }`}
              >
                <FileImage className={`w-8 h-8 mx-auto mb-2 ${format === 'png' ? 'text-primary-400' : 'text-slate-400'}`} />
                <span className={`text-sm font-medium ${format === 'png' ? 'text-primary-400' : 'text-slate-300'}`}>PNG</span>
              </button>
              
              <button
                onClick={() => setFormat('svg')}
                className={`p-4 rounded-xl border-2 transition-all ${
                  format === 'svg'
                    ? 'border-primary-500 bg-primary-500/10'
                    : 'border-slate-600 hover:border-slate-500'
                }`}
              >
                <FileText className={`w-8 h-8 mx-auto mb-2 ${format === 'svg' ? 'text-primary-400' : 'text-slate-400'}`} />
                <span className={`text-sm font-medium ${format === 'svg' ? 'text-primary-400' : 'text-slate-300'}`}>SVG</span>
              </button>
              
              <button
                onClick={() => setFormat('favicon')}
                className={`p-4 rounded-xl border-2 transition-all ${
                  format === 'favicon'
                    ? 'border-primary-500 bg-primary-500/10'
                    : 'border-slate-600 hover:border-slate-500'
                }`}
              >
                <Layers className={`w-8 h-8 mx-auto mb-2 ${format === 'favicon' ? 'text-primary-400' : 'text-slate-400'}`} />
                <span className={`text-sm font-medium ${format === 'favicon' ? 'text-primary-400' : 'text-slate-300'}`}>Favicon</span>
              </button>
              
              <button
                onClick={() => setFormat('pdf')}
                className={`p-4 rounded-xl border-2 transition-all ${
                  format === 'pdf'
                    ? 'border-primary-500 bg-primary-500/10'
                    : 'border-slate-600 hover:border-slate-500'
                }`}
              >
                <FileText className={`w-8 h-8 mx-auto mb-2 ${format === 'pdf' ? 'text-primary-400' : 'text-slate-400'}`} />
                <span className={`text-sm font-medium ${format === 'pdf' ? 'text-primary-400' : 'text-slate-300'}`}>PDF</span>
              </button>
            </div>
          </div>

          {/* Size Selection (PNG only) */}
          {format === 'png' && (
            <div>
              <h3 className="text-sm font-semibold text-slate-300 uppercase tracking-wider mb-3">
                Tamaño
              </h3>
              <div className="grid grid-cols-2 gap-2">
                {pngSizes.map((size) => (
                  <button
                    key={size.name}
                    onClick={() => setSelectedSize(size)}
                    className={`p-3 rounded-lg border transition-all text-left ${
                      selectedSize === size
                        ? 'border-primary-500 bg-primary-500/10 text-primary-400'
                        : 'border-slate-600 hover:border-slate-500 text-slate-300'
                    }`}
                  >
                    <span className="font-medium">{size.name}</span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Info */}
          <div className="bg-slate-700/50 rounded-lg p-4">
            {format === 'png' && (
              <p className="text-sm text-slate-400">
                Exporta tu logo como imagen PNG con transparencia. Ideal para uso web y redes sociales.
              </p>
            )}
            {format === 'svg' && (
              <p className="text-sm text-slate-400">
                Exporta como SVG vectorial escalable sin pérdida de calidad. Perfecto para impresión profesional.
              </p>
            )}
            {format === 'favicon' && (
              <p className="text-sm text-slate-400">
                Genera todos los tamaños de favicon necesarios: 16x16, 32x32, 48x48, 64x64, 128x128, 180x180 (Apple Touch), 192x192, 512x512, ICO y SVG.
              </p>
            )}
            {format === 'pdf' && (
              <p className="text-sm text-slate-400">
                Exporta como documento PDF de alta calidad. Ideal para impresión y documentos oficiales.
              </p>
            )}
          </div>

          {/* Exported Files */}
          {exportedFiles.length > 0 && (
            <div className="bg-green-500/10 border border-green-500/20 rounded-lg p-4">
              <div className="flex items-center gap-2 mb-2">
                <Check className="w-5 h-5 text-green-400" />
                <span className="font-medium text-green-400">Archivos exportados:</span>
              </div>
              <ul className="text-sm text-slate-400 space-y-1">
                {exportedFiles.map((file, i) => (
                  <li key={i} className="font-mono">{file}</li>
                ))}
              </ul>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="flex justify-end gap-3 p-6 border-t border-slate-700">
          <button
            onClick={onClose}
            className="btn-secondary"
          >
            Cancelar
          </button>
          <button
            onClick={handleExport}
            disabled={isExporting}
            className="btn-primary flex items-center gap-2"
          >
            {isExporting ? (
              <>
                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                <span>Exportando...</span>
              </>
            ) : (
              <>
                <Download className="w-4 h-4" />
                <span>Exportar</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  )
}
