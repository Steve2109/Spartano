import { Type, Square, Circle, Triangle, Star, Image as ImageIcon, Hexagon, Pentagon } from 'lucide-react'
import { useLogoStore, TextElement, ShapeElement } from '../store/logoStore'

const fontFamilies = [
  'Inter',
  'Arial',
  'Helvetica',
  'Times New Roman',
  'Georgia',
  'Verdana',
  'Impact',
  'Comic Sans MS',
  'Courier New',
  'Trebuchet MS',
]

const colors = [
  '#000000', '#ffffff', '#ef4444', '#f97316', '#f59e0b', '#84cc16',
  '#22c55e', '#14b8a6', '#06b6d4', '#0ea5e9', '#3b82f6', '#6366f1',
  '#8b5cf6', '#a855f7', '#d946ef', '#ec4899', '#f43f5e', '#78716c',
]

export default function Sidebar() {
  const { addElement, canvas, updateCanvas } = useLogoStore()

  const addText = () => {
    const element: TextElement = {
      id: `text-${Date.now()}`,
      type: 'text',
      text: 'Texto',
      x: canvas.width / 2 - 50,
      y: canvas.height / 2,
      width: 100,
      height: 50,
      rotation: 0,
      scaleX: 1,
      scaleY: 1,
      draggable: true,
      fontFamily: 'Inter',
      fontSize: 32,
      fill: '#000000',
      fontStyle: 'normal',
      textDecoration: '',
      align: 'center',
    }
    addElement(element)
  }

  const addShape = (shapeType: ShapeElement['shapeType']) => {
    const element: ShapeElement = {
      id: `shape-${Date.now()}`,
      type: 'shape',
      shapeType,
      x: canvas.width / 2 - 50,
      y: canvas.height / 2 - 50,
      width: 100,
      height: 100,
      rotation: 0,
      scaleX: 1,
      scaleY: 1,
      draggable: true,
      fill: '#3b82f6',
      stroke: '#000000',
      strokeWidth: 0,
    }
    addElement(element)
  }

  return (
    <aside className="w-72 bg-slate-800 border-r border-slate-700 flex flex-col overflow-y-auto">
      {/* Canvas Settings */}
      <div className="p-4 border-b border-slate-700">
        <h3 className="text-sm font-semibold text-slate-300 uppercase tracking-wider mb-3">
          Canvas
        </h3>
        
        <div className="space-y-3">
          <div>
            <label className="text-xs text-slate-400 block mb-1">Tamaño</label>
            <div className="flex gap-2">
              <input
                type="number"
                value={canvas.width}
                onChange={(e) => updateCanvas({ width: parseInt(e.target.value) || 800 })}
                className="w-20 px-2 py-1 bg-slate-700 rounded text-sm text-white"
                placeholder="Ancho"
              />
              <span className="text-slate-500 self-center">×</span>
              <input
                type="number"
                value={canvas.height}
                onChange={(e) => updateCanvas({ height: parseInt(e.target.value) || 600 })}
                className="w-20 px-2 py-1 bg-slate-700 rounded text-sm text-white"
                placeholder="Alto"
              />
            </div>
          </div>
          
          <div>
            <label className="text-xs text-slate-400 block mb-1">Fondo</label>
            <div className="flex gap-2 items-center">
              <input
                type="color"
                value={canvas.backgroundColor}
                onChange={(e) => updateCanvas({ backgroundColor: e.target.value })}
              />
              <span className="text-sm text-slate-400">{canvas.backgroundColor}</span>
            </div>
          </div>
          
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={canvas.showGrid}
              onChange={(e) => updateCanvas({ showGrid: e.target.checked })}
              className="w-4 h-4 rounded border-slate-600"
            />
            <span className="text-sm text-slate-300">Mostrar cuadrícula</span>
          </label>
        </div>
      </div>

      {/* Add Elements */}
      <div className="p-4 border-b border-slate-700">
        <h3 className="text-sm font-semibold text-slate-300 uppercase tracking-wider mb-3">
          Elementos
        </h3>
        
        <button
          onClick={addText}
          className="w-full flex items-center gap-3 p-3 bg-slate-700 hover:bg-slate-600 rounded-lg transition-colors mb-2"
        >
          <Type className="w-5 h-5 text-primary-400" />
          <span className="text-sm font-medium text-white">Agregar Texto</span>
        </button>
        
        <div className="grid grid-cols-3 gap-2">
          <button
            onClick={() => addShape('rect')}
            className="p-3 bg-slate-700 hover:bg-slate-600 rounded-lg transition-colors flex flex-col items-center gap-1"
          >
            <Square className="w-5 h-5 text-primary-400" />
            <span className="text-xs text-slate-400">Rect</span>
          </button>
          <button
            onClick={() => addShape('circle')}
            className="p-3 bg-slate-700 hover:bg-slate-600 rounded-lg transition-colors flex flex-col items-center gap-1"
          >
            <Circle className="w-5 h-5 text-primary-400" />
            <span className="text-xs text-slate-400">Círc</span>
          </button>
          <button
            onClick={() => addShape('triangle')}
            className="p-3 bg-slate-700 hover:bg-slate-600 rounded-lg transition-colors flex flex-col items-center gap-1"
          >
            <Triangle className="w-5 h-5 text-primary-400" />
            <span className="text-xs text-slate-400">Tri</span>
          </button>
          <button
            onClick={() => addShape('star')}
            className="p-3 bg-slate-700 hover:bg-slate-600 rounded-lg transition-colors flex flex-col items-center gap-1"
          >
            <Star className="w-5 h-5 text-primary-400" />
            <span className="text-xs text-slate-400">Est</span>
          </button>
          <button
            onClick={() => addShape('polygon')}
            className="p-3 bg-slate-700 hover:bg-slate-600 rounded-lg transition-colors flex flex-col items-center gap-1"
          >
            <Hexagon className="w-5 h-5 text-primary-400" />
            <span className="text-xs text-slate-400">Pol</span>
          </button>
        </div>
      </div>

      {/* Quick Colors */}
      <div className="p-4">
        <h3 className="text-sm font-semibold text-slate-300 uppercase tracking-wider mb-3">
          Colores Rápidos
        </h3>
        <div className="grid grid-cols-6 gap-2">
          {colors.map((color) => (
            <button
              key={color}
              onClick={() => navigator.clipboard.writeText(color)}
              className="w-8 h-8 rounded-lg border-2 border-slate-600 hover:border-white transition-colors"
              style={{ backgroundColor: color }}
              title={`Copiar ${color}`}
            />
          ))}
        </div>
      </div>
    </aside>
  )
}
