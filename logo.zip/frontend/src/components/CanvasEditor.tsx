import { useRef, useEffect, useCallback } from 'react'
import { Stage, Layer, Rect, Text, Circle, Star, Line, Transformer } from 'react-konva'
import type Konva from 'konva'
import { useLogoStore, Element, TextElement, ShapeElement } from '../store/logoStore'

const PADDING = 50

export default function CanvasEditor() {
  const stageRef = useRef<Konva.Stage>(null)
  const transformerRef = useRef<Konva.Transformer>(null)
  const { elements, selectedId, setSelectedId, updateElement, canvas } = useLogoStore()

  // Update transformer when selection changes
  useEffect(() => {
    const transformer = transformerRef.current
    const stage = stageRef.current
    
    if (transformer && stage) {
      if (selectedId) {
        const selectedNode = stage.findOne(`#${selectedId}`)
        if (selectedNode) {
          transformer.nodes([selectedNode])
          transformer.getLayer()?.batchDraw()
        }
      } else {
        transformer.nodes([])
        transformer.getLayer()?.batchDraw()
      }
    }
  }, [selectedId])

  const handleStageClick = useCallback((e: Konva.KonvaEventObject<MouseEvent>) => {
    // Deselect when clicking on empty stage
    if (e.target === e.target.getStage()) {
      setSelectedId(null)
    }
  }, [setSelectedId])

  const handleDragEnd = (e: Konva.KonvaEventObject<DragEvent>, id: string) => {
    const node = e.target
    updateElement(id, {
      x: node.x(),
      y: node.y(),
    })
  }

  const handleTransformEnd = (e: Konva.KonvaEventObject<Event>, id: string, element: Element) => {
    const node = e.target
    const scaleX = node.scaleX()
    const scaleY = node.scaleY()

    updateElement(id, {
      x: node.x(),
      y: node.y(),
      rotation: node.rotation(),
      scaleX: scaleX,
      scaleY: scaleY,
      width: node.width() * scaleX,
      height: node.height() * scaleY,
    })

    // Reset scale to 1 and apply to width/height
    node.scaleX(1)
    node.scaleY(1)
  }

  const renderElement = (element: Element) => {
    const isSelected = selectedId === element.id
    const commonProps = {
      id: element.id,
      x: element.x,
      y: element.y,
      rotation: element.rotation,
      scaleX: element.scaleX,
      scaleY: element.scaleY,
      draggable: true,
      onClick: () => setSelectedId(element.id),
      onDragEnd: (e: Konva.KonvaEventObject<DragEvent>) => handleDragEnd(e, element.id),
      onTransformEnd: (e: Konva.KonvaEventObject<Event>) => handleTransformEnd(e, element.id, element),
    }

    switch (element.type) {
      case 'text':
        const textEl = element as TextElement
        return (
          <Text
            key={element.id}
            {...commonProps}
            text={textEl.text}
            fontFamily={textEl.fontFamily}
            fontSize={textEl.fontSize}
            fill={textEl.fill}
            fontStyle={textEl.fontStyle}
            textDecoration={textEl.textDecoration}
            align={textEl.align}
            width={element.width}
            height={element.height}
          />
        )

      case 'shape':
        const shapeEl = element as ShapeElement
        switch (shapeEl.shapeType) {
          case 'rect':
            return (
              <Rect
                key={element.id}
                {...commonProps}
                width={element.width}
                height={element.height}
                fill={shapeEl.fill}
                stroke={shapeEl.stroke}
                strokeWidth={shapeEl.strokeWidth}
                cornerRadius={shapeEl.cornerRadius || 0}
              />
            )
          case 'circle':
            return (
              <Circle
                key={element.id}
                {...commonProps}
                width={element.width}
                height={element.height}
                fill={shapeEl.fill}
                stroke={shapeEl.stroke}
                strokeWidth={shapeEl.strokeWidth}
              />
            )
          case 'triangle':
            return (
              <Line
                key={element.id}
                {...commonProps}
                points={[
                  element.width / 2, 0,
                  element.width, element.height,
                  0, element.height,
                ]}
                fill={shapeEl.fill}
                stroke={shapeEl.stroke}
                strokeWidth={shapeEl.strokeWidth}
                closed
              />
            )
          case 'star':
            return (
              <Star
                key={element.id}
                {...commonProps}
                numPoints={5}
                innerRadius={element.width / 4}
                outerRadius={element.width / 2}
                fill={shapeEl.fill}
                stroke={shapeEl.stroke}
                strokeWidth={shapeEl.strokeWidth}
              />
            )
          case 'polygon':
            const sides = shapeEl.sides || 6
            const radius = Math.min(element.width, element.height) / 2
            const points: number[] = []
            for (let i = 0; i < sides * 2; i++) {
              const angle = (i * Math.PI) / sides
              const r = i % 2 === 0 ? radius : radius * 0.6
              points.push(
                radius + r * Math.cos(angle),
                radius + r * Math.sin(angle)
              )
            }
            return (
              <Line
                key={element.id}
                {...commonProps}
                points={points}
                fill={shapeEl.fill}
                stroke={shapeEl.stroke}
                strokeWidth={shapeEl.strokeWidth}
                closed
              />
            )
          default:
            return null
        }

      default:
        return null
    }
  }

  // Calculate stage size with padding
  const stageWidth = canvas.width + PADDING * 2
  const stageHeight = canvas.height + PADDING * 2

  // Grid lines
  const gridSize = 20
  const gridLines = []
  for (let i = 0; i < stageWidth / gridSize; i++) {
    gridLines.push(
      <Line
        key={`v${i}`}
        points={[i * gridSize, 0, i * gridSize, stageHeight]}
        stroke="#e2e8f0"
        strokeWidth={0.5}
      />
    )
  }
  for (let i = 0; i < stageHeight / gridSize; i++) {
    gridLines.push(
      <Line
        key={`h${i}`}
        points={[0, i * gridSize, stageWidth, i * gridSize]}
        stroke="#e2e8f0"
        strokeWidth={0.5}
      />
    )
  }

  return (
    <div className="shadow-2xl rounded-lg overflow-hidden">
      <Stage
        ref={stageRef}
        width={stageWidth}
        height={stageHeight}
        onMouseDown={handleStageClick}
        onTouchStart={handleStageClick}
      >
        {/* Background layer */}
        <Layer>
          {/* Canvas background */}
          <Rect
            x={PADDING}
            y={PADDING}
            width={canvas.width}
            height={canvas.height}
            fill={canvas.backgroundColor}
          />
          {/* Grid */}
          {canvas.showGrid && (
            <>
              {gridLines.map((line, i) => (
                <Line
                  key={i}
                  x={PADDING}
                  y={PADDING}
                  points={[
                    (i % (stageWidth / gridSize)) * gridSize,
                    0,
                    (i % (stageWidth / gridSize)) * gridSize,
                    canvas.height
                  ]}
                  stroke="#e2e8f0"
                  strokeWidth={0.5}
                />
              ))}
            </>
          )}
        </Layer>

        {/* Elements layer */}
        <Layer x={PADDING} y={PADDING}>
          {elements.map(renderElement)}
          <Transformer
            ref={transformerRef}
            boundBoxFunc={(oldBox, newBox) => {
              // Limit resize to positive values
              if (newBox.width < 5 || newBox.height < 5) {
                return oldBox
              }
              return newBox
            }}
            rotateEnabled={true}
            enabledAnchors={['top-left', 'top-right', 'bottom-left', 'bottom-right']}
          />
        </Layer>
      </Stage>
    </div>
  )
}
