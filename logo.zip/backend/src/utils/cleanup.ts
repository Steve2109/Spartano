import fs from 'fs/promises'
import path from 'path'

const UPLOADS_DIR = path.join(__dirname, '../../uploads')
const MAX_AGE_MS = 24 * 60 * 60 * 1000 // 24 hours

export async function cleanupOldFiles() {
  try {
    const files = await fs.readdir(UPLOADS_DIR)
    const now = Date.now()
    let deletedCount = 0

    for (const file of files) {
      const filePath = path.join(UPLOADS_DIR, file)
      const stats = await fs.stat(filePath)
      const age = now - stats.mtime.getTime()

      if (age > MAX_AGE_MS) {
        await fs.unlink(filePath)
        deletedCount++
        console.log(`🗑️ Deleted old file: ${file}`)
      }
    }

    if (deletedCount > 0) {
      console.log(`✅ Cleanup complete: ${deletedCount} files deleted`)
    }
  } catch (error) {
    console.error('Cleanup error:', error)
  }
}
