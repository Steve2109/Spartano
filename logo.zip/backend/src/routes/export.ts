import { Router } from 'express'
import sharp from 'sharp'
import JSZip from 'jszip'
import { v4 as uuidv4 } from 'uuid'
import path from 'path'
import fs from 'fs/promises'

const router = Router()
const UPLOADS_DIR = path.join(__dirname, '../../uploads')

// Ensure uploads directory exists
async function ensureUploadsDir() {
  try {
    await fs.mkdir(UPLOADS_DIR, { recursive: true })
  } catch (error) {
    console.error('Error creating uploads directory:', error)
  }
}
ensureUploadsDir()

// Export PNG in multiple sizes
router.post('/png', async (req, res) => {
  try {
    const { svgData, sizes = [512, 1024, 2048] } = req.body
    
    if (!svgData) {
      return res.status(400).json({ error: 'SVG data is required' })
    }

    const id = uuidv4()
    const files: { name: string; size: number; path: string }[] = []

    // Convert SVG to buffer
    const svgBuffer = Buffer.from(svgData)

    // Generate PNGs in different sizes
    for (const size of sizes) {
      const outputPath = path.join(UPLOADS_DIR, `logo-${id}-${size}x${size}.png`)
      
      await sharp(svgBuffer, { density: 300 })
        .resize(size, size, { fit: 'contain', background: { r: 0, g: 0, b: 0, alpha: 0 } })
        .png()
        .toFile(outputPath)
      
      const stats = await fs.stat(outputPath)
      files.push({ name: `logo-${size}x${size}.png`, size: stats.size, path: outputPath })
    }

    res.json({ 
      success: true, 
      id,
      files,
      downloadUrl: `/api/export/download/${id}` 
    })
  } catch (error) {
    console.error('PNG export error:', error)
    res.status(500).json({ error: 'Failed to export PNG' })
  }
})

// Export Favicon package
router.post('/favicon', async (req, res) => {
  try {
    const { svgData } = req.body
    
    if (!svgData) {
      return res.status(400).json({ error: 'SVG data is required' })
    }

    const id = uuidv4()
    const faviconSizes = [16, 32, 48, 64, 128, 180, 192, 512]
    const zip = new JSZip()
    const svgBuffer = Buffer.from(svgData)

    // Generate favicon PNGs
    for (const size of faviconSizes) {
      const pngBuffer = await sharp(svgBuffer, { density: 300 })
        .resize(size, size, { fit: 'contain', background: { r: 0, g: 0, b: 0, alpha: 0 } })
        .png()
        .toBuffer()
      
      zip.file(`favicon-${size}x${size}.png`, pngBuffer)
    }

    // Add SVG favicon
    zip.file('favicon.svg', svgData)

    // Generate ICO (32x32 and 16x16 combined)
    const icoBuffer = await sharp(svgBuffer, { density: 300 })
      .resize(32, 32, { fit: 'contain', background: { r: 0, g: 0, b: 0, alpha: 0 } })
      .toFormat('png')
      .toBuffer()
    zip.file('favicon.ico', icoBuffer)

    // Generate HTML for favicon links
    const html = `<!DOCTYPE html>
<html>
<head>
  <!-- Favicon -->
  <link rel="icon" type="image/svg+xml" href="/favicon.svg">
  <link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png">
  <link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png">
  <link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png">
  <link rel="manifest" href="/site.webmanifest">
  <meta name="theme-color" content="#ffffff">
</head>
<body>
  <h1>Favicon Package</h1>
  <p>Copy these files to your website root directory.</p>
</body>
</html>`
    zip.file('README.html', html)

    // Generate site.webmanifest
    const manifest = {
      name: 'My App',
      short_name: 'App',
      icons: [
        { src: '/favicon-192x192.png', sizes: '192x192', type: 'image/png' },
        { src: '/favicon-512x512.png', sizes: '512x512', type: 'image/png' }
      ],
      theme_color: '#ffffff',
      background_color: '#ffffff',
      display: 'standalone'
    }
    zip.file('site.webmanifest', JSON.stringify(manifest, null, 2))

    // Save ZIP file
    const zipBuffer = await zip.generateAsync({ type: 'nodebuffer' })
    const zipPath = path.join(UPLOADS_DIR, `favicon-${id}.zip`)
    await fs.writeFile(zipPath, zipBuffer)

    res.json({
      success: true,
      id,
      downloadUrl: `/uploads/favicon-${id}.zip`,
      files: faviconSizes.map(s => `favicon-${s}x${s}.png`).concat(['favicon.svg', 'favicon.ico', 'site.webmanifest'])
    })
  } catch (error) {
    console.error('Favicon export error:', error)
    res.status(500).json({ error: 'Failed to export favicon' })
  }
})

// Export PDF
router.post('/pdf', async (req, res) => {
  try {
    const { svgData, width = 800, height = 600 } = req.body
    
    if (!svgData) {
      return res.status(400).json({ error: 'SVG data is required' })
    }

    const id = uuidv4()
    const svgBuffer = Buffer.from(svgData)

    // Convert to high-res PNG first
    const pngBuffer = await sharp(svgBuffer, { density: 300 })
      .resize(width * 2, height * 2, { fit: 'contain', background: { r: 255, g: 255, b: 255, alpha: 1 } })
      .png()
      .toBuffer()

    // Save PNG (for embedding in PDF)
    const pngPath = path.join(UPLOADS_DIR, `pdf-${id}.png`)
    await fs.writeFile(pngPath, pngBuffer)

    // Create simple PDF with embedded image
    const pdfPath = path.join(UPLOADS_DIR, `logo-${id}.pdf`)
    
    // For a real PDF, we'd use a library like PDFKit or puppeteer
    // For now, we'll return the high-res PNG as a placeholder
    // In production, implement proper PDF generation
    
    res.json({
      success: true,
      id,
      downloadUrl: `/uploads/pdf-${id}.png`, // Temporary - should be actual PDF
      message: 'PDF generation in progress. For now, use the high-res PNG.'
    })
  } catch (error) {
    console.error('PDF export error:', error)
    res.status(500).json({ error: 'Failed to export PDF' })
  }
})

// Download exported files
router.get('/download/:id', async (req, res) => {
  try {
    const { id } = req.params
    const files = await fs.readdir(UPLOADS_DIR)
    const userFiles = files.filter(f => f.includes(id))

    if (userFiles.length === 0) {
      return res.status(404).json({ error: 'Files not found or expired' })
    }

    if (userFiles.length === 1) {
      // Single file
      const filePath = path.join(UPLOADS_DIR, userFiles[0])
      res.download(filePath)
    } else {
      // Multiple files - create ZIP
      const zip = new JSZip()
      
      for (const file of userFiles) {
        const filePath = path.join(UPLOADS_DIR, file)
        const content = await fs.readFile(filePath)
        zip.file(file, content)
      }

      const zipBuffer = await zip.generateAsync({ type: 'nodebuffer' })
      res.set('Content-Type', 'application/zip')
      res.set('Content-Disposition', `attachment; filename="logo-${id}.zip"`)
      res.send(zipBuffer)
    }
  } catch (error) {
    console.error('Download error:', error)
    res.status(500).json({ error: 'Failed to download files' })
  }
})

export default router
