# 🎨 LogoAI - Generador de Logotipos Profesional

Aplicación moderna para crear, editar y exportar logotipos en múltiples formatos: SVG, PNG, Favicon y PDF.

![LogoAI Preview](https://via.placeholder.com/800x400/3b82f6/ffffff?text=LogoAI+Generator)

## ✨ Características

- 🎨 **Editor Visual** - Interfaz drag-and-drop con Konva.js
- 📝 **Texto Editable** - Múltiples fuentes, colores, efectos
- 🔷 **Formas** - Rectángulos, círculos, triángulos, estrellas, polígonos
- 📐 **Canvas Flexible** - Tamaños personalizables con cuadrícula
- 💾 **Plantillas** - 6 diseños predefinidos para empezar rápido
- 📤 **Exportación Versátil**:
  - **PNG**: 512x512, 1024x1024, 2048x2048, 4096x4096
  - **SVG**: Vector escalable sin pérdida de calidad
  - **Favicon**: Todos los tamaños (16x16 a 512x512) + ICO + manifest.json
  - **PDF**: Documento de alta calidad para impresión
- 🔄 **Undo/Redo** - Historial de cambios
- 💾 **Persistencia** - Guardado automático en localStorage

## 🚀 Tecnologías

| Frontend | Backend | DevOps |
|----------|---------|--------|
| React 18 + TypeScript | Node.js + Express | Docker + Docker Compose |
| Konva.js (Canvas) | Sharp (Procesamiento) | Nginx |
| TailwindCSS | JSZip (Compresión) | PM2 |
| Zustand (State) | UUID | |
| Lucide Icons | CORS + Helmet | |
| html2canvas + jsPDF | Rate Limiting | |

## 📁 Estructura del Proyecto

```
windsurf-project/
├── 📦 docker-compose.yml       # Orquestación Docker
├── 🐳 Dockerfile              # Imagen de producción
├── 📜 package.json            # Scripts del proyecto
├── 🎨 frontend/               # React App
│   ├── src/
│   │   ├── components/        # Componentes React
│   │   ├── store/            # Zustand store
│   │   ├── App.tsx
│   │   └── main.tsx
│   └── package.json
├── ⚙️ backend/               # Node.js API
│   ├── src/
│   │   ├── routes/           # API routes
│   │   ├── utils/            # Utilidades
│   │   └── server.ts
│   └── package.json
└── 📚 deployments-docs/       # Guías de despliegue
    ├── docker/               # Docker Compose
    ├── nginx/                # Nginx nativo
    └── apache/               # Apache nativo
```

## 🛠️ Desarrollo Local

### Requisitos

- Node.js 20+
- npm 10+

### Instalación

```bash
# Clonar el repositorio
git clone <repo-url>
cd windsurf-project

# Instalar todas las dependencias
npm run install:all

# Iniciar desarrollo (frontend + backend)
npm run dev
```

La aplicación estará disponible en:
- **Frontend**: http://localhost:5173
- **Backend**: http://localhost:32299

### Comandos Disponibles

```bash
npm run dev              # Desarrollo (frontend + backend)
npm run dev:frontend     # Solo frontend
npm run dev:backend        # Solo backend
npm run build            # Build producción
npm run start            # Iniciar producción

# Docker
npm run docker:compose         # Levantar con Docker
npm run docker:compose:build   # Rebuild
```

## 🚀 Despliegue en Producción

### Opción 1: Docker Compose (Recomendado) ⭐

```bash
# En el servidor Debian 13
cd /opt
sudo git clone <repo-url> logoai
cd logoai

docker-compose up -d --build
```

Ver guía completa: [`deployments-docs/docker/README.md`](./deployments-docs/docker/README.md)

### Opción 2: Nginx Nativo

```bash
# Instalar dependencias
sudo apt install nodejs nginx pm2

# Configurar
sudo mkdir -p /var/www/logoai
cd /var/www/logoai
npm run install:all
npm run build

# Iniciar con PM2
pm2 start ecosystem.config.js
```

Ver guía completa: [`deployments-docs/nginx/README.md`](./deployments-docs/nginx/README.md)

### Opción 3: Apache Nativo

```bash
# Instalar dependencias
sudo apt install nodejs apache2 pm2
sudo a2enmod proxy proxy_http

# Configurar y desplegar
cd /var/www/logoai
npm run install:all
npm run build
pm2 start ecosystem.config.js
```

Ver guía completa: [`deployments-docs/apache/README.md`](./deployments-docs/apache/README.md)

## 🔧 Configuración para Tu Servidor

Tu configuración actual:

| Parámetro | Valor |
|-----------|-------|
| **Dominio** | `http://logoai.tymtechnology.shop/` |
| **Puerto** | `32299` |
| **IP Interna** | `http://10.0.1.40:32299` |
| **Proxy** | Nginx Proxy Manager |
| **Certificado** | Let's Encrypt |
| **OS** | Debian 13 |

### Pasos para Desplegar en Tu Servidor

1. **Conectar al servidor**:
   ```bash
   ssh tu-usuario@10.0.1.40
   ```

2. **Copiar archivos**:
   ```bash
   # Desde tu máquina local
   scp -r windsurf-project/* usuario@10.0.1.40:/opt/logoai/
   ```

3. **Desplegar con Docker** (recomendado):
   ```bash
   cd /opt/logoai
   docker-compose up -d --build
   ```

4. **Verificar**:
   ```bash
   curl http://localhost:32299/health
   ```

5. **Tu dominio ya está configurado** en Nginx Proxy Manager apuntando a `10.0.1.40:32299` ✅

## 📤 Uso de la Aplicación

### Crear un Logo

1. **Elegir plantilla** o empezar en blanco
2. **Agregar elementos**:
   - Texto con fuentes personalizables
   - Formas geométricas (rectángulos, círculos, estrellas)
3. **Editar propiedades**:
   - Colores, tamaños, posiciones
   - Rotación y escala
   - Capas (traer al frente/enviar atrás)
4. **Exportar** en el formato deseado:
   - **PNG**: Para redes sociales y web
   - **SVG**: Para escalado infinito
   - **Favicon**: Para tu sitio web (incluye manifest.json)
   - **PDF**: Para impresión profesional

### Atajos de Teclado

| Atajo | Acción |
|-------|--------|
| `Ctrl + Z` | Deshacer |
| `Ctrl + Y` | Rehacer |
| `Delete` | Eliminar elemento seleccionado |
| `↑ ↓ ← →` | Mover elemento (1px) |
| `Shift + flechas` | Mover elemento (10px) |

## 🔐 Variables de Entorno

```env
# Backend
NODE_ENV=production
PORT=32299
HOST=0.0.0.0
```

## 🐛 Solución de Problemas

### El puerto 32299 está ocupado

```bash
sudo lsof -i :32299
sudo kill -9 <PID>
```

### Error de permisos en uploads

```bash
sudo chown -R 1001:1001 uploads/
```

### Dependencias nativas fallan

```bash
# Debian/Ubuntu
sudo apt install build-essential python3 make g++

# Rebuild
npm rebuild
```

## 📊 Monitoreo

```bash
# Logs Docker
docker-compose logs -f

# Logs PM2
pm2 logs

# Health check
curl http://localhost:32299/health
```

## 📝 Licencia

MIT © 2024 TyM Technology

---

<p align="center">
  🚀 Desplegado en <a href="http://logoai.tymtechnology.shop">logoai.tymtechnology.shop</a>
</p>
