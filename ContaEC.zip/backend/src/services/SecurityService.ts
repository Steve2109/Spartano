import fs from 'fs';
import { exec } from 'child_process';
import util from 'util';
import axios from 'axios';
import FormData from 'form-data';

const execAsync = util.promisify(exec);

export class SecurityService {
  private static VT_API_KEY = process.env.VIRUSTOTAL_API_KEY;

  /**
   * Escanea un archivo usando clamdscan (ClamAV daemon).
   * @param filePath Ruta temporal del archivo subido.
   * @returns true si está limpio, lanza error si detecta malware.
   */
  static async scanWithClamAV(filePath: string): Promise<boolean> {
    try {
      // Usamos clamdscan que es mucho más rápido que clamscan porque usa el daemon cargado en RAM
      const { stdout } = await execAsync(`clamdscan --no-summary "${filePath}"`);
      if (stdout.includes('OK')) {
        return true;
      }
      throw new Error('Archivo sospechoso detectado por ClamAV.');
    } catch (error: any) {
      if (error.stdout && error.stdout.includes('FOUND')) {
        throw new Error('Malware detectado por ClamAV. Archivo bloqueado.');
      }
      // Error de ejecución del comando (ej. clamd no está corriendo)
      console.error('Error ejecutando ClamAV:', error);
      throw new Error('El sistema de seguridad no pudo escanear el archivo. Por seguridad, ha sido rechazado.');
    }
  }

  /**
   * Escanea un archivo con VirusTotal usando su API de forma asíncrona.
   * Útil como opción avanzada de escaneo.
   */
  static async scanWithVirusTotal(filePath: string): Promise<any> {
    if (!this.VT_API_KEY) {
      throw new Error('La API Key de VirusTotal no está configurada en el servidor.');
    }

    const form = new FormData();
    form.append('file', fs.createReadStream(filePath));

    try {
      const response = await axios.post('https://www.virustotal.com/api/v3/files', form, {
        headers: {
          ...form.getHeaders(),
          'x-apikey': this.VT_API_KEY,
        },
      });
      return response.data; // Retorna el ID del análisis para que el cliente consulte luego
    } catch (error: any) {
      console.error('Error enviando archivo a VirusTotal:', error.response?.data || error.message);
      throw new Error('Error de comunicación con VirusTotal.');
    }
  }

  /**
   * Flujo completo de escaneo (ClamAV siempre, VT opcional).
   * Si detecta malware, borra el archivo y lanza error.
   */
  static async scanUploadedFile(filePath: string, useVirusTotal: boolean = false): Promise<boolean> {
    try {
      // 1. ClamAV siempre por defecto
      await this.scanWithClamAV(filePath);

      // 2. Si el usuario marcó VT
      if (useVirusTotal) {
        // En una implementación real no bloqueante, esto podría ir a una cola (ej. BullMQ)
        // Aquí lo enviamos y no esperamos el resultado final detallado, solo el inicio del análisis.
        await this.scanWithVirusTotal(filePath);
      }

      return true;
    } catch (error) {
      // Borrar archivo inseguro
      if (fs.existsSync(filePath)) {
        fs.unlinkSync(filePath);
      }
      throw error;
    }
  }
}
