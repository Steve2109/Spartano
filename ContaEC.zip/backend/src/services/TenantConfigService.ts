import fs from 'fs';
import path from 'path';
import dotenv from 'dotenv';

// Ruta segura en el servidor, puede sobreescribirse con una variable de entorno global
const TENANT_CONFIG_DIR = process.env.TENANT_CONFIG_DIR || path.join(__dirname, '../../../tenant_configs');

export interface TenantConfig {
  SRI_SIGNATURE_PATH?: string;
  SRI_SIGNATURE_PASSWORD?: string;
  BACKUP_ENCRYPTION_KEY?: string;
  SMTP_HOST?: string;
  SMTP_PORT?: string;
  SMTP_USER?: string;
  SMTP_PASS?: string;
  [key: string]: string | undefined;
}

export class TenantConfigService {
  
  static ensureDirExists() {
    if (!fs.existsSync(TENANT_CONFIG_DIR)) {
      fs.mkdirSync(TENANT_CONFIG_DIR, { recursive: true });
    }
  }

  static getFilePath(ruc: string): string {
    this.ensureDirExists();
    // Sanitizar el RUC para evitar path traversal
    const safeRuc = ruc.replace(/[^a-zA-Z0-9]/g, '');
    return path.join(TENANT_CONFIG_DIR, `usuario_${safeRuc}.env`);
  }

  /**
   * Lee la configuración específica del tenant (usuario/empresa)
   * parseando su archivo .env privado
   */
  static getTenantConfig(ruc: string): TenantConfig {
    const filePath = this.getFilePath(ruc);
    if (!fs.existsSync(filePath)) {
      return {};
    }
    const envConfig = dotenv.parse(fs.readFileSync(filePath));
    return envConfig;
  }

  /**
   * Guarda o actualiza variables en el .env privado del tenant
   */
  static saveTenantConfig(ruc: string, configUpdates: Partial<TenantConfig>): void {
    const filePath = this.getFilePath(ruc);
    let currentConfig: Record<string, string> = {};
    
    if (fs.existsSync(filePath)) {
      currentConfig = dotenv.parse(fs.readFileSync(filePath));
    }

    const mergedConfig = { ...currentConfig, ...configUpdates };
    
    let envContent = '';
    for (const [key, value] of Object.entries(mergedConfig)) {
      if (value !== undefined && value !== null) {
        envContent += `${key}=${value}\n`;
      }
    }

    fs.writeFileSync(filePath, envContent, { mode: 0o600 }); // Solo accesible por el propietario
  }
}
