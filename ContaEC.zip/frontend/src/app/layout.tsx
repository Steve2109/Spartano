import './globals.css';
import { Inter } from 'next/font/google';

const inter = Inter({ subsets: ['latin'] });

export const metadata = {
  title: 'ContaEC - Sistema Contable y Facturación Electrónica',
  description: 'Desarrollado por T&M Technology Ec. Sistema contable inteligente con integración SRI.',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="es-EC" suppressHydrationWarning>
      <body className={`${inter.className} min-h-screen bg-background text-foreground transition-colors duration-300`}>
        {/* Aquí podríamos inyectar el ThemeProvider para next-themes en el futuro */}
        {children}
      </body>
    </html>
  );
}
