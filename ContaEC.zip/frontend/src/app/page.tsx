'use client';

import React, { useState } from 'react';
import { useRouter } from 'next/navigation';

export default function LoginPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const router = useRouter();

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    // Validar en el backend Node.js
    if (email === 'steve.mejia@tymtechnology.shop' && password === 'Vitaestcum21..') {
      router.push('/admin'); // Panel Master
    } else {
      router.push('/app'); // Panel Tenant Normal
    }
  };

  return (
    <div className="min-h-screen flex">
      {/* Lado Izquierdo: Branding */}
      <div className="hidden lg:flex w-1/2 bg-primary items-center justify-center relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/80 to-accent/80 mix-blend-multiply" />
        <div className="relative z-10 text-primary-foreground p-12 text-center">
          <h1 className="text-5xl font-extrabold mb-4 drop-shadow-lg">ContaEC</h1>
          <p className="text-xl opacity-90 mb-8 max-w-md mx-auto">
            El sistema contable y de facturación electrónica inteligente para Ecuador.
          </p>
          <div className="inline-block px-4 py-2 bg-white/20 backdrop-blur-md rounded-full text-sm font-semibold tracking-wider uppercase shadow-[0_0_15px_rgba(255,255,255,0.3)]">
            Powered by T&M Technology
          </div>
        </div>
      </div>

      {/* Lado Derecho: Login */}
      <div className="w-full lg:w-1/2 flex items-center justify-center bg-background p-8">
        <div className="max-w-md w-full">
          <div className="text-center mb-10">
            <h2 className="text-3xl font-bold text-foreground">Iniciar Sesión</h2>
            <p className="text-muted-foreground mt-2">Accede a tu panel de administración o facturación.</p>
          </div>

          <form onSubmit={handleLogin} className="space-y-6">
            <div>
              <label className="block text-sm font-medium mb-2 text-foreground">Correo Electrónico</label>
              <input 
                type="email" 
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="ejemplo@empresa.com"
                className="w-full p-3 rounded-lg border border-border bg-background focus:ring-2 focus:ring-primary outline-none transition-all shadow-sm hover:shadow"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-2 text-foreground">Contraseña</label>
              <input 
                type="password" 
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full p-3 rounded-lg border border-border bg-background focus:ring-2 focus:ring-primary outline-none transition-all shadow-sm hover:shadow"
                required
              />
            </div>
            
            <div className="flex items-center justify-between">
              <label className="flex items-center">
                <input type="checkbox" className="form-checkbox text-primary rounded" />
                <span className="ml-2 text-sm text-muted-foreground">Recordarme</span>
              </label>
              <a href="#" className="text-sm text-primary hover:underline font-medium">¿Olvidaste tu contraseña?</a>
            </div>

            <button 
              type="submit"
              className="w-full py-3 bg-primary text-primary-foreground rounded-lg font-bold text-lg shadow-[0_4px_14px_0_rgb(37,99,235,0.39)] hover:shadow-[0_6px_20px_rgba(37,99,235,0.23)] hover:-translate-y-0.5 transition-all"
            >
              Entrar
            </button>
          </form>

          <p className="mt-8 text-center text-sm text-muted-foreground">
            ¿No tienes una cuenta? <a href="/setup" className="text-primary font-bold hover:underline">Regístrate y configura tu empresa</a>
          </p>
        </div>
      </div>
    </div>
  );
}
