'use client';

import React, { useState } from 'react';

export default function SetupWizard() {
  const [ruc, setRuc] = useState('');
  const [companyData, setCompanyData] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [p12File, setP12File] = useState<File | null>(null);
  const [encryptionKey, setEncryptionKey] = useState('');

  const handleRucLookup = async () => {
    setLoading(true);
    try {
      // Esta ruta llamaría a nuestro backend Express que a su vez llama a SriConsultas
      const res = await fetch(`http://localhost:4000/api/sri/consultar/${ruc}`);
      if (!res.ok) throw new Error('Error al consultar SRI');
      const data = await res.json();
      setCompanyData(data);
    } catch (error) {
      alert('Hubo un problema consultando el RUC. Verifica que sea válido.');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!companyData || !p12File || !encryptionKey) {
      alert('Por favor completa todos los campos (RUC validado, archivo P12 y clave de encriptación).');
      return;
    }

    const formData = new FormData();
    formData.append('ruc', ruc);
    formData.append('name', companyData.razonSocial || '');
    formData.append('p12File', p12File);
    formData.append('encryptionKey', encryptionKey);

    // Enviar a nuestro backend para que guarde en /var/contaec/tenant_configs/usuario_RUC.env
    alert('Enviando configuración inicial y configurando entorno aislado para la empresa...');
    // const response = await fetch('http://localhost:4000/api/setup', { method: 'POST', body: formData });
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4">
      <div className="max-w-2xl w-full bg-secondary text-secondary-foreground p-8 rounded-2xl shadow-xl">
        <h1 className="text-3xl font-bold mb-2 text-center text-primary">Bienvenido a ContaEC</h1>
        <p className="text-center text-muted-foreground mb-8">
          Configure su empresa inicializando su entorno de facturación y respaldos aislados.
        </p>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <label className="block text-sm font-medium">RUC de la Empresa</label>
            <div className="flex gap-4">
              <input 
                type="text" 
                value={ruc}
                onChange={(e) => setRuc(e.target.value)}
                placeholder="Ej. 1790016919001"
                className="flex-1 p-3 rounded-lg border border-border bg-background focus:ring-2 focus:ring-primary outline-none"
              />
              <button 
                type="button"
                onClick={handleRucLookup}
                disabled={loading || ruc.length < 10}
                className="px-6 py-3 bg-primary text-primary-foreground rounded-lg font-semibold hover:opacity-90 disabled:opacity-50 transition-all"
              >
                {loading ? 'Consultando...' : 'Consultar SRI'}
              </button>
            </div>
          </div>

          {companyData && (
            <div className="p-4 bg-muted rounded-lg border border-border space-y-2">
              <p><strong>Razón Social:</strong> {companyData.razonSocial || 'Dato no disponible'}</p>
              <p><strong>Estado:</strong> {companyData.estado || 'ACTIVO'}</p>
              <p><strong>Clase Contribuyente:</strong> {companyData.claseContribuyente || 'OTROS'}</p>
              <p className="text-xs text-muted-foreground mt-2">Estos datos han sido extraídos automáticamente desde el SRI.</p>
            </div>
          )}

          <div className="space-y-2">
            <label className="block text-sm font-medium">Firma Electrónica (.p12)</label>
            <input 
              type="file" 
              accept=".p12"
              onChange={(e) => setP12File(e.target.files?.[0] || null)}
              className="w-full p-2 border border-border rounded-lg bg-background file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:bg-primary file:text-primary-foreground file:font-semibold hover:file:opacity-90 cursor-pointer"
            />
            <p className="text-xs text-muted-foreground">Su firma se almacenará de forma segura en un entorno aislado (no en la base de datos).</p>
          </div>

          <div className="space-y-2">
            <label className="block text-sm font-medium">Clave de Encriptación para Respaldos</label>
            <input 
              type="password" 
              value={encryptionKey}
              onChange={(e) => setEncryptionKey(e.target.value)}
              placeholder="Ingrese una clave segura..."
              className="w-full p-3 rounded-lg border border-border bg-background focus:ring-2 focus:ring-primary outline-none"
            />
            <p className="text-xs text-muted-foreground">Esta clave se solicitará una sola vez y asegurará todos los respaldos automáticos de medianoche.</p>
          </div>

          <button 
            type="submit"
            className="w-full py-4 bg-accent text-accent-foreground rounded-xl font-bold text-lg shadow-lg hover:shadow-xl transition-all active:scale-95"
          >
            Finalizar Configuración e Iniciar Entorno
          </button>
        </form>
      </div>
    </div>
  );
}
