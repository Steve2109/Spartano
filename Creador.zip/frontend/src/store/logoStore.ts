import { create } from 'zustand'
import { devtools, persist } from 'zustand/middleware'
import type { 
  CanvasElement, 
  CanvasState, 
  ToolType, 
  ExportOptions,
  Template,
  TextElement,
  ShapeElement,
  ImageElement,
  HistoryState
} from '../types'

interface LogoState {
  // Canvas State
  canvas: CanvasState
  elements: CanvasElement[]
  selectedIds: string[]
  currentTool: ToolType
  zoom: number
  
  // UI State
  isExportModalOpen: boolean
  isTemplatesModalOpen: boolean
  isShortcutsModalOpen: boolean
  
  // History
  history: HistoryState[]
  historyIndex: number
  canUndo: boolean
  canRedo: boolean
  
  // Templates
  templates: Template[]
  
  // Actions
  initializeStore: () => void
  setCanvasSize: (width: number, height: number) => void
  setCanvasBackground: (color: string) => void
  setCanvasBackgroundImage: (image: string | undefined) => void
  
  // Element Actions
  addElement: (element: Omit<CanvasElement, 'id' | 'zIndex'>) => string
  updateElement: (id: string, updates: Partial<CanvasElement>) => void
  deleteElement: (id: string) => void
  deleteSelected: () => void
  duplicateElement: (id: string) => void
  duplicateSelected: () => void
  
  // Selection
  selectElement: (id: string, multi?: boolean) => void
  deselectAll: () => void
  selectAll: () => void
  
  // Layer Management
  bringToFront: (id: string) => void
  bringForward: (id: string) => void
  sendBackward: (id: string) => void
  sendToBack: (id: string) => void
  
  // Tool Management
  setTool: (tool: ToolType) => void
  setZoom: (zoom: number) => void
  
  // Alignment
  alignElements: (alignment: 'left' | 'center' | 'right' | 'top' | 'middle' | 'bottom') => void
  distributeElements: (direction: 'horizontal' | 'vertical') => void
  
  // Group/Ungroup
  groupElements: () => void
  ungroupElements: () => void
  
  // History
  saveToHistory: () => void
  undo: () => void
  redo: () => void
  
  // Export
  exportCanvas: (options: ExportOptions) => Promise<Blob | null>
  
  // Modal Control
  setExportModalOpen: (open: boolean) => void
  setTemplatesModalOpen: (open: boolean) => void
  setShortcutsModalOpen: (open: boolean) => void
  
  // Templates
  loadTemplate: (template: Template) => void
  loadFromJSON: (json: string) => void
  saveToJSON: () => string
}

const defaultCanvas: CanvasState = {
  width: 800,
  height: 600,
  backgroundColor: '#ffffff'
}

const generateId = () => Math.random().toString(36).substring(2, 15)

export const useLogoStore = create<LogoState>()(
  devtools(
    persist(
      (set, get) => ({
        // Initial State
        canvas: defaultCanvas,
        elements: [],
        selectedIds: [],
        currentTool: 'select',
        zoom: 1,
        isExportModalOpen: false,
        isTemplatesModalOpen: false,
        isShortcutsModalOpen: false,
        history: [],
        historyIndex: -1,
        canUndo: false,
        canRedo: false,
        templates: [],

        initializeStore: () => {
          const state = get()
          if (state.history.length === 0) {
            get().saveToHistory()
          }
        },

        setCanvasSize: (width, height) => {
          set({ canvas: { ...get().canvas, width, height } })
          get().saveToHistory()
        },

        setCanvasBackground: (color) => {
          set({ canvas: { ...get().canvas, backgroundColor: color } })
          get().saveToHistory()
        },

        setCanvasBackgroundImage: (image) => {
          set({ canvas: { ...get().canvas, backgroundImage: image } })
          get().saveToHistory()
        },

        addElement: (element) => {
          const id = generateId()
          const maxZ = Math.max(0, ...get().elements.map(e => e.zIndex))
          const newElement = { ...element, id, zIndex: maxZ + 1 } as CanvasElement
          
          set({ elements: [...get().elements, newElement] })
          get().saveToHistory()
          return id
        },

        updateElement: (id, updates) => {
          set({
            elements: get().elements.map(el => 
              el.id === id ? { ...el, ...updates } as CanvasElement : el
            )
          })
        },

        deleteElement: (id) => {
          set({ 
            elements: get().elements.filter(el => el.id !== id),
            selectedIds: get().selectedIds.filter(sid => sid !== id)
          })
          get().saveToHistory()
        },

        deleteSelected: () => {
          const { selectedIds } = get()
          if (selectedIds.length === 0) return
          
          set({
            elements: get().elements.filter(el => !selectedIds.includes(el.id)),
            selectedIds: []
          })
          get().saveToHistory()
        },

        duplicateElement: (id) => {
          const element = get().elements.find(el => el.id === id)
          if (!element) return
          
          const newId = generateId()
          const maxZ = Math.max(0, ...get().elements.map(e => e.zIndex))
          
          const duplicated = {
            ...element,
            id: newId,
            position: { x: element.position.x + 20, y: element.position.y + 20 },
            zIndex: maxZ + 1
          }
          
          set({ elements: [...get().elements, duplicated] })
          set({ selectedIds: [newId] })
          get().saveToHistory()
        },

        duplicateSelected: () => {
          const { selectedIds } = get()
          selectedIds.forEach(id => get().duplicateElement(id))
        },

        selectElement: (id, multi = false) => {
          if (multi) {
            set({ selectedIds: get().selectedIds.includes(id) 
              ? get().selectedIds.filter(sid => sid !== id)
              : [...get().selectedIds, id]
            })
          } else {
            set({ selectedIds: [id] })
          }
        },

        deselectAll: () => set({ selectedIds: [] }),

        selectAll: () => {
          set({ selectedIds: get().elements.map(el => el.id) })
        },

        bringToFront: (id) => {
          const maxZ = Math.max(0, ...get().elements.map(e => e.zIndex))
          get().updateElement(id, { zIndex: maxZ + 1 })
          get().saveToHistory()
        },

        bringForward: (id) => {
          const element = get().elements.find(el => el.id === id)
          if (!element) return
          get().updateElement(id, { zIndex: element.zIndex + 1 })
          get().saveToHistory()
        },

        sendBackward: (id) => {
          const element = get().elements.find(el => el.id === id)
          if (!element || element.zIndex <= 0) return
          get().updateElement(id, { zIndex: element.zIndex - 1 })
          get().saveToHistory()
        },

        sendToBack: (id) => {
          const minZ = Math.min(0, ...get().elements.map(e => e.zIndex))
          get().updateElement(id, { zIndex: minZ - 1 })
          get().saveToHistory()
        },

        setTool: (tool) => set({ currentTool: tool }),
        setZoom: (zoom) => set({ zoom: Math.max(0.1, Math.min(5, zoom)) }),

        alignElements: (alignment) => {
          const { selectedIds, elements } = get()
          if (selectedIds.length < 2) return
          
          const selected = elements.filter(el => selectedIds.includes(el.id))
          const bounds = selected.map(el => ({
            left: el.position.x,
            right: el.position.x + el.size.width,
            top: el.position.y,
            bottom: el.position.y + el.size.height,
            centerX: el.position.x + el.size.width / 2,
            centerY: el.position.y + el.size.height / 2
          }))
          
          let targetValue: number
          
          switch (alignment) {
            case 'left':
              targetValue = Math.min(...bounds.map(b => b.left))
              selected.forEach(el => get().updateElement(el.id, { 
                position: { ...el.position, x: targetValue } 
              }))
              break
            case 'center':
              targetValue = bounds.reduce((sum, b) => sum + b.centerX, 0) / bounds.length
              selected.forEach(el => get().updateElement(el.id, { 
                position: { ...el.position, x: targetValue - el.size.width / 2 } 
              }))
              break
            case 'right':
              targetValue = Math.max(...bounds.map(b => b.right))
              selected.forEach(el => get().updateElement(el.id, { 
                position: { ...el.position, x: targetValue - el.size.width } 
              }))
              break
            case 'top':
              targetValue = Math.min(...bounds.map(b => b.top))
              selected.forEach(el => get().updateElement(el.id, { 
                position: { ...el.position, y: targetValue } 
              }))
              break
            case 'middle':
              targetValue = bounds.reduce((sum, b) => sum + b.centerY, 0) / bounds.length
              selected.forEach(el => get().updateElement(el.id, { 
                position: { ...el.position, y: targetValue - el.size.height / 2 } 
              }))
              break
            case 'bottom':
              targetValue = Math.max(...bounds.map(b => b.bottom))
              selected.forEach(el => get().updateElement(el.id, { 
                position: { ...el.position, y: targetValue - el.size.height } 
              }))
              break
          }
          
          get().saveToHistory()
        },

        distributeElements: (direction) => {
          const { selectedIds, elements } = get()
          if (selectedIds.length < 3) return
          
          const selected = elements.filter(el => selectedIds.includes(el.id))
            .sort((a, b) => direction === 'horizontal' 
              ? a.position.x - b.position.x 
              : a.position.y - b.position.y)
          
          if (direction === 'horizontal') {
            const totalWidth = selected[selected.length - 1].position.x + selected[selected.length - 1].size.width - selected[0].position.x
            const spacing = totalWidth / (selected.length - 1)
            
            selected.forEach((el, i) => {
              get().updateElement(el.id, { 
                position: { ...el.position, x: selected[0].position.x + spacing * i } 
              })
            })
          } else {
            const totalHeight = selected[selected.length - 1].position.y + selected[selected.length - 1].size.height - selected[0].position.y
            const spacing = totalHeight / (selected.length - 1)
            
            selected.forEach((el, i) => {
              get().updateElement(el.id, { 
                position: { ...el.position, y: selected[0].position.y + spacing * i } 
              })
            })
          }
          
          get().saveToHistory()
        },

        groupElements: () => {
          // Implementation for grouping
        },

        ungroupElements: () => {
          // Implementation for ungrouping
        },

        saveToHistory: () => {
          const { elements, canvas, history, historyIndex } = get()
          const newState: HistoryState = {
            elements: JSON.parse(JSON.stringify(elements)),
            canvas: JSON.parse(JSON.stringify(canvas)),
            timestamp: Date.now()
          }
          
          const newHistory = history.slice(0, historyIndex + 1)
          newHistory.push(newState)
          
          // Limit history to 50 states
          if (newHistory.length > 50) {
            newHistory.shift()
          }
          
          set({
            history: newHistory,
            historyIndex: newHistory.length - 1,
            canUndo: newHistory.length > 1,
            canRedo: false
          })
        },

        undo: () => {
          const { historyIndex, history } = get()
          if (historyIndex <= 0) return
          
          const newIndex = historyIndex - 1
          const state = history[newIndex]
          
          set({
            elements: JSON.parse(JSON.stringify(state.elements)),
            canvas: JSON.parse(JSON.stringify(state.canvas)),
            historyIndex: newIndex,
            canUndo: newIndex > 0,
            canRedo: true
          })
        },

        redo: () => {
          const { historyIndex, history } = get()
          if (historyIndex >= history.length - 1) return
          
          const newIndex = historyIndex + 1
          const state = history[newIndex]
          
          set({
            elements: JSON.parse(JSON.stringify(state.elements)),
            canvas: JSON.parse(JSON.stringify(state.canvas)),
            historyIndex: newIndex,
            canUndo: true,
            canRedo: newIndex < history.length - 1
          })
        },

        exportCanvas: async (options) => {
          // Implementation in export utility
          return null
        },

        setExportModalOpen: (open) => set({ isExportModalOpen: open }),
        setTemplatesModalOpen: (open) => set({ isTemplatesModalOpen: open }),
        setShortcutsModalOpen: (open) => set({ isShortcutsModalOpen: open }),

        loadTemplate: (template) => {
          set({
            elements: JSON.parse(JSON.stringify(template.elements)),
            canvas: JSON.parse(JSON.stringify(template.canvas)),
            selectedIds: []
          })
          get().saveToHistory()
        },

        loadFromJSON: (json) => {
          try {
            const data = JSON.parse(json)
            if (data.elements && data.canvas) {
              set({
                elements: data.elements,
                canvas: data.canvas,
                selectedIds: []
              })
              get().saveToHistory()
            }
          } catch (e) {
            console.error('Failed to load JSON:', e)
          }
        },

        saveToJSON: () => {
          const { elements, canvas } = get()
          return JSON.stringify({ elements, canvas, version: '1.0' })
        }
      }),
      {
        name: 'logoai-storage',
        partialize: (state) => ({ 
          canvas: state.canvas,
          templates: state.templates
        })
      }
    )
  )
)
