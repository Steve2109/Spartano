import { useState } from 'react'
import { X, Search, Grid3X3, Sparkles } from 'lucide-react'
import { useLogoStore } from '../store/logoStore'
import type { Template, CanvasElement, CanvasState } from '../types'
import toast from 'react-hot-toast'

// Preset templates
const PRESET_TEMPLATES: Template[] = [
  {
    id: 'minimal-1',
    name: 'Minimalista Moderno',
    category: 'Minimalista',
    thumbnail: '',
    canvas: {
      width: 800,
      height: 600,
      backgroundColor: '#ffffff'
    },
    elements: [
      {
        id: 'circle-1',
        type: 'shape',
        name: 'Círculo',
        position: { x: 300, y: 200 },
        size: { width: 200, height: 200 },
        rotation: 0,
        scaleX: 1,
        scaleY: 1,
        opacity: 1,
        visible: true,
        locked: false,
        zIndex: 1,
        shapeType: 'circle',
        fill: '#3b82f6',
        stroke: 'transparent',
        strokeWidth: 0
      } as any,
      {
        id: 'text-1',
        type: 'text',
        name: 'Logo Text',
        position: { x: 280, y: 420 },
        size: { width: 240, height: 60 },
        rotation: 0,
        scaleX: 1,
        scaleY: 1,
        opacity: 1,
        visible: true,
        locked: false,
        zIndex: 2,
        text: 'COMPANY',
        fontFamily: 'Poppins',
        fontSize: 48,
        fontWeight: 700,
        fontStyle: 'normal',
        textDecoration: 'none',
        fill: '#1f2937',
        align: 'center',
        lineHeight: 1.2,
        letterSpacing: 2
      } as any,
      {
        id: 'text-2',
        type: 'text',
        name: 'Tagline',
        position: { x: 250, y: 480 },
        size: { width: 300, height: 40 },
        rotation: 0,
        scaleX: 1,
        scaleY: 1,
        opacity: 0.7,
        visible: true,
        locked: false,
        zIndex: 3,
        text: 'Tagline goes here',
        fontFamily: 'Inter',
        fontSize: 18,
        fontWeight: 400,
        fontStyle: 'normal',
        textDecoration: 'none',
        fill: '#6b7280',
        align: 'center',
        lineHeight: 1.4,
        letterSpacing: 0
      } as any
    ]
  },
  {
    id: 'tech-1',
    name: 'Tech Startup',
    category: 'Tecnología',
    thumbnail: '',
    canvas: {
      width: 800,
      height: 600,
      backgroundColor: '#0f172a'
    },
    elements: [
      {
        id: 'hex-1',
        type: 'shape',
        name: 'Hexágono',
        position: { x: 350, y: 180 },
        size: { width: 100, height: 100 },
        rotation: 0,
        scaleX: 1,
        scaleY: 1,
        opacity: 1,
        visible: true,
        locked: false,
        zIndex: 1,
        shapeType: 'polygon',
        fill: '#10b981',
        sides: 6,
        stroke: 'transparent',
        strokeWidth: 0
      } as any,
      {
        id: 'text-1',
        type: 'text',
        name: 'Tech Name',
        position: { x: 220, y: 320 },
        size: { width: 360, height: 80 },
        rotation: 0,
        scaleX: 1,
        scaleY: 1,
        opacity: 1,
        visible: true,
        locked: false,
        zIndex: 2,
        text: 'NEXUS',
        fontFamily: 'Inter',
        fontSize: 64,
        fontWeight: 800,
        fontStyle: 'normal',
        textDecoration: 'none',
        fill: '#ffffff',
        align: 'center',
        lineHeight: 1.1,
        letterSpacing: 4
      } as any,
      {
        id: 'text-2',
        type: 'text',
        name: 'Subtitle',
        position: { x: 250, y: 400 },
        size: { width: 300, height: 40 },
        rotation: 0,
        scaleX: 1,
        scaleY: 1,
        opacity: 0.8,
        visible: true,
        locked: false,
        zIndex: 3,
        text: 'INNOVATION LABS',
        fontFamily: 'Inter',
        fontSize: 16,
        fontWeight: 500,
        fontStyle: 'normal',
        textDecoration: 'none',
        fill: '#10b981',
        align: 'center',
        lineHeight: 1.4,
        letterSpacing: 6
      } as any
    ]
  },
  {
    id: 'elegant-1',
    name: 'Elegante Clásico',
    category: 'Elegante',
    thumbnail: '',
    canvas: {
      width: 800,
      height: 600,
      backgroundColor: '#fafaf9'
    },
    elements: [
      {
        id: 'line-1',
        type: 'shape',
        name: 'Línea decorativa',
        position: { x: 200, y: 280 },
        size: { width: 400, height: 2 },
        rotation: 0,
        scaleX: 1,
        scaleY: 1,
        opacity: 1,
        visible: true,
        locked: false,
        zIndex: 1,
        shapeType: 'line',
        fill: 'transparent',
        stroke: '#78716c',
        strokeWidth: 1
      } as any,
      {
        id: 'text-1',
        type: 'text',
        name: 'Brand Name',
        position: { x: 150, y: 200 },
        size: { width: 500, height: 80 },
        rotation: 0,
        scaleX: 1,
        scaleY: 1,
        opacity: 1,
        visible: true,
        locked: false,
        zIndex: 2,
        text: 'LUXE',
        fontFamily: 'Playfair Display',
        fontSize: 72,
        fontWeight: 400,
        fontStyle: 'normal',
        textDecoration: 'none',
        fill: '#292524',
        align: 'center',
        lineHeight: 1.1,
        letterSpacing: 8
      } as any,
      {
        id: 'text-2',
        type: 'text',
        name: 'Est. Year',
        position: { x: 320, y: 320 },
        size: { width: 160, height: 30 },
        rotation: 0,
        scaleX: 1,
        scaleY: 1,
        opacity: 0.6,
        visible: true,
        locked: false,
        zIndex: 3,
        text: 'Est. 2024',
        fontFamily: 'Inter',
        fontSize: 14,
        fontWeight: 400,
        fontStyle: 'italic',
        textDecoration: 'none',
        fill: '#78716c',
        align: 'center',
        lineHeight: 1.4,
        letterSpacing: 2
      } as any
    ]
  },
  {
    id: 'creative-1',
    name: 'Creativo Colorido',
    category: 'Creativo',
    thumbnail: '',
    canvas: {
      width: 800,
      height: 600,
      backgroundColor: '#fef3c7'
    },
    elements: [
      {
        id: 'circle-1',
        type: 'shape',
        name: 'Círculo 1',
        position: { x: 280, y: 180 },
        size: { width: 80, height: 80 },
        rotation: 0,
        scaleX: 1,
        scaleY: 1,
        opacity: 0.8,
        visible: true,
        locked: false,
        zIndex: 1,
        shapeType: 'circle',
        fill: '#f59e0b',
        stroke: 'transparent',
        strokeWidth: 0
      } as any,
      {
        id: 'circle-2',
        type: 'shape',
        name: 'Círculo 2',
        position: { x: 360, y: 220 },
        size: { width: 120, height: 120 },
        rotation: 0,
        scaleX: 1,
        scaleY: 1,
        opacity: 0.7,
        visible: true,
        locked: false,
        zIndex: 2,
        shapeType: 'circle',
        fill: '#ec4899',
        stroke: 'transparent',
        strokeWidth: 0
      } as any,
      {
        id: 'circle-3',
        type: 'shape',
        name: 'Círculo 3',
        position: { x: 440, y: 160 },
        size: { width: 100, height: 100 },
        rotation: 0,
        scaleX: 1,
        scaleY: 1,
        opacity: 0.6,
        visible: true,
        locked: false,
        zIndex: 3,
        shapeType: 'circle',
        fill: '#8b5cf6',
        stroke: 'transparent',
        strokeWidth: 0
      } as any,
      {
        id: 'text-1',
        type: 'text',
        name: 'Creative',
        position: { x: 200, y: 380 },
        size: { width: 400, height: 80 },
        rotation: 0,
        scaleX: 1,
        scaleY: 1,
        opacity: 1,
        visible: true,
        locked: false,
        zIndex: 4,
        text: 'CREATIVE',
        fontFamily: 'Pacifico',
        fontSize: 56,
        fontWeight: 400,
        fontStyle: 'normal',
        textDecoration: 'none',
        fill: '#1f2937',
        align: 'center',
        lineHeight: 1.2,
        letterSpacing: 0
      } as any
    ]
  }
]

const TemplatesModal = () => {
  const { isTemplatesModalOpen, setTemplatesModalOpen, loadTemplate } = useLogoStore()
  const [searchQuery, setSearchQuery] = useState('')
  const [selectedCategory, setSelectedCategory] = useState<string>('all')

  const categories = ['all', 'Minimalista', 'Tecnología', 'Elegante', 'Creativo']

  const filteredTemplates = PRESET_TEMPLATES.filter(template => {
    const matchesSearch = template.name.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesCategory = selectedCategory === 'all' || template.category === selectedCategory
    return matchesSearch && matchesCategory
  })

  const handleLoadTemplate = (template: Template) => {
    loadTemplate(template)
    setTemplatesModalOpen(false)
    toast.success(`Template "${template.name}" cargado`)
  }

  if (!isTemplatesModalOpen) return null

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-dark-100 rounded-xl w-full max-w-4xl m-4 shadow-2xl max-h-[80vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-gray-800 shrink-0">
          <div className="flex items-center gap-3">
            <Sparkles className="w-6 h-6 text-primary-500" />
            <h2 className="text-lg font-semibold">Templates</h2>
          </div>
          <button
            onClick={() => setTemplatesModalOpen(false)}
            className="p-2 hover:bg-gray-800 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search and Filter */}
        <div className="p-4 border-b border-gray-800 space-y-3 shrink-0">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input
              type="text"
              placeholder="Buscar templates..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="input-field w-full pl-10"
            />
          </div>

          <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-thin">
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => setSelectedCategory(category)}
                className={`px-4 py-2 rounded-lg text-sm whitespace-nowrap transition-colors ${
                  selectedCategory === category
                    ? 'bg-primary-600 text-white'
                    : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
                }`}
              >
                {category === 'all' ? 'Todos' : category}
              </button>
            ))}
          </div>
        </div>

        {/* Templates Grid */}
        <div className="flex-1 overflow-y-auto p-4 scrollbar-thin">
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            {filteredTemplates.map((template) => (
              <button
                key={template.id}
                onClick={() => handleLoadTemplate(template)}
                className="group relative bg-gray-800 rounded-xl overflow-hidden hover:ring-2 hover:ring-primary-500 transition-all text-left"
              >
                {/* Preview */}
                <div 
                  className="aspect-[4/3] relative overflow-hidden"
                  style={{ backgroundColor: template.canvas.backgroundColor }}
                >
                  {/* Simplified preview */}
                  {template.elements.slice(0, 3).map((el: any, idx: number) => (
                    <div
                      key={idx}
                      className="absolute"
                      style={{
                        left: `${(el.position.x / template.canvas.width) * 100}%`,
                        top: `${(el.position.y / template.canvas.height) * 100}%`,
                        width: `${(el.size.width / template.canvas.width) * 100}%`,
                        height: `${(el.size.height / template.canvas.height) * 100}%`,
                        backgroundColor: el.type === 'shape' ? el.fill : 'transparent',
                        borderRadius: el.shapeType === 'circle' ? '50%' : '0',
                        opacity: el.opacity
                      }}
                    >
                      {el.type === 'text' && (
                        <span 
                          className="text-xs truncate block w-full text-center"
                          style={{ 
                            color: el.fill,
                            fontSize: `${Math.max(10, (el.fontSize / template.canvas.height) * 100)}px`
                          }}
                        >
                          {el.text.slice(0, 10)}
                        </span>
                      )}
                    </div>
                  ))}
                  
                  {/* Hover overlay */}
                  <div className="absolute inset-0 bg-primary-600/0 group-hover:bg-primary-600/20 transition-colors flex items-center justify-center">
                    <span className="opacity-0 group-hover:opacity-100 text-white font-medium bg-primary-600 px-4 py-2 rounded-lg transition-opacity">
                      Usar template
                    </span>
                  </div>
                </div>

                {/* Info */}
                <div className="p-3">
                  <h3 className="font-medium text-sm text-white truncate">{template.name}</h3>
                  <p className="text-xs text-gray-400">{template.category}</p>
                  <p className="text-xs text-gray-500 mt-1">
                    {template.elements.length} elementos
                  </p>
                </div>
              </button>
            ))}
          </div>

          {filteredTemplates.length === 0 && (
            <div className="text-center py-12 text-gray-500">
              <Grid3X3 className="w-12 h-12 mx-auto mb-3 opacity-50" />
              <p>No se encontraron templates</p>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

export default TemplatesModal
