import { useRef, useEffect, useState, useCallback } from 'react'
import { Stage, Layer, Rect, Circle, Line, Text, Image, Star, Group, Transformer } from 'react-konva'
import { KonvaEventObject } from 'konva/lib/Node'
import useImage from 'use-image'
import { useLogoStore } from '../store/logoStore'
import type { CanvasElement, TextElement, ShapeElement, ImageElement } from '../types'
import { getShapePoints, loadGoogleFont, FONTS } from '../utils/canvasHelpers'
import toast from 'react-hot-toast'

// Image component with loading
const CanvasImage = ({ element, onSelect }: { element: ImageElement; onSelect: () => void }) => {
  const [image] = useImage(element.src, 'anonymous')
  
  if (!image) {
    return (
      <Rect
        x={element.position.x}
        y={element.position.y}
        width={element.size.width}
        height={element.size.height}
        fill="#374151"
        stroke="#4b5563"
        strokeWidth={1}
      />
    )
  }

  return (
    <Image
      image={image}
      x={element.position.x}
      y={element.position.y}
      width={element.size.width}
      height={element.size.height}
      rotation={element.rotation}
      scaleX={element.scaleX}
      scaleY={element.scaleY}
      opacity={element.opacity}
      draggable={!element.locked}
      onClick={onSelect}
      onTap={onSelect}
    />
  )
}

const CanvasEditor = () => {
  const stageRef = useRef<any>(null)
  const transformerRef = useRef<any>(null)
  const containerRef = useRef<HTMLDivElement>(null)
  
  const {
    canvas,
    elements,
    selectedIds,
    currentTool,
    zoom,
    selectElement,
    deselectAll,
    updateElement,
    addElement,
    duplicateSelected,
    deleteSelected,
    bringToFront,
    sendToBack,
    saveToHistory
  } = useLogoStore()

  const [isDragging, setIsDragging] = useState(false)

  // Load fonts
  useEffect(() => {
    FONTS.forEach(font => loadGoogleFont(font))
  }, [])

  // Update transformer when selection changes
  useEffect(() => {
    if (transformerRef.current && stageRef.current) {
      const stage = stageRef.current.getStage()
      const selectedNodes = selectedIds
        .map(id => stage.findOne(`#${id}`))
        .filter(node => node !== undefined)
      
      transformerRef.current.nodes(selectedNodes)
      transformerRef.current.getLayer()?.batchDraw()
    }
  }, [selectedIds])

  // Handle stage click (deselect)
  const handleStageClick = (e: KonvaEventObject<MouseEvent>) => {
    if (e.target === e.target.getStage()) {
      deselectAll()
    }
  }

  // Handle element selection
  const handleElementClick = (e: KonvaEventObject<MouseEvent>, id: string) => {
    e.cancelBubble = true
    const isMultiSelect = e.evt.shiftKey || e.evt.ctrlKey || e.evt.metaKey
    selectElement(id, isMultiSelect)
  }

  // Handle drag end
  const handleDragEnd = (e: KonvaEventObject<DragEvent>, id: string) => {
    const node = e.target
    updateElement(id, {
      position: {
        x: node.x(),
        y: node.y()
      }
    })
    saveToHistory()
  }

  // Handle transform end
  const handleTransformEnd = (e: KonvaEventObject<Event>, id: string) => {
    const node = e.target
    const scaleX = node.scaleX()
    const scaleY = node.scaleY()
    
    updateElement(id, {
      position: { x: node.x(), y: node.y() },
      rotation: node.rotation(),
      scaleX,
      scaleY,
      size: {
        width: Math.max(5, node.width() * scaleX),
        height: Math.max(5, node.height() * scaleY)
      }
    })
    
    // Reset scale (we store it in state)
    node.scaleX(1)
    node.scaleY(1)
    
    saveToHistory()
  }

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Delete
      if (e.key === 'Delete' || e.key === 'Backspace') {
        if (selectedIds.length > 0) {
          deleteSelected()
        }
      }
      
      // Duplicate
      if (e.key === 'd' && (e.ctrlKey || e.metaKey)) {
        e.preventDefault()
        duplicateSelected()
      }
      
      // Select all
      if (e.key === 'a' && (e.ctrlKey || e.metaKey)) {
        e.preventDefault()
        useLogoStore.getState().selectAll()
      }
      
      // Deselect
      if (e.key === 'Escape') {
        deselectAll()
      }
      
      // Bring to front
      if (e.key === ']' && (e.ctrlKey || e.metaKey)) {
        e.preventDefault()
        selectedIds.forEach(id => bringToFront(id))
      }
      
      // Send to back
      if (e.key === '[' && (e.ctrlKey || e.metaKey)) {
        e.preventDefault()
        selectedIds.forEach(id => sendToBack(id))
      }
    }

    window.addEventListener('keydown', handleKeyDown)
    return () => window.removeEventListener('keydown', handleKeyDown)
  }, [selectedIds, deleteSelected, duplicateSelected, deselectAll, bringToFront, sendToBack])

  // Render element
  const renderElement = (element: CanvasElement) => {
    const isSelected = selectedIds.includes(element.id)
    const commonProps = {
      id: element.id,
      x: element.position.x,
      y: element.position.y,
      rotation: element.rotation,
      scaleX: element.scaleX,
      scaleY: element.scaleY,
      opacity: element.opacity,
      draggable: !element.locked && currentTool === 'select',
      visible: element.visible,
      onClick: (e: KonvaEventObject<MouseEvent>) => handleElementClick(e, element.id),
      onTap: (e: KonvaEventObject<MouseEvent>) => handleElementClick(e, element.id),
      onDragEnd: (e: KonvaEventObject<DragEvent>) => handleDragEnd(e, element.id),
      onTransformEnd: (e: KonvaEventObject<Event>) => handleTransformEnd(e, element.id)
    }

    switch (element.type) {
      case 'text':
        const textEl = element as TextElement
        return (
          <Text
            key={element.id}
            {...commonProps}
            text={textEl.text}
            fontSize={textEl.fontSize}
            fontFamily={textEl.fontFamily}
            fontStyle={textEl.fontStyle}
            textDecoration={textEl.textDecoration}
            fill={textEl.fill}
            stroke={textEl.stroke}
            strokeWidth={textEl.strokeWidth || 0}
            align={textEl.align}
            lineHeight={textEl.lineHeight}
            letterSpacing={textEl.letterSpacing}
            width={element.size.width}
            height={element.size.height}
          />
        )

      case 'shape':
        const shapeEl = element as ShapeElement
        const { shapeType } = shapeEl

        if (shapeType === 'rectangle') {
          return (
            <Rect
              key={element.id}
              {...commonProps}
              width={element.size.width}
              height={element.size.height}
              fill={shapeEl.fill}
              stroke={shapeEl.stroke}
              strokeWidth={shapeEl.strokeWidth || 0}
              cornerRadius={shapeEl.cornerRadius || 0}
            />
          )
        }

        if (shapeType === 'circle') {
          return (
            <Circle
              key={element.id}
              {...commonProps}
              radius={Math.min(element.size.width, element.size.height) / 2}
              fill={shapeEl.fill}
              stroke={shapeEl.stroke}
              strokeWidth={shapeEl.strokeWidth || 0}
              offsetX={-element.size.width / 2}
              offsetY={-element.size.height / 2}
            />
          )
        }

        if (shapeType === 'star') {
          return (
            <Star
              key={element.id}
              {...commonProps}
              numPoints={5}
              innerRadius={shapeEl.innerRadius || 30}
              outerRadius={shapeEl.outerRadius || 50}
              fill={shapeEl.fill}
              stroke={shapeEl.stroke}
              strokeWidth={shapeEl.strokeWidth || 0}
              offsetX={-element.size.width / 2}
              offsetY={-element.size.height / 2}
            />
          )
        }

        if (shapeType === 'triangle' || shapeType === 'polygon') {
          const points = getShapePoints(shapeEl)
          return (
            <Line
              key={element.id}
              {...commonProps}
              points={points}
              fill={shapeEl.fill}
              stroke={shapeEl.stroke}
              strokeWidth={shapeEl.strokeWidth || 0}
              closed
            />
          )
        }

        if (shapeType === 'line' || shapeType === 'arrow') {
          return (
            <Line
              key={element.id}
              {...commonProps}
              points={[0, 0, element.size.width, 0]}
              stroke={shapeEl.stroke || shapeEl.fill}
              strokeWidth={shapeEl.strokeWidth || 4}
            />
          )
        }

        return null

      case 'image':
        const imageEl = element as ImageElement
        return (
          <CanvasImage
            key={element.id}
            element={imageEl}
            onSelect={() => selectElement(element.id)}
          />
        )

      default:
        return null
    }
  }

  return (
    <div 
      ref={containerRef}
      className="relative w-full h-full bg-gray-900 overflow-hidden"
      id="canvas-container"
    >
      {/* Background Pattern */}
      <div 
        className="absolute inset-0 opacity-20"
        style={{
          backgroundImage: `
            linear-gradient(45deg, #374151 25%, transparent 25%),
            linear-gradient(-45deg, #374151 25%, transparent 25%),
            linear-gradient(45deg, transparent 75%, #374151 75%),
            linear-gradient(-45deg, transparent 75%, #374151 75%)
          `,
          backgroundSize: '20px 20px',
          backgroundPosition: '0 0, 0 10px, 10px -10px, -10px 0px'
        }}
      />

      {/* Canvas Stage */}
      <div className="absolute inset-0 flex items-center justify-center">
        <Stage
          ref={stageRef}
          width={canvas.width * zoom}
          height={canvas.height * zoom}
          scaleX={zoom}
          scaleY={zoom}
          onMouseDown={handleStageClick}
          onTouchStart={handleStageClick}
          className="shadow-2xl"
          style={{
            backgroundColor: canvas.backgroundColor
          }}
        >
          <Layer>
            {/* Background */}
            <Rect
              x={0}
              y={0}
              width={canvas.width}
              height={canvas.height}
              fill={canvas.backgroundColor}
            />

            {/* Elements sorted by z-index */}
            {[...elements]
              .sort((a, b) => a.zIndex - b.zIndex)
              .map(renderElement)}

            {/* Transformer for selected elements */}
            <Transformer
              ref={transformerRef}
              flipEnabled={false}
              rotateEnabled={true}
              anchorSize={8}
              borderStroke="#3b82f6"
              anchorStroke="#3b82f6"
              anchorFill="#ffffff"
              anchorCornerRadius={2}
              boundBoxFunc={(oldBox, newBox) => {
                // Limit resize
                if (Math.abs(newBox.width) < 5 || Math.abs(newBox.height) < 5) {
                  return oldBox
                }
                return newBox
              }}
            />
          </Layer>
        </Stage>
      </div>

      {/* Zoom indicator */}
      <div className="absolute bottom-4 right-4 bg-dark-100/90 backdrop-blur px-3 py-1.5 rounded-lg text-xs text-gray-400 border border-gray-700">
        {canvas.width} × {canvas.height} px
      </div>
    </div>
  )
}

export default CanvasEditor
