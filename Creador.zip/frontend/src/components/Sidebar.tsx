import { useState } from 'react'
import {
  MousePointer2,
  Type,
  Square,
  Circle,
  Triangle,
  Hexagon,
  Star,
  Minus,
  ArrowRight,
  Image as ImageIcon,
  Hand,
  Upload,
  Shapes,
  Type as TypeIcon,
  Image as ImageIcon2,
  Settings
} from 'lucide-react'
import { useLogoStore } from '../store/logoStore'
import { createTextElement, createShapeElement, createImageElement, FONTS } from '../utils/canvasHelpers'
import type { ToolType } from '../types'
import toast from 'react-hot-toast'

const tools = [
  { id: 'select' as ToolType, icon: MousePointer2, label: 'Seleccionar', shortcut: 'V' },
  { id: 'hand' as ToolType, icon: Hand, label: 'Mover canvas', shortcut: 'H' },
]

const shapeTools = [
  { id: 'rectangle' as ToolType, icon: Square, label: 'Rectángulo' },
  { id: 'circle' as ToolType, icon: Circle, label: 'Círculo' },
  { id: 'triangle' as ToolType, icon: Triangle, label: 'Triángulo' },
  { id: 'polygon' as ToolType, icon: Hexagon, label: 'Polígono' },
  { id: 'star' as ToolType, icon: Star, label: 'Estrella' },
  { id: 'line' as ToolType, icon: Minus, label: 'Línea' },
  { id: 'arrow' as ToolType, icon: ArrowRight, label: 'Flecha' },
]

const Sidebar = () => {
  const { currentTool, setTool, addElement, canvas } = useLogoStore()
  const [activeTab, setActiveTab] = useState<'tools' | 'templates' | 'uploads'>('tools')
  const [showFontDropdown, setShowFontDropdown] = useState(false)

  const handleToolClick = (toolId: ToolType) => {
    if (toolId === 'text') {
      const element = createTextElement('Tu texto aquí', {
        x: canvas.width / 2 - 100,
        y: canvas.height / 2 - 25
      })
      addElement(element)
      toast.success('Texto agregado')
    } else if (shapeTools.some(s => s.id === toolId)) {
      const element = createShapeElement(toolId as any, {
        x: canvas.width / 2 - 50,
        y: canvas.height / 2 - 50
      })
      addElement(element)
      toast.success('Forma agregada')
    } else {
      setTool(toolId)
    }
  }

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    if (!file.type.startsWith('image/')) {
      toast.error('Solo se permiten archivos de imagen')
      return
    }

    const reader = new FileReader()
    reader.onload = (event) => {
      const src = event.target?.result as string
      const element = createImageElement(src, {
        x: canvas.width / 2 - 100,
        y: canvas.height / 2 - 100
      })
      addElement(element)
      toast.success('Imagen agregada')
    }
    reader.readAsDataURL(file)
    e.target.value = ''
  }

  return (
    <aside className="w-16 bg-dark-100 border-r border-gray-800 flex flex-col shrink-0">
      {/* Main Tools */}
      <div className="p-2 space-y-1">
        {tools.map((tool) => (
          <button
            key={tool.id}
            onClick={() => handleToolClick(tool.id)}
            className={`w-12 h-12 rounded-xl flex items-center justify-center transition-all ${
              currentTool === tool.id
                ? 'bg-primary-600 text-white'
                : 'text-gray-400 hover:bg-gray-800 hover:text-white'
            }`}
            title={`${tool.label} (${tool.shortcut})`}
          >
            <tool.icon className="w-5 h-5" />
          </button>
        ))}
      </div>

      <div className="h-px bg-gray-800 mx-2" />

      {/* Text Tool */}
      <div className="p-2 space-y-1">
        <button
          onClick={() => handleToolClick('text')}
          className="w-12 h-12 rounded-xl flex items-center justify-center text-gray-400 hover:bg-gray-800 hover:text-white transition-all"
          title="Agregar texto (T)"
        >
          <Type className="w-5 h-5" />
        </button>
      </div>

      <div className="h-px bg-gray-800 mx-2" />

      {/* Shape Tools */}
      <div className="p-2 space-y-1">
        {shapeTools.map((tool) => (
          <button
            key={tool.id}
            onClick={() => handleToolClick(tool.id)}
            className="w-12 h-12 rounded-xl flex items-center justify-center text-gray-400 hover:bg-gray-800 hover:text-white transition-all"
            title={tool.label}
          >
            <tool.icon className="w-5 h-5" />
          </button>
        ))}
      </div>

      <div className="h-px bg-gray-800 mx-2" />

      {/* Image Upload */}
      <div className="p-2 space-y-1">
        <label className="w-12 h-12 rounded-xl flex items-center justify-center text-gray-400 hover:bg-gray-800 hover:text-white transition-all cursor-pointer">
          <ImageIcon className="w-5 h-5" />
          <input
            type="file"
            accept="image/*"
            onChange={handleImageUpload}
            className="hidden"
          />
        </label>
      </div>

      <div className="flex-1" />

      {/* Bottom Actions */}
      <div className="p-2 space-y-1 border-t border-gray-800">
        <button
          onClick={() => useLogoStore.getState().setTemplatesModalOpen(true)}
          className="w-12 h-12 rounded-xl flex items-center justify-center text-gray-400 hover:bg-gray-800 hover:text-white transition-all"
          title="Templates"
        >
          <Shapes className="w-5 h-5" />
        </button>
      </div>
    </aside>
  )
}

export default Sidebar
