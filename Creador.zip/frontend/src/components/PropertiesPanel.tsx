import { useState } from 'react'
import { 
  Layers, 
  Move, 
  RotateCw, 
  Maximize2, 
  Type, 
  Palette, 
  Eye,
  EyeOff,
  Lock,
  Unlock,
  ArrowUp,
  ArrowDown,
  Trash2,
  Copy,
  AlignLeft,
  AlignCenter,
  AlignRight,
  AlignVerticalJustifyCenter,
  AlignVerticalJustifyStart,
  AlignVerticalJustifyEnd,
  Grid3X3,
  ChevronDown,
  ChevronRight
} from 'lucide-react'
import { useLogoStore } from '../store/logoStore'
import { HexColorPicker } from 'react-colorful'
import { FONTS, PRESET_COLORS } from '../utils/canvasHelpers'
import type { TextElement, ShapeElement } from '../types'
import toast from 'react-hot-toast'

const PropertiesPanel = () => {
  const {
    elements,
    selectedIds,
    canvas,
    updateElement,
    setCanvasSize,
    setCanvasBackground,
    bringToFront,
    sendToBack,
    bringForward,
    sendBackward,
    deleteElement,
    duplicateElement,
    alignElements,
    distributeElements
  } = useLogoStore()

  const [activeTab, setActiveTab] = useState<'properties' | 'layers' | 'canvas'>('properties')
  const [showColorPicker, setShowColorPicker] = useState<string | null>(null)
  const [expandedSections, setExpandedSections] = useState<string[]>(['transform', 'appearance'])

  const selectedElements = elements.filter(el => selectedIds.includes(el.id))
  const singleSelected = selectedElements.length === 1 ? selectedElements[0] : null

  const toggleSection = (section: string) => {
    setExpandedSections(prev => 
      prev.includes(section) 
        ? prev.filter(s => s !== section)
        : [...prev, section]
    )
  }

  const handleDelete = () => {
    selectedIds.forEach(id => deleteElement(id))
    toast.success('Elementos eliminados')
  }

  const handleDuplicate = () => {
    selectedIds.forEach(id => duplicateElement(id))
    toast.success('Elementos duplicados')
  }

  // Canvas settings section
  const renderCanvasSettings = () => (
    <div className="space-y-4">
      <div>
        <label className="text-xs text-gray-400 block mb-2">Dimensiones</label>
        <div className="flex gap-2">
          <div className="flex-1">
            <span className="text-xs text-gray-500">Ancho</span>
            <input
              type="number"
              value={canvas.width}
              onChange={(e) => setCanvasSize(Number(e.target.value), canvas.height)}
              className="input-field w-full text-sm"
            />
          </div>
          <div className="flex-1">
            <span className="text-xs text-gray-500">Alto</span>
            <input
              type="number"
              value={canvas.height}
              onChange={(e) => setCanvasSize(canvas.width, Number(e.target.value))}
              className="input-field w-full text-sm"
            />
          </div>
        </div>
      </div>

      <div>
        <label className="text-xs text-gray-400 block mb-2">Color de fondo</label>
        <div className="flex items-center gap-2">
          <input
            type="color"
            value={canvas.backgroundColor}
            onChange={(e) => setCanvasBackground(e.target.value)}
            className="w-10 h-10 rounded cursor-pointer"
          />
          <input
            type="text"
            value={canvas.backgroundColor}
            onChange={(e) => setCanvasBackground(e.target.value)}
            className="input-field flex-1 text-sm"
          />
        </div>
      </div>

      <div className="grid grid-cols-2 gap-2">
        <button
          onClick={() => setCanvasSize(800, 600)}
          className="btn-secondary text-xs"
        >
          800 × 600
        </button>
        <button
          onClick={() => setCanvasSize(1200, 630)}
          className="btn-secondary text-xs"
        >
          1200 × 630
        </button>
        <button
          onClick={() => setCanvasSize(1080, 1080)}
          className="btn-secondary text-xs"
        >
          1080 × 1080
        </button>
        <button
          onClick={() => setCanvasSize(1920, 1080)}
          className="btn-secondary text-xs"
        >
          1920 × 1080
        </button>
      </div>
    </div>
  )

  // Properties section for selected element
  const renderProperties = () => {
    if (!singleSelected) {
      return (
        <div className="text-center text-gray-500 py-8">
          <Layers className="w-12 h-12 mx-auto mb-2 opacity-50" />
          <p className="text-sm">Selecciona un elemento para editar sus propiedades</p>
          {selectedElements.length > 1 && (
            <div className="mt-4 space-y-2">
              <p className="text-xs text-gray-400">{selectedElements.length} elementos seleccionados</p>
              <div className="flex gap-1 justify-center">
                <button onClick={() => alignElements('left')} className="p-1 hover:bg-gray-800 rounded" title="Alinear izquierda">
                  <AlignLeft className="w-4 h-4" />
                </button>
                <button onClick={() => alignElements('center')} className="p-1 hover:bg-gray-800 rounded" title="Alinear centro">
                  <AlignCenter className="w-4 h-4" />
                </button>
                <button onClick={() => alignElements('right')} className="p-1 hover:bg-gray-800 rounded" title="Alinear derecha">
                  <AlignRight className="w-4 h-4" />
                </button>
                <button onClick={() => alignElements('top')} className="p-1 hover:bg-gray-800 rounded" title="Alinear arriba">
                  <AlignVerticalJustifyStart className="w-4 h-4" />
                </button>
                <button onClick={() => alignElements('middle')} className="p-1 hover:bg-gray-800 rounded" title="Alinear medio">
                  <AlignVerticalJustifyCenter className="w-4 h-4" />
                </button>
                <button onClick={() => alignElements('bottom')} className="p-1 hover:bg-gray-800 rounded" title="Alinear abajo">
                  <AlignVerticalJustifyEnd className="w-4 h-4" />
                </button>
              </div>
              <div className="flex gap-1 justify-center">
                <button onClick={() => distributeElements('horizontal')} className="btn-secondary text-xs px-2 py-1">
                  Distribuir H
                </button>
                <button onClick={() => distributeElements('vertical')} className="btn-secondary text-xs px-2 py-1">
                  Distribuir V
                </button>
              </div>
            </div>
          )}
        </div>
      )
    }

    return (
      <div className="space-y-4">
        {/* Quick Actions */}
        <div className="flex gap-2">
          <button
            onClick={handleDuplicate}
            className="flex-1 btn-secondary text-xs flex items-center justify-center gap-1"
          >
            <Copy className="w-3 h-3" />
            Duplicar
          </button>
          <button
            onClick={handleDelete}
            className="flex-1 btn-secondary text-xs flex items-center justify-center gap-1 text-red-400 hover:text-red-300"
          >
            <Trash2 className="w-3 h-3" />
            Eliminar
          </button>
        </div>

        {/* Transform Section */}
        <div>
          <button
            onClick={() => toggleSection('transform')}
            className="flex items-center justify-between w-full text-xs font-medium text-gray-300 hover:text-white mb-2"
          >
            <span className="flex items-center gap-2">
              <Move className="w-4 h-4" />
              Transformar
            </span>
            {expandedSections.includes('transform') ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
          </button>
          
          {expandedSections.includes('transform') && (
            <div className="space-y-3 pl-6">
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <span className="text-xs text-gray-500">X</span>
                  <input
                    type="number"
                    value={Math.round(singleSelected.position.x)}
                    onChange={(e) => updateElement(singleSelected.id, { 
                      position: { ...singleSelected.position, x: Number(e.target.value) } 
                    })}
                    className="input-field w-full text-sm"
                  />
                </div>
                <div>
                  <span className="text-xs text-gray-500">Y</span>
                  <input
                    type="number"
                    value={Math.round(singleSelected.position.y)}
                    onChange={(e) => updateElement(singleSelected.id, { 
                      position: { ...singleSelected.position, y: Number(e.target.value) } 
                    })}
                    className="input-field w-full text-sm"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <span className="text-xs text-gray-500">Ancho</span>
                  <input
                    type="number"
                    value={Math.round(singleSelected.size.width)}
                    onChange={(e) => updateElement(singleSelected.id, { 
                      size: { ...singleSelected.size, width: Number(e.target.value) } 
                    })}
                    className="input-field w-full text-sm"
                  />
                </div>
                <div>
                  <span className="text-xs text-gray-500">Alto</span>
                  <input
                    type="number"
                    value={Math.round(singleSelected.size.height)}
                    onChange={(e) => updateElement(singleSelected.id, { 
                      size: { ...singleSelected.size, height: Number(e.target.value) } 
                    })}
                    className="input-field w-full text-sm"
                  />
                </div>
              </div>

              <div>
                <span className="text-xs text-gray-500">Rotación</span>
                <input
                  type="range"
                  min="-180"
                  max="180"
                  value={singleSelected.rotation}
                  onChange={(e) => updateElement(singleSelected.id, { rotation: Number(e.target.value) })}
                  className="w-full"
                />
                <div className="flex justify-between text-xs text-gray-500">
                  <span>-180°</span>
                  <span>{Math.round(singleSelected.rotation)}°</span>
                  <span>180°</span>
                </div>
              </div>

              <div>
                <span className="text-xs text-gray-500">Opacidad</span>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.1"
                  value={singleSelected.opacity}
                  onChange={(e) => updateElement(singleSelected.id, { opacity: Number(e.target.value) })}
                  className="w-full"
                />
                <div className="text-center text-xs text-gray-500">
                  {Math.round(singleSelected.opacity * 100)}%
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Layer Order */}
        <div>
          <button
            onClick={() => toggleSection('layer')}
            className="flex items-center justify-between w-full text-xs font-medium text-gray-300 hover:text-white mb-2"
          >
            <span className="flex items-center gap-2">
              <Layers className="w-4 h-4" />
              Capa (Z-Index: {singleSelected.zIndex})
            </span>
            {expandedSections.includes('layer') ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
          </button>
          
          {expandedSections.includes('layer') && (
            <div className="flex gap-1 pl-6">
              <button
                onClick={() => sendToBack(singleSelected.id)}
                className="flex-1 p-1.5 hover:bg-gray-800 rounded text-xs"
                title="Enviar al fondo"
              >
                <AlignVerticalJustifyEnd className="w-4 h-4 mx-auto" />
              </button>
              <button
                onClick={() => sendBackward(singleSelected.id)}
                className="flex-1 p-1.5 hover:bg-gray-800 rounded text-xs"
                title="Enviar atrás"
              >
                <ArrowDown className="w-4 h-4 mx-auto" />
              </button>
              <button
                onClick={() => bringForward(singleSelected.id)}
                className="flex-1 p-1.5 hover:bg-gray-800 rounded text-xs"
                title="Traer adelante"
              >
                <ArrowUp className="w-4 h-4 mx-auto" />
              </button>
              <button
                onClick={() => bringToFront(singleSelected.id)}
                className="flex-1 p-1.5 hover:bg-gray-800 rounded text-xs"
                title="Traer al frente"
              >
                <AlignVerticalJustifyStart className="w-4 h-4 mx-auto" />
              </button>
            </div>
          )}
        </div>

        {/* Type-specific properties */}
        {singleSelected.type === 'text' && renderTextProperties(singleSelected as TextElement)}
        {(singleSelected.type === 'shape') && renderShapeProperties(singleSelected as ShapeElement)}
      </div>
    )
  }

  // Text element properties
  const renderTextProperties = (element: TextElement) => (
    <div>
      <button
        onClick={() => toggleSection('text')}
        className="flex items-center justify-between w-full text-xs font-medium text-gray-300 hover:text-white mb-2"
      >
        <span className="flex items-center gap-2">
          <Type className="w-4 h-4" />
          Texto
        </span>
        {expandedSections.includes('text') ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
      </button>
      
      {expandedSections.includes('text') && (
        <div className="space-y-3 pl-6">
          <div>
            <span className="text-xs text-gray-500">Contenido</span>
            <textarea
              value={element.text}
              onChange={(e) => updateElement(element.id, { text: e.target.value })}
              className="input-field w-full text-sm h-20 resize-none"
            />
          </div>

          <div>
            <span className="text-xs text-gray-500">Fuente</span>
            <select
              value={element.fontFamily}
              onChange={(e) => updateElement(element.id, { fontFamily: e.target.value })}
              className="input-field w-full text-sm"
            >
              {FONTS.map(font => (
                <option key={font} value={font}>{font}</option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div>
              <span className="text-xs text-gray-500">Tamaño</span>
              <input
                type="number"
                value={element.fontSize}
                onChange={(e) => updateElement(element.id, { fontSize: Number(e.target.value) })}
                className="input-field w-full text-sm"
              />
            </div>
            <div>
              <span className="text-xs text-gray-500">Peso</span>
              <select
                value={element.fontWeight}
                onChange={(e) => updateElement(element.id, { fontWeight: e.target.value })}
                className="input-field w-full text-sm"
              >
                <option value="300">Light</option>
                <option value="400">Normal</option>
                <option value="500">Medium</option>
                <option value="600">Semibold</option>
                <option value="700">Bold</option>
                <option value="800">Extra Bold</option>
              </select>
            </div>
          </div>

          <div className="flex gap-1">
            <button
              onClick={() => updateElement(element.id, { fontStyle: element.fontStyle === 'italic' ? 'normal' : 'italic' })}
              className={`flex-1 p-2 rounded text-xs ${element.fontStyle === 'italic' ? 'bg-primary-600' : 'bg-gray-800'}`}
            >
              I
            </button>
            <button
              onClick={() => updateElement(element.id, { textDecoration: element.textDecoration === 'underline' ? 'none' : 'underline' })}
              className={`flex-1 p-2 rounded text-xs ${element.textDecoration === 'underline' ? 'bg-primary-600' : 'bg-gray-800'}`}
            >
              U
            </button>
          </div>

          <div>
            <span className="text-xs text-gray-500">Color</span>
            <div className="flex items-center gap-2 mt-1">
              <input
                type="color"
                value={element.fill}
                onChange={(e) => updateElement(element.id, { fill: e.target.value })}
                className="w-8 h-8 rounded cursor-pointer"
              />
              <input
                type="text"
                value={element.fill}
                onChange={(e) => updateElement(element.id, { fill: e.target.value })}
                className="input-field flex-1 text-sm"
              />
            </div>
          </div>
        </div>
      )}
    </div>
  )

  // Shape element properties
  const renderShapeProperties = (element: ShapeElement) => (
    <div>
      <button
        onClick={() => toggleSection('appearance')}
        className="flex items-center justify-between w-full text-xs font-medium text-gray-300 hover:text-white mb-2"
      >
        <span className="flex items-center gap-2">
          <Palette className="w-4 h-4" />
          Apariencia
        </span>
        {expandedSections.includes('appearance') ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
      </button>
      
      {expandedSections.includes('appearance') && (
        <div className="space-y-3 pl-6">
          <div>
            <span className="text-xs text-gray-500">Relleno</span>
            <div className="flex items-center gap-2 mt-1">
              <input
                type="color"
                value={element.fill}
                onChange={(e) => updateElement(element.id, { fill: e.target.value })}
                className="w-8 h-8 rounded cursor-pointer"
              />
              <input
                type="text"
                value={element.fill}
                onChange={(e) => updateElement(element.id, { fill: e.target.value })}
                className="input-field flex-1 text-sm"
              />
            </div>
          </div>

          <div>
            <span className="text-xs text-gray-500">Borde</span>
            <div className="flex items-center gap-2 mt-1">
              <input
                type="color"
                value={element.stroke || '#000000'}
                onChange={(e) => updateElement(element.id, { stroke: e.target.value })}
                className="w-8 h-8 rounded cursor-pointer"
              />
              <input
                type="number"
                value={element.strokeWidth || 0}
                onChange={(e) => updateElement(element.id, { strokeWidth: Number(e.target.value) })}
                className="input-field w-20 text-sm"
                placeholder="Ancho"
              />
            </div>
          </div>

          {element.shapeType === 'rectangle' && (
            <div>
              <span className="text-xs text-gray-500">Radio de esquinas</span>
              <input
                type="range"
                min="0"
                max="100"
                value={element.cornerRadius || 0}
                onChange={(e) => updateElement(element.id, { cornerRadius: Number(e.target.value) })}
                className="w-full"
              />
            </div>
          )}
        </div>
      )}
    </div>
  )

  // Layers panel
  const renderLayers = () => (
    <div className="space-y-1">
      {[...elements]
        .sort((a, b) => b.zIndex - a.zIndex)
        .map(element => (
          <div
            key={element.id}
            onClick={() => useLogoStore.getState().selectElement(element.id)}
            className={`flex items-center gap-2 p-2 rounded-lg cursor-pointer text-sm ${
              selectedIds.includes(element.id) 
                ? 'bg-primary-600 text-white' 
                : 'hover:bg-gray-800 text-gray-300'
            }`}
          >
            <button
              onClick={(e) => {
                e.stopPropagation()
                updateElement(element.id, { visible: !element.visible })
              }}
              className="p-1 hover:bg-white/20 rounded"
            >
              {element.visible ? <Eye className="w-3 h-3" /> : <EyeOff className="w-3 h-3" />}
            </button>
            <button
              onClick={(e) => {
                e.stopPropagation()
                updateElement(element.id, { locked: !element.locked })
              }}
              className="p-1 hover:bg-white/20 rounded"
            >
              {element.locked ? <Lock className="w-3 h-3" /> : <Unlock className="w-3 h-3" />}
            </button>
            <span className="flex-1 truncate">{element.name || element.type}</span>
          </div>
        ))}
    </div>
  )

  return (
    <aside className="w-72 bg-dark-100 border-l border-gray-800 flex flex-col shrink-0 overflow-hidden">
      {/* Tabs */}
      <div className="flex border-b border-gray-800">
        <button
          onClick={() => setActiveTab('properties')}
          className={`flex-1 py-3 text-xs font-medium ${
            activeTab === 'properties' ? 'text-primary-500 border-b-2 border-primary-500' : 'text-gray-400'
          }`}
        >
          Propiedades
        </button>
        <button
          onClick={() => setActiveTab('layers')}
          className={`flex-1 py-3 text-xs font-medium ${
            activeTab === 'layers' ? 'text-primary-500 border-b-2 border-primary-500' : 'text-gray-400'
          }`}
        >
          Capas ({elements.length})
        </button>
        <button
          onClick={() => setActiveTab('canvas')}
          className={`flex-1 py-3 text-xs font-medium ${
            activeTab === 'canvas' ? 'text-primary-500 border-b-2 border-primary-500' : 'text-gray-400'
          }`}
        >
          Canvas
        </button>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto p-4 scrollbar-thin">
        {activeTab === 'properties' && renderProperties()}
        {activeTab === 'layers' && renderLayers()}
        {activeTab === 'canvas' && renderCanvasSettings()}
      </div>
    </aside>
  )
}

export default PropertiesPanel
