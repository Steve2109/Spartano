import { useState, useRef, useEffect } from 'react'
import { X, Download, FileImage, FileText, FileCode, Archive, Check } from 'lucide-react'
import { useLogoStore } from '../store/logoStore'
import { exportCanvas } from '../utils/exportUtils'
import type { ExportOptions } from '../types'
import toast from 'react-hot-toast'

const ExportModal = () => {
  const { isExportModalOpen, setExportModalOpen, elements, canvas } = useLogoStore()
  const [selectedFormat, setSelectedFormat] = useState<ExportOptions['format']>('png')
  const [isExporting, setIsExporting] = useState(false)
  const [scale, setScale] = useState(2)
  const [transparent, setTransparent] = useState(false)
  const [quality, setQuality] = useState(90)
  const canvasRef = useRef<HTMLDivElement>(null)

  // Clone canvas content for preview
  useEffect(() => {
    if (!isExportModalOpen || !canvasRef.current) return
    
    const container = canvasRef.current
    container.innerHTML = ''
    
    // Create preview canvas
    const previewDiv = document.createElement('div')
    previewDiv.style.width = `${canvas.width}px`
    previewDiv.style.height = `${canvas.height}px`
    previewDiv.style.backgroundColor = transparent ? 'transparent' : canvas.backgroundColor
    previewDiv.style.position = 'relative'
    previewDiv.style.transform = `scale(${Math.min(200 / canvas.width, 200 / canvas.height)})`
    previewDiv.style.transformOrigin = 'top left'
    
    // Add simplified preview of elements
    elements.sort((a, b) => a.zIndex - b.zIndex).forEach(el => {
      const elDiv = document.createElement('div')
      elDiv.style.position = 'absolute'
      elDiv.style.left = `${el.position.x}px`
      elDiv.style.top = `${el.position.y}px`
      elDiv.style.width = `${el.size.width}px`
      elDiv.style.height = `${el.size.height}px`
      elDiv.style.opacity = el.opacity.toString()
      elDiv.style.transform = `rotate(${el.rotation}deg)`
      
      if (el.type === 'text') {
        elDiv.innerText = el.text
        elDiv.style.fontFamily = el.fontFamily
        elDiv.style.fontSize = `${el.fontSize}px`
        elDiv.style.color = el.fill
        elDiv.style.fontWeight = el.fontWeight.toString()
        elDiv.style.fontStyle = el.fontStyle
      } else if (el.type === 'shape') {
        elDiv.style.backgroundColor = el.fill
        if (el.shapeType === 'circle') {
          elDiv.style.borderRadius = '50%'
        }
      } else if (el.type === 'image') {
        const img = document.createElement('img')
        img.src = el.src
        img.style.width = '100%'
        img.style.height = '100%'
        img.style.objectFit = 'cover'
        elDiv.appendChild(img)
      }
      
      previewDiv.appendChild(elDiv)
    })
    
    container.appendChild(previewDiv)
  }, [isExportModalOpen, elements, canvas, transparent])

  const handleExport = async () => {
    setIsExporting(true)
    
    try {
      // Find the actual canvas container in the DOM
      const canvasContainer = document.querySelector('.canvas-container') as HTMLElement
      
      if (!canvasContainer) {
        throw new Error('Canvas container not found')
      }

      const options: ExportOptions = {
        format: selectedFormat,
        scale: selectedFormat === 'png' ? scale : undefined,
        transparent: selectedFormat === 'png' ? transparent : false,
        quality: selectedFormat === 'png' ? quality / 100 : undefined,
        width: canvas.width,
        height: canvas.height
      }

      await exportCanvas(canvasContainer, elements, canvas, options)
      
      toast.success(`Exportado como ${selectedFormat.toUpperCase()}`)
      setExportModalOpen(false)
    } catch (error) {
      console.error('Export error:', error)
      toast.error('Error al exportar')
    } finally {
      setIsExporting(false)
    }
  }

  const exportOptions = [
    { id: 'png', label: 'PNG', icon: FileImage, desc: 'Imagen raster de alta calidad' },
    { id: 'svg', label: 'SVG', icon: FileCode, desc: 'Vector escalable sin pérdida' },
    { id: 'pdf', label: 'PDF', icon: FileText, desc: 'Documento para impresión' },
    { id: 'favicon', label: 'Favicon Package', icon: Archive, desc: 'Todos los formatos de favicon' }
  ]

  if (!isExportModalOpen) return null

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-dark-100 rounded-xl w-full max-w-2xl m-4 shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-gray-800">
          <h2 className="text-lg font-semibold">Exportar Logo</h2>
          <button
            onClick={() => setExportModalOpen(false)}
            className="p-2 hover:bg-gray-800 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex">
          {/* Left - Format Selection */}
          <div className="w-64 p-4 border-r border-gray-800">
            <h3 className="text-xs font-medium text-gray-400 uppercase mb-3">Formato</h3>
            <div className="space-y-2">
              {exportOptions.map((option) => (
                <button
                  key={option.id}
                  onClick={() => setSelectedFormat(option.id as ExportOptions['format'])}
                  className={`w-full p-3 rounded-lg flex items-center gap-3 transition-all ${
                    selectedFormat === option.id
                      ? 'bg-primary-600 text-white'
                      : 'bg-gray-800/50 hover:bg-gray-800 text-gray-300'
                  }`}
                >
                  <option.icon className="w-5 h-5" />
                  <div className="text-left">
                    <div className="font-medium text-sm">{option.label}</div>
                    <div className="text-xs opacity-70">{option.desc}</div>
                  </div>
                  {selectedFormat === option.id && (
                    <Check className="w-4 h-4 ml-auto" />
                  )}
                </button>
              ))}
            </div>
          </div>

          {/* Right - Options */}
          <div className="flex-1 p-4">
            <h3 className="text-xs font-medium text-gray-400 uppercase mb-3">Opciones</h3>
            
            {selectedFormat === 'png' && (
              <div className="space-y-4">
                <div>
                  <label className="text-sm text-gray-300 block mb-2">Escala</label>
                  <div className="flex items-center gap-3">
                    <input
                      type="range"
                      min="1"
                      max="4"
                      step="0.5"
                      value={scale}
                      onChange={(e) => setScale(Number(e.target.value))}
                      className="flex-1"
                    />
                    <span className="text-sm text-gray-400 w-12">{scale}x</span>
                  </div>
                  <p className="text-xs text-gray-500 mt-1">
                    {canvas.width * scale} × {canvas.height * scale} px
                  </p>
                </div>

                <div>
                  <label className="text-sm text-gray-300 block mb-2">Calidad</label>
                  <div className="flex items-center gap-3">
                    <input
                      type="range"
                      min="50"
                      max="100"
                      value={quality}
                      onChange={(e) => setQuality(Number(e.target.value))}
                      className="flex-1"
                    />
                    <span className="text-sm text-gray-400 w-12">{quality}%</span>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    id="transparent"
                    checked={transparent}
                    onChange={(e) => setTransparent(e.target.checked)}
                    className="w-4 h-4 rounded border-gray-600 bg-gray-700"
                  />
                  <label htmlFor="transparent" className="text-sm text-gray-300">
                    Fondo transparente
                  </label>
                </div>
              </div>
            )}

            {selectedFormat === 'svg' && (
              <div className="space-y-2 text-sm text-gray-400">
                <p>El formato SVG es ideal para:</p>
                <ul className="list-disc list-inside space-y-1 text-xs">
                  <li>Logos que necesitan escalarse a cualquier tamaño</li>
                  <li>Impresión de alta calidad</li>
                  <li>Uso en sitios web (ligero y escalable)</li>
                  <li>Editar en software vectorial (Illustrator, Inkscape)</li>
                </ul>
              </div>
            )}

            {selectedFormat === 'pdf' && (
              <div className="space-y-2 text-sm text-gray-400">
                <p>El formato PDF incluye:</p>
                <ul className="list-disc list-inside space-y-1 text-xs">
                  <li>Imagen embebida en alta resolución</li>
                  <li>Compatible con impresoras profesionales</li>
                  <li>Ideal para documentos corporativos</li>
                </ul>
              </div>
            )}

            {selectedFormat === 'favicon' && (
              <div className="space-y-2 text-sm text-gray-400">
                <p>El paquete incluye:</p>
                <ul className="list-disc list-inside space-y-1 text-xs">
                  <li>favicon.ico (16x16, 32x32, 48x48)</li>
                  <li>favicon-16x16.png</li>
                  <li>favicon-32x32.png</li>
                  <li>apple-touch-icon.png (180x180)</li>
                  <li>android-chrome-192x192.png</li>
                  <li>android-chrome-512x512.png</li>
                  <li>manifest.json</li>
                  <li>Código HTML listo para copiar</li>
                </ul>
              </div>
            )}

            {/* Preview */}
            <div className="mt-6">
              <label className="text-xs font-medium text-gray-400 uppercase mb-2 block">Vista previa</label>
              <div 
                ref={canvasRef}
                className="w-full h-48 bg-gray-800 rounded-lg flex items-center justify-center overflow-hidden"
                style={{ 
                  backgroundImage: transparent ? 'linear-gradient(45deg, #374151 25%, transparent 25%), linear-gradient(-45deg, #374151 25%, transparent 25%), linear-gradient(45deg, transparent 75%, #374151 75%), linear-gradient(-45deg, transparent 75%, #374151 75%)' : undefined,
                  backgroundSize: transparent ? '20px 20px' : undefined,
                  backgroundPosition: transparent ? '0 0, 0 10px, 10px -10px, -10px 0px' : undefined
                }}
              >
                <span className="text-gray-500 text-sm">Generando preview...</span>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="flex justify-end gap-2 p-4 border-t border-gray-800">
          <button
            onClick={() => setExportModalOpen(false)}
            className="btn-secondary"
          >
            Cancelar
          </button>
          <button
            onClick={handleExport}
            disabled={isExporting}
            className="btn-primary flex items-center gap-2"
          >
            {isExporting ? (
              <>
                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                Exportando...
              </>
            ) : (
              <>
                <Download className="w-4 h-4" />
                Descargar {selectedFormat.toUpperCase()}
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  )
}

export default ExportModal
