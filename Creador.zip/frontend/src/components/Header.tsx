import { useState } from 'react'
import { 
  Download, 
  Undo, 
  Redo, 
  ZoomIn, 
  ZoomOut, 
  Grid,
  FileJson,
  Palette,
  Keyboard,
  Layers
} from 'lucide-react'
import { useLogoStore } from '../store/logoStore'
import ExportModal from './ExportModal'
import TemplatesModal from './TemplatesModal'
import toast from 'react-hot-toast'

const Header = () => {
  const { 
    zoom, 
    setZoom, 
    canUndo, 
    canRedo, 
    undo, 
    redo, 
    saveToJSON, 
    loadFromJSON,
    canvas,
    elements,
    setCanvasBackground
  } = useLogoStore()

  const [showShortcuts, setShowShortcuts] = useState(false)

  const handleExport = () => {
    useLogoStore.getState().setExportModalOpen(true)
  }

  const handleSaveJSON = () => {
    const json = saveToJSON()
    const blob = new Blob([json], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `logo-${Date.now()}.json`
    a.click()
    URL.revokeObjectURL(url)
    toast.success('Proyecto guardado')
  }

  const handleLoadJSON = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    const reader = new FileReader()
    reader.onload = (event) => {
      try {
        loadFromJSON(event.target?.result as string)
        toast.success('Proyecto cargado')
      } catch (error) {
        toast.error('Error al cargar el archivo')
      }
    }
    reader.readAsText(file)
    e.target.value = ''
  }

  return (
    <>
      <header className="h-14 bg-dark-100 border-b border-gray-800 flex items-center justify-between px-4 shrink-0 z-50">
        {/* Left Section */}
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <Palette className="w-6 h-6 text-primary-500" />
            <span className="font-bold text-lg">LogoAI</span>
          </div>
          
          <div className="h-6 w-px bg-gray-700 mx-2" />
          
          {/* Undo/Redo */}
          <div className="flex items-center gap-1">
            <button
              onClick={undo}
              disabled={!canUndo}
              className="p-2 rounded-lg hover:bg-gray-800 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
              title="Deshacer (Ctrl+Z)"
            >
              <Undo className="w-4 h-4" />
            </button>
            <button
              onClick={redo}
              disabled={!canRedo}
              className="p-2 rounded-lg hover:bg-gray-800 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
              title="Rehacer (Ctrl+Y)"
            >
              <Redo className="w-4 h-4" />
            </button>
          </div>

          <div className="h-6 w-px bg-gray-700 mx-2" />

          {/* Zoom Controls */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => setZoom(zoom - 0.1)}
              className="p-2 rounded-lg hover:bg-gray-800 transition-colors"
              title="Alejar"
            >
              <ZoomOut className="w-4 h-4" />
            </button>
            <span className="text-sm text-gray-400 w-14 text-center">
              {Math.round(zoom * 100)}%
            </span>
            <button
              onClick={() => setZoom(zoom + 0.1)}
              className="p-2 rounded-lg hover:bg-gray-800 transition-colors"
              title="Acercar"
            >
              <ZoomIn className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Center - File Operations */}
        <div className="flex items-center gap-2">
          <label className="btn-secondary cursor-pointer flex items-center gap-2 text-sm">
            <FileJson className="w-4 h-4" />
            Abrir
            <input
              type="file"
              accept=".json"
              onChange={handleLoadJSON}
              className="hidden"
            />
          </label>
          <button
            onClick={handleSaveJSON}
            className="btn-secondary flex items-center gap-2 text-sm"
          >
            <FileJson className="w-4 h-4" />
            Guardar
          </button>
        </div>

        {/* Right Section */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowShortcuts(true)}
            className="p-2 rounded-lg hover:bg-gray-800 transition-colors"
            title="Atajos de teclado"
          >
            <Keyboard className="w-4 h-4" />
          </button>

          <div className="h-6 w-px bg-gray-700 mx-2" />

          <button
            onClick={handleExport}
            className="btn-primary flex items-center gap-2"
          >
            <Download className="w-4 h-4" />
            Exportar
          </button>
        </div>
      </header>

      <ExportModal />
      <TemplatesModal />

      {/* Shortcuts Modal */}
      {showShortcuts && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-dark-100 rounded-xl p-6 w-96 max-h-[80vh] overflow-auto">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold text-lg flex items-center gap-2">
                <Keyboard className="w-5 h-5" />
                Atajos de teclado
              </h3>
              <button
                onClick={() => setShowShortcuts(false)}
                className="p-1 hover:bg-gray-800 rounded-lg"
              >
                ×
              </button>
            </div>
            
            <div className="space-y-3 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-400">Deshacer</span>
                <kbd className="bg-gray-800 px-2 py-1 rounded">Ctrl+Z</kbd>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Rehacer</span>
                <kbd className="bg-gray-800 px-2 py-1 rounded">Ctrl+Y</kbd>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Seleccionar todo</span>
                <kbd className="bg-gray-800 px-2 py-1 rounded">Ctrl+A</kbd>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Eliminar</span>
                <kbd className="bg-gray-800 px-2 py-1 rounded">Delete</kbd>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Duplicar</span>
                <kbd className="bg-gray-800 px-2 py-1 rounded">Ctrl+D</kbd>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Traer al frente</span>
                <kbd className="bg-gray-800 px-2 py-1 rounded">Ctrl+]</kbd>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Enviar al fondo</span>
                <kbd className="bg-gray-800 px-2 py-1 rounded">Ctrl+[</kbd>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  )
}

export default Header
