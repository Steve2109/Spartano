import { useEffect } from 'react'
import { Toaster } from 'react-hot-toast'
import Header from './components/Header'
import Sidebar from './components/Sidebar'
import CanvasEditor from './components/CanvasEditor'
import PropertiesPanel from './components/PropertiesPanel'
import { useLogoStore } from './store/logoStore'

function App() {
  const { initializeStore } = useLogoStore()

  useEffect(() => {
    initializeStore()
  }, [initializeStore])

  return (
    <div className="flex flex-col h-screen bg-dark-200">
      <Toaster
        position="top-right"
        toastOptions={{
          duration: 3000,
          style: {
            background: '#1e293b',
            color: '#fff',
            border: '1px solid #374151',
          },
        }}
      />
      
      {/* Header */}
      <Header />
      
      {/* Main Content */}
      <div className="flex flex-1 overflow-hidden">
        {/* Left Sidebar - Tools */}
        <Sidebar />
        
        {/* Center - Canvas */}
        <main className="flex-1 relative overflow-hidden">
          <CanvasEditor />
        </main>
        
        {/* Right Panel - Properties */}
        <PropertiesPanel />
      </div>
    </div>
  )
}

export default App
