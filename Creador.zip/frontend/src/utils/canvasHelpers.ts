import type { CanvasElement, TextElement, ShapeElement, Position, Size } from '../types'

export const generateId = () => Math.random().toString(36).substring(2, 15)

export const createTextElement = (
  text: string = 'Texto',
  position: Position = { x: 100, y: 100 }
): Omit<TextElement, 'id' | 'zIndex'> => ({
  type: 'text',
  name: text,
  position,
  size: { width: 200, height: 50 },
  rotation: 0,
  scaleX: 1,
  scaleY: 1,
  opacity: 1,
  visible: true,
  locked: false,
  text,
  fontFamily: 'Poppins',
  fontSize: 24,
  fontWeight: 400,
  fontStyle: 'normal',
  textDecoration: 'none',
  fill: '#000000',
  align: 'left',
  lineHeight: 1.2,
  letterSpacing: 0
})

export const createShapeElement = (
  shapeType: ShapeElement['shapeType'],
  position: Position = { x: 100, y: 100 }
): Omit<ShapeElement, 'id' | 'zIndex'> => {
  const base = {
    type: 'shape' as const,
    name: shapeType,
    position,
    rotation: 0,
    scaleX: 1,
    scaleY: 1,
    opacity: 1,
    visible: true,
    locked: false,
    shapeType,
    fill: '#3b82f6',
    stroke: 'transparent',
    strokeWidth: 0
  }

  switch (shapeType) {
    case 'rectangle':
      return {
        ...base,
        size: { width: 150, height: 100 },
        cornerRadius: 0
      }
    case 'circle':
      return {
        ...base,
        size: { width: 100, height: 100 }
      }
    case 'triangle':
      return {
        ...base,
        size: { width: 100, height: 100 }
      }
    case 'polygon':
      return {
        ...base,
        size: { width: 100, height: 100 },
        sides: 6
      }
    case 'star':
      return {
        ...base,
        size: { width: 100, height: 100 },
        innerRadius: 30,
        outerRadius: 50
      }
    case 'line':
    case 'arrow':
      return {
        ...base,
        size: { width: 100, height: 2 },
        stroke: '#3b82f6',
        strokeWidth: 4
      }
    default:
      return {
        ...base,
        size: { width: 100, height: 100 }
      }
  }
}

export const createImageElement = (
  src: string,
  position: Position = { x: 100, y: 100 }
): Omit<CanvasElement, 'id' | 'zIndex'> => ({
  type: 'image',
  name: 'Imagen',
  position,
  size: { width: 200, height: 200 },
  rotation: 0,
  scaleX: 1,
  scaleY: 1,
  opacity: 1,
  visible: true,
  locked: false,
  src
})

export const getShapePoints = (shape: ShapeElement): number[] => {
  const { width, height } = shape.size
  const cx = width / 2
  const cy = height / 2

  switch (shape.shapeType) {
    case 'triangle':
      return [cx, 0, width, height, 0, height]
    
    case 'polygon':
      const sides = shape.sides || 6
      const radius = Math.min(width, height) / 2
      const points: number[] = []
      for (let i = 0; i < sides; i++) {
        const angle = (i * 2 * Math.PI) / sides - Math.PI / 2
        points.push(cx + radius * Math.cos(angle))
        points.push(cy + radius * Math.sin(angle))
      }
      return points
    
    case 'star':
      const outerR = shape.outerRadius || Math.min(width, height) / 2
      const innerR = shape.innerRadius || outerR / 2
      const numPoints = 5
      const starPoints: number[] = []
      for (let i = 0; i < numPoints * 2; i++) {
        const radius = i % 2 === 0 ? outerR : innerR
        const angle = (i * Math.PI) / numPoints - Math.PI / 2
        starPoints.push(cx + radius * Math.cos(angle))
        starPoints.push(cy + radius * Math.sin(angle))
      }
      return starPoints
    
    default:
      return []
  }
}

export const snapToGrid = (value: number, gridSize: number = 10): number => {
  return Math.round(value / gridSize) * gridSize
}

export const constrainToCanvas = (
  position: Position,
  size: Size,
  canvasWidth: number,
  canvasHeight: number
): Position => ({
  x: Math.max(0, Math.min(position.x, canvasWidth - size.width)),
  y: Math.max(0, Math.min(position.y, canvasHeight - size.height))
})

export const calculateBoundingBox = (elements: CanvasElement[]) => {
  if (elements.length === 0) {
    return { x: 0, y: 0, width: 0, height: 0 }
  }

  const minX = Math.min(...elements.map(el => el.position.x))
  const minY = Math.min(...elements.map(el => el.position.y))
  const maxX = Math.max(...elements.map(el => el.position.x + el.size.width))
  const maxY = Math.max(...elements.map(el => el.position.y + el.size.height))

  return {
    x: minX,
    y: minY,
    width: maxX - minX,
    height: maxY - minY
  }
}

export const rotatePoint = (
  x: number,
  y: number,
  cx: number,
  cy: number,
  angle: number
): { x: number; y: number } => {
  const radians = (angle * Math.PI) / 180
  const cos = Math.cos(radians)
  const sin = Math.sin(radians)
  
  return {
    x: cos * (x - cx) - sin * (y - cy) + cx,
    y: sin * (x - cx) + cos * (y - cy) + cy
  }
}

export const hexToRgba = (hex: string, alpha: number = 1): string => {
  const r = parseInt(hex.slice(1, 3), 16)
  const g = parseInt(hex.slice(3, 5), 16)
  const b = parseInt(hex.slice(5, 7), 16)
  return `rgba(${r}, ${g}, ${b}, ${alpha})`
}

export const getGoogleFontUrl = (fontFamily: string): string => {
  const encoded = encodeURIComponent(fontFamily)
  return `https://fonts.googleapis.com/css2?family=${encoded}:wght@300;400;500;600;700;800&display=swap`
}

export const loadGoogleFont = (fontFamily: string): Promise<void> => {
  return new Promise((resolve, reject) => {
    if (document.querySelector(`link[data-font="${fontFamily}"]`)) {
      resolve()
      return
    }

    const link = document.createElement('link')
    link.href = getGoogleFontUrl(fontFamily)
    link.rel = 'stylesheet'
    link.setAttribute('data-font', fontFamily)
    
    link.onload = () => resolve()
    link.onerror = () => reject(new Error(`Failed to load font: ${fontFamily}`))
    
    document.head.appendChild(link)
  })
}

export const FONTS = [
  'Inter',
  'Poppins',
  'Roboto',
  'Montserrat',
  'Lato',
  'Oswald',
  'Raleway',
  'Nunito',
  'Open Sans',
  'Playfair Display',
  'Merriweather',
  'Bebas Neue',
  'Pacifico',
  'Lobster',
  'Abril Fatface',
  'Fjalla One'
]

export const PRESET_COLORS = [
  '#000000', '#ffffff', '#ef4444', '#f97316', '#f59e0b', '#84cc16',
  '#22c55e', '#10b981', '#14b8a6', '#06b6d4', '#0ea5e9', '#3b82f6',
  '#6366f1', '#8b5cf6', '#a855f7', '#d946ef', '#ec4899', '#f43f5e',
  '#78716c', '#9ca3af', '#6b7280', '#4b5563', '#374151', '#1f2937'
]
