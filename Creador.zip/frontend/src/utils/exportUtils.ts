import html2canvas from 'html2canvas'
import { jsPDF } from 'jspdf'
import JSZip from 'jszip'
import { saveAs } from 'file-saver'
import type { ExportOptions, CanvasElement, FaviconSizes } from '../types'

export const exportToPNG = async (
  container: HTMLElement,
  options: ExportOptions
): Promise<Blob> => {
  const { width = 800, height = 600, scale = 1, transparent = false } = options
  
  const canvas = await html2canvas(container, {
    scale: scale,
    backgroundColor: transparent ? null : undefined,
    logging: false,
    useCORS: true,
    allowTaint: true,
    width: width,
    height: height
  })
  
  return new Promise((resolve, reject) => {
    canvas.toBlob((blob) => {
      if (blob) resolve(blob)
      else reject(new Error('Failed to create PNG blob'))
    }, 'image/png', 1.0)
  })
}

export const exportToSVG = (
  elements: CanvasElement[],
  canvasWidth: number,
  canvasHeight: number,
  backgroundColor?: string
): string => {
  const svgNS = 'http://www.w3.org/2000/svg'
  const svg = document.createElementNS(svgNS, 'svg')
  
  svg.setAttribute('width', canvasWidth.toString())
  svg.setAttribute('height', canvasHeight.toString())
  svg.setAttribute('viewBox', `0 0 ${canvasWidth} ${canvasHeight}`)
  svg.setAttribute('xmlns', svgNS)
  
  // Background
  if (backgroundColor && backgroundColor !== 'transparent') {
    const rect = document.createElementNS(svgNS, 'rect')
    rect.setAttribute('width', '100%')
    rect.setAttribute('height', '100%')
    rect.setAttribute('fill', backgroundColor)
    svg.appendChild(rect)
  }
  
  // Elements
  elements.sort((a, b) => a.zIndex - b.zIndex).forEach(element => {
    const g = document.createElementNS(svgNS, 'g')
    g.setAttribute('transform', 
      `translate(${element.position.x}, ${element.position.y}) ` +
      `rotate(${element.rotation}, ${element.size.width / 2}, ${element.size.height / 2}) ` +
      `scale(${element.scaleX}, ${element.scaleY})`
    )
    g.setAttribute('opacity', element.opacity.toString())
    
    if (element.type === 'text') {
      const text = document.createElementNS(svgNS, 'text')
      text.setAttribute('x', '0')
      text.setAttribute('y', element.fontSize.toString())
      text.setAttribute('font-family', element.fontFamily)
      text.setAttribute('font-size', element.fontSize.toString())
      text.setAttribute('font-weight', element.fontWeight.toString())
      text.setAttribute('font-style', element.fontStyle)
      text.setAttribute('text-decoration', element.textDecoration)
      text.setAttribute('fill', element.fill)
      text.textContent = element.text
      g.appendChild(text)
    } else if (element.type === 'shape') {
      let shape
      switch (element.shapeType) {
        case 'rectangle':
          shape = document.createElementNS(svgNS, 'rect')
          shape.setAttribute('width', element.size.width.toString())
          shape.setAttribute('height', element.size.height.toString())
          shape.setAttribute('rx', (element.cornerRadius || 0).toString())
          break
        case 'circle':
          shape = document.createElementNS(svgNS, 'circle')
          shape.setAttribute('cx', (element.size.width / 2).toString())
          shape.setAttribute('cy', (element.size.height / 2).toString())
          shape.setAttribute('r', (Math.min(element.size.width, element.size.height) / 2).toString())
          break
        case 'triangle':
          shape = document.createElementNS(svgNS, 'polygon')
          const h = element.size.height
          const w = element.size.width
          shape.setAttribute('points', `${w/2},0 ${w},${h} 0,${h}`)
          break
        default:
          shape = document.createElementNS(svgNS, 'rect')
          shape.setAttribute('width', element.size.width.toString())
          shape.setAttribute('height', element.size.height.toString())
      }
      
      shape.setAttribute('fill', element.fill)
      if (element.stroke && element.stroke !== 'transparent') {
        shape.setAttribute('stroke', element.stroke)
        shape.setAttribute('stroke-width', (element.strokeWidth || 1).toString())
      }
      g.appendChild(shape)
    } else if (element.type === 'image') {
      const image = document.createElementNS(svgNS, 'image')
      image.setAttribute('href', element.src)
      image.setAttribute('width', element.size.width.toString())
      image.setAttribute('height', element.size.height.toString())
      image.setAttribute('preserveAspectRatio', 'xMidYMid slice')
      g.appendChild(image)
    }
    
    svg.appendChild(g)
  })
  
  return new XMLSerializer().serializeToString(svg)
}

export const exportToPDF = async (
  container: HTMLElement,
  options: ExportOptions
): Promise<Blob> => {
  const { width = 800, height = 600 } = options
  
  const pdf = new jsPDF({
    orientation: width > height ? 'landscape' : 'portrait',
    unit: 'px',
    format: [width, height]
  })
  
  const canvas = await html2canvas(container, {
    scale: 2,
    backgroundColor: null,
    logging: false,
    useCORS: true,
    allowTaint: true
  })
  
  const imgData = canvas.toDataURL('image/png')
  pdf.addImage(imgData, 'PNG', 0, 0, width, height)
  
  return pdf.output('blob')
}

export const generateFaviconPackage = async (
  container: HTMLElement,
  logoName: string = 'logo'
): Promise<Blob> => {
  const zip = new JSZip()
  const sizes = {
    'favicon.ico': [16, 32, 48],
    'favicon-16x16.png': [16, 16],
    'favicon-32x32.png': [32, 32],
    'apple-touch-icon.png': [180, 180],
    'android-chrome-192x192.png': [192, 192],
    'android-chrome-512x512.png': [512, 512]
  }
  
  for (const [filename, dims] of Object.entries(sizes)) {
    if (filename === 'favicon.ico') {
      // Generate multi-resolution ICO
      const blobs: Blob[] = []
      for (const size of dims as number[]) {
        const blob = await exportToPNG(container, {
          format: 'png',
          width: size,
          height: size,
          scale: 1
        })
        blobs.push(blob)
      }
      // Convert PNGs to ICO format would require additional library
      // For now, just add the largest PNG
      zip.file(filename, blobs[blobs.length - 1])
    } else {
      const [w, h] = dims as [number, number]
      const blob = await exportToPNG(container, {
        format: 'png',
        width: w,
        height: h,
        scale: 1
      })
      zip.file(filename, blob)
    }
  }
  
  // Generate manifest.json
  const manifest = {
    name: logoName,
    short_name: logoName,
    icons: [
      {
        src: '/android-chrome-192x192.png',
        sizes: '192x192',
        type: 'image/png'
      },
      {
        src: '/android-chrome-512x512.png',
        sizes: '512x512',
        type: 'image/png'
      }
    ],
    theme_color: '#ffffff',
    background_color: '#ffffff',
    display: 'standalone'
  }
  
  zip.file('manifest.json', JSON.stringify(manifest, null, 2))
  
  // Generate HTML snippet
  const htmlSnippet = `<!-- Favicon -->
<link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png">
<link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png">
<link rel="manifest" href="/manifest.json">
<meta name="theme-color" content="#ffffff">`
  
  zip.file('favicon-snippet.html', htmlSnippet)
  
  return zip.generateAsync({ type: 'blob' })
}

export const downloadFile = (blob: Blob, filename: string) => {
  saveAs(blob, filename)
}

export const exportCanvas = async (
  container: HTMLElement | null,
  elements: CanvasElement[],
  canvasState: { width: number; height: number; backgroundColor: string },
  options: ExportOptions
): Promise<void> => {
  if (!container) return
  
  switch (options.format) {
    case 'png':
      const pngBlob = await exportToPNG(container, options)
      downloadFile(pngBlob, 'logo.png')
      break
      
    case 'svg':
      const svgString = exportToSVG(
        elements, 
        canvasState.width, 
        canvasState.height,
        canvasState.backgroundColor
      )
      const svgBlob = new Blob([svgString], { type: 'image/svg+xml' })
      downloadFile(svgBlob, 'logo.svg')
      break
      
    case 'pdf':
      const pdfBlob = await exportToPDF(container, options)
      downloadFile(pdfBlob, 'logo.pdf')
      break
      
    case 'favicon':
      const faviconZip = await generateFaviconPackage(container)
      downloadFile(faviconZip, 'favicon-package.zip')
      break
      
    default:
      throw new Error(`Unsupported format: ${options.format}`)
  }
}
