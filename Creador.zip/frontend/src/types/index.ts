export type ElementType = 'text' | 'shape' | 'image' | 'group'

export type ShapeType = 'rectangle' | 'circle' | 'triangle' | 'polygon' | 'star' | 'line' | 'arrow'

export interface Position {
  x: number
  y: number
}

export interface Size {
  width: number
  height: number
}

export interface BaseElement {
  id: string
  type: ElementType
  name: string
  position: Position
  size: Size
  rotation: number
  scaleX: number
  scaleY: number
  opacity: number
  visible: boolean
  locked: boolean
  zIndex: number
}

export interface TextElement extends BaseElement {
  type: 'text'
  text: string
  fontFamily: string
  fontSize: number
  fontWeight: number | string
  fontStyle: 'normal' | 'italic'
  textDecoration: 'none' | 'underline' | 'line-through'
  fill: string
  stroke?: string
  strokeWidth?: number
  align: 'left' | 'center' | 'right'
  lineHeight: number
  letterSpacing: number
}

export interface ShapeElement extends BaseElement {
  type: 'shape'
  shapeType: ShapeType
  fill: string
  stroke?: string
  strokeWidth?: number
  cornerRadius?: number
  sides?: number
  innerRadius?: number
  outerRadius?: number
}

export interface ImageElement extends BaseElement {
  type: 'image'
  src: string
  originalSrc?: string
  crop?: {
    x: number
    y: number
    width: number
    height: number
  }
  filters?: ImageFilters
}

export interface ImageFilters {
  brightness?: number
  contrast?: number
  saturation?: number
  blur?: number
  grayscale?: boolean
  sepia?: boolean
}

export interface GroupElement extends BaseElement {
  type: 'group'
  children: string[]
}

export type CanvasElement = TextElement | ShapeElement | ImageElement | GroupElement

export interface CanvasState {
  width: number
  height: number
  backgroundColor: string
  backgroundImage?: string
}

export interface ExportOptions {
  format: 'png' | 'svg' | 'pdf' | 'favicon'
  quality?: number
  scale?: number
  transparent?: boolean
  width?: number
  height?: number
}

export interface FaviconSizes {
  'favicon.ico': number[]
  'favicon-16x16.png': [16, 16]
  'favicon-32x32.png': [32, 32]
  'apple-touch-icon.png': [180, 180]
  'android-chrome-192x192.png': [192, 192]
  'android-chrome-512x512.png': [512, 512]
}

export type ToolType = 
  | 'select' 
  | 'text' 
  | 'rectangle' 
  | 'circle' 
  | 'triangle' 
  | 'polygon'
  | 'star'
  | 'line'
  | 'arrow'
  | 'image'
  | 'hand'

export type Alignment = 'left' | 'center' | 'right' | 'top' | 'middle' | 'bottom'

export type LayerAction = 'bringToFront' | 'bringForward' | 'sendBackward' | 'sendToBack'

export interface HistoryState {
  elements: CanvasElement[]
  canvas: CanvasState
  timestamp: number
}

export interface Template {
  id: string
  name: string
  thumbnail: string
  category: string
  elements: CanvasElement[]
  canvas: CanvasState
}
