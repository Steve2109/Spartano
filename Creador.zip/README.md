# LogoAI - Generador de Logotipos Profesional

Aplicación moderna tipo Canva para crear logotipos con exportación en múltiples formatos.

## ✨ Características

### Editor de Diseño (Tipo Canva)
- **Canvas interactivo** con Konva.js
- **Múltiples herramientas**: Texto, formas (rectángulo, círculo, triángulo, polígono, estrella, línea, flecha)
- **Sistema de capas** completo
- **Alineación y distribución** de elementos
- **Panel de propiedades** en tiempo real
- **Templates predefinidos**
- **Zoom y navegación**
- **Deshacer/Rehacer** con historial

### Tipos de Elementos
- **Texto**: Fuentes de Google Fonts, estilos, colores, espaciado
- **Formas**: Rectángulos, círculos, triángulos, polígonos, estrellas
- **Imágenes**: Upload y manipulación
- **Grupos**: Agrupar/desagrupar elementos

### Exportación
- **PNG**: Raster de alta calidad (con opción de fondo transparente)
- **SVG**: Vector escalable
- **PDF**: Documento para impresión
- **Favicon Package**: Todos los tamaños necesarios + manifest.json

### Seguridad Implementada
- ✅ Rate limiting en todas las rutas API
- ✅ Sanitización de todas las entradas (XSS prevention)
- ✅ Protección HTTP Parameter Pollution
- ✅ Headers de seguridad (Helmet)
- ✅ CORS configurado
- ✅ Validación de archivos subidos
- ✅ Sanitización de SVG
- ✅ API Keys en variables de entorno
- ✅ Logging completo

## 🚀 Tecnologías

### Frontend
- React 18 + TypeScript
- Konva.js (Canvas 2D)
- Zustand (State Management)
- TailwindCSS
- html2canvas + jsPDF + jszip
- Lucide React (Iconos)

### Backend
- Node.js 20 + Express
- TypeScript
- Sharp (Procesamiento de imágenes)
- SVGO (Optimización SVG)
- Multer (Upload de archivos)
- Winston (Logging)
- express-rate-limit
- helmet, cors, hpp

## 📦 Instalación

### Requisitos
- Node.js 20+
- npm 10+

### Instalación Local

```bash
# 1. Clonar repositorio
git clone https://github.com/tu-repo/logoai.git
cd logoai

# 2. Instalar dependencias
npm run install:all

# 3. Configurar variables de entorno
cp .env.example .env
# Editar .env según tus necesidades

# 4. Iniciar en modo desarrollo
npm run dev

# 5. O construir para producción
npm run build
npm start
```

La aplicación estará disponible en:
- Frontend: http://localhost:32299
- API: http://localhost:32299/api

## 🌐 Despliegue

Ver guías completas en `deployments-docs/`:

- **[Nginx](deployments-docs/nginx/README.md)** - Reverse proxy con Nginx
- **[Apache](deployments-docs/apache/README.md)** - Despliegue con Apache
- **[Docker](deployments-docs/docker/README.md)** - Containerización básica
- **[Full Docker Stack](deployments-docs/full-docker/README.md)** - Stack completo con Docker Compose

### Resumen Rápido - Docker

```bash
# Construir y ejecutar
docker compose up -d

# La app estará en http://localhost:32299
```

### Resumen Rápido - PM2 (Servidor VPS)

```bash
# Instalar PM2
sudo npm install -g pm2

# Configurar la app
npm run install:all
npm run build

# Iniciar con PM2
pm2 start ecosystem.config.js
pm2 save
pm2 startup
```

## 🎨 Uso

### Crear un Logo
1. Selecciona un **template** o empieza en blanco
2. Agrega **texto**, **formas** o **imágenes**
3. Edita propiedades en el panel derecho
4. Usa el panel de capas para organizar elementos
5. Exporta en el formato deseado

### Atajos de Teclado
| Atajo | Acción |
|-------|--------|
| `Ctrl+Z` | Deshacer |
| `Ctrl+Y` | Rehacer |
| `Ctrl+A` | Seleccionar todo |
| `Ctrl+D` | Duplicar |
| `Delete` | Eliminar selección |
| `Ctrl+]` | Traer al frente |
| `Ctrl+[` | Enviar al fondo |

## 🔧 Configuración

### Variables de Entorno
```env
# Servidor
NODE_ENV=production
PORT=32299
HOST=0.0.0.0

# Seguridad
JWT_SECRET=tu_secreto_seguro
RATE_LIMIT_WINDOW_MS=900000
RATE_LIMIT_MAX_REQUESTS=100

# Base de datos (opcional)
DATABASE_URL=postgresql://user:pass@localhost:5432/logoai

# Storage (opcional)
AWS_ACCESS_KEY_ID=
AWS_SECRET_ACCESS_KEY=
CLOUDINARY_CLOUD_NAME=
```

## 🛡️ Seguridad

Esta aplicación implementa:
- Rate limiting en todas las rutas API
- Sanitización de entradas (XSS, SQL injection)
- Validación estricta de archivos
- Headers de seguridad
- CORS configurado
- Logging de actividad

## 📋 API Endpoints

### Health
- `GET /api/health` - Verificar estado
- `GET /api/health/details` - Información detallada

### Export
- `POST /api/export/raster` - Exportar a PNG/JPEG/WebP
- `POST /api/export/optimize-svg` - Optimizar SVG
- `POST /api/export/favicon` - Generar favicon package

### Upload
- `POST /api/upload/image` - Subir una imagen
- `POST /api/upload/images` - Subir múltiples imágenes
- `POST /api/upload/validate` - Validar imagen

## 📁 Estructura del Proyecto

```
logoai/
├── frontend/               # React + Vite
│   ├── src/
│   │   ├── components/     # Componentes React
│   │   ├── store/          # Estado (Zustand)
│   │   ├── utils/          # Utilidades
│   │   └── types/          # TypeScript types
│   └── package.json
├── backend/                # Node.js + Express
│   ├── src/
│   │   ├── routes/         # API routes
│   │   ├── middleware/     # Middleware
│   │   └── utils/          # Utilidades
│   └── package.json
├── deployments-docs/        # Documentación despliegue
│   ├── nginx/
│   ├── apache/
│   ├── docker/
│   └── full-docker/
├── docker-compose.yml
├── Dockerfile
└── ecosystem.config.js      # PM2 config
```

## 🤝 Contribuir

1. Fork el repositorio
2. Crear rama feature (`git checkout -b feature/nueva-funcionalidad`)
3. Commit cambios (`git commit -am 'Agregar nueva funcionalidad'`)
4. Push a la rama (`git push origin feature/nueva-funcionalidad`)
5. Crear Pull Request

## 📄 Licencia

MIT License - Ver [LICENSE](LICENSE)

## 👨‍💻 Autor

**T&M Technology Ec**
- Website: https://tymtechnology.shop
- Email: info@tymtechnology.shop

---

<p align="center">Hecho con ❤️ para diseñadores y desarrolladores</p>
