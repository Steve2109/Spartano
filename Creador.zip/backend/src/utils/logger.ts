import winston from 'winston'
import path from 'path'

const { combine, timestamp, json, errors, printf, colorize } = winston.format

// Custom format for console output
const consoleFormat = printf(({ level, message, timestamp, stack }) => {
  const msg = `${timestamp} [${level}]: ${message}`
  return stack ? `${msg}\n${stack}` : msg
})

// Determine log level from environment
const logLevel = process.env.LOG_LEVEL || 'info'
const isDev = process.env.NODE_ENV === 'development'

// Create logs directory if it doesn't exist
const logsDir = process.env.LOG_FILE 
  ? path.dirname(process.env.LOG_FILE)
  : path.join(process.cwd(), 'logs')

// Winston logger configuration
export const logger = winston.createLogger({
  level: logLevel,
  defaultMeta: {
    service: 'logoai-backend',
    environment: process.env.NODE_ENV || 'development'
  },
  format: combine(
    timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }),
    errors({ stack: true })
  ),
  transports: [
    // Console transport (colored in dev)
    new winston.transports.Console({
      format: isDev 
        ? combine(colorize(), timestamp(), consoleFormat)
        : combine(timestamp(), json())
    })
  ]
})

// Add file transport in production
if (!isDev && process.env.LOG_FILE) {
  logger.add(new winston.transports.File({
    filename: process.env.LOG_FILE,
    format: combine(timestamp(), json()),
    maxsize: 5242880, // 5MB
    maxFiles: 5
  }))
}

// Stream for Morgan HTTP logging
export const morganStream = {
  write: (message: string) => {
    logger.info(message.trim())
  }
}
