import { Router } from 'express'
import multer from 'multer'
import path from 'path'
import { v4 as uuidv4 } from 'uuid'
import sharp from 'sharp'
import { asyncHandler, AppError } from '../middleware/errorHandler.js'
import { sanitizeFileName } from '../middleware/sanitize.js'
import { logger } from '../utils/logger.js'

const router = Router()

// Configure multer storage
const storage = multer.memoryStorage()

// File filter
const fileFilter = (req: any, file: any, cb: any) => {
  const allowedMimes = [
    'image/jpeg',
    'image/png',
    'image/gif',
    'image/webp',
    'image/svg+xml'
  ]
  
  if (allowedMimes.includes(file.mimetype)) {
    cb(null, true)
  } else {
    cb(new AppError(
      `Invalid file type. Allowed: ${allowedMimes.join(', ')}`,
      400,
      'INVALID_FILE_TYPE'
    ), false)
  }
}

// Configure multer
const upload = multer({
  storage,
  fileFilter,
  limits: {
    fileSize: parseInt(process.env.MAX_FILE_SIZE || '10485760'), // 10MB
    files: parseInt(process.env.MAX_FILES_PER_UPLOAD || '5')
  }
})

// Upload single image
router.post('/image', upload.single('image'), asyncHandler(async (req, res) => {
  if (!req.file) {
    throw new AppError('No image file provided', 400, 'NO_FILE')
  }
  
  try {
    const { buffer, originalname, mimetype, size } = req.file
    
    logger.info(`Processing upload: ${originalname} (${size} bytes)`)
    
    // Generate safe filename
    const safeName = sanitizeFileName(originalname)
    const fileId = uuidv4()
    const ext = path.extname(safeName) || '.png'
    const filename = `${fileId}${ext}`
    
    // Process image with Sharp
    let processedBuffer = buffer
    let metadata: any = {}
    
    if (mimetype !== 'image/svg+xml') {
      // Get metadata
      const sharpInstance = sharp(buffer)
      metadata = await sharpInstance.metadata()
      
      // Optimize image
      processedBuffer = await sharpInstance
        .resize(2048, 2048, { // Max dimensions
          fit: 'inside',
          withoutEnlargement: true
        })
        .png({
          quality: 90,
          compressionLevel: 9
        })
        .toBuffer()
    }
    
    // Convert to data URI for immediate use
    const base64 = processedBuffer.toString('base64')
    const dataUri = `data:image/png;base64,${base64}`
    
    res.json({
      success: true,
      data: {
        id: fileId,
        filename,
        originalName: safeName,
        mimeType: 'image/png',
        size: processedBuffer.length,
        width: metadata.width || null,
        height: metadata.height || null,
        dataUri,
        url: `/uploads/${filename}` // For future file serving
      }
    })
    
  } catch (error: any) {
    logger.error('Image processing error:', error)
    throw new AppError('Image processing failed', 500, 'PROCESS_ERROR')
  }
}))

// Upload multiple images
router.post('/images', upload.array('images', 5), asyncHandler(async (req, res) => {
  if (!req.files || req.files.length === 0) {
    throw new AppError('No image files provided', 400, 'NO_FILES')
  }
  
  const files = req.files as Express.Multer.File[]
  
  const processed = await Promise.all(
    files.map(async (file) => {
      try {
        const { buffer, originalname, mimetype } = file
        
        const safeName = sanitizeFileName(originalname)
        const fileId = uuidv4()
        
        let processedBuffer = buffer
        let metadata: any = {}
        
        if (mimetype !== 'image/svg+xml') {
          const sharpInstance = sharp(buffer)
          metadata = await sharpInstance.metadata()
          
          processedBuffer = await sharpInstance
            .resize(2048, 2048, {
              fit: 'inside',
              withoutEnlargement: true
            })
            .png({ quality: 90 })
            .toBuffer()
        }
        
        const base64 = processedBuffer.toString('base64')
        
        return {
          id: fileId,
          originalName: safeName,
          success: true,
          width: metadata.width || null,
          height: metadata.height || null,
          dataUri: `data:image/png;base64,${base64}`,
          size: processedBuffer.length
        }
        
      } catch (error) {
        logger.error(`Failed to process ${file.originalname}:`, error)
        return {
          originalName: file.originalname,
          success: false,
          error: 'Processing failed'
        }
      }
    })
  )
  
  const successful = processed.filter(p => p.success)
  const failed = processed.filter(p => !p.success)
  
  res.json({
    success: failed.length === 0,
    data: {
      uploaded: successful,
      failed,
      total: files.length,
      successful: successful.length
    }
  })
}))

// Validate image without uploading
router.post('/validate', upload.single('image'), asyncHandler(async (req, res) => {
  if (!req.file) {
    throw new AppError('No image file provided', 400, 'NO_FILE')
  }
  
  try {
    const { buffer, mimetype } = req.file
    
    let isValid = true
    let metadata: any = {}
    let error = null
    
    // Validate with Sharp
    if (mimetype !== 'image/svg+xml') {
      try {
        const sharpInstance = sharp(buffer)
        metadata = await sharpInstance.metadata()
        
        // Check if image is corrupt
        await sharpInstance.stats()
        
      } catch (err) {
        isValid = false
        error = 'Invalid or corrupt image'
      }
    }
    
    res.json({
      success: true,
      data: {
        valid: isValid,
        format: metadata.format || mimetype.split('/')[1],
        width: metadata.width,
        height: metadata.height,
        hasAlpha: metadata.hasAlpha,
        error
      }
    })
    
  } catch (error: any) {
    logger.error('Validation error:', error)
    throw new AppError('Validation failed', 500, 'VALIDATION_ERROR')
  }
}))

// Error handler for multer
router.use((error: any, req: any, res: any, next: any) => {
  if (error instanceof multer.MulterError) {
    if (error.code === 'LIMIT_FILE_SIZE') {
      return res.status(400).json({
        success: false,
        error: 'File too large. Max size: 10MB'
      })
    }
    if (error.code === 'LIMIT_FILE_COUNT') {
      return res.status(400).json({
        success: false,
        error: 'Too many files. Max: 5 files'
      })
    }
  }
  next(error)
})

export default router
