import { Router } from 'express'
import sharp from 'sharp'
import { optimize } from 'svgo'
import { asyncHandler, AppError } from '../middleware/errorHandler.js'
import { logger } from '../utils/logger.js'

const router = Router()

// Validate export request
const validateExportRequest = (data: any) => {
  if (!data || typeof data !== 'object') {
    throw new AppError('Invalid export data', 400, 'INVALID_DATA')
  }
  
  const { format, width, height, svg } = data
  
  // Validate format
  const validFormats = ['png', 'jpeg', 'webp', 'svg', 'pdf']
  if (!validFormats.includes(format)) {
    throw new AppError(`Invalid format. Must be one of: ${validFormats.join(', ')}`, 400, 'INVALID_FORMAT')
  }
  
  // Validate dimensions
  if (width && (typeof width !== 'number' || width < 1 || width > 10000)) {
    throw new AppError('Invalid width', 400, 'INVALID_DIMENSIONS')
  }
  
  if (height && (typeof height !== 'number' || height < 1 || height > 10000)) {
    throw new AppError('Invalid height', 400, 'INVALID_DIMENSIONS')
  }
  
  // Validate SVG content
  if (!svg || typeof svg !== 'string') {
    throw new AppError('SVG content is required', 400, 'MISSING_SVG')
  }
  
  // Check for potential malicious content in SVG
  const forbiddenPatterns = [
    /<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi,
    /javascript:/gi,
    /on\w+\s*=/gi,
    /xlink:href\s*=/gi
  ]
  
  for (const pattern of forbiddenPatterns) {
    if (pattern.test(svg)) {
      throw new AppError('SVG contains potentially unsafe content', 400, 'UNSAFE_SVG')
    }
  }
  
  return true
}

// Export SVG to raster format
router.post('/raster', asyncHandler(async (req, res) => {
  const startTime = Date.now()
  
  try {
    // Validate request
    validateExportRequest(req.body)
    
    const { format, width, height, svg, quality = 90, background = 'transparent' } = req.body
    
    logger.info(`Starting raster export: ${format} ${width}x${height}`)
    
    // Convert SVG to buffer
    const svgBuffer = Buffer.from(svg, 'utf-8')
    
    // Use Sharp for rasterization
    let sharpInstance = sharp(svgBuffer, {
      density: 300 // High DPI for quality
    })
    
    // Resize if dimensions provided
    if (width && height) {
      sharpInstance = sharpInstance.resize(width, height, {
        fit: 'contain',
        background: background === 'transparent' ? { r: 0, g: 0, b: 0, alpha: 0 } : background
      })
    }
    
    // Set output format and quality
    switch (format) {
      case 'png':
        sharpInstance = sharpInstance.png({
          quality: Math.min(quality, 100),
          compressionLevel: 9
        })
        break
        
      case 'jpeg':
      case 'jpg':
        sharpInstance = sharpInstance.jpeg({
          quality: Math.min(quality, 100),
          mozjpeg: true
        })
        break
        
      case 'webp':
        sharpInstance = sharpInstance.webp({
          quality: Math.min(quality, 100)
        })
        break
        
      default:
        throw new AppError('Unsupported format', 400, 'UNSUPPORTED_FORMAT')
    }
    
    // Generate output
    const outputBuffer = await sharpInstance.toBuffer()
    
    // Set response headers
    res.set({
      'Content-Type': `image/${format}`,
      'Content-Length': outputBuffer.length,
      'Cache-Control': 'public, max-age=31536000',
      'X-Export-Time': `${Date.now() - startTime}ms`
    })
    
    logger.info(`Export completed in ${Date.now() - startTime}ms`)
    
    res.send(outputBuffer)
    
  } catch (error: any) {
    logger.error('Export error:', error)
    
    if (error instanceof AppError) {
      throw error
    }
    
    throw new AppError(
      error.message || 'Export failed',
      500,
      'EXPORT_ERROR'
    )
  }
}))

// Optimize SVG
router.post('/optimize-svg', asyncHandler(async (req, res) => {
  try {
    const { svg, multipass = true } = req.body
    
    if (!svg || typeof svg !== 'string') {
      throw new AppError('SVG content is required', 400, 'MISSING_SVG')
    }
    
    // Basic security check
    const forbiddenTags = ['script', 'iframe', 'object', 'embed']
    for (const tag of forbiddenTags) {
      if (svg.toLowerCase().includes(`<${tag}`)) {
        throw new AppError(`SVG contains forbidden element: ${tag}`, 400, 'UNSAFE_SVG')
      }
    }
    
    // Optimize with SVGO
    const result = optimize(svg, {
      multipass,
      plugins: [
        'preset-default',
        {
          name: 'removeViewBox',
          active: false // Keep viewBox for scaling
        },
        {
          name: 'removeDimensions',
          active: false // Keep dimensions
        }
      ]
    })
    
    res.json({
      success: true,
      data: {
        original: svg.length,
        optimized: result.data.length,
        savings: `${((1 - result.data.length / svg.length) * 100).toFixed(1)}%`,
        svg: result.data
      }
    })
    
  } catch (error: any) {
    logger.error('SVG optimization error:', error)
    
    if (error instanceof AppError) {
      throw error
    }
    
    throw new AppError('SVG optimization failed', 500, 'OPTIMIZE_ERROR')
  }
}))

// Generate favicon package
router.post('/favicon', asyncHandler(async (req, res) => {
  try {
    const { svg } = req.body
    
    if (!svg || typeof svg !== 'string') {
      throw new AppError('SVG content is required', 400, 'MISSING_SVG')
    }
    
    const svgBuffer = Buffer.from(svg, 'utf-8')
    
    // Generate favicon sizes
    const sizes = [16, 32, 48]
    const faviconBuffers = await Promise.all(
      sizes.map(async (size) => {
        return sharp(svgBuffer, { density: 300 })
          .resize(size, size)
          .png()
          .toBuffer()
      })
    )
    
    // For now, return the 32x32 as the main favicon
    // Full ICO generation would require additional libraries
    res.set({
      'Content-Type': 'image/png',
      'Content-Disposition': 'attachment; filename="favicon.png"'
    })
    
    res.send(faviconBuffers[1]) // 32x32
    
  } catch (error: any) {
    logger.error('Favicon generation error:', error)
    
    if (error instanceof AppError) {
      throw error
    }
    
    throw new AppError('Favicon generation failed', 500, 'FAVICON_ERROR')
  }
}))

export default router
