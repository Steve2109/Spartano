import type { Request, Response, NextFunction } from 'express'
import { logger } from '../utils/logger.js'

export interface CustomError extends Error {
  statusCode?: number
  code?: string
  isOperational?: boolean
}

export const errorHandler = (
  err: CustomError,
  req: Request,
  res: Response,
  _next: NextFunction
) => {
  // Default error values
  const statusCode = err.statusCode || 500
  const message = err.message || 'Internal Server Error'
  
  // Log error
  logger.error({
    error: err.message,
    stack: err.stack,
    url: req.url,
    method: req.method,
    ip: req.ip,
    statusCode
  })

  // Don't leak error details in production
  const isDev = process.env.NODE_ENV === 'development'
  
  res.status(statusCode).json({
    success: false,
    error: message,
    ...(isDev && { stack: err.stack }),
    ...(err.code && { code: err.code })
  })
}

// Async handler wrapper
export const asyncHandler = (fn: Function) => {
  return (req: Request, res: Response, next: NextFunction) => {
    Promise.resolve(fn(req, res, next)).catch(next)
  }
}

// Custom error class
export class AppError extends Error {
  statusCode: number
  code: string
  isOperational: boolean

  constructor(message: string, statusCode: number = 500, code: string = 'INTERNAL_ERROR') {
    super(message)
    this.statusCode = statusCode
    this.code = code
    this.isOperational = true
    Error.captureStackTrace(this, this.constructor)
  }
}
