import type { Request, Response, NextFunction } from 'express'
import sanitizeHtml from 'sanitize-html'
import { logger } from '../utils/logger.js'

// Sanitize string input
const sanitizeString = (str: string): string => {
  return sanitizeHtml(str, {
    allowedTags: [],
    allowedAttributes: {}
  }).trim()
}

// Recursively sanitize object
const sanitizeObject = (obj: any): any => {
  if (typeof obj === 'string') {
    return sanitizeString(obj)
  }
  
  if (Array.isArray(obj)) {
    return obj.map(sanitizeObject)
  }
  
  if (obj && typeof obj === 'object') {
    const sanitized: any = {}
    for (const [key, value] of Object.entries(obj)) {
      // Sanitize keys too to prevent prototype pollution
      const sanitizedKey = sanitizeString(key).replace(/[^a-zA-Z0-9_]/g, '')
      sanitized[sanitizedKey] = sanitizeObject(value)
    }
    return sanitized
  }
  
  return obj
}

// XSS Prevention middleware
export const sanitizeInput = (req: Request, res: Response, next: NextFunction) => {
  try {
    // Sanitize body
    if (req.body && typeof req.body === 'object') {
      req.body = sanitizeObject(req.body)
    }
    
    // Sanitize query parameters
    if (req.query && typeof req.query === 'object') {
      req.query = sanitizeObject(req.query)
    }
    
    // Sanitize params
    if (req.params && typeof req.params === 'object') {
      req.params = sanitizeObject(req.params)
    }
    
    next()
  } catch (error) {
    logger.error('Sanitization error:', error)
    res.status(400).json({
      success: false,
      error: 'Invalid input data'
    })
  }
}

// SQL Injection prevention helper
export const preventSqlInjection = (input: string): boolean => {
  const sqlPattern = /(\b(SELECT|INSERT|UPDATE|DELETE|DROP|CREATE|ALTER|EXEC|UNION|SCRIPT|JAVA|--|\\*|;|\\x00)\b)|(\b(OR|AND)\b\s*\d+\s*=\s*\d+)|('|"|;|--|\\*|=)/i
  return !sqlPattern.test(input)
}

// Validate file name
export const sanitizeFileName = (fileName: string): string => {
  // Remove path traversal attempts and special characters
  return fileName
    .replace(/[^a-zA-Z0-9._-]/g, '')
    .replace(/\.\./g, '')
    .substring(0, 100) // Limit length
}

// Content Security Policy violation handler
export const cspViolationHandler = (req: Request, res: Response) => {
  const { 'csp-report': report } = req.body
  
  if (report) {
    logger.warn('CSP Violation:', {
      blockedURI: report['blocked-uri'],
      violatedDirective: report['violated-directive'],
      documentURI: report['document-uri'],
      ip: req.ip
    })
  }
  
  res.status(204).send()
}
