import express from 'express'
import cors from 'cors'
import helmet from 'helmet'
import rateLimit from 'express-rate-limit'
import compression from 'compression'
import hpp from 'hpp'
import morgan from 'morgan'
import path from 'path'
import { fileURLToPath } from 'url'
import dotenv from 'dotenv'

// Load environment variables
const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)
dotenv.config({ path: path.join(__dirname, '../.env') })

// Import routes and middleware
import { errorHandler } from './middleware/errorHandler.js'
import { sanitizeInput } from './middleware/sanitize.js'
import exportRouter from './routes/export.js'
import uploadRouter from './routes/upload.js'
import healthRouter from './routes/health.js'
import { logger } from './utils/logger.js'

const app = express()
const PORT = process.env.PORT || 32299
const NODE_ENV = process.env.NODE_ENV || 'development'
const HOST = process.env.HOST || '0.0.0.0'

// ==========================================
// SECURITY MIDDLEWARE
// ==========================================

// Helmet - Security headers
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
      fontSrc: ["'self'", "https://fonts.gstatic.com"],
      imgSrc: ["'self'", "data:", "blob:"],
      scriptSrc: ["'self'"],
      connectSrc: ["'self'"],
    },
  },
  crossOriginEmbedderPolicy: false,
}))

// CORS Configuration
const corsOptions = {
  origin: process.env.CORS_ORIGIN || (NODE_ENV === 'development' ? true : false),
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With'],
  maxAge: 86400 // 24 hours
}
app.use(cors(corsOptions))

// Rate Limiting
const rateLimitOptions = {
  windowMs: parseInt(process.env.RATE_LIMIT_WINDOW_MS || '900000'), // 15 minutes
  max: parseInt(process.env.RATE_LIMIT_MAX_REQUESTS || '100'),
  message: {
    success: false,
    error: 'Too many requests, please try again later.'
  },
  standardHeaders: true,
  legacyHeaders: false,
  handler: (req, res) => {
    logger.warn(`Rate limit exceeded for IP: ${req.ip}`)
    res.status(429).json({
      success: false,
      error: 'Too many requests, please try again later.',
      retryAfter: Math.ceil(rateLimitOptions.windowMs / 1000)
    })
  }
}
app.use(rateLimit(rateLimitOptions))

// Stricter rate limit for export endpoint
const exportRateLimit = rateLimit({
  windowMs: 60000, // 1 minute
  max: 10, // 10 exports per minute
  message: {
    success: false,
    error: 'Export limit reached, please try again in a minute.'
  }
})

// HTTP Parameter Pollution Protection
app.use(hpp())

// Compression
app.use(compression())

// Body Parsing
app.use(express.json({ limit: '10mb' }))
app.use(express.urlencoded({ extended: true, limit: '10mb' }))

// Input Sanitization
app.use(sanitizeInput)

// Request Logging
app.use(morgan(NODE_ENV === 'production' ? 'combined' : 'dev', {
  stream: {
    write: (message) => logger.info(message.trim())
  }
}))

// ==========================================
// STATIC FILES (Production)
// ==========================================
if (NODE_ENV === 'production') {
  const frontendDist = path.join(__dirname, '../../frontend/dist')
  app.use(express.static(frontendDist, {
    maxAge: '1y',
    etag: true,
    lastModified: true
  }))
}

// ==========================================
// API ROUTES
// ==========================================
app.use('/api/health', healthRouter)
app.use('/api/export', exportRateLimit, exportRouter)
app.use('/api/upload', uploadRouter)

// API 404 Handler
app.use('/api/*', (req, res) => {
  res.status(404).json({
    success: false,
    error: 'API endpoint not found'
  })
})

// ==========================================
// FRONTEND SERVING (Production)
// ==========================================
if (NODE_ENV === 'production') {
  app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, '../../frontend/dist/index.html'))
  })
}

// ==========================================
// ERROR HANDLING
// ==========================================
app.use(errorHandler)

// ==========================================
// SERVER START
// ==========================================
const server = app.listen(PORT, HOST, () => {
  logger.info(`=================================`)
  logger.info(`Server running on ${HOST}:${PORT}`)
  logger.info(`Environment: ${NODE_ENV}`)
  logger.info(`CORS Origin: ${process.env.CORS_ORIGIN || 'default'}`)
  logger.info(`=================================`)
})

// Graceful Shutdown
const gracefulShutdown = (signal: string) => {
  logger.info(`${signal} received. Starting graceful shutdown...`)
  server.close(() => {
    logger.info('Server closed. Process terminated.')
    process.exit(0)
  })
}

process.on('SIGTERM', () => gracefulShutdown('SIGTERM'))
process.on('SIGINT', () => gracefulShutdown('SIGINT'))

// Handle uncaught exceptions
process.on('uncaughtException', (err) => {
  logger.error('Uncaught Exception:', err)
  process.exit(1)
})

process.on('unhandledRejection', (reason, promise) => {
  logger.error('Unhandled Rejection at:', promise, 'reason:', reason)
})

export default app
