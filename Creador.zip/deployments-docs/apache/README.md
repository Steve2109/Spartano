# Despliegue con Apache - Debian 13

## Requisitos Previos
- Debian 13 instalado
- Acceso root o sudo
- Dominio `logoai.tymtechnology.shop` apuntando al servidor

## 1. Instalar Node.js y NPM
```bash
# Actualizar sistema
sudo apt update && sudo apt upgrade -y

# Instalar Node.js 20.x
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo bash -
sudo apt install -y nodejs

# Verificar instalación
node --version  # v20.x.x
npm --version   # 10.x.x
```

## 2. Instalar Apache
```bash
sudo apt install -y apache2

# Habilitar módulos necesarios
sudo a2enmod proxy
sudo a2enmod proxy_http
sudo a2enmod proxy_balancer
sudo a2enmod lbmethod_byrequests
sudo a2enmod ssl
sudo a2enmod headers
sudo a2enmod rewrite
sudo a2enmod deflate
sudo a2enmod expires

# Iniciar y habilitar Apache
sudo systemctl start apache2
sudo systemctl enable apache2
```

## 3. Instalar PM2
```bash
sudo npm install -g pm2
```

## 4. Configurar la Aplicación
```bash
# Crear directorio
sudo mkdir -p /var/www/logoai
cd /var/www/logoai

# Copiar archivos del proyecto
# (Clonar o copiar con SCP/FTP)

# Instalar dependencias
sudo npm run install:all

# Construir
sudo npm run build

# Crear .env
sudo tee .env << EOF
NODE_ENV=production
PORT=32299
HOST=127.0.0.1
CORS_ORIGIN=https://logoai.tymtechnology.shop
RATE_LIMIT_WINDOW_MS=900000
RATE_LIMIT_MAX_REQUESTS=100
LOG_LEVEL=info
EOF

sudo mkdir -p logs uploads
```

## 5. Configurar Apache Virtual Host
```bash
# Crear archivo de configuración
sudo tee /etc/apache2/sites-available/logoai.conf << 'EOF'
<VirtualHost *:80>
    ServerName logoai.tymtechnology.shop
    ServerAlias www.logoai.tymtechnology.shop
    
    # Redirect to HTTPS
    RewriteEngine On
    RewriteCond %{HTTPS} off
    RewriteRule ^(.*)$ https://%{HTTP_HOST}$1 [R=301,L]
</VirtualHost>

<VirtualHost *:443>
    ServerName logoai.tymtechnology.shop
    ServerAlias www.logoai.tymtechnology.shop
    
    # SSL Configuration
    SSLEngine on
    SSLCertificateFile /etc/letsencrypt/live/logoai.tymtechnology.shop/fullchain.pem
    SSLCertificateKeyFile /etc/letsencrypt/live/logoai.tymtechnology.shop/privkey.pem
    
    # Modern SSL
    SSLProtocol all -SSLv3 -TLSv1 -TLSv1.1
    SSLCipherSuite ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256
    SSLHonorCipherOrder on
    
    # Security Headers
    Header always set X-Frame-Options "SAMEORIGIN"
    Header always set X-Content-Type-Options "nosniff"
    Header always set X-XSS-Protection "1; mode=block"
    Header always set Referrer-Policy "strict-origin-when-cross-origin"
    Header always set Strict-Transport-Security "max-age=63072000; includeSubDomains"
    
    # Compression
    SetOutputFilter DEFLATE
    SetEnvIfNoCase Request_URI \
        \.(?:gif|jpe?g|png)$ no-gzip dont-vary
    SetEnvIfNoCase Request_URI \
        \.(?:exe|t?gz|zip|bz2|sit|rar)$ no-gzip dont-vary
    
    # Proxy to Node.js
    ProxyPreserveHost On
    ProxyPass / http://127.0.0.1:32299/
    ProxyPassReverse / http://127.0.0.1:32299/
    
    # WebSocket support (if needed)
    RewriteEngine On
    RewriteCond %{HTTP:Upgrade} websocket [NC]
    RewriteCond %{HTTP:Connection} upgrade [NC]
    RewriteRule ^/?(.*) "ws://127.0.0.1:32299/$1" [P,L]
    
    # Logging
    ErrorLog ${APACHE_LOG_DIR}/logoai-error.log
    CustomLog ${APACHE_LOG_DIR}/logoai-access.log combined
</VirtualHost>
EOF

# Deshabilitar sitio por defecto
sudo a2dissite 000-default

# Habilitar nuevo sitio
sudo a2ensite logoai

# Verificar configuración
sudo apache2ctl configtest
```

## 6. Obtener Certificado SSL
```bash
sudo apt install -y certbot python3-certbot-apache

sudo certbot --apache -d logoai.tymtechnology.shop --agree-tos --non-interactive --email tu-email@example.com

# Verificar renovación
sudo certbot renew --dry-run
```

## 7. Iniciar Aplicación con PM2
```bash
cd /var/www/logoai

# Iniciar
sudo pm2 start ecosystem.config.js

# Guardar configuración
sudo pm2 save
sudo pm2 startup systemd
```

## 8. Reiniciar Apache
```bash
sudo systemctl restart apache2
```

## 9. Configurar Firewall
```bash
sudo apt install -y ufw
sudo ufw allow 'Apache Full'
sudo ufw allow OpenSSH
sudo ufw --force enable
```

## Comandos de Gestión
```bash
# Ver estado Apache
sudo systemctl status apache2
sudo apache2ctl -S

# Ver logs
sudo tail -f /var/log/apache2/logoai-error.log
sudo pm2 logs logoai

# Recargar Apache
sudo systemctl reload apache2

# Reiniciar todo
sudo pm2 restart logoai
sudo systemctl restart apache2
```

## Actualización
```bash
cd /var/www/logoai

# Backup
sudo cp -r uploads uploads-backup-$(date +%Y%m%d)

# Actualizar
git pull origin main
sudo npm run install:all
sudo npm run build

# Reiniciar
sudo pm2 restart logoai
sudo systemctl reload apache2
```

## Solución de Problemas
```bash
# Verificar puertos
sudo netstat -tulpn | grep apache
sudo netstat -tulpn | grep node

# Verificar configuración
sudo apache2ctl configtest
sudo apache2ctl -S

# Logs de error
sudo tail -f /var/log/apache2/error.log
sudo pm2 logs logoai
```
