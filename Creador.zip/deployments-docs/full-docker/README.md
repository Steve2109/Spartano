# Despliegue Full Docker Stack - Debian 13

Esta configuración incluye:
- LogoAI App (Node.js)
- Nginx Reverse Proxy
- Redis (caché/sesiones)
- PostgreSQL (base de datos opcional)
- Let's Encrypt (SSL automático)
- Monitoring (opcional)

## 1. Estructura del Proyecto
```
~/logoai/
├── docker-compose.yml
├── .env
├── app/
│   └── (código de la aplicación)
├── data/
│   ├── postgres/
│   ├── redis/
│   └── nginx/
└── logs/
```

## 2. Instalar Docker y Docker Compose
```bash
#!/bin/bash

# Actualizar sistema
sudo apt update && sudo apt upgrade -y

# Instalar dependencias
sudo apt install -y apt-transport-https ca-certificates curl gnupg lsb-release software-properties-common

# Agregar Docker GPG key
curl -fsSL https://download.docker.com/linux/debian/gpg | sudo gpg --dearmor -o /usr/share/keyrings/docker-archive-keyring.gpg

# Agregar repositorio Docker
echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/docker-archive-keyring.gpg] https://download.docker.com/linux/debian $(lsb_release -cs) stable" | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null

# Instalar Docker
sudo apt update
sudo apt install -y docker-ce docker-ce-cli containerd.io docker-compose-plugin

# Verificar
sudo docker --version
sudo docker compose version

# Habilitar Docker
sudo systemctl enable docker
sudo systemctl start docker
```

## 3. Configurar Proyecto
```bash
mkdir -p ~/logoai
cd ~/logoai

# Crear estructura de directorios
mkdir -p {logs,uploads,data/postgres,data/redis,data/nginx/ssl}
```

## 4. Docker Compose Completo

Crear `docker-compose.yml`:

```yaml
version: '3.8'

services:
  # Aplicación Principal
  app:
    build:
      context: .
      dockerfile: Dockerfile
      target: production
    container_name: logoai-app
    restart: unless-stopped
    environment:
      - NODE_ENV=production
      - PORT=32299
      - HOST=0.0.0.0
      - DATABASE_URL=postgresql://logoai:${DB_PASSWORD}@postgres:5432/logoai
      - REDIS_URL=redis://redis:6379
    env_file:
      - .env
    volumes:
      - ./logs:/app/logs
      - ./uploads:/app/uploads
    networks:
      - logoai-network
    depends_on:
      - postgres
      - redis
    healthcheck:
      test: ["CMD", "node", "-e", "require('http').get('http://localhost:32299/api/health', (r) => {process.exit(r.statusCode === 200 ? 0 : 1)})"]
      interval: 30s
      timeout: 10s
      retries: 3
      start_period: 40s
    deploy:
      resources:
        limits:
          cpus: '2'
          memory: 2G
        reservations:
          cpus: '0.5'
          memory: 512M

  # PostgreSQL Database
  postgres:
    image: postgres:15-alpine
    container_name: logoai-postgres
    restart: unless-stopped
    environment:
      POSTGRES_USER: logoai
      POSTGRES_PASSWORD: ${DB_PASSWORD}
      POSTGRES_DB: logoai
    volumes:
      - ./data/postgres:/var/lib/postgresql/data
    networks:
      - logoai-network
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U logoai"]
      interval: 10s
      timeout: 5s
      retries: 5

  # Redis Cache
  redis:
    image: redis:7-alpine
    container_name: logoai-redis
    restart: unless-stopped
    command: redis-server --appendonly yes --maxmemory 256mb --maxmemory-policy allkeys-lru
    volumes:
      - ./data/redis:/data
    networks:
      - logoai-network
    healthcheck:
      test: ["CMD", "redis-cli", "ping"]
      interval: 10s
      timeout: 3s
      retries: 5

  # Nginx Reverse Proxy
  nginx:
    image: nginx:alpine
    container_name: logoai-nginx
    restart: unless-stopped
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./deployments-docs/nginx/nginx.conf:/etc/nginx/nginx.conf:ro
      - ./data/nginx/ssl:/etc/nginx/ssl:ro
      - ./logs/nginx:/var/log/nginx
    depends_on:
      - app
    networks:
      - logoai-network

  # Let's Encrypt Companion (opcional)
  certbot:
    image: certbot/certbot
    container_name: logoai-certbot
    volumes:
      - ./data/nginx/ssl:/etc/letsencrypt
      - ./logs/certbot:/var/log/letsencrypt
    entrypoint: "/bin/sh -c 'trap exit TERM; while :; do certbot renew; sleep 12h; done'"
    networks:
      - logoai-network

  # Watchtower - Auto-update (opcional)
  watchtower:
    image: containrrr/watchtower
    container_name: logoai-watchtower
    volumes:
      - /var/run/docker.sock:/var/run/docker.sock
    command: --interval 3600 --cleanup
    restart: unless-stopped
    networks:
      - logoai-network

networks:
  logoai-network:
    driver: bridge
    ipam:
      config:
        - subnet: 172.20.0.0/16
```

## 5. Archivo .env
```bash
nano ~/logoai/.env
```

```env
# App Configuration
NODE_ENV=production
PORT=32299
HOST=0.0.0.0

# Security
JWT_SECRET=$(openssl rand -hex 64)
JWT_EXPIRE=24h
RATE_LIMIT_WINDOW_MS=900000
RATE_LIMIT_MAX_REQUESTS=100

# Database (generar contraseña segura)
DB_PASSWORD=$(openssl rand -base64 32)
DATABASE_URL=postgresql://logoai:${DB_PASSWORD}@postgres:5432/logoai

# Redis
REDIS_URL=redis://redis:6379

# Domain
CORS_ORIGIN=https://logoai.tymtechnology.shop
FRONTEND_URL=https://logoai.tymtechnology.shop

# Logs
LOG_LEVEL=info
LOG_FILE=logs/app.log

# Upload Limits
MAX_FILE_SIZE=10485760
MAX_FILES_PER_UPLOAD=5
```

## 6. Script de Despliegue Automático

Crear `deploy.sh`:

```bash
#!/bin/bash

set -e

PROJECT_DIR="/opt/logoai"
DOMAIN="logoai.tymtechnology.shop"
EMAIL="tu-email@example.com"

echo "🚀 Iniciando despliegue de LogoAI..."

# Crear directorio
sudo mkdir -p $PROJECT_DIR
sudo chown $USER:$USER $PROJECT_DIR
cd $PROJECT_DIR

# Clonar repositorio (si aplica)
# git clone https://github.com/tu-usuario/logoai.git .

# Generar contraseñas seguras
DB_PASSWORD=$(openssl rand -base64 32)
JWT_SECRET=$(openssl rand -hex 64)

# Crear .env
cat > .env << EOF
NODE_ENV=production
PORT=32299
HOST=0.0.0.0
JWT_SECRET=$JWT_SECRET
JWT_EXPIRE=24h
DB_PASSWORD=$DB_PASSWORD
DATABASE_URL=postgresql://logoai:$DB_PASSWORD@postgres:5432/logoai
REDIS_URL=redis://redis:6379
CORS_ORIGIN=https://$DOMAIN
FRONTEND_URL=https://$DOMAIN
RATE_LIMIT_WINDOW_MS=900000
RATE_LIMIT_MAX_REQUESTS=100
LOG_LEVEL=info
LOG_FILE=logs/app.log
MAX_FILE_SIZE=10485760
MAX_FILES_PER_UPLOAD=5
EOF

# Crear directorios necesarios
mkdir -p {logs,uploads,data/postgres,data/redis,data/nginx/ssl}

# Construir y ejecutar
echo "📦 Construyendo imágenes..."
docker compose build --no-cache

echo "🚀 Iniciando servicios..."
docker compose up -d

# Esperar a que la app esté lista
echo "⏳ Esperando a que la aplicación esté lista..."
sleep 30

# Verificar salud
if curl -s http://localhost:32299/api/health > /dev/null; then
    echo "✅ Aplicación saludable!"
else
    echo "❌ Error: La aplicación no responde"
    docker compose logs app
    exit 1
fi

# Instalar Certbot para SSL
echo "🔒 Configurando SSL..."
sudo apt install -y certbot

# Obtener certificado
sudo certbot certonly --standalone -d $DOMAIN --agree-tos --non-interactive --email $EMAIL

# Copiar certificados para Nginx
sudo cp /etc/letsencrypt/live/$DOMAIN/fullchain.pem data/nginx/ssl/
sudo cp /etc/letsencrypt/live/$DOMAIN/privkey.pem data/nginx/ssl/
sudo chown -R $USER:$USER data/nginx/ssl

# Recargar Nginx
docker compose exec nginx nginx -s reload

echo "✅ Despliegue completado!"
echo "🌐 Accede a: https://$DOMAIN"
echo ""
echo "Comandos útiles:"
echo "  Logs:         docker compose logs -f"
echo "  Reiniciar:    docker compose restart"
echo "  Actualizar:   docker compose pull && docker compose up -d"
echo "  Backup:       ./backup.sh"
```

## 7. Script de Backup

Crear `backup.sh`:

```bash
#!/bin/bash

BACKUP_DIR="/opt/backups/logoai"
DATE=$(date +%Y%m%d_%H%M%S)
mkdir -p $BACKUP_DIR

echo "💾 Creando backup..."

# Backup de base de datos
docker compose exec -T postgres pg_dump -U logoai logoai > $BACKUP_DIR/db_$DATE.sql

# Backup de uploads
tar -czf $BACKUP_DIR/uploads_$DATE.tar.gz uploads/

# Backup de logs
tar -czf $BACKUP_DIR/logs_$DATE.tar.gz logs/

# Backup de configuración
cp .env $BACKUP_DIR/env_$DATE

# Limpiar backups antiguos (mantener 7 días)
find $BACKUP_DIR -type f -mtime +7 -delete

echo "✅ Backup completado: $BACKUP_DIR"
ls -lh $BACKUP_DIR
```

## 8. Configurar Cron para Backups Automáticos
```bash
# Editar crontab
sudo crontab -e

# Agregar línea para backup diario a las 2 AM
0 2 * * * /opt/logoai/backup.sh >> /var/log/logoai-backup.log 2>&1

# Renovar certificados (dos veces al día)
0 */12 * * * /usr/bin/certbot renew --quiet && docker compose -f /opt/logoai/docker-compose.yml exec -T nginx nginx -s reload
```

## 9. Firewall con UFW
```bash
sudo apt install -y ufw

# Permitir servicios necesarios
sudo ufw default deny incoming
sudo ufw default allow outgoing
sudo ufw allow 22/tcp      # SSH
sudo ufw allow 80/tcp      # HTTP
sudo ufw allow 443/tcp     # HTTPS

# Habilitar
sudo ufw --force enable
sudo ufw status verbose
```

## 10. Monitoreo

### Logs en tiempo real:
```bash
cd ~/logoai

# Todos los servicios
docker compose logs -f

# Solo la app
docker compose logs -f app

# Nginx
docker compose logs -f nginx
```

### Estadísticas:
```bash
# Uso de recursos
docker stats

# Inspeccionar red
docker network inspect logoai-logoai-network
```

## 11. Actualización

```bash
cd ~/logoai

# Pull de nuevos cambios
git pull origin main

# Backup antes de actualizar
./backup.sh

# Reconstruir sin downtime
docker compose build --no-cache app
docker compose up -d app

# Verificar
docker compose ps
```

## 12. Troubleshooting

```bash
# Reset completo
docker compose down -v  # Elimina también volúmenes
docker compose up -d --build

# Limpiar sistema Docker
docker system prune -a --volumes

# Verificar conectividad entre contenedores
docker compose exec app ping postgres
docker compose exec app ping redis

# Shell en contenedor
docker compose exec app sh
docker compose exec postgres psql -U logoai
```

## 13. Acceso a la Aplicación

Después del despliegue:
- **Aplicación**: https://logoai.tymtechnology.shop
- **Health Check**: https://logoai.tymtechnology.shop/api/health
- **API Base**: https://logoai.tymtechnology.shop/api/

---

## 📝 Resumen de Comandos

| Comando | Descripción |
|---------|-------------|
| `docker compose up -d` | Iniciar todos los servicios |
| `docker compose down` | Detener todos los servicios |
| `docker compose logs -f` | Ver logs en tiempo real |
| `docker compose ps` | Estado de los servicios |
| `docker compose exec app sh` | Entrar al contenedor de la app |
| `docker compose restart app` | Reiniciar solo la app |
| `./backup.sh` | Crear backup manual |
| `./deploy.sh` | Desplegar desde cero |
