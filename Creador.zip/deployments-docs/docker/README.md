# Despliegue con Docker - Debian 13

## Opción 1: Docker Básico

### 1. Instalar Docker
```bash
# Actualizar sistema
sudo apt update && sudo apt upgrade -y

# Instalar dependencias
sudo apt install -y apt-transport-https ca-certificates curl gnupg lsb-release

# Agregar GPG key de Docker
curl -fsSL https://download.docker.com/linux/debian/gpg | sudo gpg --dearmor -o /usr/share/keyrings/docker-archive-keyring.gpg

# Agregar repositorio
echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/docker-archive-keyring.gpg] https://download.docker.com/linux/debian $(lsb_release -cs) stable" | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null

# Instalar Docker
sudo apt update
sudo apt install -y docker-ce docker-ce-cli containerd.io docker-compose-plugin

# Verificar
sudo docker --version
sudo docker compose version

# Agregar usuario al grupo docker (opcional, para no usar sudo)
sudo usermod -aG docker $USER
newgrp docker
```

### 2. Preparar Proyecto
```bash
# Crear directorio
mkdir -p ~/logoai
cd ~/logoai

# Copiar archivos del proyecto
# (git clone o copiar manualmente)

# Crear archivo .env
nano .env
```

Contenido del `.env`:
```env
NODE_ENV=production
PORT=32299
HOST=0.0.0.0
CORS_ORIGIN=https://logoai.tymtechnology.shop
RATE_LIMIT_WINDOW_MS=900000
RATE_LIMIT_MAX_REQUESTS=100
LOG_LEVEL=info
```

### 3. Ejecutar con Docker
```bash
# Construir imagen
docker build -t logoai:latest .

# Ejecutar contenedor
docker run -d \
  --name logoai \
  -p 32299:32299 \
  --env-file .env \
  -v $(pwd)/logs:/app/logs \
  -v $(pwd)/uploads:/app/uploads \
  --restart unless-stopped \
  logoai:latest

# Ver logs
docker logs -f logoai

# Verificar salud
curl http://localhost:32299/api/health
```

### 4. Comandos Útiles
```bash
# Detener contenedor
docker stop logoai

# Eliminar contenedor
docker rm logoai

# Reiniciar
docker restart logoai

# Entrar al contenedor
docker exec -it logoai sh

# Actualizar imagen
docker pull logoai:latest
docker stop logoai
docker rm logoai
docker run -d --name logoai -p 32299:32299 --env-file .env logoai:latest
```

---

## Opción 2: Docker Compose (Recomendado)

### 1. Crear docker-compose.yml
El archivo `docker-compose.yml` ya está incluido en el proyecto.

### 2. Ejecutar
```bash
# Construir y ejecutar
docker compose up -d

# Ver estado
docker compose ps

# Ver logs
docker compose logs -f logoai

# Escalar (si se necesitan múltiples instancias)
docker compose up -d --scale logoai=2
```

### 3. Actualizar
```bash
# Pull de nuevos cambios
git pull origin main

# Reconstruir y reiniciar
docker compose down
docker compose up -d --build

# O sin downtime (blue-green)
docker compose up -d --build --no-deps logoai
```

### 4. Backup de Datos
```bash
# Backup de logs
docker cp logoai:/app/logs ./backup-logs-$(date +%Y%m%d)

# Backup de uploads
docker cp logoai:/app/uploads ./backup-uploads-$(date +%Y%m%d)
```

---

## Opción 3: Docker con Nginx Proxy Manager

### 1. Instalar Docker Compose
```bash
sudo apt install -y docker-compose-plugin
```

### 2. Crear docker-compose con Nginx Proxy Manager
```yaml
version: '3.8'

services:
  logoai:
    build: .
    container_name: logoai-app
    restart: unless-stopped
    environment:
      - NODE_ENV=production
      - PORT=32299
      - HOST=0.0.0.0
    env_file:
      - .env
    volumes:
      - ./logs:/app/logs
      - ./uploads:/app/uploads
    networks:
      - logoai-network
    expose:
      - 32299

  nginx-proxy-manager:
    image: jc21/nginx-proxy-manager:latest
    container_name: npm
    restart: unless-stopped
    ports:
      - "80:80"
      - "443:443"
      - "81:81"  # Admin interface
    volumes:
      - ./npm-data:/data
      - ./npm-letsencrypt:/etc/letsencrypt
    networks:
      - logoai-network

networks:
  logoai-network:
    driver: bridge
```

### 3. Configurar Nginx Proxy Manager
1. Acceder a `http://tu-ip:81`
2. Login default: `admin@example.com` / `changeme`
3. Agregar Proxy Host:
   - Domain: `logoai.tymtechnology.shop`
   - Forward Hostname/IP: `logoai`
   - Forward Port: `32299`
   - Scheme: `http`
4. Obtener SSL en la pestaña SSL

---

## Configuración de Firewall
```bash
sudo apt install -y ufw
sudo ufw allow 22/tcp    # SSH
sudo ufw allow 80/tcp    # HTTP
sudo ufw allow 443/tcp   # HTTPS
sudo ufw allow 32299/tcp # App (si es directo)
sudo ufw --force enable
```

## Monitoreo
```bash
# Uso de recursos
docker stats

# Inspeccionar contenedor
docker inspect logoai

# Top de procesos
docker top logoai
```

## Troubleshooting
```bash
# Contenedor no inicia
docker logs logoai

# Problemas de red
docker network inspect bridge

# Limpiar
docker system prune -a

# Reconstruir sin caché
docker build --no-cache -t logoai:latest .
```
