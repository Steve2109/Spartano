# Despliegue con Nginx - Debian 13

## Requisitos Previos
- Debian 13 instalado
- Acceso root o sudo
- Dominio `logoai.tymtechnology.shop` apuntando al servidor

## 1. Instalar Node.js y NPM
```bash
# Actualizar sistema
sudo apt update && sudo apt upgrade -y

# Instalar Node.js 20.x
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo bash -
sudo apt install -y nodejs

# Verificar instalación
node --version  # v20.x.x
npm --version   # 10.x.x
```

## 2. Instalar Nginx
```bash
sudo apt install -y nginx

# Iniciar y habilitar Nginx
sudo systemctl start nginx
sudo systemctl enable nginx
```

## 3. Instalar PM2 (Process Manager)
```bash
sudo npm install -g pm2
```

## 4. Configurar la Aplicación
```bash
# Crear directorio
sudo mkdir -p /var/www/logoai
cd /var/www/logoai

# Clonar repositorio (o copiar archivos)
sudo git clone https://github.com/tu-repo/logoai.git .
# O copiar archivos manualmente con SCP/FTP

# Instalar dependencias
sudo npm run install:all

# Construir frontend y backend
sudo npm run build

# Crear archivo .env
sudo tee .env << EOF
NODE_ENV=production
PORT=32299
HOST=0.0.0.0
CORS_ORIGIN=https://logoai.tymtechnology.shop
RATE_LIMIT_WINDOW_MS=900000
RATE_LIMIT_MAX_REQUESTS=100
LOG_LEVEL=info
LOG_FILE=logs/app.log
EOF

# Crear directorio de logs
sudo mkdir -p logs uploads
```

## 5. Configurar Nginx como Reverse Proxy
```bash
# Copiar configuración de nginx
sudo cp deployments-docs/nginx/nginx.conf /etc/nginx/nginx.conf

# Crear directorio para SSL
sudo mkdir -p /etc/nginx/ssl

# Verificar configuración
sudo nginx -t
```

## 6. Obtener Certificado SSL (Let's Encrypt)
```bash
# Instalar Certbot
sudo apt install -y certbot python3-certbot-nginx

# Obtener certificado
sudo certbot --nginx -d logoai.tymtechnology.shop --agree-tos --non-interactive --email tu-email@example.com

# Verificar auto-renewal
sudo certbot renew --dry-run
```

## 7. Iniciar la Aplicación con PM2
```bash
cd /var/www/logoai

# Iniciar aplicación
sudo pm2 start ecosystem.config.js

# Guardar configuración PM2
sudo pm2 save

# Configurar PM2 para iniciar con el sistema
sudo pm2 startup systemd
```

## 8. Configurar Firewall
```bash
sudo apt install -y ufw
sudo ufw allow 'Nginx Full'
sudo ufw allow OpenSSH
sudo ufw --force enable
```

## 9. Verificar Despliegue
```bash
# Verificar estado de los servicios
sudo systemctl status nginx
sudo pm2 status

# Verificar logs
sudo pm2 logs logoai
sudo tail -f /var/log/nginx/error.log

# Probar aplicación
curl http://localhost:32299/api/health
```

## Comandos Útiles
```bash
# Reiniciar aplicación
sudo pm2 restart logoai

# Ver logs en tiempo real
sudo pm2 logs logoai

# Recargar Nginx
sudo systemctl reload nginx

# Actualizar aplicación
cd /var/www/logoai
git pull origin main
sudo npm run install:all
sudo npm run build
sudo pm2 restart logoai
```

## Solución de Problemas

### Error: "Port already in use"
```bash
sudo lsof -i :32299
sudo kill -9 <PID>
```

### Error: "Permission denied"
```bash
sudo chown -R $USER:$USER /var/www/logoai
```

### Verificar configuración Nginx
```bash
sudo nginx -t
sudo nginx -T  # Mostrar configuración completa
```
