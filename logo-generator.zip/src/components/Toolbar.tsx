import { useState } from 'react'
import { 
  Type, Square, Circle, Hexagon, Triangle, 
  Star, Heart, Zap, Shield, Layers, 
  Palette, Image, Upload, Trash2, Grid3X3,
  LayoutTemplate, Sparkles
} from 'lucide-react'
import useLogoEditor, { LogoElement } from '../hooks/useLogoEditor'
import { TabType } from '../App'

interface ToolbarProps {
  activeTab: TabType
  selectedId: string | null
  onSelectElement: (id: string | null) => void
}

const fonts = [
  { name: 'Montserrat', label: 'Montserrat' },
  { name: 'Inter', label: 'Inter' },
  { name: 'Poppins', label: 'Poppins' },
  { name: 'Roboto', label: 'Roboto' },
  { name: 'Playfair Display', label: 'Playfair' },
  { name: 'Bebas Neue', label: 'Bebas Neue' },
  { name: 'Pacifico', label: 'Pacifico' },
]

const colors = [
  '#3b82f6', '#ef4444', '#22c55e', '#f59e0b', '#8b5cf6',
  '#ec4899', '#06b6d4', '#14b8a6', '#f97316', '#6366f1',
  '#1e293b', '#64748b', '#94a3b8', '#ffffff', '#000000',
]

const templates: { name: string; elements: LogoElement[] }[] = [
  {
    name: 'Tech Minimal',
    elements: [
      { id: 't1-1', type: 'circle', x: 300, y: 250, width: 120, height: 120, fill: '#3b82f6', stroke: 'transparent', strokeWidth: 0, rotation: 0 },
      { id: 't1-2', type: 'text', x: 250, y: 340, width: 200, height: 40, text: 'TECH', fontSize: 28, fontFamily: 'Montserrat', fill: '#1e293b', stroke: 'transparent', strokeWidth: 0, rotation: 0, align: 'center' },
    ],
  },
  {
    name: 'Modern Badge',
    elements: [
      { id: 't2-1', type: 'rect', x: 200, y: 180, width: 200, height: 200, fill: '#1e293b', stroke: 'transparent', strokeWidth: 0, rotation: 45, cornerRadius: 30 },
      { id: 't2-2', type: 'text', x: 250, y: 270, width: 200, height: 60, text: 'BRAND', fontSize: 36, fontFamily: 'Bebas Neue', fill: '#ffffff', stroke: 'transparent', strokeWidth: 0, rotation: 0, align: 'center' },
    ],
  },
  {
    name: 'Elegant Script',
    elements: [
      { id: 't3-1', type: 'path', x: 220, y: 200, width: 200, height: 60, data: 'M10,50 Q60,10 110,50 T210,50', fill: 'transparent', stroke: '#8b5cf6', strokeWidth: 6, rotation: 0 },
      { id: 't3-2', type: 'text', x: 220, y: 270, width: 200, height: 50, text: 'Signature', fontSize: 32, fontFamily: 'Pacifico', fill: '#1e293b', stroke: 'transparent', strokeWidth: 0, rotation: 0, align: 'center' },
    ],
  },
  {
    name: 'Geometric',
    elements: [
      { id: 't4-1', type: 'rect', x: 270, y: 200, width: 60, height: 60, fill: '#22c55e', stroke: 'transparent', strokeWidth: 0, rotation: 0, cornerRadius: 0 },
      { id: 't4-2', type: 'circle', x: 270, y: 200, width: 60, height: 60, fill: '#22c55e', stroke: 'transparent', strokeWidth: 0, rotation: 0 },
      { id: 't4-3', type: 'text', x: 230, y: 290, width: 200, height: 40, text: 'SQUARE', fontSize: 24, fontFamily: 'Inter', fill: '#1e293b', stroke: 'transparent', strokeWidth: 0, rotation: 0, align: 'center' },
    ],
  },
]

export default function Toolbar({ activeTab, selectedId, onSelectElement }: ToolbarProps) {
  const { addElement, updateElement, elements, clearCanvas, loadTemplate } = useLogoEditor()
  const [customText, setCustomText] = useState('Tu Texto')
  const [selectedFont, setSelectedFont] = useState('Montserrat')
  const [selectedColor, setSelectedColor] = useState('#3b82f6')
  const [textColor, setTextColor] = useState('#1e293b')

  const selectedElement = elements.find((el) => el.id === selectedId)

  const handleAddText = () => {
    addElement('text', {
      text: customText,
      fontFamily: selectedFont,
      fill: textColor,
    })
  }

  const handleAddShape = (shape: 'rect' | 'circle') => {
    addElement(shape, { fill: selectedColor })
  }

  const handleLoadTemplate = (template: typeof templates[0]) => {
    clearCanvas()
    loadTemplate(template.elements)
  }

  if (activeTab === 'templates') {
    return (
      <div className="space-y-4">
        <div className="flex items-center gap-2 mb-4">
          <LayoutTemplate className="w-5 h-5 text-blue-600" />
          <h3 className="font-semibold text-slate-900">Plantillas</h3>
        </div>
        
        <div className="grid grid-cols-2 gap-3">
          {templates.map((template) => (
            <button
              key={template.name}
              onClick={() => handleLoadTemplate(template)}
              className="p-3 bg-slate-50 hover:bg-blue-50 border border-slate-200 hover:border-blue-300 rounded-xl transition-all text-left group"
            >
              <div className="w-full h-16 bg-white rounded-lg mb-2 flex items-center justify-center shadow-sm group-hover:shadow-md transition-shadow">
                <Grid3X3 className="w-8 h-8 text-slate-300 group-hover:text-blue-400" />
              </div>
              <span className="text-sm font-medium text-slate-700">{template.name}</span>
            </button>
          ))}
        </div>

        <div className="mt-6 p-4 bg-gradient-to-br from-blue-50 to-indigo-50 rounded-xl border border-blue-100">
          <div className="flex items-center gap-2 mb-2">
            <Sparkles className="w-4 h-4 text-blue-600" />
            <span className="text-sm font-medium text-blue-900">Consejo Pro</span>
          </div>
          <p className="text-xs text-blue-700">
            Selecciona una plantilla para comenzar rápidamente. Puedes modificar cada elemento después.
          </p>
        </div>
      </div>
    )
  }

  if (activeTab === 'text') {
    return (
      <div className="space-y-4">
        <div className="flex items-center gap-2 mb-4">
          <Type className="w-5 h-5 text-blue-600" />
          <h3 className="font-semibold text-slate-900">Agregar Texto</h3>
        </div>

        <div className="space-y-3">
          <div>
            <label className="text-sm text-slate-600 mb-1 block">Contenido</label>
            <input
              type="text"
              value={customText}
              onChange={(e) => setCustomText(e.target.value)}
              className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="Escribe tu texto..."
            />
          </div>

          <div>
            <label className="text-sm text-slate-600 mb-1 block">Fuente</label>
            <select
              value={selectedFont}
              onChange={(e) => setSelectedFont(e.target.value)}
              className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              {fonts.map((font) => (
                <option key={font.name} value={font.name} style={{ fontFamily: font.name }}>
                  {font.label}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="text-sm text-slate-600 mb-2 block">Color del texto</label>
            <div className="grid grid-cols-5 gap-2">
              {colors.map((color) => (
                <button
                  key={color}
                  onClick={() => setTextColor(color)}
                  className={`w-8 h-8 rounded-full border-2 transition-all ${
                    textColor === color ? 'border-slate-900 scale-110' : 'border-transparent'
                  }`}
                  style={{ backgroundColor: color }}
                />
              ))}
            </div>
          </div>

          <button
            onClick={handleAddText}
            className="w-full py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium transition-colors flex items-center justify-center gap-2"
          >
            <Type className="w-4 h-4" />
            Agregar Texto
          </button>
        </div>

        {selectedElement?.type === 'text' && (
          <div className="mt-6 p-4 bg-slate-50 rounded-xl border border-slate-200">
            <h4 className="text-sm font-semibold text-slate-900 mb-3">Editar Texto</h4>
            <div className="space-y-3">
              <div>
                <label className="text-xs text-slate-500 mb-1 block">Texto</label>
                <input
                  type="text"
                  value={selectedElement.text || ''}
                  onChange={(e) => updateElement(selectedId!, { text: e.target.value })}
                  className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg"
                />
              </div>
              <div>
                <label className="text-xs text-slate-500 mb-1 block">Tamaño de fuente</label>
                <input
                  type="range"
                  min="12"
                  max="72"
                  value={selectedElement.fontSize || 32}
                  onChange={(e) => updateElement(selectedId!, { fontSize: parseInt(e.target.value) })}
                  className="w-full"
                />
                <span className="text-xs text-slate-500">{selectedElement.fontSize}px</span>
              </div>
              <div>
                <label className="text-xs text-slate-500 mb-1 block">Fuente</label>
                <select
                  value={selectedElement.fontFamily || 'Montserrat'}
                  onChange={(e) => updateElement(selectedId!, { fontFamily: e.target.value })}
                  className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg"
                >
                  {fonts.map((font) => (
                    <option key={font.name} value={font.name}>
                      {font.label}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>
        )}
      </div>
    )
  }

  if (activeTab === 'shapes') {
    return (
      <div className="space-y-4">
        <div className="flex items-center gap-2 mb-4">
          <Shapes className="w-5 h-5 text-blue-600" />
          <h3 className="font-semibold text-slate-900">Formas</h3>
        </div>

        <div className="grid grid-cols-3 gap-2">
          <button
            onClick={() => handleAddShape('rect')}
            className="p-3 bg-slate-50 hover:bg-blue-50 border border-slate-200 rounded-xl flex flex-col items-center gap-2 transition-colors"
          >
            <Square className="w-6 h-6 text-slate-600" />
            <span className="text-xs text-slate-600">Rectángulo</span>
          </button>
          <button
            onClick={() => handleAddShape('circle')}
            className="p-3 bg-slate-50 hover:bg-blue-50 border border-slate-200 rounded-xl flex flex-col items-center gap-2 transition-colors"
          >
            <Circle className="w-6 h-6 text-slate-600" />
            <span className="text-xs text-slate-600">Círculo</span>
          </button>
          <button
            onClick={() => addElement('path', { fill: selectedColor })}
            className="p-3 bg-slate-50 hover:bg-blue-50 border border-slate-200 rounded-xl flex flex-col items-center gap-2 transition-colors"
          >
            <Zap className="w-6 h-6 text-slate-600" />
            <span className="text-xs text-slate-600">Rayo</span>
          </button>
          <button
            onClick={() => addElement('path', { data: 'M50,5 L61,40 L98,40 L68,62 L79,97 L50,75 L21,97 L32,62 L2,40 L39,40 Z', fill: selectedColor })}
            className="p-3 bg-slate-50 hover:bg-blue-50 border border-slate-200 rounded-xl flex flex-col items-center gap-2 transition-colors"
          >
            <Star className="w-6 h-6 text-slate-600" />
            <span className="text-xs text-slate-600">Estrella</span>
          </button>
          <button
            onClick={() => addElement('path', { data: 'M50,88 C50,88 10,60 10,30 C10,15 25,5 50,5 C75,5 90,15 90,30 C90,60 50,88 50,88 Z', fill: selectedColor })}
            className="p-3 bg-slate-50 hover:bg-blue-50 border border-slate-200 rounded-xl flex flex-col items-center gap-2 transition-colors"
          >
            <Heart className="w-6 h-6 text-slate-600" />
            <span className="text-xs text-slate-600">Corazón</span>
          </button>
          <button
            onClick={() => addElement('path', { data: 'M50,5 L90,25 L90,75 L50,95 L10,75 L10,25 Z', fill: selectedColor })}
            className="p-3 bg-slate-50 hover:bg-blue-50 border border-slate-200 rounded-xl flex flex-col items-center gap-2 transition-colors"
          >
            <Hexagon className="w-6 h-6 text-slate-600" />
            <span className="text-xs text-slate-600">Hexágono</span>
          </button>
        </div>

        <div>
          <label className="text-sm text-slate-600 mb-2 block">Color de forma</label>
          <div className="grid grid-cols-5 gap-2">
            {colors.map((color) => (
              <button
                key={color}
                onClick={() => setSelectedColor(color)}
                className={`w-8 h-8 rounded-full border-2 transition-all ${
                  selectedColor === color ? 'border-slate-900 scale-110' : 'border-transparent'
                }`}
                style={{ backgroundColor: color }}
              />
            ))}
          </div>
        </div>
      </div>
    )
  }

  if (activeTab === 'elements') {
    return (
      <div className="space-y-4">
        <div className="flex items-center gap-2 mb-4">
          <Layers className="w-5 h-5 text-blue-600" />
          <h3 className="font-semibold text-slate-900">Capas</h3>
        </div>

        <div className="space-y-2 max-h-80 overflow-y-auto">
          {elements.length === 0 ? (
            <p className="text-sm text-slate-500 text-center py-8">
              No hay elementos en el canvas
            </p>
          ) : (
            [...elements].reverse().map((element, index) => (
              <button
                key={element.id}
                onClick={() => onSelectElement(element.id)}
                className={`w-full p-3 rounded-lg flex items-center gap-3 transition-colors ${
                  selectedId === element.id
                    ? 'bg-blue-50 border border-blue-200'
                    : 'bg-slate-50 border border-slate-200 hover:bg-slate-100'
                }`}
              >
                {element.type === 'text' && <Type className="w-4 h-4 text-slate-500" />}
                {element.type === 'rect' && <Square className="w-4 h-4 text-slate-500" />}
                {element.type === 'circle' && <Circle className="w-4 h-4 text-slate-500" />}
                {element.type === 'path' && <Zap className="w-4 h-4 text-slate-500" />}
                {element.type === 'line' && <div className="w-4 h-0.5 bg-slate-500" />}
                <span className="text-sm text-slate-700 truncate flex-1 text-left">
                  {element.type === 'text' ? element.text : `${element.type} ${elements.length - index}`}
                </span>
                <span className="text-xs text-slate-400">#{elements.length - index}</span>
              </button>
            ))
          )}
        </div>

        <button
          onClick={clearCanvas}
          className="w-full py-2 bg-red-50 hover:bg-red-100 text-red-600 rounded-lg font-medium transition-colors flex items-center justify-center gap-2"
        >
          <Trash2 className="w-4 h-4" />
          Limpiar Todo
        </button>
      </div>
    )
  }

  if (activeTab === 'export') {
    return (
      <div className="space-y-4">
        <div className="flex items-center gap-2 mb-4">
          <Upload className="w-5 h-5 text-blue-600" />
          <h3 className="font-semibold text-slate-900">Exportar</h3>
        </div>

        <div className="space-y-3">
          <p className="text-sm text-slate-600">
            Ve al panel derecho para exportar tu logo en diferentes formatos:
          </p>
          
          <div className="space-y-2">
            <div className="flex items-center gap-3 p-3 bg-slate-50 rounded-lg">
              <div className="w-8 h-8 bg-orange-100 rounded-lg flex items-center justify-center">
                <Image className="w-4 h-4 text-orange-600" />
              </div>
              <div className="flex-1">
                <p className="text-sm font-medium text-slate-900">PNG</p>
                <p className="text-xs text-slate-500">Alta resolución con transparencia</p>
              </div>
            </div>
            
            <div className="flex items-center gap-3 p-3 bg-slate-50 rounded-lg">
              <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center">
                <Palette className="w-4 h-4 text-blue-600" />
              </div>
              <div className="flex-1">
                <p className="text-sm font-medium text-slate-900">SVG</p>
                <p className="text-xs text-slate-500">Vector escalable infinitamente</p>
              </div>
            </div>
            
            <div className="flex items-center gap-3 p-3 bg-slate-50 rounded-lg">
              <div className="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center">
                <Shield className="w-4 h-4 text-green-600" />
              </div>
              <div className="flex-1">
                <p className="text-sm font-medium text-slate-900">Favicon</p>
                <p className="text-xs text-slate-500">Pack completo para web</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }

  return null
}

function Shapes({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <rect x="3" y="3" width="7" height="7" />
      <circle cx="17.5" cy="6.5" r="3.5" />
      <path d="M3 17l4-4 4 4" />
      <path d="M17 14h4v4h-4z" />
    </svg>
  )
}
