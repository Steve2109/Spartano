import { useRef, useEffect, useState } from 'react'
import { Stage, Layer, Rect, Circle, Text, Path, Line, Group, Transformer } from 'react-konva'
import { KonvaEventObject } from 'konva/lib/Node'
import useLogoEditor from '../hooks/useLogoEditor'
import { ShapeType, LogoElement } from '../hooks/useLogoEditor'

interface LogoEditorProps {
  selectedId: string | null
  onSelectElement: (id: string | null) => void
}

const CANVAS_WIDTH = 600
const CANVAS_HEIGHT = 600

export default function LogoEditor({ selectedId, onSelectElement }: LogoEditorProps) {
  const stageRef = useRef<any>(null)
  const transformerRef = useRef<any>(null)
  const {
    elements,
    backgroundColor,
    setBackgroundColor,
    addElement,
    updateElement,
    deleteElement,
    bringToFront,
    sendToBack,
  } = useLogoEditor()

  const [stageScale, setStageScale] = useState(1)
  const [stagePosition, setStagePosition] = useState({ x: 0, y: 0 })

  useEffect(() => {
    if (transformerRef.current) {
      const selectedNode = stageRef.current?.findOne(`#${selectedId}`)
      if (selectedNode) {
        transformerRef.current.nodes([selectedNode])
        transformerRef.current.getLayer()?.batchDraw()
      } else {
        transformerRef.current.nodes([])
        transformerRef.current.getLayer()?.batchDraw()
      }
    }
  }, [selectedId])

  const handleStageClick = (e: KonvaEventObject<MouseEvent>) => {
    const clickedOnEmpty = e.target === e.target.getStage()
    if (clickedOnEmpty) {
      onSelectElement(null)
    }
  }

  const handleElementClick = (e: KonvaEventObject<MouseEvent>, id: string) => {
    e.cancelBubble = true
    onSelectElement(id)
  }

  const handleDragEnd = (e: KonvaEventObject<DragEvent>, id: string) => {
    const node = e.target
    updateElement(id, {
      x: node.x(),
      y: node.y(),
    })
  }

  const handleTransformEnd = (e: KonvaEventObject<Event>, id: string) => {
    const node = e.target
    const scaleX = node.scaleX()
    const scaleY = node.scaleY()

    node.scaleX(1)
    node.scaleY(1)

    updateElement(id, {
      x: node.x(),
      y: node.y(),
      width: node.width() * scaleX,
      height: node.height() * scaleY,
      rotation: node.rotation(),
    })
  }

  const renderElement = (element: LogoElement) => {
    const isSelected = selectedId === element.id
    const commonProps = {
      id: element.id,
      x: element.x,
      y: element.y,
      draggable: true,
      onClick: (e: KonvaEventObject<MouseEvent>) => handleElementClick(e, element.id),
      onTap: (e: KonvaEventObject<MouseEvent>) => handleElementClick(e, element.id),
      onDragEnd: (e: KonvaEventObject<DragEvent>) => handleDragEnd(e, element.id),
      onTransformEnd: (e: KonvaEventObject<Event>) => handleTransformEnd(e, element.id),
    }

    switch (element.type) {
      case 'rect':
        return (
          <Rect
            key={element.id}
            {...commonProps}
            width={element.width}
            height={element.height}
            fill={element.fill}
            stroke={element.stroke}
            strokeWidth={element.strokeWidth}
            cornerRadius={element.cornerRadius || 0}
            rotation={element.rotation}
          />
        )
      case 'circle':
        return (
          <Circle
            key={element.id}
            {...commonProps}
            width={element.width}
            height={element.height}
            fill={element.fill}
            stroke={element.stroke}
            strokeWidth={element.strokeWidth}
            rotation={element.rotation}
          />
        )
      case 'text':
        return (
          <Text
            key={element.id}
            {...commonProps}
            text={element.text}
            fontSize={element.fontSize}
            fontFamily={element.fontFamily}
            fill={element.fill}
            width={element.width}
            align={element.align || 'center'}
            rotation={element.rotation}
          />
        )
      case 'path':
        return (
          <Path
            key={element.id}
            {...commonProps}
            data={element.data}
            fill={element.fill}
            stroke={element.stroke}
            strokeWidth={element.strokeWidth}
            scaleX={element.width / 100}
            scaleY={element.height / 100}
            rotation={element.rotation}
          />
        )
      case 'line':
        return (
          <Line
            key={element.id}
            {...commonProps}
            points={element.points}
            stroke={element.stroke}
            strokeWidth={element.strokeWidth}
            rotation={element.rotation}
          />
        )
      default:
        return null
    }
  }

  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      {/* Toolbar */}
      <div className="bg-white border-b border-slate-200 px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="text-sm font-medium text-slate-700">Canvas:</span>
          <input
            type="color"
            value={backgroundColor}
            onChange={(e) => setBackgroundColor(e.target.value)}
            title="Color de fondo"
          />
        </div>
        <div className="flex items-center gap-2">
          {selectedId && (
            <>
              <button
                onClick={() => bringToFront(selectedId)}
                className="px-3 py-1.5 text-sm bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors"
              >
                Traer al frente
              </button>
              <button
                onClick={() => sendToBack(selectedId)}
                className="px-3 py-1.5 text-sm bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors"
              >
                Enviar atrás
              </button>
              <button
                onClick={() => {
                  deleteElement(selectedId)
                  onSelectElement(null)
                }}
                className="px-3 py-1.5 text-sm bg-red-100 hover:bg-red-200 text-red-700 rounded-lg transition-colors"
              >
                Eliminar
              </button>
            </>
          )}
        </div>
      </div>

      {/* Canvas Container */}
      <div className="flex-1 overflow-auto flex items-center justify-center p-8 canvas-grid">
        <div className="bg-white shadow-2xl rounded-lg overflow-hidden">
          <Stage
            ref={stageRef}
            width={CANVAS_WIDTH}
            height={CANVAS_HEIGHT}
            scaleX={stageScale}
            scaleY={stageScale}
            x={stagePosition.x}
            y={stagePosition.y}
            onClick={handleStageClick}
            onTap={handleStageClick}
            style={{ backgroundColor }}
          >
            <Layer>
              {/* Grid */}
              <Group>
                {Array.from({ length: CANVAS_WIDTH / 20 }).map((_, i) => (
                  <Line
                    key={`v${i}`}
                    points={[i * 20, 0, i * 20, CANVAS_HEIGHT]}
                    stroke="#e2e8f0"
                    strokeWidth={0.5}
                  />
                ))}
                {Array.from({ length: CANVAS_HEIGHT / 20 }).map((_, i) => (
                  <Line
                    key={`h${i}`}
                    points={[0, i * 20, CANVAS_WIDTH, i * 20]}
                    stroke="#e2e8f0"
                    strokeWidth={0.5}
                  />
                ))}
              </Group>

              {/* Elements */}
              {elements.map((element) => renderElement(element))}

              {/* Transformer */}
              <Transformer
                ref={transformerRef}
                boundBoxFunc={(oldBox, newBox) => {
                  if (newBox.width < 5 || newBox.height < 5) {
                    return oldBox
                  }
                  return newBox
                }}
                rotateEnabled={true}
                enabledAnchors={['top-left', 'top-right', 'bottom-left', 'bottom-right', 'middle-left', 'middle-right', 'top-center', 'bottom-center']}
              />
            </Layer>
          </Stage>
        </div>
      </div>

      {/* Zoom Controls */}
      <div className="bg-white border-t border-slate-200 px-4 py-2 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="text-sm text-slate-600">Zoom:</span>
          <input
            type="range"
            min="0.5"
            max="2"
            step="0.1"
            value={stageScale}
            onChange={(e) => setStageScale(parseFloat(e.target.value))}
            className="w-32"
          />
          <span className="text-sm text-slate-600 w-12">{Math.round(stageScale * 100)}%</span>
        </div>
        <div className="text-sm text-slate-500">
          {CANVAS_WIDTH} × {CANVAS_HEIGHT}px
        </div>
      </div>
    </div>
  )
}
