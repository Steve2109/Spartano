import { useState } from 'react'
import { Download, Image, FileCode, Star, Check, Loader2, Package } from 'lucide-react'
import { exportToPNG, exportToSVG, exportFaviconPackage } from '../utils/exportUtils'

interface ExportPanelProps {
  selectedId: string | null
}

export default function ExportPanel({ selectedId }: ExportPanelProps) {
  const [isExporting, setIsExporting] = useState(false)
  const [exportStatus, setExportStatus] = useState<string>('')
  const [lastExport, setLastExport] = useState<string | null>(null)

  const handleExportPNG = async () => {
    setIsExporting(true)
    setExportStatus('Generando PNG...')
    try {
      await exportToPNG({ width: 1024, height: 1024, transparent: true })
      setLastExport('PNG')
      setExportStatus('¡PNG descargado!')
    } catch (error) {
      setExportStatus('Error al exportar PNG')
    } finally {
      setTimeout(() => setIsExporting(false), 1000)
    }
  }

  const handleExportSVG = async () => {
    setIsExporting(true)
    setExportStatus('Generando SVG...')
    try {
      await exportToSVG()
      setLastExport('SVG')
      setExportStatus('¡SVG descargado!')
    } catch (error) {
      setExportStatus('Error al exportar SVG')
    } finally {
      setTimeout(() => setIsExporting(false), 1000)
    }
  }

  const handleExportFavicon = async () => {
    setIsExporting(true)
    setExportStatus('Generando pack de favicons...')
    try {
      await exportFaviconPackage()
      setLastExport('Favicon')
      setExportStatus('¡Pack de favicons descargado!')
    } catch (error) {
      setExportStatus('Error al exportar favicons')
    } finally {
      setTimeout(() => setIsExporting(false), 1000)
    }
  }

  return (
    <div className="space-y-4">
      {/* PNG Export */}
      <div className="p-4 bg-slate-50 rounded-xl border border-slate-200">
        <div className="flex items-start gap-3 mb-3">
          <div className="w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center flex-shrink-0">
            <Image className="w-5 h-5 text-orange-600" />
          </div>
          <div>
            <h4 className="font-semibold text-slate-900">Exportar PNG</h4>
            <p className="text-xs text-slate-500 mt-1">
              Alta resolución (1024×1024) con transparencia. Ideal para redes sociales y presentaciones.
            </p>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-2 mb-3">
          <button
            onClick={() => exportToPNG({ width: 512, height: 512, transparent: true })}
            className="px-3 py-2 bg-white border border-slate-300 rounded-lg text-sm hover:bg-slate-50 transition-colors"
          >
            512×512
          </button>
          <button
            onClick={() => exportToPNG({ width: 1024, height: 1024, transparent: true })}
            className="px-3 py-2 bg-white border border-slate-300 rounded-lg text-sm hover:bg-slate-50 transition-colors"
          >
            1024×1024
          </button>
        </div>
        <button
          onClick={handleExportPNG}
          disabled={isExporting}
          className="w-full py-2 bg-orange-600 hover:bg-orange-700 disabled:bg-orange-400 text-white rounded-lg font-medium transition-colors flex items-center justify-center gap-2"
        >
          {isExporting && exportStatus.includes('PNG') ? (
            <Loader2 className="w-4 h-4 animate-spin" />
          ) : (
            <Download className="w-4 h-4" />
          )}
          Descargar PNG
        </button>
      </div>

      {/* SVG Export */}
      <div className="p-4 bg-slate-50 rounded-xl border border-slate-200">
        <div className="flex items-start gap-3 mb-3">
          <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
            <FileCode className="w-5 h-5 text-blue-600" />
          </div>
          <div>
            <h4 className="font-semibold text-slate-900">Exportar SVG</h4>
            <p className="text-xs text-slate-500 mt-1">
              Vector escalable infinitamente. Ideal para impresión profesional y uso en cualquier tamaño.
            </p>
          </div>
        </div>
        <button
          onClick={handleExportSVG}
          disabled={isExporting}
          className="w-full py-2 bg-blue-600 hover:bg-blue-700 disabled:bg-blue-400 text-white rounded-lg font-medium transition-colors flex items-center justify-center gap-2"
        >
          {isExporting && exportStatus.includes('SVG') ? (
            <Loader2 className="w-4 h-4 animate-spin" />
          ) : (
            <Download className="w-4 h-4" />
          )}
          Descargar SVG
        </button>
      </div>

      {/* Favicon Package */}
      <div className="p-4 bg-slate-50 rounded-xl border border-slate-200">
        <div className="flex items-start gap-3 mb-3">
          <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center flex-shrink-0">
            <Package className="w-5 h-5 text-green-600" />
          </div>
          <div>
            <h4 className="font-semibold text-slate-900">Pack Favicon</h4>
            <p className="text-xs text-slate-500 mt-1">
              Pack completo para web: favicon.ico, apple-touch-icon, manifest.json y más.
            </p>
          </div>
        </div>
        <div className="space-y-2 mb-3">
          <div className="flex items-center gap-2 text-xs text-slate-600">
            <Check className="w-3 h-3 text-green-500" />
            <span>favicon.ico (16×16, 32×32)</span>
          </div>
          <div className="flex items-center gap-2 text-xs text-slate-600">
            <Check className="w-3 h-3 text-green-500" />
            <span>favicon.svg (vector)</span>
          </div>
          <div className="flex items-center gap-2 text-xs text-slate-600">
            <Check className="w-3 h-3 text-green-500" />
            <span>apple-touch-icon.png (180×180)</span>
          </div>
          <div className="flex items-center gap-2 text-xs text-slate-600">
            <Check className="w-3 h-3 text-green-500" />
            <span>android-chrome (192×192, 512×512)</span>
          </div>
          <div className="flex items-center gap-2 text-xs text-slate-600">
            <Check className="w-3 h-3 text-green-500" />
            <span>manifest.json para PWA</span>
          </div>
        </div>
        <button
          onClick={handleExportFavicon}
          disabled={isExporting}
          className="w-full py-2 bg-green-600 hover:bg-green-700 disabled:bg-green-400 text-white rounded-lg font-medium transition-colors flex items-center justify-center gap-2"
        >
          {isExporting && exportStatus.includes('favicon') ? (
            <Loader2 className="w-4 h-4 animate-spin" />
          ) : (
            <Download className="w-4 h-4" />
          )}
          Descargar Pack
        </button>
      </div>

      {/* Status Message */}
      {exportStatus && (
        <div className={`p-3 rounded-lg text-sm text-center ${
          exportStatus.includes('Error') 
            ? 'bg-red-50 text-red-700' 
            : exportStatus.includes('descargado')
            ? 'bg-green-50 text-green-700'
            : 'bg-blue-50 text-blue-700'
        }`}>
          {exportStatus}
        </div>
      )}

      {/* Tips */}
      <div className="p-4 bg-gradient-to-br from-purple-50 to-pink-50 rounded-xl border border-purple-100">
        <div className="flex items-center gap-2 mb-2">
          <Star className="w-4 h-4 text-purple-600" />
          <span className="text-sm font-medium text-purple-900">Consejo Pro</span>
        </div>
        <p className="text-xs text-purple-700">
          Usa <strong>SVG</strong> para impresión profesional y escalado infinito. 
          Usa <strong>PNG</strong> para web y redes sociales. 
          El <strong>pack favicon</strong> incluye todo lo necesario para tu sitio web.
        </p>
      </div>
    </div>
  )
}
