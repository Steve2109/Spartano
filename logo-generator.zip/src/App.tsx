import { useState } from 'react'
import LogoEditor from './components/LogoEditor'
import Toolbar from './components/Toolbar'
import ExportPanel from './components/ExportPanel'
import { Layers, Download, Palette, Type, Shapes, Settings } from 'lucide-react'

export type TabType = 'templates' | 'text' | 'shapes' | 'elements' | 'export'

function App() {
  const [activeTab, setActiveTab] = useState<TabType>('templates')
  const [selectedId, setSelectedId] = useState<string | null>(null)

  const tabs = [
    { id: 'templates' as TabType, icon: Palette, label: 'Plantillas' },
    { id: 'text' as TabType, icon: Type, label: 'Texto' },
    { id: 'shapes' as TabType, icon: Shapes, label: 'Formas' },
    { id: 'elements' as TabType, icon: Layers, label: 'Elementos' },
    { id: 'export' as TabType, icon: Download, label: 'Exportar' },
  ]

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-xl flex items-center justify-center">
            <Palette className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-slate-900">LogoGen Pro</h1>
            <p className="text-xs text-slate-500">Generador de Logotipos Profesional</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={() => setActiveTab('export')}
            className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium transition-colors"
          >
            <Download className="w-4 h-4" />
            Exportar Logo
          </button>
        </div>
      </header>

      {/* Main Content */}
      <div className="flex-1 flex overflow-hidden">
        {/* Sidebar */}
        <aside className="w-80 bg-white border-r border-slate-200 flex flex-col">
          {/* Tab Navigation */}
          <div className="flex border-b border-slate-200 overflow-x-auto">
            {tabs.map((tab) => {
              const Icon = tab.icon
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex flex-col items-center gap-1 px-4 py-3 min-w-[64px] transition-colors ${
                    activeTab === tab.id
                      ? 'bg-blue-50 text-blue-600 border-b-2 border-blue-600'
                      : 'text-slate-500 hover:text-slate-700 hover:bg-slate-50'
                  }`}
                >
                  <Icon className="w-5 h-5" />
                  <span className="text-xs font-medium whitespace-nowrap">{tab.label}</span>
                </button>
              )
            })}
          </div>

          {/* Tab Content */}
          <div className="flex-1 overflow-y-auto p-4">
            <Toolbar 
              activeTab={activeTab} 
              selectedId={selectedId}
              onSelectElement={setSelectedId}
            />
          </div>
        </aside>

        {/* Canvas Area */}
        <main className="flex-1 bg-slate-100 flex flex-col">
          <LogoEditor 
            selectedId={selectedId}
            onSelectElement={setSelectedId}
          />
        </main>

        {/* Properties Panel */}
        <aside className="w-72 bg-white border-l border-slate-200 p-4 overflow-y-auto">
          <h3 className="text-sm font-semibold text-slate-900 mb-4 flex items-center gap-2">
            <Settings className="w-4 h-4" />
            Propiedades
          </h3>
          <ExportPanel selectedId={selectedId} />
        </aside>
      </div>
    </div>
  )
}

export default App
