import { saveAs } from 'file-saver'
import JSZip from 'jszip'

interface ExportOptions {
  width: number
  height: number
  transparent?: boolean
}

// Get the Konva stage from the DOM
const getStage = () => {
  const canvas = document.querySelector('canvas')
  if (!canvas) throw new Error('Canvas not found')
  return canvas
}

// Export to PNG
export const exportToPNG = async (options: ExportOptions): Promise<void> => {
  const canvas = getStage()
  
  // Create a new canvas with desired dimensions
  const exportCanvas = document.createElement('canvas')
  exportCanvas.width = options.width
  exportCanvas.height = options.height
  const ctx = exportCanvas.getContext('2d')
  
  if (!ctx) throw new Error('Could not get canvas context')
  
  // Fill with transparent or white background
  if (options.transparent) {
    ctx.clearRect(0, 0, options.width, options.height)
  } else {
    ctx.fillStyle = '#ffffff'
    ctx.fillRect(0, 0, options.width, options.height)
  }
  
  // Draw original canvas scaled to new size
  ctx.drawImage(
    canvas,
    0, 0, canvas.width, canvas.height,
    0, 0, options.width, options.height
  )
  
  // Convert to blob and download
  const blob = await new Promise<Blob>((resolve) => {
    exportCanvas.toBlob((b) => resolve(b!), 'image/png')
  })
  
  saveAs(blob, `logo-${options.width}x${options.height}.png`)
}

// Export to SVG
export const exportToSVG = async (): Promise<void> => {
  // Get all elements from the Konva stage
  const stage = document.querySelector('[data-konva-stage]')
  if (!stage) {
    // Fallback: create SVG from canvas
    const canvas = getStage()
    const svgContent = generateSVGFromCanvas(canvas)
    const blob = new Blob([svgContent], { type: 'image/svg+xml' })
    saveAs(blob, 'logo.svg')
    return
  }
  
  // Extract SVG content from the layer
  const svgContent = generateSVGFromElements()
  const blob = new Blob([svgContent], { type: 'image/svg+xml' })
  saveAs(blob, 'logo.svg')
}

// Generate SVG from canvas (fallback)
const generateSVGFromCanvas = (canvas: HTMLCanvasElement): string => {
  const dataUrl = canvas.toDataURL('image/png')
  const width = canvas.width
  const height = canvas.height
  
  return `<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="${width}" height="${height}" viewBox="0 0 ${width} ${height}">
  <image width="${width}" height="${height}" xlink:href="${dataUrl}"/>
</svg>`
}

// Generate SVG from elements
const generateSVGFromElements = (): string => {
  // This would ideally extract the actual vector data from Konva
  // For now, we'll create a basic SVG structure
  const width = 600
  const height = 600
  
  // Get all visible elements and convert to SVG
  const elements = document.querySelectorAll('.konva-shape')
  let svgContent = ''
  
  elements.forEach((el) => {
    const shape = el as HTMLElement
    const type = shape.getAttribute('data-shape-type')
    
    if (type === 'rect') {
      const x = parseFloat(shape.style.left || '0')
      const y = parseFloat(shape.style.top || '0')
      const width = parseFloat(shape.style.width || '100')
      const height = parseFloat(shape.style.height || '100')
      const fill = shape.style.backgroundColor || '#3b82f6'
      
      svgContent += `  <rect x="${x}" y="${y}" width="${width}" height="${height}" fill="${fill}"/>\n`
    }
  })
  
  return `<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}" viewBox="0 0 ${width} ${height}">
${svgContent}</svg>`
}

// Export favicon package
export const exportFaviconPackage = async (): Promise<void> => {
  const zip = new JSZip()
  const canvas = getStage()
  
  // Generate different sizes
  const sizes = [16, 32, 180, 192, 512]
  
  for (const size of sizes) {
    const exportCanvas = document.createElement('canvas')
    exportCanvas.width = size
    exportCanvas.height = size
    const ctx = exportCanvas.getContext('2d')
    
    if (!ctx) continue
    
    ctx.clearRect(0, 0, size, size)
    ctx.drawImage(canvas, 0, 0, canvas.width, canvas.height, 0, 0, size, size)
    
    const blob = await new Promise<Blob>((resolve) => {
      exportCanvas.toBlob((b) => resolve(b!), 'image/png')
    })
    
    let filename = ''
    if (size === 16) filename = 'favicon-16x16.png'
    else if (size === 32) filename = 'favicon-32x32.png'
    else if (size === 180) filename = 'apple-touch-icon.png'
    else if (size === 192) filename = 'android-chrome-192x192.png'
    else if (size === 512) filename = 'android-chrome-512x512.png'
    
    zip.file(filename, blob)
  }
  
  // Generate ICO file (simplified - just use 32x32 PNG)
  const icoCanvas = document.createElement('canvas')
  icoCanvas.width = 32
  icoCanvas.height = 32
  const icoCtx = icoCanvas.getContext('2d')
  if (icoCtx) {
    icoCtx.drawImage(canvas, 0, 0, canvas.width, canvas.height, 0, 0, 32, 32)
    const icoBlob = await new Promise<Blob>((resolve) => {
      icoCanvas.toBlob((b) => resolve(b!), 'image/png')
    })
    zip.file('favicon.ico', icoBlob)
  }
  
  // Generate SVG favicon
  const svgContent = generateSVGFromCanvas(canvas)
  zip.file('favicon.svg', svgContent)
  
  // Generate manifest.json
  const manifest = {
    name: 'Logo',
    short_name: 'Logo',
    icons: [
      {
        src: '/android-chrome-192x192.png',
        sizes: '192x192',
        type: 'image/png'
      },
      {
        src: '/android-chrome-512x512.png',
        sizes: '512x512',
        type: 'image/png'
      }
    ],
    theme_color: '#ffffff',
    background_color: '#ffffff',
    display: 'standalone'
  }
  zip.file('manifest.json', JSON.stringify(manifest, null, 2))
  
  // Generate HTML snippet
  const htmlSnippet = `<!-- Favicon -->
<link rel="icon" type="image/x-icon" href="/favicon.ico">
<link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png">
<link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png">
<link rel="icon" type="image/svg+xml" href="/favicon.svg">

<!-- Apple Touch Icon -->
<link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png">

<!-- Android/Chrome -->
<link rel="manifest" href="/manifest.json">
<meta name="theme-color" content="#ffffff">
`
  zip.file('favicon-html-snippet.html', htmlSnippet)
  
  // Generate and download zip
  const content = await zip.generateAsync({ type: 'blob' })
  saveAs(content, 'favicon-package.zip')
}

// Export all formats at once
export const exportAllFormats = async (): Promise<void> => {
  const zip = new JSZip()
  const canvas = getStage()
  
  // PNG 1024x1024
  const pngCanvas = document.createElement('canvas')
  pngCanvas.width = 1024
  pngCanvas.height = 1024
  const pngCtx = pngCanvas.getContext('2d')
  if (pngCtx) {
    pngCtx.clearRect(0, 0, 1024, 1024)
    pngCtx.drawImage(canvas, 0, 0, canvas.width, canvas.height, 0, 0, 1024, 1024)
    const pngBlob = await new Promise<Blob>((resolve) => {
      pngCanvas.toBlob((b) => resolve(b!), 'image/png')
    })
    zip.file('logo-1024x1024.png', pngBlob)
  }
  
  // SVG
  const svgContent = generateSVGFromCanvas(canvas)
  zip.file('logo.svg', svgContent)
  
  // Download
  const content = await zip.generateAsync({ type: 'blob' })
  saveAs(content, 'logo-package.zip')
}
