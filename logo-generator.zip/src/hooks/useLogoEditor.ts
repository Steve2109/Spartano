import { useState, useCallback } from 'react'

export type ShapeType = 'rect' | 'circle' | 'text' | 'path' | 'line'

export interface LogoElement {
  id: string
  type: ShapeType
  x: number
  y: number
  width: number
  height: number
  fill?: string
  stroke?: string
  strokeWidth?: number
  rotation?: number
  // Text specific
  text?: string
  fontSize?: number
  fontFamily?: string
  align?: 'left' | 'center' | 'right'
  // Path specific
  data?: string
  // Line specific
  points?: number[]
  // Rect specific
  cornerRadius?: number
}

const generateId = () => Math.random().toString(36).substr(2, 9)

export default function useLogoEditor() {
  const [elements, setElements] = useState<LogoElement[]>([])
  const [backgroundColor, setBackgroundColor] = useState('#ffffff')

  const addElement = useCallback((type: ShapeType, config?: Partial<LogoElement>) => {
    const id = generateId()
    const baseElement: LogoElement = {
      id,
      type,
      x: 250,
      y: 250,
      width: 100,
      height: 100,
      fill: '#3b82f6',
      stroke: '#1e40af',
      strokeWidth: 2,
      rotation: 0,
      ...config,
    }

    switch (type) {
      case 'text':
        return setElements((prev) => [
          ...prev,
          {
            ...baseElement,
            text: 'Tu Texto',
            fontSize: 32,
            fontFamily: 'Montserrat',
            fill: '#1e293b',
            stroke: 'transparent',
            strokeWidth: 0,
            width: 200,
            height: 50,
            align: 'center',
          },
        ])
      case 'circle':
        return setElements((prev) => [
          ...prev,
          {
            ...baseElement,
            width: 100,
            height: 100,
          },
        ])
      case 'rect':
        return setElements((prev) => [
          ...prev,
          {
            ...baseElement,
            width: 120,
            height: 80,
            cornerRadius: 8,
          },
        ])
      case 'path':
        return setElements((prev) => [
          ...prev,
          {
            ...baseElement,
            data: 'M10,30 Q50,5 90,30 T170,30',
            fill: 'transparent',
            width: 150,
            height: 50,
            strokeWidth: 4,
          },
        ])
      case 'line':
        return setElements((prev) => [
          ...prev,
          {
            ...baseElement,
            points: [0, 0, 100, 0],
            fill: 'transparent',
            width: 100,
            height: 2,
            strokeWidth: 4,
          },
        ])
      default:
        return setElements((prev) => [...prev, baseElement])
    }
  }, [])

  const updateElement = useCallback((id: string, updates: Partial<LogoElement>) => {
    setElements((prev) =>
      prev.map((el) => (el.id === id ? { ...el, ...updates } : el))
    )
  }, [])

  const deleteElement = useCallback((id: string) => {
    setElements((prev) => prev.filter((el) => el.id !== id))
  }, [])

  const bringToFront = useCallback((id: string) => {
    setElements((prev) => {
      const element = prev.find((el) => el.id === id)
      if (!element) return prev
      return [...prev.filter((el) => el.id !== id), element]
    })
  }, [])

  const sendToBack = useCallback((id: string) => {
    setElements((prev) => {
      const element = prev.find((el) => el.id === id)
      if (!element) return prev
      return [element, ...prev.filter((el) => el.id !== id)]
    })
  }, [])

  const clearCanvas = useCallback(() => {
    setElements([])
  }, [])

  const loadTemplate = useCallback((template: LogoElement[]) => {
    setElements(template)
  }, [])

  return {
    elements,
    backgroundColor,
    setBackgroundColor,
    addElement,
    updateElement,
    deleteElement,
    bringToFront,
    sendToBack,
    clearCanvas,
    loadTemplate,
  }
}
