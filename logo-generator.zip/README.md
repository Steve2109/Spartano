# LogoGen Pro - Generador de Logotipos

Aplicación web moderna para crear logotipos profesionales con exportación en PNG, SVG y pack completo de favicons.

## Características

- **Editor Visual Interactivo**: Canvas basado en Konva.js con drag & drop
- **Elementos Vectoriales**: Formas, texto, paths editables
- **Plantillas Predefinidas**: 4 estilos listos para usar
- **Exportación Profesional**:
  - PNG (512×512, 1024×1024) con transparencia
  - SVG vectorial escalable
  - Pack completo de favicons (ICO, PNG, SVG, manifest.json)
- **Interfaz Moderna**: Construida con React + TypeScript + TailwindCSS

## Stack Tecnológico

```
Frontend: React 18 + TypeScript + Vite
Canvas: Konva.js (renderizado 2D de alto rendimiento)
Estilos: TailwindCSS
Exportación: HTML5 Canvas API + JSZip
Iconos: Lucide React
```

## Instalación Local

```bash
# 1. Clonar o descargar el proyecto
cd logo-generator

# 2. Instalar dependencias
npm install

# 3. Iniciar servidor de desarrollo
npm run dev

# 4. Abrir en navegador
# http://localhost:3000
```

## Scripts Disponibles

| Comando | Descripción |
|---------|-------------|
| `npm run dev` | Servidor de desarrollo con hot reload |
| `npm run build` | Construcción para producción |
| `npm run preview` | Vista previa de producción local |

## Estructura del Proyecto

```
logo-generator/
├── src/
│   ├── components/
│   │   ├── LogoEditor.tsx      # Canvas principal Konva
│   │   ├── Toolbar.tsx         # Panel lateral de herramientas
│   │   └── ExportPanel.tsx     # Opciones de exportación
│   ├── hooks/
│   │   └── useLogoEditor.ts    # Lógica de estado del editor
│   ├── utils/
│   │   └── exportUtils.ts      # Funciones de exportación
│   ├── App.tsx                 # Componente raíz
│   ├── main.tsx                # Punto de entrada
│   └── index.css               # Estilos globales
├── dist/                       # Build de producción
├── package.json
├── tsconfig.json
├── vite.config.ts
└── README.md
```

## Guías de Despliegue

Consulta las guías específicas según tu infraestructura:

- [Debian 13 + Nginx](./deployments-docs/debian13-nginx/README.md)
- [Debian 13 + Apache](./deployments-docs/debian13-apache/README.md)
- [Docker + Nginx + SSL](./deployments-docs/docker-nginx-ssl-cdn/README.md)
- [Docker Compose Full-Auto](./deployments-docs/full-auto-docker-compose/README.md)

**Nota**: La aplicación está configurada para ejecutarse en el puerto **32299** por defecto en todos los despliegues.

## Exportación de Logotipos

### PNG (Raster)
- Resoluciones: 512×512, 1024×1024
- Canal alpha (transparencia)
- Ideal para: Redes sociales, presentaciones, web

### SVG (Vector)
- Escalable infinitamente sin pérdida de calidad
- Editable en software vectorial (Illustrator, Figma, Inkscape)
- Ideal para: Impresión profesional, merchandising

### Pack Favicon
Incluye:
- `favicon.ico` (16×16, 32×32)
- `favicon.svg` (vector)
- `favicon-16x16.png`
- `favicon-32x32.png`
- `apple-touch-icon.png` (180×180)
- `android-chrome-192x192.png`
- `android-chrome-512x512.png`
- `manifest.json` (para PWA)
- `favicon-html-snippet.html` (código para copiar)

## Licencia

MIT License - Libre para uso personal y comercial.

---

Desarrollado con React + Konva.js + TailwindCSS
